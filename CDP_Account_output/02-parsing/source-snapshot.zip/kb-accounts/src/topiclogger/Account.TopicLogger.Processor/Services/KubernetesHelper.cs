﻿namespace Account.TopicLogger.Processor.Services;

/// <summary>
///     Provides helper methods for interacting with Kubernetes.
/// </summary>
public class KubernetesHelper : IKubernetesHelper
{
    private const string NamespaceFilePath =
        "/var/run/secrets/kubernetes.io/serviceaccount/namespace";

    private readonly Lazy<string> _cachedNamespace;

    /// <summary>
    ///     Initializes a new instance of the <see cref="KubernetesHelper" /> class.
    /// </summary>
    /// <param name="fileHelper">The file helper to use for file operations.</param>
    public KubernetesHelper(IFileHelper fileHelper)
    {
        _cachedNamespace = new Lazy<string>(() => fileHelper.Exists(NamespaceFilePath)
            ? fileHelper.ReadAllText(NamespaceFilePath)
            : "default");
    }

    /// <summary>
    ///     Gets the current namespace.
    /// </summary>
    /// <returns>The current namespace.</returns>
    public string GetCurrentNamespace()
    {
        return _cachedNamespace.Value;
    }
}