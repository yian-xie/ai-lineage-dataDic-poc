# Account Domain - Origination Subdomain


Provides account create services for origination purposes.

See [Account Create Design](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/4094034211/Account+Create) for an overview of how the Account Create/Open process works within a Product Application process. 

Product Applications implemented are tracked on the [Known Product Applications](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/4101374575/Account+Create+-+Known+Product+Applications) register


## Account Origination Subdomain Container View
![Account Origination Subdomain Container View](./container/account.origination.svg)

## Account Origination State View
![Account Origination State View](./state/account.origination.state.svg)





## Services

### Account.Customer.Processor
Account Origination has a dependency on Customer subdomain. 

Account.Customer.Process provides sync of key customer information into this domain and TMV.

View [Implementation Details ](../../Account.Customer.Processor/README.md)

### Account.Origination.Processor
Consumes product application events and logs account create jobs.

Account Create/Opening is not performed in this processor. All Account Create/Openings are handled in Account.Origination.Job

View [Implementation Details ](.././Account.Origination.Processor/README.md)

### Account.Origination.Job
Handles Account Create and Openings. Create can be immediate or scheduled.

Consumes `paymentAccountNumber` events from `payment.account_number.v1.event` and associates Account Numbers to Accounts.



TODO: View [Implementation Details](../../Account.Origination.Job/README.md) 

## Origination Sequences

### High level sequence
With scheduled account creation

![High Level Sequence](./sequence/account.origination.high-level.svg)

### Account create and account number assignment

![Account create and account number assignment](./sequence/account.origination.account-number.svg)


### Account status change 
TBD

### Account closure
TBD

