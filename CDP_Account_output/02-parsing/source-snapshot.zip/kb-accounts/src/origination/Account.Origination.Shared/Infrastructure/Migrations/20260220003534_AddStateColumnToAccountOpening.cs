﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddStateColumnToAccountOpening : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "state",
                schema: "origination",
                table: "account_opening",
                type: "varchar(50)",
                nullable: true);

            migrationBuilder.Sql(@"
                UPDATE origination.account_opening
                SET state = CASE
                    WHEN failed IS NOT NULL THEN 'Failed'
                    WHEN opened IS NOT NULL THEN 'Opened'
                    WHEN created IS NOT NULL THEN 'Created'
                    ELSE 'Initial'
                END
                WHERE state IS NULL;
            ");

            migrationBuilder.AlterColumn<string>(
                name: "state",
                schema: "origination",
                table: "account_opening",
                type: "varchar(50)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(50)",
                oldNullable: true);
            migrationBuilder.CreateIndex(
                name: "ix_account_opening_state",
                schema: "origination",
                table: "account_opening",
                columns: new[] { "state", "retry_count", "last_retry" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "ix_account_opening_state",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "state",
                schema: "origination",
                table: "account_opening");
        }
    }
}