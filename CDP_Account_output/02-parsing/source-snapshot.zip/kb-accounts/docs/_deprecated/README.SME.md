# Account Domain

Maintains the customer’s bank accounts (establishment, details and balances). The domain currently provides required information to be displayed in the Customer Portal web app.

It also maintains core banking customer and account create and update functionality.

Thought Machine Vault (tmv) is the core banking system this domain currently communicates with.

## Service Register

### Account.Api

-   Local HTTP Port: 50000

### Tmv.Account.Read.Processor

-   Local HTTP Port: 50001
-   subscribes to the events raised by Thought Machine and populate the local data store with customer, account and transaction details


## Start the local environment only for Account domain

-   To run local environment execute following commands:

```bash
./code/account/scripts/run-docker-compose.sh
```

By default every script will execute `docker compose up -d --build` command, but you can provide required `docker compose` command as a script argument, for example:

-   To run the docker compose with different arguments, you can override it as follow:

```bash
./code/account/scripts/run-docker-compose.sh "build --parallel"
./code/account/scripts/run-docker-compose.sh "up --build"
./code/account/scripts/run-docker-compose.sh up
./code/account/scripts/run-docker-compose.sh "up -d"
./code/account/scripts/run-docker-compose.sh restart
./code/account/scripts/run-docker-compose.sh down
```

## Useful commands

### View container status

```bash
./code/account/scripts/run-docker-compose.sh "ps"
```

### View logs

```bash
./code/account/scripts/run-docker-compose.sh "logs account-api"
./code/account/scripts/run-docker-compose.sh "logs tmv-account-read-processor"
```

## DB Migration

[Please refer to Shared project readme file.](./Account.Shared/readme.md)

## Run test locally

-   [Run Account.Shared Unit Tests](./Account.Shared.UnitTests/readme.md)
-   [Run Account.Api Unit Tests.](./Account.Api.UnitTests/readme.md)
-   [Run Account.Api Integration Tests.](./Account.Api.IntegrationTests/readme.md)
-   [Run Tmv.Account.Read.Processor Unit Tests.](./Tmv.Account.Read.Processor.UnitTests/readme.md)

