﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

using Account.Shared.Constants;

using Kb.Api.Infrastructure.Constants;

using Microsoft.IdentityModel.Tokens;

namespace Account.Shared.Testing.Integration;

public static class TokenHelper
{
    public static string GenerateStaffToken()
    {
        var securityKey =
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Guid.NewGuid().ToString()));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            Guid.NewGuid().ToString(),
            Guid.NewGuid().ToString(),
            [
                new Claim(InfrastructureConstants.ClaimTypes.Sub, Guid.NewGuid().ToString()),
                new Claim(InfrastructureConstants.ClaimTypes.PreferredUsername, "testUser"),
                new Claim(JwtClaimTypes.TenantId, "test-tid"),
                new Claim(JwtClaimTypes.AuthorizedParty, "test-azp")
            ],
            expires: DateTime.Now.AddHours(1),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public static string GenerateCustomerIntrospectionToken(int accessNumber)
    {
        var securityKey =
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Guid.NewGuid().ToString()));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            Guid.NewGuid().ToString(),
            Guid.NewGuid().ToString(),
            [
                new Claim(
                    InfrastructureConstants.ClaimTypes
                        .LegacyKbLoginName, accessNumber.ToString()),
                new Claim(
                    InfrastructureConstants.ClaimTypes
                        .ClientId, Guid.NewGuid().ToString()),
                new Claim(
                    InfrastructureConstants.ClaimTypes
                        .AuthenticationLevel, Guid.NewGuid().ToString()),
                new Claim(InfrastructureConstants.ClaimTypes.Sub, Guid.NewGuid().ToString())
            ],
            expires: DateTime.Now.AddHours(1),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public static string GenerateCustomerToken()
    {
        return Guid.NewGuid().ToString();
    }
}