﻿using Account.Origination.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.Origination.Shared.Infrastructure.EntityConfigurations;

public class
    AccountOpeningEntityTypeConfiguration : AccountBaseEntityTypeConfiguration<AccountOpening,
    OriginationDbContext>
{
    protected override string TableName => "account_opening";

    protected override void ConfigureTable(EntityTypeBuilder<AccountOpening> builder)
    {
        builder.HasKey(x => x.AccountId);

        var stateProperty = builder.Property(x => x.State)
            .HasConversion<string>()
            .IsRequired();

        stateProperty.HasColumnType("varchar(50)");

        builder.HasIndex(x => x.ProductCode);
        builder.HasIndex(x => new
        {
            x.State,
            x.RetryCount,
            x.LastRetry
        })
            .HasDatabaseName("ix_account_opening_state");
    }
}