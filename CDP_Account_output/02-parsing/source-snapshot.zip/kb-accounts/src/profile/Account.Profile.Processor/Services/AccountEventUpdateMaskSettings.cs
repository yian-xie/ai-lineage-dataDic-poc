﻿#nullable enable

namespace Account.Profile.Processor.Services;

/// <summary>
///     Static class to store AccountEvent UpdateMask.
/// </summary>
public static class AccountEventUpdateMaskSettings
{
    /// <summary>
    ///     Map to AccountEvent status.
    /// </summary>
    public const string Status = "status";

    /// <summary>
    ///     Map to AccountEvent stakeholder_ids.
    /// </summary>
    public const string PartyIds = "stakeholder_ids";

    /// <summary>
    ///     Map to AccountEvent source_open_timestamp.
    /// </summary>
    public const string Opened = "source_open_timestamp";

    /// <summary>
    ///     Map to AccountEvent source_close_timestamp.
    /// </summary>
    public const string Closed = "source_close_timestamp";

    /// <summary>
    ///     Map to AccountEvent details.
    /// </summary>
    public const string Details = "details";
}