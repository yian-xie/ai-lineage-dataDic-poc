﻿#nullable enable

using Account.Origination.Shared.Entities;

namespace Account.Origination.Shared.Repositories;

/// <summary>
///     The <see cref="AccountOpening" /> repository.
/// </summary>
public interface IAccountOpeningRepository
{
    /// <summary>
    ///     Insert the account.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="Account.Origination.Shared.Entities.AccountOpening" />
    /// </param>
    /// <returns></returns>
    void Add(AccountOpening accountOpening);

    /// <summary>
    ///     Update the account.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="Account.Origination.Shared.Entities.AccountOpening" />
    /// </param>
    /// <returns></returns>
    void Update(AccountOpening accountOpening);

    /// <summary>
    ///     Get the AccountOpening job by event id.
    /// </summary>
    /// <param name="eventId">Event id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountOpening" />
    /// </returns>
    Task<AccountOpening?> GetJobAsync(Guid eventId, CancellationToken cancellationToken);
}