﻿namespace Account.Origination.Job.Infrastructure.Resilience;

public interface IResilienceExceptionStrategy
{
    bool ShouldRetry(Exception ex);
}