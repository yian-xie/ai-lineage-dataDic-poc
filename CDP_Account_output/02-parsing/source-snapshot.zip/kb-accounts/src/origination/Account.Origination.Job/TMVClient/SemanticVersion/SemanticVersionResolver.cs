﻿using Account.Origination.Job.Configurations;

using Microsoft.Extensions.Caching.Memory;

namespace Account.Origination.Job.TMVClient.SemanticVersion;

public class SemanticVersionResolver : ISemanticVersionResolver
{
    private readonly IMemoryCache _cache;
    private readonly IProductVersionIterator _productVersionIterator;
    private readonly TmvSemanticOptionCollection _semanticOptions;

    public SemanticVersionResolver(
        IMemoryCache cache,
        IProductVersionIterator productVersionIterator,
        TmvSemanticOptionCollection tmvSemanticOptionCollection)
    {
        _cache = cache;
        _productVersionIterator = productVersionIterator;
        _semanticOptions = tmvSemanticOptionCollection;
    }
    public async Task<string> ResolveAsync(string productKey, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(productKey))
        {
            throw new ArgumentNullException(nameof(productKey));
        }

        var matchedOption = _semanticOptions.Options.Single(opt =>
            string.Equals(productKey, opt.Key, StringComparison.InvariantCultureIgnoreCase));

        var cacheKey = $"{productKey}-{matchedOption.TmvProductCode}-{matchedOption.Version}";

        return await _cache.GetOrCreateAsync(cacheKey, async _ =>
        {
            _.Priority = CacheItemPriority.NeverRemove;

            return await _productVersionIterator.ResolveAsync(matchedOption.TmvProductCode,
                matchedOption.Version, cancellationToken);
        });
    }
}