﻿using Account.Domain.Directory.Service.WebApiClient;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Origination.Job.Services;

public interface ITmvCustomerAction
{
    /// <summary>
    ///     Get TMV Customer.
    /// </summary>
    /// <param name="id">Customer Id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1customersCustomer" />
    /// </returns>
    Task<V1customersCustomer?> GetAsync(string id, CancellationToken cancellationToken);

    /// <summary>
    ///     Get TMV Customer.
    /// </summary>
    /// <param name="id">Customer Id</param>
    /// <param name="correlationId">Correlation Id for logging and tracking purposes</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1customersCustomer" />
    /// </returns>
    Task<V1customersCustomer?> GetAsync(string id, string correlationId, CancellationToken cancellationToken);

    /// <summary>
    ///     Create TMV Customer.
    /// </summary>
    /// <param name="id">Customer Id</param>
    /// <param name="party">Party profile used to populate customer details and additional_details</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1customersCustomer" />
    /// </returns>
    Task<V1customersCustomer> CreateAsync(string id, PartyResultDto? party, CancellationToken cancellationToken);

    /// <summary>
    ///     Create TMV Customer.
    /// </summary>
    /// <param name="id">Customer Id</param>
    /// <param name="correlationId">Correlation Id for logging and tracking purposes</param>
    /// <param name="party">Party profile used to populate customer details and additional_details</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1customersCustomer" />
    /// </returns>
    Task<V1customersCustomer> CreateAsync(string id, string correlationId, PartyResultDto? party, CancellationToken cancellationToken);
}