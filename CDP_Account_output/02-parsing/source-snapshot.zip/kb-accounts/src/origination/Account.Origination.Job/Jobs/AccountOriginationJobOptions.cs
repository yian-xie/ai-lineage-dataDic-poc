﻿namespace Account.Origination.Job.Jobs;

/// <summary>
///     The AccountOriginationJobOptions settings defined in appsettings.json.
/// </summary>
public class AccountOriginationJobOptions
{
    /// <summary>
    ///     The auto repository polling time seconds
    /// </summary>
    public int PollingTimeSeconds { get; set; }

    /// <summary>
    ///     Retry interval seconds.
    /// </summary>
    public int RetryIntervalSeconds { get; set; }
}