﻿using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Origination.Job.Extension;

public static class TmvCoreApiProductsClientExtensions
{
    public static string GetFullVersion(
        this V1productsProductVersion v1ProductsProductVersion)
    {
        var version =
            $"{v1ProductsProductVersion.Display_version_number.Major}.{v1ProductsProductVersion.Display_version_number.Minor}.{v1ProductsProductVersion.Display_version_number.Patch}";

        if (!string.IsNullOrWhiteSpace(v1ProductsProductVersion.Display_version_number.Label))
        {
            version = $"{version}.{v1ProductsProductVersion.Display_version_number.Label}";
        }
        return version;
    }
}