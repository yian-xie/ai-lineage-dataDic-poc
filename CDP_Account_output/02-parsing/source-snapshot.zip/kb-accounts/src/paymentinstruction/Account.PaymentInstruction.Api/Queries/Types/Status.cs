﻿namespace Account.PaymentInstruction.Api.Queries.Types;

public enum Status
{
    Created,
    Submitted,
    Rejected,
    Accepted,
    Error,
    Posted
}