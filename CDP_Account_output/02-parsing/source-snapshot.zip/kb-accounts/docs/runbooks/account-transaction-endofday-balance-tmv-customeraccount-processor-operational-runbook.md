## Service Summary

| Field | Details |
|---|---|
| Business purpose | Processes TMV `END_OF_DAY` contract notifications, retrieves customer balances from the transaction datastore, and publishes end-of-day customer-account balance events to ESP. |
| Runtime | .NET 10 ASP.NET Core executable in a Linux container; HTTP port 8080. Kafka event processor. |
| Source | [Customer-account processor source](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Account.Transaction.EndOfDay.Balance.Tmv.CustomerAccount.Processor) |
| Pipeline | [Transaction pipeline](https://github.com/Kiwibank/kb-accounts/blob/main/src/transaction/.pipelineconfig/pipeline.yaml), using [component deployment values](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Deploy/Account.Transaction.EndOfDay.Balance.Tmv.CustomerAccount.Processor) |
| Last reviewed | 2026-10-01 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. A reliable Kafka subscriber consumes environment-prefixed TMV `vault.core_api.v1.contract.notification.event` records and skips notifications whose type is not `END_OF_DAY`.
2. For each valid notification, the processor queries `transaction.account_balance` at the effective datetime and builds supported `InterimBooked` and `InterimAvailable` balances, defaulting missing supported values to zero NZD.
3. The processor publishes `account.balance.end-of-day.customer-account.v1.event` to environment-prefixed ESP Kafka and exports processing telemetry; failures redeliver for up to six hours before DLQ.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Inbound Kafka | TMV Kafka | Supplies contract notifications. | `TmvKafka__*`; topic `vault.core_api.v1.contract.notification.event`. |
| Persistence | PostgreSQL transaction datastore | Supplies balances from `transaction.account_balance`. | `ConnectionStrings__DefaultConnection`; shared transaction DbContext/repository. |
| Outbound Kafka | ESP Kafka and Schema Registry | Publishes customer-account end-of-day balance events. | `Kafka__*`, `Kafka__SchemaRegistry__*`; topic `account.balance.end-of-day.customer-account.v1.event`. |
| Observability | Dynatrace and SumoLogic | Receives metrics, traces, and terminal failure logs. | `MetricsOptions__*`, `TracingOptions__*`, `SumoLogicIngestion__*`. |

### Interfaces and Schedule

- Event-driven; no repository-defined schedule.
- Only notifications with `notification_details.event_type=END_OF_DAY` are processed.
- Redelivery interval is one minute; maximum retry period is six hours from first delivery.
- Invalid blank resource IDs or missing effective datetimes move directly to DLQ.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| Pipeline stages | Builds, tests, and deploys the transaction component. | `accept`, `integrate` (`perf0` and `situat`), `rehearse` (`preprod`), and `deliver` (`prod`) are mapped in `src/transaction/.pipelineconfig/pipeline.yaml` and `Deploy/deploy_spec.json`. |
| Image and workload | Selects the immutable processor image and Kubernetes app. | Image `accounts/account/transaction-eod-tmv-customeraccount-processor`; app/release `transaction-eod-tmv-customeraccount-processor`; base replicas 3, `maxUnavailable` 1. |
| Kafka and Schema Registry | Configures inbound TMV consumption and outbound ESP publication. | Environment values define brokers, prefixes, group IDs, authentication, and Schema Registry. |
| PostgreSQL | Configures the transaction datastore. | `ConnectionStrings__DefaultConnection`; deployment values use `PGHOST`, `PGDATABASE`, and `PGUSER` with SSL. |

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `GET http://transaction-eod-tmv-customeraccount-processor/health/readiness` on service port 80 (target 8080), no application authentication configured | HTTP 200; Kubernetes starts after 10 seconds, polls every 5 seconds, and marks unready after 3 failures. Cluster-internal and not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and infrastructure authentication requirements]. | Non-200, timeout over 3 seconds, or a replica remains unready. |
| `GET http://transaction-eod-tmv-customeraccount-processor/health/liveness` on service port 80 (target 8080), no application authentication configured | HTTP 200; Kubernetes starts after 10 seconds, polls every 5 seconds, and restarts after 3 failures. Cluster-internal and not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and infrastructure authentication requirements]. | Non-200, timeout over 2 seconds, or repeated restarts. |
| Kafka processing | Received and successful-processing counts continue; redelivery, exception, and DLQ counts remain at the agreed environment baseline. | Success stops, redelivery/DLQ rises, or consumer lag grows. [TODO: confirm environment-specific consumer-lag thresholds and access procedure]. |
| Output correctness | A valid `END_OF_DAY` input produces one customer-account balance event with supported balance types. | Output is absent, duplicated, or unexpectedly defaults a balance to zero. |

Observability: <ul><li>[Account Transaction EoD Customer Accounts Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203297869/Account+Transaction+EoD+Customer+Accounts+Observability+Dashboard)</li><li>[EoD Components Runbook logs](https://kiwibank.atlassian.net/wiki/x/CQG6PwE)</li></ul>

Local verification from the repository root; requires the integration-test dependencies and credentials documented by the repository:

```powershell
dotnet test .\src\transaction\Account.Transaction.EndOfDay.Balance.Tmv.CustomerAccount.Processor.IntegrationTests\Account.Transaction.EndOfDay.Balance.Tmv.CustomerAccount.Processor.IntegrationTests.csproj
```

Expected result: exit code 0; tests exercise input validation, retry behavior, datastore reads, and publication. This command was not executed during runbook generation and does not validate a deployed environment.

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the transaction pipeline builds `accounts/account/transaction-eod-tmv-customeraccount-processor` from the named project and unit/integration evidence passes for the candidate commit.
2. Review shared transaction migrations and the target environment values for database, TMV/ESP Kafka, Schema Registry, telemetry, retry settings, topic prefixes, group ID, and secret references.
3. Promote through SITUAT and PREPROD before PROD; use only non-production events for deployment rehearsal.

### After Deployment

1. In the target environment, confirm the expected image tag and replica count, and verify both cluster-internal health requests return HTTP 200 through the approved access path.
2. Confirm successful `END_OF_DAY` processing resumes with no new PostgreSQL, Kafka, Schema Registry, redelivery, or DLQ errors.
3. In SITUAT or PREPROD, process a representative notification and verify the output event's account ID, effective datetime, and supported balances; record the environment and result in change evidence.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

- Prefer fix-forward when shared database migrations or externally visible balance events are involved.
- For an application-only regression, redeploy the last approved immutable image through the transaction pipeline. [TODO: confirm the pipeline rollback action, release identifier, required approval, and database-migration rollback policy].
- Do not reset offsets, replay DLQ records, edit balances, or reverse migrations without an approved environment-specific procedure.

### Recovery Validation

1. Confirm all replicas are ready/live, dependency errors stop, successful processing resumes, and lag trends toward its pre-incident baseline.
2. Verify an affected account's output matches the eligible datastore balances at the notification effective datetime and check for duplicate events.

Operational guardrail: A retried notification can repeat datastore reads and publication; use the approved replay path and verify downstream duplicate handling before manual replay.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Kiwibank kb-accounts](https://github.com/Kiwibank/kb-accounts) |
| Dashboards and logs | <ul><li>[Account Transaction EoD Customer Accounts Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203297869/Account+Transaction+EoD+Customer+Accounts+Observability+Dashboard)</li><li>[EoD Components Runbook logs](https://kiwibank.atlassian.net/wiki/x/CQG6PwE)</li></ul>
 |
| Minimum Standard for Runbooks | [Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |