﻿using Account.Origination.Job.Extension;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Origination.Job.TMVClient.SemanticVersion;

public class ProductVersionIterator(ICoreAPIProductsClient coreApiAccountsClient)
    : IProductVersionIterator
{
    private const int MaxPageSize = 30;

    public async Task<string?> ResolveAsync(
        string productId,
        string version,
        CancellationToken cancellationToken)
    {
        string? nextPageToken = null;

        do
        {
            var result = await coreApiAccountsClient.ListProductVersionsAsync(MaxPageSize, productId, nextPageToken, View4.PRODUCT_VERSION_VIEW_BASIC, cancellationToken);

            foreach (var item in result.Product_versions)
            {
                var itemVersion = item.GetFullVersion();

                if (productId == item.Product_id && itemVersion == version)
                {
                    return item.Id;
                }
            }

            nextPageToken = result.Next_page_token;
        } while (!string.IsNullOrWhiteSpace(nextPageToken));

        return null;
    }
}