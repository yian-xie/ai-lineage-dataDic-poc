﻿using System.Text.RegularExpressions;

using Account.Transaction.Api.Queries.Types;

namespace Account.Transaction.Api.Queries.Mapping;

/// <summary>
/// The extension to format the account number.
/// See the format description in <see cref="AccountTransaction.AccountNumberDisplay"/> and <see cref="PartyAccount.AccountIdentificationDisplay"/>.
/// </summary>
public static partial class AccountNumberExtension
{
    [GeneratedRegex(@"^(\d{2})(\d{4})(\d{7})(\d{2,3})$")]
    private static partial Regex AccountNumberRegex();

    [GeneratedRegex(@"^(\d{2})-(\d{4})-(\d{7})-(\d{2,3})$")]
    private static partial Regex AccountNumberDisplayRegex();


    /// <summary>
    /// Format the given account number to BB-bbbb-AAAAAAA-SSS format if it's a valid account number.
    /// Anything shorter than 15 or longer than 16 digits, or contains non-digit characters will be returned as is.
    /// </summary>
    /// <param name="accountNumber">The bank account number</param>
    /// <returns>The formatted account number in <see cref="AccountTransaction.AccountNumberDisplay"/> and <see cref="PartyAccount.AccountIdentificationDisplay"/>.
    /// If the account number is shorter than 15 or longer than 16 digits, or contains non-digit characters, the original account number will be returned.</returns>
    public static string ToAccountNumberDisplay(this string accountNumber)
    {
        if (string.IsNullOrWhiteSpace(accountNumber))
        {
            return accountNumber;
        }

        var match = AccountNumberRegex().Match(accountNumber);

        return match.Success
            ? $"{match.Groups[1].Value}-{match.Groups[2].Value}-{match.Groups[3].Value}-{match.Groups[4].Value}"
            : accountNumber;
    }

    /// <summary>
    /// Format the given account number to BBbbbbAAAAAAASSS format if it's an account number display (remove hyphens).
    /// Anything not formatted as account number display with hyphens will be returned as is.
    /// </summary>
    /// <param name="accountNumber">The bank account number</param>
    /// <returns>The formatted account number in <see cref="AccountTransaction.AccountNumber"/> and <see cref="PartyAccount.AccountIdentification"/>.
    /// If the account number is not formatted as account number display with hyphens, the original account number will be returned.</returns>
    public static string ToAccountNumber(this string accountNumber)
    {
        if (string.IsNullOrWhiteSpace(accountNumber))
        {
            return accountNumber;
        }

        var match = AccountNumberDisplayRegex().Match(accountNumber);

        return match.Success
            ? accountNumber.Replace("-", "")
            : accountNumber;
    }
}