﻿namespace Account.Profile.Processor.Services;

/// <summary>
/// ThoughtMachine contract notification type identifiers.
/// </summary>
public static class ThoughtMachineNotificationTypes
{
    public const string ParameterChange = "parameter_change";
}