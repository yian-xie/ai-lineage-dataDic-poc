﻿namespace Account.Shared.Constants;

public static class JwtClaimTypes
{
    public const string TenantId = "tid";
    public const string AuthorizedParty = "azp";
}

public static class DatabaseConstants
{
    /// <summary>
    ///     Name of the table where the migration data is held
    /// </summary>
    public const string MigrationTableName = "__migration";
}

public static class CurrencyCode
{
    public const string Nzd = "NZD";
}

public static class Asset
{
    public const string CommercialBankMoney = "COMMERCIAL_BANK_MONEY";
}

public static class General
{
    public const string AccountProfileApiAppName = "Account.Profile.Api";
    public const string AccountTransactionBalanceApiAppName = "Account.Transaction.Balance.Api";
    public const string AccountTransactionApiAppName = "Account.Transaction.Api";
    public const string AccountTransactionTmvProcessor = "Account.Transaction.Tmv.Processor";

    public static readonly string[] IdentityClaimNames =
        ["preferred_username", "unique_name", "name", "oid"];
}

public static class Constants
{
    public const string XAuthTokenHeader = "X-Auth-Token";
    public const string XSumoNameHeader = "X-Sumo-Name";
    public const string XSumoCategoryHeader = "X-Sumo-Category";
    public const string ApplicationJson = "application/json";
    public const string UrlEncoded = "application/x-www-form-urlencoded";
    public const string TextPlain = "text/plain";

    // Trait Tags for Integration Tests
    public const string ProcessFinanceBoaSetup = "Process:Finance.BOA.Setup";
    public const string ProcessFinanceBoaMonitoring = "Process:Finance.BOA.Monitoring";

    public const string ProcessL4CustomerViewAccountDetails =
        "Process: L4CustomerViewAccountDetails";

    public const string ProcessL4ReconcileGeneralLedgerAccount =
        "Process: L4ReconcileGeneralLedgerAccount";

    public const string ProcessL4StaffViewCustomerAccountDetails =
            "Process: L4StaffViewCustomerAccountDetails";

    public const string OutcomeL4CustomerViewAccountDetailsAccurateDetails =
        "Outcome: L4CustomerViewAccountDetails.AccurateDetails";

    public const string OutcomeL4CustomerViewAccountDetailsViewDetails =
        "Outcome: L4CustomerViewAccountDetails.ViewDetails";

    public const string OutcomeL4CustomerViewAccountDetailsViewPermitted =
        "Outcome: L4CustomerViewAccountDetails.ViewPermitted";

    public const string ProcessL4CustomerViewAccountTransactions =
        "Process: L4CustomerViewAccountTransactions";
    public const string OutcomeL4CustomerViewAccountTransactionsWhtTransaction =
        "Outcome: L4CustomerViewAccountTransactions.WhtTransaction";

    public const string OutcomeL4CustomerViewAccountTransactionsWhtTransactionDetails =
        "Outcome: L4CustomerViewAccountTransactions.WhtTransactionDetails";

    public const string OutcomeL4CustomerViewAccountTransactionsInterestTransactionDetails =
        "Outcome: L4CustomerViewAccountTransactions.InterestTransactionDetails";

    public const string OutcomeL4CustomerViewAccountTransactionsMonthEndPostings =
        "Outcome: L4CustomerViewAccountTransactions.MonthEndPostings";

    public const string ProcessL4StaffViewCustomerAccountTransactions =
        "Process: L4StaffViewCustomerAccountTransactions";

    public const string OutcomeL4StaffViewCustomerAccountTransactionsWhtTransaction =
        "Outcome: L4StaffViewCustomerAccountTransactions.WhtTransaction";

    public const string OutcomeL4StaffViewCustomerAccountTransactionsWhtTransactionDetails =
        "Outcome: L4StaffViewCustomerAccountTransactions.WhtTransactionDetails";

    public const string OutcomeL4StaffViewCustomerAccountTransactionsInterestTransactionDetails =
        "Outcome: L4StaffViewCustomerAccountTransactions.InterestTransactionDetails";

    public const string OutcomeL4StaffViewCustomerAccountTransactionsMonthEndPostings =
        "Outcome: L4StaffViewCustomerAccountTransactions.MonthEndPostings";

    public const string OutcomeL4StaffViewCustomerAccountDetailsInterestWhtSettings =
        "Outcome: L4StaffViewCustomerAccountDetails.InterestWhtSettings";

    public const string OutcomeL4StaffViewCustomerAccountDetailsDeductionWhtSettings =
        "Outcome: L4StaffViewCustomerAccountDetails.DeductionWhtSettings";

    public const string OutcomeL4ReconcileGeneralLedgerAccountBalanceFormat =
        "Outcome: L4ReconcileGeneralLedgerAccount.BalanceFormat";

    public const string OutcomeL4ReconcileGeneralLedgerAccountDeltaFormat =
        "Outcome: L4ReconcileGeneralLedgerAccount.DeltaFormat";

    public const string OutcomeL4ReconcileGeneralLedgerAccountTimely =
        "Outcome: L4ReconcileGeneralLedgerAccount.Timely";

    public const string OutcomeL4StaffViewCustomerAccountDetailsAccurateDetails =
        "Outcome: L4StaffViewCustomerAccountDetails.AccurateDetails";

    public const string OutcomeL4StaffViewCustomerAccountDetailsViewPermitted =
        "Outcome: L4StaffViewCustomerAccountDetails.ViewPermitted";

    public const string OutcomeL4StaffViewCustomerAccountDetailsViewLogged =
        "Outcome: L4StaffViewCustomerAccountDetails.ViewLogged";

    public const string OutcomeL4CustomerViewAccountTransactionsViewPermitted =
        "Outcome: L4CustomerViewAccountTransactions.ViewPermitted";

    public const string OutcomeL4CustomerViewAccountTransactionsViewList =
        "Outcome: L4CustomerViewAccountTransactions.ViewList";

    public const string OutcomeL4CustomerViewAccountTransactionsViewDetails =
        "Outcome: L4CustomerViewAccountTransactions.ViewDetails";

    public const string OutcomeL4CustomerViewAccountTransactionsAccurateDetails =
        "Outcome: L4CustomerViewAccountTransactions.AccurateDetails";

    public const string OutcomeL4StaffViewCustomerAccountDetailsViewDetails =
        "Outcome: L4StaffViewCustomerAccountDetails.ViewDetails";
}

/// <summary>
/// This is a static class that contains constants for HTTP context data keys and values.
/// They are used for transaction.api to store the transaction type and original account id in the context data dictionary.
/// It is no ideal to put this in account.shared as it is transaction subdomain things, it is short term solution and ultimately will change to use ADDS.
/// </summary>
public static class HttpContextDataConstants
{
    /// <summary>
    /// The key that is used to store the transaction type in the context data dictionary.
    /// </summary>
    public const string TransactionTypeKey = "TransactionType";
    /// <summary>
    /// The key that is used to store the original account id (i.e. no prefix) in the context data dictionary.
    /// </summary>
    public const string AccountIdKey = "AccountId";

    /// <summary>
    /// Transaction types enum.
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// TMV Transaction.
        /// </summary>
        Tmv,

        /// <summary>
        /// Credit Card Transaction.
        /// </summary>
        CreditCard,

        /// <summary>
        /// Foreign Currency Transaction.
        /// </summary>
        ForeignCurrency,

        /// <summary>
        /// Unknown Transaction type.
        /// </summary>
        Unknown
    }
}

/// <summary>
/// This is a static class that contains constants for local state data keys and values.
/// They are used for transaction.api and profile.api to store information about the user in the context data dictionary.
/// </summary>
public static class LocalStateConstants
{
    /// <summary>
    /// The key that is used to store the IsStaff flag in the context data dictionary.
    /// </summary>
    public const string IsStaffKey = "IsStaff";
    /// <summary>
    /// The key that is used to store the AccessNumber of the customer in the context data dictionary.
    /// </summary>
    public const string AccessNumberKey = "AccessNumber";

}