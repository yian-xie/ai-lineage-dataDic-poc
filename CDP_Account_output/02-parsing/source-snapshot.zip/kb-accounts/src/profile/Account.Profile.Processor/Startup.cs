﻿using System;

using Account.Profile.Processor.Publishers;
using Account.Profile.Processor.Services;
using Account.Profile.Processor.Subscribers;
using Account.Profile.Shared;
using Account.Profile.Shared.Constants;
using Account.Profile.Shared.Infrastructure;
using Account.Shared;
using Account.Shared.Configurations;
using Account.Shared.Extensions;
using Account.Shared.Metrics.Decorator;

using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;
using Api.Shared.Clients.Events.ThoughtMachine.V1.RestrictionSet;
using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;

using Enterprise.Shared.Kafka;
using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Profile.Processor;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Constants.Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        var retrySettings = Configuration.GetSection(RetrySettings.Key).Get<RetrySettings>()
            ?? throw new InvalidOperationException($"Missing required configuration section: {RetrySettings.Key}");

        services.AddSingleton(retrySettings);

        AddPooledDbContextWithOutbox<AccountProfileDbContext>(services);

        UseKafka(services);
        services.AddTmvKafkaClusterConfigurations(configuration);

        services
            // TMV Kafka failover consumers to support TMV OAuth.
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvAccountEventSubscriber, string, AccountEvent>(configuration, GetKafkaSettings(0))
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvContractNotificationSubscriber, string, ContractNotification>(configuration, GetKafkaSettings(0))
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvRestrictionEventSubscriber, string, RestrictionSetEvent>(configuration, GetKafkaSettings(0))
            .AddRepositories()
            .AddSingleton<IAccountProfileChangeSetCreator, AccountProfileChangeSetCreator>()
            .AddSingleton<IAccountProfileEventBuilder, AccountProfileEventBuilder>()
            .AddSingleton<IAccountProfileEventPublisher, AccountProfileEventPublisher>()
            .AddScoped<IContractNotificationProcessor, ContractNotificationProcessor>()
            .AddScoped<IAccountProfileCreator, AccountProfileCreator>()
            .AddScoped<IAccountProfileUpdater, AccountProfileUpdater>()
            .AddScoped<IParameterValueCreator, ParameterValueCreator>()
            .AddScoped<IRestrictionSetEventHandler, RestrictionSetCreatedEventHandler>()
            .AddScoped<IRestrictionSetEventHandler, RestrictionSetUpdatedEventHandler>();

        services.AddAlertingServices(Configuration);

        services
            .Decorate<IIncomingEventSubscriber<AccountEvent>,
                AccountIncomingEventSubscriberMetricDecorator<AccountEvent>>()
            .Decorate<IIncomingEventSubscriber<ContractNotification>,
                AccountIncomingEventSubscriberMetricDecorator<ContractNotification>>()
            .Decorate<IIncomingEventSubscriber<RestrictionSetEvent>, AccountIncomingEventSubscriberMetricDecorator<RestrictionSetEvent>>();
    }
}