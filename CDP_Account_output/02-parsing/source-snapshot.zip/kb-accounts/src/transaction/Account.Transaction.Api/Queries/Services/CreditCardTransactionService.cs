﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Transaction.Api.CardsClient;
using Account.Transaction.Api.CardsClient.Models;
using Account.Transaction.Api.Queries.Services.Filtering;
using Account.Transaction.Api.Queries.Services.Models;
using Account.Transaction.Api.Queries.Services.Validation;
using Account.Transaction.Api.Queries.Types;

using Microsoft.Extensions.Logging;

namespace Account.Transaction.Api.Queries.Services;

/// <summary>
/// Calling Cards API to get credit card transactions.
/// </summary>
public class CreditCardTransactionService(ICardsClient cardsClient, ICreditCardDateRangeDefaults creditCardDateRangeDefaults, ICreditCardDateRangeValidator creditCardDateRangeValidator, ILogger<CreditCardTransactionService> logger) : ICreditCardTransactionsService
{
    private static string FormatDate(DateTimeOffset date) =>
        DateOnly.FromDateTime(date.Date).ToString("yyyy-MM-dd");

    /// <summary>
    /// Calling the Cards API to get credit card transactions.
    /// </summary>
    /// <param name="queryParams"><see cref="AccountTransactionQueryParams"/></param>
    /// <param name="cancellationToken"><see cref="CancellationToken"/></param>
    /// <exception cref="ArgumentNullException">Throwing <see cref="ArgumentNullException"/> when <see cref="AccountTransactionQueryParams.AccessNumber"/> is null</exception>
    /// <returns><see cref="CardTransactionsResponseState"/></returns>
    public async Task<CardTransactionsResponseState> GetCreditCardTransactionsAsync(
        AccountTransactionQueryParams queryParams, CancellationToken cancellationToken)
    {
        var dateRange = creditCardDateRangeDefaults.Get(queryParams.TransactionDateFrom,
            queryParams.TransactionDateTo);

        creditCardDateRangeValidator.IsValid(dateRange);

        var request = new CardTransactionsRequest
        {
            AccessNumber = queryParams.AccessNumber.ToString() ?? string.Empty,
            AccountCardId = queryParams.AccountId,
            FromDate = FormatDate(dateRange.FromDate),
            ToDate = FormatDate(dateRange.ToDate)
        };

        try
        {
            var response =
                await cardsClient.SendTransactionsRequestAsync(request, cancellationToken);

            return MapToCardTransactionsResponseState(response);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Fail in fetching credit card transactions for access number {accessNumber}.", queryParams.AccessNumber);

            throw;
        }
    }

    private static CardTransactionsResponseState MapToCardTransactionsResponseState(CardTransactionsResponse cardTransactionsResponse)
    {
        var responseStatusType = string.Compare(cardTransactionsResponse.Status, "SUCCESS", StringComparison.InvariantCultureIgnoreCase) == 0
            ? ResponseStatusType.Success
            : ResponseStatusType.PartialSuccess;

        var responseState =
            new ResponseState(cardTransactionsResponse.Warnings, responseStatusType);

        return new CardTransactionsResponseState(cardTransactionsResponse.Transactions, responseState);
    }
}