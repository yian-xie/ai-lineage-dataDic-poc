﻿namespace Account.Origination.Job.Configurations;

public class ResilienceOptions
{
    public required int RetryAttempts { get; set; } = 3;
    public required int TimeoutAfterSeconds { get; set; } = 10;
    public required int RetryDelaySeconds { get; set; } = 2;
    public required bool UseJitter { get; set; } = true;
}