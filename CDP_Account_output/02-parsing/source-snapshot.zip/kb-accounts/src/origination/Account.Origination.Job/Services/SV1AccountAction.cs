﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Constants;
using Account.Origination.Job.Infrastructure;
using Account.Origination.Job.Infrastructure.Resilience;
using Account.Origination.Job.TMVClient.Factories;
using Account.Origination.Job.TMVClient.SemanticVersion;
using Account.Origination.Public;
using Account.Origination.Public.Interfaces;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure.Exceptions;
using Account.Shared.FeatureFlags;

using Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Origination.Job.Services;

public class SV1AccountAction(
    ICoreAPIAccountsClient coreApiAccountsClient,
    IOnlineCallClient onlineCallClient,
    ISemanticVersionResolver semanticVersionResolver,
    IAccountNameGenerator accountNameGenerator,
    ILogger<TmvAccountAction> logger,
    IOnlineCallAccountRequestFactory onlineCallAccountRequestFactory,
    IStandardResiliencePipeline<CreateOnlineCallAccountResponse, DefaultResilienceStrategy, IPartyClient> tmv2ResiliencePipeline,
    IFeatureService featureService,
    Kb.TMV.Client.ITmvClient tmvClient
) : TmvAccountAction(Shared.Services.Product.Sv1, coreApiAccountsClient, onlineCallClient, semanticVersionResolver, logger, featureService, tmvClient)
{
    private async Task<CreateOnlineCallAccountResponse> CreateTmvAccountAsync(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(accountOpening);
        ArgumentNullException.ThrowIfNull(accountOpening.PartyId);

        try
        {
            var useTMVLibrary = FeatureService.IsFeatureEnabled(
                FeatureFlag.UseTmvRestApiClient,
                defaultValue: false);

            var parties = ConvertPartyResultsToParties(partyResults);

            var accountName = accountNameGenerator.GenerateAccountName(parties);

            var semanticVersionId = await SemanticVersionResolver.ResolveAsync(Product, cancellationToken);

            if (useTMVLibrary == true)
            {
                var request = onlineCallAccountRequestFactory.CreateV2AccountRequest(accountOpening, partyResults, semanticVersionId, accountName);

                var result = await tmvClient.CreateOnlineCallAccountAsync(request, cancellationToken);

                if (result.IsSuccess)
                {
                    Logger.LogInformation("Created TMV account {accountId} with TMV library.", accountOpening.AccountId);

                    var accountStatus = EnumConverter.ToEnum<AccountStatus>(result.Success.AccountStatus, AccountStatus.ACCOUNT_STATUS_UNKNOWN);

                    return new CreateOnlineCallAccountResponse
                    {
                        Id = result.Success.AccountId,
                        Status = accountStatus
                    };
                }
                else
                {
                    var error = result.Failure.Errors[0];
                    Logger.LogError("Failed to create TMV account {accountId}. Error: {error}",
                        accountOpening.AccountId, error.Message);
                    throw new AccountOriginationException($"Failed to create TMV account {accountOpening.AccountId}: [{error.Code}] {error.Message}");
                }
            }
            else
            {
                var request = onlineCallAccountRequestFactory.Create(accountOpening, partyResults, semanticVersionId, accountName);

                return await tmv2ResiliencePipeline.ExecuteAsync(async ct => await OnlineCallClient.CreateOnlineCallAccountAsync(request, ct), cancellationToken, new { AccountId = request.Account.Id });
            }
        }
        catch (Exception exp)
        {
            Logger.LogError(exp, "Failed to create account {accountId}",
                accountOpening.AccountId);

            throw;
        }
    }

    public override Task<V1accountsAccount> CreateAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken)
    {
        throw new NotSupportedException(
            $"{GetType().Name} does not support CreateAsync. Use CreateV2Async instead.");
    }

    public override async Task<CreateOnlineCallAccountResponse> CreateV2Async(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        CancellationToken cancellationToken)
    {
        try
        {
            Logger.LogInformation("Creating TMV account {accountId}.", accountOpening.AccountId);

            var tmvAccount = await CreateTmvAccountAsync(accountOpening, partyResults, cancellationToken);

            if (tmvAccount.Status is not (AccountStatus.ACCOUNT_STATUS_PENDING
                                         or AccountStatus.ACCOUNT_STATUS_OPEN))
            {
                throw new AccountOriginationException(
                    $"Expecting the returned TMV account {tmvAccount.Id} status is {AccountStatus.ACCOUNT_STATUS_PENDING} or {AccountStatus.ACCOUNT_STATUS_OPEN} after creating account but the status is {tmvAccount.Status}.");
            }

            Logger.LogInformation("Created TMV account {accountId}.", accountOpening.AccountId);

            return tmvAccount;
        }
        catch (Exception ex)
        {
            Logger.LogError(
                ex,
                "Failed to create TMV account {accountId} for ProductApplicationEvent {eventId}.",
                accountOpening.AccountId, accountOpening.EventId);

            throw;
        }
    }

    /// <inheritdoc />
    public override AccountOpeningState? GetPrerequisiteState(AccountOpening accountOpening)
    {
        return string.IsNullOrWhiteSpace(accountOpening.AccountNumber)
            ? AccountOpeningState.PendingNumberAllocation
            : null;
    }

    private static Party[] ConvertPartyResultsToParties(ICollection<PartyResultDto> partyResults)
    {
        return partyResults.Select(p => new Party(
                    p.PartyType,
                    p.FirstName ?? string.Empty,
                    p.MiddleName ?? string.Empty,
                    p.LastName ?? string.Empty,
                    p.FullName ?? string.Empty
                )
            )
            .ToArray();
    }
}