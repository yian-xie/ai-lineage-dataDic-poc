﻿#nullable enable

using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;

using Enterprise.Shared.Database;

namespace Account.Profile.Processor.Publishers;

/// <summary>
///     Represents an interface for publishing AccountProfileEvent.
/// </summary>
public interface IAccountProfileEventPublisher
{
    /// <summary>
    ///     Publish AccountProfileEvent.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="AccountProfile" />
    /// </param>
    /// <param name="metadataType">
    ///     <see cref="MetadataType" />
    /// </param>
    /// <param name="accountStatusTimestamp">The account status timestamp</param>
    /// <param name="correlationId">The correlation ID</param>
    /// <param name="unitOfWork">
    ///     <see cref="IUnitOfWork" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns></returns>
    Task PublishAccountProfileEventAsync(
        AccountProfile accountProfile,
        MetadataType metadataType,
        DateTimeOffset accountStatusTimestamp,
        Guid? correlationId,
        IUnitOfWork unitOfWork,
        CancellationToken cancellationToken);
}