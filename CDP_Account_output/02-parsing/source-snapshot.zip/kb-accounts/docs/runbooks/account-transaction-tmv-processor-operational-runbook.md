## Service Summary

| Field | Details |
|---|---|
| Business purpose | Consumes TMV posting and contract events, calculates and stores balances/transactions, and enqueues account events for ESP. |
| Runtime | .NET ASP.NET Core hosted Kafka consumer with PostgreSQL outbox; image `accounts/account/transaction-tmv-processor`. |
| Source | `src/transaction/Account.Transaction.Tmv.Processor` |
| Pipeline | `src/transaction/.pipelineconfig/pipeline.yaml`; deployment values in `src/transaction/Deploy/Account.Transaction.Tmv.Processor` |
| Last reviewed | 2026-10-05 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. Reliable consumers receive TMV PIB and contract-notification events through the OAuth Kafka cluster, with a configured plain-TLS cluster fallback; a separate KB Kafka consumer handles transaction-history migration events.
2. Accepted PIBs load balance specifications, calculate balances, and atomically store balances, transactions, the PIB, and outbox items; duplicates already marked successful are skipped idempotently.
3. The outbox service publishes transaction/posting/consumption events; failures redeliver the source event after five seconds and attempt a Sumo alert at the configured threshold.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Inbound Kafka | TMV OAuth and plain-TLS clusters | PIB and balance-specification contract notifications | `KafkaClusters`; `Consumers:DefaultConsumers` |
| Inbound/Outbound Kafka | Kiwibank Confluent Cloud and schema registry | Migration requests and ESP/outbox events | `Kafka__*`; environment topic prefix |
| Data store | PostgreSQL `account_transaction`, schema `transaction` | Balance specs/lookups, PIB idempotency, balances, transactions, and outbox | `ConnectionStrings__DefaultConnection`; `AccountTransactionDbContext` |
| Observability | Dynatrace and Sumo Logic ingestion | Metrics/traces and threshold failure ingestion | `MetricsOptions`, `TracingOptions`, `SumoLogicIngestion` |
| Autoscaling | KEDA | Scale migration-history consumption by lag | `Deploy/Account.Transaction.Tmv.Processor/Keda` |

### Interfaces and Schedule

- Consumes `vault.api.v1.postings.posting_instruction_batch.created` and `vault.core_api.v1.contracts.contract_notification.events` from TMV.
- Consumes the environment-prefixed transaction-history migration event from KB Kafka; KEDA targets `<prefix>.migrate.transactions.history.v1.event`.
- Publishes `account.transaction.v1.event` plus account-posting, consumption, and migration-response events through the transactional outbox.
- Health-only HTTP interface: `GET /health/liveness` and `GET /health/readiness` on port 8080. No REST or GraphQL business API and no schedule.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| `Retry:RedeliveryInterval` | Delay before failed Kafka event redelivery | Default `00:00:05`. |
| `Retry:RetryAttemptAlertThreshold` | Delivery attempt that triggers Sumo ingestion | Default `3`; redelivery continues after the alert attempt. |
| `KafkaClusters:TMVKafkaOAuth`, `TMVKafka` | Primary OAuth and fallback plain-TLS TMV clusters | OAuth secret key: `KafkaClusters__TMVKafkaOAuth__OAuth__ClientSecret`. |
| `Consumers:DefaultConsumers` | TMV topics, cluster, and group | ACCEPT group: `cg_accept_accounts_transaction_tmv_processor`. |
| `Kafka__*` | KB Kafka, schema registry, prefixes, and migration consumer group | Secret keys: SASL username/password and schema-registry API key/secret. |
| `SumoLogicIngestion` | Failure-alert destination | Secret key: `SumoLogicIngestion__ApiToken`. |

Environments map to namespaces `accept-transaction-tmv-processor`, `situat-transaction-tmv-processor`, `perf0-transaction-tmv-processor`, `preprod-transaction-tmv-processor`, and `prod-transaction-tmv-processor`, all with release `transaction-tmv-processor`.

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `/health/liveness` and `/health/readiness` | HTTP 200 and stable pods | Probe fails or pods restart; repository startup does not prove these probes include SQL/Kafka health. |
| PIB processing logs | Receive, calculation, database, success, and completion stages appear once per successful batch | Failure/redelivery repeats or a stage is missing. |
| Consumer lag and assignments | Environment groups hold assignments and lag trends to baseline | No incoming logs or lag increases. |
| Outbox telemetry | Enqueued events publish and backlog remains stable | Database processing succeeds while publication falls behind. |
| KEDA migration scaler | 1-10 replicas; activation lag 10; lag threshold 5000; fallback 3 | Scaler errors, pipeline skips resources, or migration lag does not trigger scaling. |

Observability: <ul><li>[Account Transaction Processor Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/DoCoNgE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33414087)</li></ul>

Health endpoints are cluster service probes; no external host is configured for this processor. They are not verified as laptop-reachable. [TODO: confirm the supported cluster/VPN/port-forward access path and expected health-response bodies.]

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the pipeline built `accounts/account/transaction-tmv-processor` and passed its unit and integration stages; review event-schema, balance-calculation, migration, and database changes.
2. Verify environment consumer groups/topic prefixes and required secret-key mappings for TMV OAuth, KB Kafka/schema registry, and Sumo ingestion.

### After Deployment

1. Confirm the `transaction-tmv-processor` release reaches its configured replica count, probes remain healthy, and all three consumers obtain expected assignments without redelivery spikes.
2. Inspect `apply-keda-resources.sh` pipeline output for `Successfully applied KEDA ScaledObject`; confirm migration lag/scaler telemetry in non-production. No Kafka or cluster command was executed during generation.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

Use the repository pipeline and environment-specific Helm values. Stop promotion for consumer assignment, redelivery, database, outbox, or KEDA regressions. Prefer fix forward when events or data have already been processed; [TODO: confirm approved rollback, offset-reset, poison-event, and outbox-replay procedures.]

### Recovery Validation

1. In ACCEPT or another approved non-production environment, confirm a PIB reaches completion once, stores expected non-cached balances/transactions, and creates downstream outbox events.
2. Confirm contract notifications update balance-specification data, lag returns to baseline, outbox backlog drains, and KEDA responds to migration lag as configured.

Operational guardrail: Never reset consumer offsets, change group IDs, delete PIB/outbox rows, or replay events without an approved procedure and a reviewed idempotency/data-impact plan.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Account.Transaction.Tmv.Processor source](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Account.Transaction.Tmv.Processor) |
| Dashboards and logs | <ul><li>[Account Transaction Processor Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/DoCoNgE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33414087)</li></ul> |
| Minimum Standard for Runbooks | [Account Domain Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |