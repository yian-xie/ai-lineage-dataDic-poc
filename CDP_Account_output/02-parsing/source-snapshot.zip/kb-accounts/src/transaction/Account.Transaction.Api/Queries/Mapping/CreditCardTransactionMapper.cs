﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

using Account.Transaction.Api.Queries.Services.Filtering;
using Account.Transaction.Api.Queries.Services.Models;
using Account.Transaction.Api.Queries.Types;

namespace Account.Transaction.Api.Queries.Mapping;

/// <summary>
///     Provide mapping functionality to map <see cref="CreditCardTransaction" /> to <see cref="AccountTransaction" />.
/// </summary>
public class CreditCardTransactionMapper : ITransactionMapper<CreditCardTransaction, AccountTransaction>
{
    /// <summary>
    ///     Mapping the <see cref="CreditCardTransaction"/> to <see cref="AccountTransaction" />.
    /// </summary>
    /// <param name="query"><see cref="IQueryable{TSource}" /> where TSource is <see cref="CreditCardTransaction"/></param>
    /// <param name="accountId"></param>
    /// <returns><see cref="IQueryable{TTarget}" /> where TTarget is <see cref="AccountTransaction" /></returns>
    /// <remarks>Reference: <see href="https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5646254590/ATS+Credit+Card+Transaction+Fields+Mapping"/></remarks>
    public IQueryable<AccountTransaction> MapTo(
        IQueryable<CreditCardTransaction> query,
        string accountId)
    {
        return query.AsEnumerable()
            .Select((x, index) =>
            {
                var key = CreateDeterministicGuid(x, index, accountId);

                var valueDateTime = ConvertToNzt(x.PurchasingDate);

                return new AccountTransaction
                {
                    Id = key,
                    TransactionId = key.ToString(),
                    MaskedCardNumber = x.MaskedCardNumber,
                    AccountId = accountId,
                    AccountNumber = x.MaskedCardNumber.ToAccountNumber(),
                    AccountNumberDisplay = x.MaskedCardNumber.ToAccountNumberDisplay(),
                    TransactionDescription = x.TransactionDescription,
                    CreditDebitIndicator = x.TransactionAmount < 0
                        ? CreditDebitIndicator.Credit
                        : CreditDebitIndicator.Debit,
                    Status = x.PostedDate == null ? Status.Pending : Status.Executed,
                    FinancialTransactionAmount = new Money
                    {
                        Value = x.TransactionAmount.ToString(CultureInfo.InvariantCulture),
                        Currency = Currency.NZD
                    },
                    ValueDateTime = valueDateTime,
                    BookingDateTime = string.IsNullOrWhiteSpace(x.PostedDate)
                        ? null
                        : ConvertToNzt(x.PostedDate),
                    OriginalAmountDetails = x.OriginalAmountDetails,
                    // Set InsertedDateTime to ValueDateTime as the Card API does not provide an inserted date, and ValueDateTime
                    // is the closest approximation to when the transaction occurred.
                    InsertionDateTime = valueDateTime
                };
            })
            .AsQueryable();
    }

    /// <summary>
    /// Use MD5 on a combination of <see cref="CreditCardTransaction"/> fields with its index in the Card API response, then convert to a GUID.
    /// </summary>
    /// <param name="creditCardTransaction"><see cref="CreditCardTransaction"/></param>
    /// <param name="index">The index of <see cref="CreditCardTransaction"/> in the list</param>
    /// <param name="accountId">The account ID for uniqueness</param>
    /// <returns><see cref="Guid"/></returns>
    public static Guid CreateDeterministicGuid(CreditCardTransaction creditCardTransaction, int index, string accountId)
    {
        var key =
            $"{accountId}|{creditCardTransaction.MaskedCardNumber}|{creditCardTransaction.PurchasingDate}|{creditCardTransaction.TransactionAmount}|{creditCardTransaction.TransactionDescription}|{index}";
        var hash = MD5.HashData(Encoding.UTF8.GetBytes(key));

        return new Guid(hash);
    }

    private static DateTimeOffset ConvertToNzt(string dateStr)
    {
        var date = DateTime.Parse(dateStr, CultureInfo.InvariantCulture, DateTimeStyles.None);
        var nztZone = TimeZoneInfo.FindSystemTimeZoneById(TimeZoneIds.NewZealandStandardTime);

        return new DateTimeOffset(date, nztZone.GetUtcOffset(date));
    }
}