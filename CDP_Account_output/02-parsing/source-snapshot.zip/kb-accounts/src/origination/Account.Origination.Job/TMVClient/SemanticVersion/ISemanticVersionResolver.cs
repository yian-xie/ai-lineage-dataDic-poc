﻿namespace Account.Origination.Job.TMVClient.SemanticVersion;

public interface ISemanticVersionResolver
{
    Task<string> ResolveAsync(string productKey, CancellationToken cancellationToken);
}