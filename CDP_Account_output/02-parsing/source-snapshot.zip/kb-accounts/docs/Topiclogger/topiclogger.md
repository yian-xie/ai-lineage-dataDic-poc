
# Topiclogger Subdomain

Topigclogger consumes Action, Audit and DLQ message from TMV Kafka servers and ingests them into Sumo Logic. Metrics related to DLQ logs are generated and sent to Dynatrace for monitoring and alerting purposes.