﻿using System.Diagnostics;
using System.Net;
using System.Net.Http;

using Account.Transaction.Api.CardsClient.Exceptions;
using Account.Transaction.Api.Observability;
using Account.Transaction.Api.Queries.Exceptions;

using HotChocolate;

using Kb.Api.Infrastructure.ErrorHandling.Exceptions;
using Kb.Api.Observability.Metrics;

using Microsoft.AspNetCore.Http;

namespace Account.Transaction.Api.Queries.ErrorFilters;

/// <summary>
/// The Hot Chocolate GraphQL error filter to intercept expcetions that occur during GraphQL execution before they are returned to the client.
/// This filter maps exceptions to error codes and customizes error messages for better client understanding.
/// It also use the metrics to record error occurrences for observability.
/// </summary>
/// <param name="metrics"><see cref="IProfilingMetrics"/></param>
public class GraphQLErrorFilter(IProfilingMetrics metrics) : IErrorFilter
{
    /// <summary>
    /// OnError is called whenever an error occurred during execution of a query.
    /// </summary>
    /// <param name="error"><see cref="IError"/></param>
    /// <returns><see cref="IError"/></returns>
    public IError OnError(IError error)
    {
        // Skip the invalid query errors that Hot Chocolate framework threw as the invalid query errors without the exception content.
        if (error.Exception == null)
        {
            return error;
        }

        var errorCode = error.Exception switch
        {
            ResourceNotFoundException => ErrorCodeConstants.NotFound,
            UnauthorizedException => ErrorCodeConstants.UnauthorizedServerError,
            ForbiddenException => ErrorCodeConstants.Forbidden,
            ApplicationValidationException => ErrorCodeConstants.RequestValidationError,
            RequestValidationException => ErrorCodeConstants.RequestValidationError,
            BadHttpRequestException => ErrorCodeConstants.BadRequest,
            HttpRequestException ex => ex.StatusCode switch
            {
                HttpStatusCode.Unauthorized => ErrorCodeConstants.UnauthorizedServerError,
                HttpStatusCode.Forbidden => ErrorCodeConstants.Forbidden,
                _ => ErrorCodeConstants.InternalServerError
            },
            CreditCardTransactionsException ex => ex.StatusCode switch
            {
                HttpStatusCode.Unauthorized => ErrorCodeConstants.UnauthorizedServerError,
                HttpStatusCode.InternalServerError => ErrorCodeConstants.InternalServerError,
                HttpStatusCode.ServiceUnavailable => ErrorCodeConstants.ServiceUnavailable,
                _ => ErrorCodeConstants.ReceivedCreditCardTransactionExceptionFromCardsApi
            },
            RequiredContextLocalStateMissingException => ErrorCodeConstants.InternalServerError,
            RequiredContextLocalStateInvalidException => ErrorCodeConstants.InternalServerError,
            RequestRequiredFieldMissingException => ErrorCodeConstants.RequiredFieldMissingErrorCode,
            _ => ErrorCodeConstants.InternalServerError
        };

        metrics.Counter(MetricNames.ResponseErrorCountMetric, 1, new TagList { { MetricNames.ErrorCodeTagKey, errorCode } });

        switch (errorCode)
        {
            case ErrorCodeConstants.NotFound:
            case ErrorCodeConstants.Forbidden:
            case ErrorCodeConstants.RequestValidationError:
            case ErrorCodeConstants.BadRequest:
            case ErrorCodeConstants.ReceivedCreditCardTransactionExceptionFromCardsApi:
            case ErrorCodeConstants.RequiredFieldMissingErrorCode:
            case ErrorCodeConstants.InternalServerError:
            case ErrorCodeConstants.ServiceUnavailable:
                return error.WithMessage(error.Exception!.Message).WithCode(errorCode);
            case ErrorCodeConstants.UnauthorizedServerError:
                return error.WithMessage(error.Exception!.Message)
                    .WithCode(errorCode)
                    .SetExtension("serviceName", "account-transaction-api");
            default:
                return error.WithMessage(error.Exception?.Message ?? "Internal Server Error")
                    .WithCode(errorCode);
        }
    }
}