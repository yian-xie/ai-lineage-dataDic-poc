﻿using Account.Transaction.Api.CardsClient.Exceptions;

using Kb.Api.Infrastructure.ErrorHandling;

namespace Account.Transaction.Api.Queries.ErrorFilters;

/// <summary>
/// Error code constants used in the Account Transaction API.
/// </summary>
public class ErrorCodeConstants
{
    /// <summary>
    /// Bad Request Error Code.
    /// </summary>
    public const string BadRequest = ErrorCodes.BadUserInput;
    /// <summary>
    /// Not Found Error Code.
    /// </summary>
    public const string NotFound = ErrorCodes.NotFound;
    /// <summary>
    /// Internal Server Error Code.
    /// </summary>
    public const string InternalServerError = ErrorCodes.InternalServerError;
    /// <summary>
    /// Service Unavailable Error Code.
    /// </summary>
    public const string ServiceUnavailable = "SERVICE_UNAVAILABLE";
    /// <summary>
    /// Transaction API Request Validation Error Code.
    /// </summary>
    public const string RequestValidationError = ErrorCodes.RequestValidationError;
    /// <summary>
    /// Unauthorized Server Error Code.
    /// </summary>
    public const string UnauthorizedServerError = HotChocolate.ErrorCodes.Authentication.NotAuthorized;
    /// <summary>
    /// Received <see cref="CreditCardTransactionsException"/> from Cards API Error Code.
    /// </summary>
    public const string ReceivedCreditCardTransactionExceptionFromCardsApi = "RECEIVED_CREDIT_CARD_TRANSACTION_EXCEPTION_FROM_CARDS_API";
    /// <summary>
    /// Forbidden Error Code.
    /// </summary>
    public const string Forbidden = ErrorCodes.Forbidden;
    /// <summary>
    /// Error code when required fields are missing from the GraphQL query.
    /// </summary>
    public const string RequiredFieldMissingErrorCode = "REQUIRED_FIELD_MISSING";
    /// <summary>
    /// Header Validation Failure Code.
    /// </summary>
    public const string HeaderValidationFailureCode = ErrorCodes.RequiredHeaderMissing;
    /// <summary>
    /// Required Header Missing Error Code.
    /// </summary>
    public const string RequiredHeaderMissing = ErrorCodes.RequiredHeaderMissing;
    /// <summary>
    /// Request Header Invalid Error Code.
    /// </summary>
    public const string RequestHeaderInvalid = "REQUEST_HEADER_INVALID";
}