﻿using System.Diagnostics;

using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Activities;
using Account.Origination.Job.Constants;
using Account.Origination.Job.Infrastructure.Resilience;
using Account.Origination.Job.Services;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure;
using Account.Origination.Shared.Infrastructure.Exceptions;
using Account.Origination.Shared.Repositories;
using Account.Origination.Shared.Services;
using Account.Shared.FeatureFlags;
using Account.Shared.Metrics;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Enterprise.Shared.Database;

using Kb.Api.Observability.Metrics;

using Microsoft.Extensions.Options;

using Serilog.Context;

namespace Account.Origination.Job.Jobs;

/// <summary>
///     This abstract class defines the behavior that can be implemented in account creation and opening.
/// </summary>
/// <typeparam name="TQuery">
///     <see cref="IAccountOpeningGetReadyJobQuery" />
/// </typeparam>
// TODO: This job class is quite heavy with all it's immediate dependencies. Will take a look at breaking this up into smaller parts later.
public abstract class AccountOriginationJobBase<TQuery>(
    ITmvCustomerAction tmvCustomerAction,
    ITmvAccountActionGetter tmvAccountActionGetter,
    IDbTransactionBuilder dbTransactionBuilder,
    IOptions<AccountOriginationJobOptions> accountOriginationJobOptions,
    TimeProvider timeProvider,
    ILogger logger,
    IAccountOriginationActivity accountOriginationActivity,
    IPartyClient partyClient,
    IFeatureService featureService,
    IStandardResiliencePipeline<ICollection<PartyResultDto>, DefaultResilienceStrategy, IPartyClient> partyResiliencePipeline,
    IProfilingMetrics metrics,
    string activityTag)
    : IAccountOriginationJob
    where TQuery : IAccountOpeningGetReadyJobQuery
{
    private const string CorrelationIdProperty = "CorrelationId";
    protected readonly IOptions<AccountOriginationJobOptions>
        AccountOriginationJobOptions = accountOriginationJobOptions;

    protected readonly ILogger Logger = logger;
    protected readonly TimeProvider TimeProvider = timeProvider;
    protected readonly ITmvAccountActionGetter TmvAccountActionGetter = tmvAccountActionGetter;
    protected readonly IPartyClient PartyClient = partyClient;
    protected readonly IFeatureService FeatureService = featureService;
    protected readonly IStandardResiliencePipeline<ICollection<PartyResultDto>, DefaultResilienceStrategy, IPartyClient> PartyResiliencePipeline = partyResiliencePipeline;

    private readonly TagList _tagList = new TagList
    {
        { TelemetryTagKeys.EventType, activityTag }
    };

    /// <summary>
    /// Gets the tag list containing the EventType and other standard telemetry tags.
    /// Useful for derived classes to emit metrics with consistent tagging.
    /// </summary>
    protected TagList GetStandardTagList() => _tagList;

    public async Task<Domain.Account?> DoWorkAsync(
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken)
    {
        await using var transaction =
            dbTransactionBuilder.BeginTransaction(repositoryFactory.UnitOfWork);

        var accountOpening = await GetReadyJob(repositoryFactory);

        if (accountOpening == null)
        {
            return null;
        }

        using var correlationIdProperty = LogContext.PushProperty(CorrelationIdProperty, accountOpening.CorrelationId);

        var queryTimer = Stopwatch.StartNew();
        metrics.Counter(string.Concat(Metrics.OriginationJob, Metrics.RequestTotal), 1, GetStandardTagList());

        var activity = accountOriginationActivity.StartActivityFromPropagationContext(
            activityTag,
            accountOpening);

        using (activity)
        {
            try
            {
                var now = TimeProvider.GetUtcNow();

                if (accountOpening.ValidUntil >= now)
                {
                    var result = await DoWorkInternalAsync(accountOpening, repositoryFactory, cancellationToken);
                    metrics.Counter(string.Concat(Metrics.OriginationJob, Metrics.RequestSuccess), 1, _tagList);

                    return result;
                }

                UpdateAccountOpeningFailed(accountOpening, now, repositoryFactory);

                // Record expired outcome
                Logger.LogWarning(
                    "Account {accountId} origination job '{activityTag}' is no longer valid as of {now}.",
                    accountOpening.AccountId,
                    activityTag,
                    now);

                return null;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception e)
            {
                Logger.LogError(e, "Failed to {activityTag} {accountId}", activityTag, accountOpening.AccountId);

                UpdateAccountOpeningRetry(accountOpening, repositoryFactory);

                var exceptionTag =
                new KeyValuePair<string, object>(TelemetryTagKeys.ExceptionType, e.GetType().Name);

                metrics.Counter(string.Concat(Metrics.OriginationJob, Metrics.Exception), 1,
                    [.. GetStandardTagList(), exceptionTag]);


            }
            finally
            {
                await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);
                await transaction.CommitAsync(cancellationToken);

                queryTimer.Stop();
                var lastExecutionDuration = queryTimer.Elapsed;

                metrics.Histogram(string.Concat(Metrics.OriginationJob, Metrics.Duration),
         (long)lastExecutionDuration.TotalMilliseconds, _tagList);

            }

            return null;
        }
    }

    /// <summary>
    ///     Get ready <see cref="AccountOpening" /> for processing.
    /// </summary>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <returns></returns>
    private Task<AccountOpening?> GetReadyJob(IRepositoryFactory repositoryFactory)
    {
        var now = TimeProvider.GetUtcNow();

        var retryTimeThreshold = now
            .AddSeconds(-AccountOriginationJobOptions.Value.RetryIntervalSeconds);

        return TQuery.GetQuery()(
            (OriginationDbContext)repositoryFactory.UnitOfWork,
            retryTimeThreshold,
            now);
    }

    /// <summary>
    ///     Account Origination task.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns></returns>
    protected abstract Task<Domain.Account?> DoWorkInternalAsync(
        AccountOpening accountOpening,
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Create TMV account and update account_opening.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1accountsAccount" />
    /// </returns>
    protected async Task<Domain.Account> CreateTmvAccountAsync(
        AccountOpening accountOpening,
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken)
    {
        // TODO: Remove this check when SPUD is deprecated. Spud has null ProductCode
        // PartyRoleIds should be used for the Customer Ids going forward
        var customerIds = accountOpening.ProductCode != null ?
        [
            accountOpening.PartyId!.Value.ToString()
        ] : accountOpening.PartyRoleIds;

        var partyResults = await PartyResiliencePipeline.ExecuteAsync(
            async ct => await PartyClient.GetPartyProfilesAsync(customerIds, ct),
            cancellationToken,
            new
            {
                PartyIds = customerIds
            });

        if (accountOpening.ProductCode != null && partyResults.Count == 0)
        {
            throw new AccountOriginationException(
                $"No party profiles returned for account {accountOpening.AccountId}. Cannot create TMV account without party data.");
        }

        await ConfirmCustomersExistAsync(accountOpening, customerIds, partyResults, cancellationToken);

        var tmvAccountAction = TmvAccountActionGetter.GetTmvAccountAction(accountOpening);
        string accountId;
        switch (tmvAccountAction.Product)
        {
            case Product.Spud:
                {
                    var tmvAccount =
                        await tmvAccountAction.CreateAsync(accountOpening, cancellationToken);

                    accountId = tmvAccount.Id;

                    break;
                }
            case Product.Sv1:
                {
                    var tmvAccount =
                        await tmvAccountAction.CreateV2Async(accountOpening, partyResults, cancellationToken);
                    accountId = tmvAccount.Id;

                    break;
                }
            default:
                throw new InvalidOperationException(
                    $"No TMV account action found for account {accountOpening.AccountId}.");
        }

        UpdateAccountOpeningCreated(accountOpening, repositoryFactory);

        return new Domain.Account
        {
            AccountId = accountId
        };
    }

    /// <summary>
    ///     Update TMV account status to ACCOUNT_STATUS_OPEN and update account_opening.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="tmvAccount">Current TMV account. <see cref="V1accountsAccount" /></param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    protected async Task<Domain.Account?> OpenTmvAccountAsync(
        AccountOpening accountOpening,
        V1accountsAccount tmvAccount,
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken)
    {
        V1accountsAccount openedTmvAccount;

        switch (tmvAccount.Status)
        {
            case V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN:
                openedTmvAccount = tmvAccount;

                break;
            case V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING:
                var tmvAccountAction = TmvAccountActionGetter.GetTmvAccountAction(accountOpening);

                openedTmvAccount =
                    await tmvAccountAction.OpenAsync(accountOpening, cancellationToken);

                break;
            default:
                throw new AccountOriginationException(
                    $"Expecting the TMV account {accountOpening.AccountId} status is {V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING} before opening account but the status is {tmvAccount.Status}.");
        }

        UpdateAccountOpeningOpened(accountOpening, openedTmvAccount, repositoryFactory);

        return new Domain.Account
        {
            AccountId = openedTmvAccount.Id
        };
    }

    protected void UpdateAccountOpeningToPrerequisiteState(
        AccountOpening accountOpening,
        AccountOpeningState prerequisiteState,
        IRepositoryFactory repositoryFactory)
    {
        accountOpening.State = prerequisiteState;

        repositoryFactory.AccountOpeningRepository.Update(accountOpening);

        Logger.LogInformation("Account {AccountId} transitioned to {State}.", accountOpening.AccountId, prerequisiteState);
    }

    /// <summary>
    ///     Update the account_opening.created to the current time in the repository.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    protected void UpdateAccountOpeningCreated(
        AccountOpening accountOpening,
        IRepositoryFactory repositoryFactory)
    {
        accountOpening.Created = TimeProvider.GetUtcNow();
        accountOpening.State = AccountOpeningState.Created;

        repositoryFactory.AccountOpeningRepository.Update(accountOpening);
    }

    /// <summary>
    ///     Update the account_opening after account number allocation to transition to Pending state.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="accountNumber">The allocated account number</param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    protected void UpdateAccountOpeningNumberAllocated(
        AccountOpening accountOpening,
        string accountNumber,
        IRepositoryFactory repositoryFactory)
    {
        accountOpening.AccountNumber = accountNumber;
        accountOpening.State = AccountOpeningState.Initial;

        repositoryFactory.AccountOpeningRepository.Update(accountOpening);
    }

    /// <summary>
    ///     Update the account_opening.opened to TMV account opening_timestamp in the repository.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="tmvAccount">
    ///     <see cref="V1accountsAccount" />
    /// </param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    protected void UpdateAccountOpeningOpened(
        AccountOpening accountOpening,
        V1accountsAccount tmvAccount,
        IRepositoryFactory repositoryFactory)
    {
        accountOpening.Opened = tmvAccount.Opening_timestamp;
        accountOpening.State = AccountOpeningState.Opened;

        repositoryFactory.AccountOpeningRepository.Update(accountOpening);
    }

    /// <summary>
    ///     Increment the account_opening.retry_count and last_retry time in the repository.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    protected void UpdateAccountOpeningRetry(
        AccountOpening accountOpening,
        IRepositoryFactory repositoryFactory)
    {
        accountOpening.RetryCount += 1;
        accountOpening.LastRetry = TimeProvider.GetUtcNow();

        repositoryFactory.AccountOpeningRepository.Update(accountOpening);
    }

    /// <summary>
    ///    Confirm the customers exist in TMV, if not create them in TMV. This is to ensure the customers are created before creating/opening account in TMV, as TMV requires the customer to be created before creating/opening account.
    /// </summary>
    private async Task ConfirmCustomersExistAsync(
        AccountOpening accountOpening,
        ICollection<string> customerIds,
        ICollection<PartyResultDto> partyResults,
        CancellationToken cancellationToken)
    {
        var useTMVLibrary = FeatureService.IsFeatureEnabled(
            FeatureFlag.UseTmvRestApiClient,
            defaultValue: false);

        var partyLookup = partyResults.ToDictionary(p => p.PartyId);

        await Task.WhenAll(customerIds.Select(async customerId =>
        {
            var customer = useTMVLibrary == true
            ? await tmvCustomerAction.GetAsync(customerId, accountOpening.CorrelationId.ToString(), cancellationToken)
            : await tmvCustomerAction.GetAsync(customerId, cancellationToken);

            if (customer == null)
            {
                partyLookup.TryGetValue(customerId, out var party);

                if (useTMVLibrary == true)
                {
                    await tmvCustomerAction.CreateAsync(customerId, accountOpening.CorrelationId.ToString(), party, cancellationToken);
                }
                else
                {
                    await tmvCustomerAction.CreateAsync(customerId, party, cancellationToken);
                }

                Logger.LogInformation("Customer created in TMV for PartyId {CustomerId} for AccountId {AccountId} because it did not exist.", customerId, accountOpening.AccountId);
            }
        }));
    }

    /// <summary>
    ///     Set <see cref="AccountOpening" />.failed in the repository.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="failed">Failed time</param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    protected void UpdateAccountOpeningFailed(
        AccountOpening accountOpening,
        DateTimeOffset failed,
        IRepositoryFactory repositoryFactory)
    {
        Logger.LogError("Failed to open account {AccountId}", accountOpening.AccountId);

        accountOpening.Failed = failed;
        accountOpening.State = AccountOpeningState.Failed;

        repositoryFactory.AccountOpeningRepository.Update(accountOpening);
    }
}