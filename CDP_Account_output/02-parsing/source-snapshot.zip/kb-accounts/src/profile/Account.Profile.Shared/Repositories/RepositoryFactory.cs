﻿using Account.Profile.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.Profile.Shared.Repositories;

public class RepositoryFactory(
    AccountProfileDbContext dbContext,
    IAccountProfileRepository accountProfileRepository)
    : IRepositoryFactory
{
    public AccountProfileDbContext DbContext { get; } = dbContext;
    public IUnitOfWork UnitOfWork { get; } = dbContext;
    public IAccountProfileRepository AccountProfileRepository { get; } = accountProfileRepository;
}