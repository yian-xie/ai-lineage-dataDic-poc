﻿using Account.Origination.Job.Jobs;
using Account.Origination.Shared.Repositories;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Services;

/// <summary>
///     A background service to implement a long-running process of <see cref="IAccountOriginationJob" /> .
/// </summary>
/// <typeparam name="T">
///     <see cref="IAccountOriginationJob" />
/// </typeparam>
public class AccountOriginationJobRunner<T>(
    IServiceProvider serviceProvider,
    IOptions<AccountOriginationJobOptions> accountOriginationJobOptions,
    IHostApplicationLifetime hostApplicationLifetime,
    ILogger<AccountOriginationJobRunner<T>> logger)
    : BackgroundService
    where T : IAccountOriginationJob
{
    private readonly TimeSpan _pollingTimeInSecond =
        TimeSpan.FromSeconds(accountOriginationJobOptions.Value.PollingTimeSeconds);

    /// <summary>
    ///     This is called to run the background service until the given token cancellation has been requested.
    /// </summary>
    /// <param name="stoppingToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            logger.LogInformation("{job} - Start.", typeof(T).Name);

            var linkedTokenSource = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await using var scope = serviceProvider.CreateAsyncScope();

                    var t = scope.ServiceProvider.GetRequiredService<T>();

                    var repositoryFactory =
                        scope.ServiceProvider.GetRequiredService<IRepositoryFactory>();

                    await ExecuteInternalAsync(t, repositoryFactory, linkedTokenSource);
                }
                catch (OperationCanceledException ex)
                {
                    // Handling cancellation.
                    logger.LogError(ex, "Detecting cancellation in {func}.", nameof(ExecuteAsync));
                    break; // Exit loop gracefully
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Exception in {job} execution", typeof(T).Name);
                }
            }
        }
        catch (Exception ex)
        {
            logger.LogCritical(ex,
                "Exception occurred in {func}. Stopping {job}.",
                nameof(ExecuteAsync), typeof(T).Name);
        }

        logger.LogWarning("{job} - Finished.", typeof(T).Name);
        hostApplicationLifetime.StopApplication();
    }

    /// <summary>
    ///     To execute the <see cref="IAccountOriginationJob" /> DoWorkAsync.
    /// </summary>
    /// <param name="t">The implementation of <see cref="IAccountOriginationJob" /></param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <param name="cancellationTokenSource">
    ///     <see cref="CancellationTokenSource" />
    /// </param>
    private async Task ExecuteInternalAsync(
        T t,
        IRepositoryFactory repositoryFactory,
        CancellationTokenSource cancellationTokenSource)
    {
        var account = await t.DoWorkAsync(repositoryFactory, cancellationTokenSource.Token);

        if (account == null)
        {
            await Task.Delay(_pollingTimeInSecond, cancellationTokenSource.Token);
        }
    }
}