﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAccountNumberNameProduct : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "account_name",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "account_number",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "banking_relationship_id",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "product_code",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "ix_account_opening_product_code",
                schema: "origination",
                table: "account_opening",
                column: "product_code");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "ix_account_opening_product_code",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "account_name",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "account_number",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "banking_relationship_id",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "product_code",
                schema: "origination",
                table: "account_opening");
        }
    }
}