﻿using Account.Origination.Shared.Entities;

namespace Account.Origination.Job.Services;

public interface ITmvAccountActionGetter
{
    /// <summary>
    ///     Get the implemented <see cref="ITmvAccountAction" />.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <returns>
    ///     <see cref="ITmvAccountAction" />
    /// </returns>
    ITmvAccountAction GetTmvAccountAction(AccountOpening accountOpening);
}