﻿using Newtonsoft.Json;

namespace Account.Profile.Shared.Models.ContractNotifications;

public class Edm
{
    [JsonProperty("attribute")]
    public string Attribute { get; set; }

    [JsonProperty("type")]
    public string Type { get; set; }
}