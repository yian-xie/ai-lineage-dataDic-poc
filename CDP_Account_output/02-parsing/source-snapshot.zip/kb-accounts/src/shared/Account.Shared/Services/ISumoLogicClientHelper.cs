﻿using System.Threading;
using System.Threading.Tasks;

namespace Account.Shared.Services;

/// <summary>
///     Interface for interacting with the Sumo Logic API.
///     This interface defines a method for ingesting logs into Sumo Logic.
/// </summary>
public interface ISumoLogicClientHelper
{
    /// <summary>
    ///     Ingests a log into Sumo Logic.
    /// </summary>
    /// <param name="message">The log message to ingest.</param>
    /// <param name="sourceCategory">The source category for the log.</param>
    /// <param name="sourceName">The source name for the log</param>
    /// <param name="apiToken">The api token for the Sumo Logic endpoint.</param>
    /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task IngestLogAsync(
        byte[] message,
        string sourceCategory,
        string sourceName,
        string apiToken,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Ingests a log into Sumo Logic.
    /// </summary>
    /// <param name="message">The log message to ingest.</param>
    /// <param name="sourceCategory">The source category for the log.</param>
    /// <param name="sourceName">The source name for the log</param>
    /// <param name="apiToken">The api token for the Sumo Logic endpoint.</param>
    /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task IngestLogAsync(
        string message,
        string sourceCategory,
        string sourceName,
        string apiToken,
        CancellationToken cancellationToken);
}