﻿using Kb.Api.Infrastructure.Authorization.OPA;

namespace Account.Shared.Testing.Integration.GraphQL;

/// <summary>
///     The authorization settings for the custom HTTP client used in GraphQL requests.
/// </summary>
/// <param name="authorizationOptions">
///     <see cref="AuthorizationOptions" />
/// </param>
/// <param name="authorizationToken">The authorization bearer token</param>
/// <param name="CustomerIntrospectionToken">The customer introspection token</param>
public record CustomHttpClientAuthorizationSettings(
    AuthorizationOptions authorizationOptions,
    string? authorizationToken,
    string? CustomerIntrospectionToken);