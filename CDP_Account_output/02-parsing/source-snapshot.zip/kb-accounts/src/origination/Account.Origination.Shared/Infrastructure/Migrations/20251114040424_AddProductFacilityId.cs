﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddProductFacilityId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("ALTER TABLE origination.account_opening ALTER COLUMN product_proposition_id TYPE uuid USING product_proposition_id::uuid;");
            migrationBuilder.Sql("ALTER TABLE origination.account_opening ALTER COLUMN banking_relationship_id TYPE uuid USING banking_relationship_id::uuid;");

            migrationBuilder.AddColumn<Guid>(
                name: "product_facility_id",
                schema: "origination",
                table: "account_opening",
                type: "uuid",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "product_facility_id",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.AlterColumn<string>(
                name: "product_proposition_id",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uuid",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "banking_relationship_id",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uuid",
                oldNullable: true);
        }
    }
}