﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Posting.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddTransactionCodeCol : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "transaction_code",
                schema: "posting",
                table: "account_posting",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "transaction_code",
                schema: "posting",
                table: "account_posting");
        }
    }
}