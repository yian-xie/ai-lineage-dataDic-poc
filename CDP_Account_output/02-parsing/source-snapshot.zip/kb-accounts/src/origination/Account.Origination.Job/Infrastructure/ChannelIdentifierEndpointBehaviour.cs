﻿using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

using Account.Origination.Job.Configurations;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Infrastructure;

public class ChannelIdentifierEndpointBehaviour(IOptions<MiddlewareOptions> middlewareOptions)
    : IEndpointBehavior
{
    public void AddBindingParameters(
        ServiceEndpoint endpoint,
        BindingParameterCollection bindingParameters)
    { }

    public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
    {
        clientRuntime.ClientMessageInspectors.Add(
            new ChannelIdentifierMessageInspector(middlewareOptions));
    }

    public void ApplyDispatchBehavior(
        ServiceEndpoint endpoint,
        EndpointDispatcher endpointDispatcher)
    { }

    public void Validate(ServiceEndpoint endpoint) { }
}