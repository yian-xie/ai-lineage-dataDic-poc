﻿using Enterprise.Shared.Application.WebHostService;

namespace Account.TopicLogger.Processor;

public class Program : WebHostServiceBase<Program>
{
    public static async Task Main(string[] args)
    {
        await CreateHostBuilder(args)
            .Build()
            .RunAsync();
    }

    /// <summary>
    ///     Note: Remember not to change the signature of the below method or removing it.
    ///     The WebApplicationFactory in our integration test uses reflection and look for this
    ///     method with this exact signature.
    /// </summary>
    /// <param name="args"></param>
    /// <returns></returns>
    private static IHostBuilder CreateHostBuilder(string[] args)
    {
        return createWebHostBuilder<Startup>(args);
    }
}