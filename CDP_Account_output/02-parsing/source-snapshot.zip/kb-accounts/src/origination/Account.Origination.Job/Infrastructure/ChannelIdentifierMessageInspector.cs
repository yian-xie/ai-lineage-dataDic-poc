﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;

using Account.Origination.Job.Configurations;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Infrastructure;

public class ChannelIdentifierMessageInspector(IOptions<MiddlewareOptions> middlewareOptions)
    : IClientMessageInspector
{
    private const string Header = "x-channel-identifier";
    private const string Namespace = "http://kiwibank.co.nz/";
    public void AfterReceiveReply(ref Message reply, object correlationState) { }

    // Add a SOAP header to every outgoing MW request to identify the KB channel the request was initiated from
    public object BeforeSendRequest(ref Message request, IClientChannel channel)
    {
        var header = MessageHeader.CreateHeader(Header, Namespace,
            middlewareOptions.Value.ChannelIdentifier);
        request.Headers.Add(header);

        return null!;
    }
}