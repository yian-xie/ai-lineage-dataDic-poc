﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;

using AccountProfile__AccountProfile =
    Account.Profile.Api.Queries.Types.AccountProfile__AccountProfile;

namespace Account.Profile.Api.Services;

/// <summary>
///     The account profile actions interface.
/// </summary>
public interface IAccountProfileAction
{
    /// <summary>
    ///     Get list of account profiles using given list of account IDs.
    /// </summary>
    /// <param name="accountIds">Account IDs</param>
    /// <param name="auditLogDataProvider"></param>
    /// <param name="isStaff">Flag indicating if the user is a staff member</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns></returns>
    Task<AccountProfile__AccountProfile[]> GetAccountProfilesByAccountIdsAsync(
        IReadOnlyCollection<string> accountIds,
        IProfileAuditLogDataProvider auditLogDataProvider,
        bool isStaff,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Get single account profile for an accountId
    /// </summary>
    /// <param name="accountId">Account id</param>
    /// <param name="auditLogDataProvider"></param>
    /// <param name="isStaff">Flag indicating if the user is a staff member</param>
    /// <param name="cancellationToken"></param>
    /// <returns>
    ///     <see cref="AccountProfile" />
    /// </returns>
    Task<AccountProfile__AccountProfile?> GetAccountProfileAsync(
        string accountId,
        IProfileAuditLogDataProvider auditLogDataProvider,
        bool isStaff,
        CancellationToken cancellationToken);
}