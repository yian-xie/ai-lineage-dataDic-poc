﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Shared.Entities;

using Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Origination.Job.Services;

public interface ITmvAccountAction
{
    /// <summary>
    ///     The supported product.
    /// </summary>
    public string Product { get; }

    /// <summary>
    ///     Create TMV account.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1accountsAccount" />
    /// </returns>
    public Task<V1accountsAccount> CreateAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Create TMV account using V2 Account API.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="partyResults">
    ///     A collection of party results containing information about the parties involved.
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="CreateOnlineCallAccountResponse" />
    /// </returns>
    public Task<CreateOnlineCallAccountResponse> CreateV2Async(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Open TMV account.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1accountsAccount" />
    /// </returns>
    public Task<V1accountsAccount> OpenAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Get TMV account.
    /// </summary>
    /// <param name="id">Account id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1accountsAccount" />
    /// </returns>
    public Task<V1accountsAccount?>
        GetAsync(string id, CancellationToken cancellationToken);

    /// <summary>
    ///     Get TMV account.
    /// </summary>
    /// <param name="id">Account id</param>
    /// <param name="correlationID">Correlation id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="V1accountsAccount" />
    /// </returns>
    public Task<V1accountsAccount?>
        GetAsync(string id, string correlationID, CancellationToken cancellationToken);

    /// <summary>
    ///     Returns the state to transition to if the account opening is not yet ready to proceed, or <see langword="null" /> if it is ready.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <returns>
    ///     The <see cref="AccountOpeningState" /> to transition to, or <see langword="null" /> if ready to proceed.
    /// </returns>
    public AccountOpeningState? GetPrerequisiteState(AccountOpening accountOpening);
}