﻿using System;

using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Helper;

public static class AccountEventHelper
{
    private const string UndefinedAccountId = "Undefined AccountId";
    public static string GetAccountId(this AccountEvent accountEvent)
    {
        return accountEvent.Account_created?.Account?.Id
            ?? accountEvent.Account_updated?.Account?.Id
            ?? UndefinedAccountId;
    }

    public static bool IsInternalAccount(this AccountEvent accountEvent)
    {
        return string.Equals(accountEvent.Account_created?.Account?.Type, V2accountsAccountType.ACCOUNT_TYPE_INTERNAL.ToString(), StringComparison.OrdinalIgnoreCase)
            || string.Equals(accountEvent.Account_updated?.Account?.Type, V2accountsAccountType.ACCOUNT_TYPE_INTERNAL.ToString(), StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    ///     Get the correlation ID from the AccountEvent.
    /// </summary>
    /// <param name="accountEvent">The account event containing the correlation ID.</param>
    /// <param name="logger">Logger for missing or invalid correlation IDs.</param>
    /// <returns>The correlation ID as a Guid if it exists and is valid; otherwise, null.</returns>
    public static Guid? GetCorrelationId(this AccountEvent accountEvent, ILogger logger)
    {
        var correlationId =
            accountEvent.Account_created?.Account?.Details?.CorrelationId ??
            accountEvent.Account_updated?.Account?.Details?.CorrelationId;

        if (Guid.TryParse(correlationId, out var parsedCorrelationId))
        {
            return parsedCorrelationId;
        }

        logger.LogWarning(
            "CorrelationId is missing or invalid for AccountEvent {eventId} and AccountId {accountId}.",
            accountEvent.Event_id,
            accountEvent.GetAccountId());

        return null;
    }
}