﻿using Account.Origination.Shared.Infrastructure;

using Enterprise.Shared.Database;

using Microsoft.Extensions.Hosting;

namespace Account.Origination.Shared;

public class Program
{
    public static async Task Main(string[] args)
    {
        await MigrationHelper.RunMigrationAsync<OriginationDbContext>(() =>
            CreateHostBuilder(args));
    }

    public static IHostBuilder CreateHostBuilder(string[] args)
    {
        return Host.CreateDefaultBuilder(args)
            .ConfigureServices((host, services) =>
            {
                services
                    .UseDb(host.Configuration)
                    .WithDbContext<OriginationDbContext>(Migration.SetAssembly)
                    .AddSqlHealthCheck();
            });
    }
}