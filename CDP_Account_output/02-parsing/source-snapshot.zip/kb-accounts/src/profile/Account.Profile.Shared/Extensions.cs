﻿using Account.Profile.Shared.Repositories;

using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;

using Microsoft.Extensions.DependencyInjection;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Account.Profile.Shared;

public static class Extensions
{
    public static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        return services
            .AddScoped<IRepositoryFactory, RepositoryFactory>()
            .AddScoped<IAccountProfileRepository, AccountProfileRepository>();
    }

    public static T GetTypedNotification<T>(
        this Notification_details details,
        string notificationType)
        where T : class
    {
        if (details.AdditionalProperties != null &&
            details.AdditionalProperties.TryGetValue(notificationType, out var value))
        {
            if (value is string jsonString)
            {
                return JsonConvert.DeserializeObject<T>(jsonString);
            }

            if (value is JToken jToken)
            {
                return jToken.ToObject<T>();
            }
        }

        return null;
    }
}