﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AssignDefaultValuesToNewColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                UPDATE profile.account_profile
                SET
                    product_facility_banking_product_code = product_facility_banking_product_id,
                    banking_relationship_banking_relationship_id = '',
                    banking_relationship_banking_relationship_type = '',
                    banking_relationship_party_ids = party_role_ids
                WHERE
                    product_facility_banking_product_code = ''
                    OR product_facility_banking_product_code IS NULL
                    OR banking_relationship_banking_relationship_id IS NULL
                    OR banking_relationship_banking_relationship_type IS NULL
                    OR banking_relationship_party_ids IS NULL
                    OR banking_relationship_party_ids = ARRAY[]::text[];
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}