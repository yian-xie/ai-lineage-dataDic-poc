﻿using System;
using System.Linq;

using Account.Profile.Processor.Exceptions;
using Account.Profile.Processor.Models;
using Account.Profile.Shared.Entities;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Helper;

public static class RestrictionSetEventHelper
{
    public static void CheckAccountStatus(
        Restriction restriction,
        AccountProfile accountProfile,
        ILogger logger)
    {
        var accountId = restriction.RestrictionSet.Account_id;

        // Check the account's TMV status is valid.
        var accountStatus = accountProfile.TmvStatus;

        if (AccountStatusHelper.IsTmvAccountStatusPreOpen(accountStatus))
        {
            // Restriction event has arrived before the Account Opened event.
            logger.LogWarning("""
                              Received Restriction Set {type} Event (EventId: {eventId}) for account profile (AccountId: {accountId}) with unexpected TMV status '{Status}'.
                              Only ACCOUNT_STATUS_OPEN status is allowed.
                              """, restriction.Type, restriction.EventId, accountId,
                accountStatus);

            // Force retry until account Opened event has arrived.
            throw new Exception(
                $"Cannot process Restriction Set {restriction.Type} Event for account profile (AccountId: {accountId}) with TMV status '{accountStatus}'. Only ACCOUNT_STATUS_OPEN status is allowed.");
        }

        if (AccountStatusHelper.IsTmvAccountStatusPostOpen(accountStatus))
        {
            // Restriction event has arrived after the Account Closure event.
            logger.LogError("""
                            Received Restriction Set {type} Event (EventId: {eventId}) for account profile (AccountId: {accountId}) with unexpected TMV status '{Status}'.
                            Only ACCOUNT_STATUS_OPEN status is allowed.
                            """, restriction.Type, restriction.EventId, accountId,
                accountStatus);

            // Can't retry we must have missed the account Opened event, send this event to the DLQ.
            throw new RestrictionSetEventException(
                $"Cannot process Restriction Set {restriction.Type} Event for account profile (AccountId: {accountId}) with status '{accountStatus}'. Only ACCOUNT_STATUS_OPEN status is allowed.");
        }
    }

    public static bool IsLatestRestriction(
        Restriction restriction,
        AccountProfile accountProfile,
        ILogger logger)
    {
        if (!accountProfile.Restrictions.Any())
        {
            return true;
        }

        // Stryker disable once all: First vs FirstOrDefault equivalent due to Any() guard
        var latestRestriction = accountProfile.Restrictions.OrderByDescending(x => x.EffectiveAt)
            .ThenByDescending(x => x.ChangeId)
            .First();

        if (restriction.RestrictionSet.Effective_timestamp > latestRestriction.EffectiveAt)
        {
            // Log warning when missed previous event for unfreezing
            if (latestRestriction.IsActive)
            {
                logger.LogWarning("""
                                  Restriction Set Event (EventId: {eventId}) is out of order for account profile (AccountId: {accountId}) for missing unfreeze event.
                                  Existing Restriction: {@existingRestriction}
                                  New Restriction: {@Restriction}
                                  """, restriction.EventId, accountProfile.AccountId, accountProfile.AccountFreezeDetails, restriction);
            }

            return true;
        }

        if (restriction.RestrictionSet.Effective_timestamp == latestRestriction.EffectiveAt)
        {
            return restriction.ChangeId > latestRestriction.ChangeId;
        }

        return false;
    }

    /// <summary>
    /// Return true if we receive an unfreeze event but our current state is
    /// not frozen.  The caller can then avoid sending an Account Profile event
    /// since we never sent one for the frozen state.
    /// </summary>
    /// <param name="isCurrentlyFrozen"></param>
    /// <param name="restriction"></param>
    /// <param name="logger"></param>
    /// <returns></returns>
    public static bool ShouldSuppressProfileEvent(
        bool isCurrentlyFrozen,
        Restriction restriction,
        ILogger logger)
    {
        if (restriction.RestrictionSet.Is_active is true)
        {
            // The latest event is a freeze we always publish the new details.
            //
            return false;
        }

        if (isCurrentlyFrozen)
        {
            // The latest event is an unfreeze and we ARE currently frozen.  Publish the new details.
            return false;
        }

        // If we receive an unfreeze but our current (and last published) status is NOT frozen
        // then we suppress the Account Profile event as it would not contain any changes.
        // In practice this should be quite unlikely to occur.
        //
        logger.LogWarning(
            "Suppressing account profile event after receiving unfreeze with no freeze currently in effect." +
            "Restriction: {@Restriction}",
            restriction);

        return true;
    }
}