﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;

using Account.Shared.Constants;

using Api.Shared.Clients.Events.Internal.V1.AccountAuditLog;

using HotChocolate.Language;
using HotChocolate.Resolvers;

using Kb.Api.Infrastructure.JwtTokenProvider;

using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;

namespace Account.Shared.Kafka.Publishers;

public class AccountAuditLogEventBuilder : IAccountAuditLogEventBuilder
{
    /// <summary>
    ///     Build AccountBalanceEndOfDayInternalAccountEvent.
    /// </summary>
    /// <param name="middlewareContext"></param>
    /// <param name="httpContext"></param>
    /// <param name="appName"></param>
    /// <returns>
    ///     <see cref="AccountAuditLogEvent" />
    /// </returns>
    public AccountAuditLogEvent BuildEvent(
        IMiddlewareContext middlewareContext,
        HttpContext httpContext,
        string appName)
    {
        var tokenString = httpContext.Request.Headers[HeaderNames.Authorization].ToString();
        var jwtToken = TokenStringExtensions.ReadJwtToken(tokenString);

        var requestIdentifier = jwtToken.Claims
            .FirstOrDefault(claim => General.IdentityClaimNames.Contains(claim.Type));

        var requestParameters = JsonSerializer.Serialize(
            middlewareContext.Selection.Arguments.ToDictionary(
                x => x.Key,
                (KeyValuePair<string, ArgumentValue> x) => x.Value.ValueLiteral switch
                {
                    StringValueNode stringValueNode => stringValueNode.Value,
                    ListValueNode listValueNode => listValueNode.Items.Select(item =>
                            item is StringValueNode strNode ? strNode.Value : item.ToString())
                        .ToList(),
                    ObjectValueNode objectValueNode => objectValueNode.Fields
                        .Select(node => string.Join(':', node.Name.Value, node.Value.Value))
                        .ToList(),
                    VariableNode variableNode => middlewareContext.Variables.TryGetVariable(
                        variableNode.Name.Value, out ObjectValueNode objectValueNode)
                        ? objectValueNode.Fields.Select(node =>
                                string.Join(':', node.Name.Value, node.Value.Value))
                            .ToList()
                        : null,
                    _ => x.Value.Value
                }
            ));
        var requestBody = middlewareContext.Selection.SelectionSet?.ToString();

        return new AccountAuditLogEvent
        {
            ClientLogRequestId = Guid.NewGuid().ToString(),
            Client = appName,
            Action = "read",
            TenantIdentifier =
                TokenStringExtensions.ExtractFieldValue(jwtToken, JwtClaimTypes.TenantId),
            TenantClientId =
                TokenStringExtensions.ExtractFieldValue(jwtToken, JwtClaimTypes.AuthorizedParty),
            RequestIdentifier = requestIdentifier?.Value,
            RequestIdentifierType = requestIdentifier?.Type,
            RequestCustomerIdentifier = string.Empty, // only available in UAS
            RequestAction = httpContext.Request.Method,
            RequestPath = httpContext.Request.Path,
            RequestBody = requestBody,
            RequestParameters = requestParameters,
            TraceId = Activity.Current?.TraceId.ToString()
        };
    }
}