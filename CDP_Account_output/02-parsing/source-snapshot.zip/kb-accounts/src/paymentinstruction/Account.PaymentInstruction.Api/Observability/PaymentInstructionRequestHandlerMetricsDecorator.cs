﻿using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Api.Services;

using Kb.Api.Observability.Metrics;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;
using PaymentInstructionWithStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionWithStatus;

namespace Account.PaymentInstruction.Api.Observability;

/// <summary>
///     A decorator class that extends the behavior of AddPaymentInstructionRequestHandler to add Metrics.
/// </summary>
public class PaymentInstructionRequestHandlerMetricsDecorator(
    IAddPaymentInstructionRequestHandler instance,
    IProfilingMetrics metrics)
    : IAddPaymentInstructionRequestHandler
{
    private const string CounterMetricsName = "payment_instruction_request_counter";
    private const string HistogramMetricsName = "payment_instruction_request_histogram";


    /// <summary>
    ///     A decorator function that extends the behavior of AddPaymentInstructionRequestHandler to add Metrics.
    /// </summary>
    /// <param name="input">
    ///     <see cref="PaymentInstructionRequestInput" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    public async Task<PaymentInstructionWithStatus> HandleAsync(
        PaymentInstructionRequestInput input,
        CancellationToken cancellationToken)
    {
        metrics.Counter(CounterMetricsName);

        var queryTimer = Stopwatch.StartNew();
        var paymentInstructionWithStatus = await instance.HandleAsync(input, cancellationToken);
        queryTimer.Stop();
        metrics.Histogram(HistogramMetricsName, queryTimer.ElapsedMilliseconds);

        return paymentInstructionWithStatus;
    }
}