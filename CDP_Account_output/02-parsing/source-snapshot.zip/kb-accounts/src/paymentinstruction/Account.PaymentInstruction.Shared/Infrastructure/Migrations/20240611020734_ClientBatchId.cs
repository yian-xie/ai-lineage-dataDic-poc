﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.PaymentInstruction.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ClientBatchId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "trace_context",
                schema: "paymentinstruction",
                table: "payment_instruction");

            migrationBuilder.RenameColumn(
                name: "batch_id",
                schema: "paymentinstruction",
                table: "payment_instruction",
                newName: "client_batch_id");

            migrationBuilder.AddColumn<string>(
                name: "client_batch_id",
                schema: "paymentinstruction",
                table: "payment_instruction_status",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "client_batch_id",
                schema: "paymentinstruction",
                table: "payment_instruction_status");

            migrationBuilder.RenameColumn(
                name: "client_batch_id",
                schema: "paymentinstruction",
                table: "payment_instruction",
                newName: "batch_id");

            migrationBuilder.AddColumn<string>(
                name: "trace_context",
                schema: "paymentinstruction",
                table: "payment_instruction",
                type: "text",
                nullable: true);
        }
    }
}