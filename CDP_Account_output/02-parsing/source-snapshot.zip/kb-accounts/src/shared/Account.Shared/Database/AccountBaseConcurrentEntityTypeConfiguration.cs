﻿using Account.Shared.Entities;

using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.Shared.Database;

/// <summary>
///     Entity type configuration base for the account domain to support EF core optimistic concurrency.
/// </summary>
/// <typeparam name="TEntity">The entity type that extends <see cref="AccountBaseConcurrentEntity" /> to be configured.</typeparam>
/// <typeparam name="TDbContext">DbContext that inherits IDbContextSchemaName</typeparam>
public abstract class
    AccountBaseConcurrentEntityTypeConfiguration<TEntity, TDbContext> :
    AccountBaseEntityTypeConfiguration<TEntity, TDbContext>
    where TEntity : AccountBaseConcurrentEntity where TDbContext : IDbContextSchemaName
{
    protected sealed override void PreConfigureTable(EntityTypeBuilder<TEntity> builder)
    {
        base.PreConfigureTable(builder);
        // xmin system column in PostgreSQL to hold the id of the latest updating transaction for use as a concurrency token.
        builder.Property(x => x.Version).IsRowVersion();
    }

    protected sealed override void PostConfigureTable(EntityTypeBuilder<TEntity> builder)
    {
        base.PostConfigureTable(builder);
    }
}