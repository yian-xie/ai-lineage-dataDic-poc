﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Posting.Processor.Publishers;
using Account.Posting.Shared.Entities;
using Account.Posting.Shared.Repositories;
using Account.Shared.Configurations;
using Account.Shared.Constants.Tmv;
using Account.Shared.Services;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;
using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Database;
using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.Extensions.Logging;

namespace Account.Posting.Processor.Subscribers;

public class TmvPibCreatedEventSubscriber(
    IDbTransactionBuilder dbTransactionBuilder,
    IRepositoryFactory repositoryFactory,
    SumoLogicSettings sumoLogicSettings,
    ISumoLogicClientHelper sumoLogicClientHelper,
    IAccountPostingEventOutboxPublisher accountPostingEventOutboxPublisher,
    RetrySettings retrySettings,
    ILogger<TmvPibCreatedEventSubscriber> logger)
    : IIncomingEventSubscriber<PostingBatchEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        PostingBatchEvent incomingEvent,
        CancellationToken cancellationToken)
    {
        var batchId = incomingEvent.Posting_instruction_batch.Id;

        try
        {
            var tmvPostingBatch = await repositoryFactory.TmvPostingBatchRepository.GetByIdAsync(
                batchId,
                cancellationToken);

            if (tmvPostingBatch is not null)
            {
                return EventSubscriberResults.Skip;
            }

            await using var transaction =
                dbTransactionBuilder.BeginTransaction(repositoryFactory.UnitOfWork);

            repositoryFactory.TmvPostingBatchRepository.Add(new TmvPostingBatch
            {
                Id = batchId,
                PostingBatchEventPayload = context.ConsumeResult.Message.Value
            });

            if (incomingEvent.Posting_instruction_batch.Status ==
                PostingInstructionBatchStatuses.Accepted)
            {
                await accountPostingEventOutboxPublisher.PublishAsync(
                    incomingEvent,
                    repositoryFactory.UnitOfWork,
                    cancellationToken);
            }

            await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);

            logger.LogInformation(
                $"Successfully processed Posting Instruction Batch (PIB) for batchId: {batchId}");

            return EventSubscriberResults.Success;
        }
        catch (Exception ex)
        {
            logger.LogError(
                ex,
                "Failed to process PIB create Event with batch Id: {BatchId}.", batchId);

            try
            {
                await sumoLogicClientHelper.IngestLogAsync(
                    $"Failed to process Posting Instruction Batch Event with batch Id: {batchId}. Exception: {ex}",
                    sumoLogicSettings.SourceCategory,
                    sumoLogicSettings.SourceName,
                    sumoLogicSettings.ApiToken,
                    cancellationToken);
            }
            catch (Exception nestedEx)
            {
                logger.LogError(
                    nestedEx,
                    "Failed to push log into SumoLogic for failed processing of PIB create with batch Id: {BatchId}.", batchId);
            }

            return new RedeliverMessageEventSubscriberResult(retrySettings.RedeliveryInterval);
        }
    }
}