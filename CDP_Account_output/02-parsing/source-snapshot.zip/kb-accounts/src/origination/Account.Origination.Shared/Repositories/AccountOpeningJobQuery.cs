﻿#nullable enable

using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure;

using Enterprise.Shared.Database.Interceptors;

using Microsoft.EntityFrameworkCore;

namespace Account.Origination.Shared.Repositories;

/// <summary>
///     Implement <see cref="IAccountOpeningGetReadyJobQuery" /> to return the query to get the
///     <see cref="AccountOpening" /> for the account opening in TMV.
/// </summary>
public class AccountOpeningJobQuery : IAccountOpeningGetReadyJobQuery
{
    private static readonly Func<OriginationDbContext, DateTimeOffset, DateTimeOffset,
            Task<AccountOpening?>>
        Query =
            EF.CompileAsyncQuery<OriginationDbContext, DateTimeOffset, DateTimeOffset,
                AccountOpening?>(
                (
                    dbContext,
                    retryTimeThreshold,
                    now) => dbContext.AccountOpenings
                    .TagWith(EntityFrameworkInterceptorTags.ForUpdateSkipLocked)
                    .Where(x => x.State == AccountOpeningState.Created)
                    .Where(x =>
                        x.RetryCount == 0 ||
                        x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold)
                    .Where(x => x.ScheduledOpen <= now)
                    .OrderBy(x => x.RetryCount)
                    .ThenBy(x => x.ScheduledOpen)
                    .ThenBy(x => x.AccountId)
                    .FirstOrDefault());

    public static Func<OriginationDbContext, DateTimeOffset, DateTimeOffset, Task<AccountOpening?>>
        GetQuery()
    {
        return Query;
    }
}