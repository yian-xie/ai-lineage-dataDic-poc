﻿namespace Account.TopicLogger.Processor.Services;

/// <summary>
///     Provides helper methods for file operations.
/// </summary>
public class FileHelper : IFileHelper
{
    /// <summary>
    ///     Checks if a file exists at the specified path.
    /// </summary>
    /// <param name="path">The path to the file.</param>
    /// <returns>True if the file exists; otherwise, false.</returns>
    public bool Exists(string path)
    {
        return File.Exists(path);
    }

    /// <summary>
    ///     Reads all text from a file.
    /// </summary>
    /// <param name="path">The path to the file.</param>
    /// <returns>The contents as a string.</returns>
    public string ReadAllText(string path)
    {
        return File.ReadAllText(path);
    }
}