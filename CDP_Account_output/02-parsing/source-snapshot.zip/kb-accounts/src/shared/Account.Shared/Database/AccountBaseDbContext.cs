﻿using System;

using Account.Shared.Constants;

using Enterprise.Shared.Database;
using Enterprise.Shared.Database.Configurations;

using Microsoft.EntityFrameworkCore;

namespace Account.Shared.Database;

/// <summary>
///     Account Domain Base DB Context
///     Provides the typical setup for a DB context
/// </summary>
/// <param name="options">DB Options</param>
/// <param name="customDbContextOptions">Custom DB Context Options</param>
/// <typeparam name="T"></typeparam>
public abstract class AccountBaseDbContext<T>(
    DbContextOptions<T> options,
    CustomDbContextOptions customDbContextOptions)
    : KafkaOutboxDbContext<T>(options, customDbContextOptions)
    where T : KafkaOutboxDbContext<T>, IDbContextSchemaName
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!customDbContextOptions.IsPooled)
        {
            optionsBuilder.UseNpgsql(builder =>
                    builder.MigrationsHistoryTable(DatabaseConstants.MigrationTableName,
                        T.SchemaName()))
                .UseSnakeCaseNamingConvention();
        }

        base.OnConfiguring(optionsBuilder);
    }

    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
    {
        configurationBuilder.Properties<DateTimeOffset>(builder =>
            builder
                .HaveConversion<DateTimeOffsetToUtcConverter>()
                .HaveConversion<NullableDateTimeOffsetToUtcConverter>());
        base.ConfigureConventions(configurationBuilder);
    }
}