﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Activities;
using Account.Origination.Job.Constants;
using Account.Origination.Job.Infrastructure.Resilience;
using Account.Origination.Job.Services;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Repositories;
using Account.Shared.FeatureFlags;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Enterprise.Shared.Database;

using Kb.Api.Observability.Metrics;

using Microsoft.Extensions.Options;


namespace Account.Origination.Job.Jobs;

/// <summary>
///     Inherit <see cref="AccountOriginationJobBase{TQuery}" /> to implement DoWorkInternalAsync method to open an account
///     in TMV.
/// </summary>
/// <typeparam name="TQuery">
///     <see cref="IAccountOpeningGetReadyJobQuery" />
/// </typeparam>
// TODO: This job class is quite heavy with all it's immediate dependencies. Will take a look at breaking this up into smaller parts later.
public class TmvAccountOpeningJob<TQuery>(
    ITmvCustomerAction tmvCustomerAction,
    ITmvAccountActionGetter tmvAccountActionGetter,
    IDbTransactionBuilder dbTransactionBuilder,
    IOptions<AccountOriginationJobOptions> accountOriginationJobOptions,
    TimeProvider timeProvider,
    ILogger<TmvAccountOpeningJob<TQuery>> logger,
    IAccountOriginationActivity accountOriginationActivity,
    IPartyClient partyClient,
    IFeatureService featureService,
    IStandardResiliencePipeline<ICollection<PartyResultDto>, DefaultResilienceStrategy, IPartyClient> partyResiliencePipeline,
    IProfilingMetrics metrics)
    : AccountOriginationJobBase<TQuery>(
        tmvCustomerAction,
        tmvAccountActionGetter,
        dbTransactionBuilder,
        accountOriginationJobOptions,
        timeProvider,
        logger,
        accountOriginationActivity,
        partyClient,
        featureService,
        partyResiliencePipeline,
        metrics,
        "open TMV account")
    where TQuery : IAccountOpeningGetReadyJobQuery
{
    protected override async Task<Domain.Account?> DoWorkInternalAsync(
        AccountOpening accountOpening,
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken)
    {
        var useTMVLibrary = FeatureService.IsFeatureEnabled(
            FeatureFlag.UseTmvRestApiClient,
            defaultValue: false);

        var tmvAccountAction = TmvAccountActionGetter.GetTmvAccountAction(accountOpening);

        var tmvAccount = useTMVLibrary == true
            ? await tmvAccountAction.GetAsync(accountOpening.AccountId, accountOpening.CorrelationId.ToString(), cancellationToken)
            : await tmvAccountAction.GetAsync(accountOpening.AccountId, cancellationToken);

        if (tmvAccount is
            {
                Status: V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN
            })
        {
            UpdateAccountOpeningOpened(accountOpening, tmvAccount, repositoryFactory);

            Logger.LogWarning("TMV Account {accountId} is already opened.", tmvAccount.Id);

            return new Domain.Account
            {
                AccountId = accountOpening.AccountId
            };
        }

        var account = await OpenTmvAccountAsync(
            accountOpening,
            tmvAccount!,
            repositoryFactory,
            cancellationToken);

        return account;
    }
}