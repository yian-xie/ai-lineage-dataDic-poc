﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

using Account.Transaction.Api.CardsClient.Exceptions;
using Account.Transaction.Api.CardsClient.Models;
using Account.Transaction.Api.Queries.Exceptions;

using Kb.Api.Infrastructure.ErrorHandling.Exceptions;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Account.Transaction.Api.CardsClient.Extensions;

/// <summary>
/// Provides extension methods for <see cref="HttpClient"/> to streamline HTTP calls and error handling.
/// </summary>
public static class HttpClientExtensions
{
    /// <summary>
    /// Constructs an error message string from an unsuccessful HTTP response.
    /// </summary>
    /// <param name="responseMessage">The HTTP response message.</param>
    /// <returns>A formatted string indicating the status code and a generic error message.</returns>
    private static string NotfoundMessage(this HttpResponseMessage responseMessage) => $"Received unsuccessful status code '{responseMessage.StatusCode}' from downstream services";
    private static string BadRequestMessage(string errorMessage) => $"Received unsuccessful status code BadRequest - {errorMessage}";

    /// <summary>
    /// Raises a custom exception based on the HTTP status code of the response.
    /// </summary>
    /// <typeparam name="TException">The type of the custom exception to throw if the status code does not match any predefined case.</typeparam>
    /// <param name="responseMessage">The HTTP response message.</param>
    /// <param name="logger">The logger for logging the critical error.</param>
    /// <param name="url">The URL of the HTTP request.</param>
    /// <exception cref="TransactionExceptionBase">A base class for exceptions specific to credit card operations.</exception>
    private static void RaiseCustomException<TException>(this HttpResponseMessage responseMessage, ILogger logger, string url) where TException : Exception
    {
        var responseString = responseMessage.Content.ReadAsStringAsync().Result;
        var errorMessage = responseMessage.NotfoundMessage();

        // Deserialize if BadRequest and list of errors returned from downstream service
        if (responseMessage.StatusCode == HttpStatusCode.BadRequest && responseString.Contains("\"errors\":"))
        {
            var validationError = string.Empty;

            try
            {
                var errorResponse = JsonSerializer.Deserialize<ValidationErrors>(responseString, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (errorResponse?.Errors != null)
                {
                    validationError = string.Join("\n", errorResponse.Errors.Select(e => e.Message));
                }
            }
            catch
            {
                validationError = "Cannot read error message from downstream service";
            }

            errorMessage = BadRequestMessage(validationError);
        }

        logger.LogCritical($"Received unsuccessful status code ({responseMessage.StatusCode}) from downstream services - ({url})' with responseContent - ({responseMessage.Content.ReadAsStringAsync().Result})");

        throw responseMessage.StatusCode switch
        {
            HttpStatusCode.BadRequest => new BadHttpRequestException(errorMessage),
            HttpStatusCode.NotFound => new ResourceNotFoundException(errorMessage),
            _ => (TException)Activator.CreateInstance(typeof(TException), errorMessage, responseMessage.StatusCode)!
        };
    }

    /// <summary>
    /// Executes an HTTP POST request asynchronously and deserializes the response content to a specified type.
    /// </summary>
    /// <typeparam name="T">The type to which the response content will be deserialized.</typeparam>
    /// <typeparam name="TException">The type of custom exception to throw in case of an error response.</typeparam>
    /// <param name="client">The HTTP client performing the request.</param>
    /// <param name="requestPath">The endpoint URL path for the request.</param>
    /// <param name="cardTransactionsRequest">The query parameters needed to perform the request.</param>
    /// <param name="logger">The logger for logging the request and any errors.</param>
    /// <returns>A task representing the asynchronous operation, containing the deserialized response.</returns>
    public static async Task<T> SendAsync<T, TException>(this HttpClient client, string requestPath,
        CardTransactionsRequest cardTransactionsRequest, ILogger logger) where T : class where TException : Exception
    {
        var fullUrlPath = client.BaseAddress + "/" + requestPath;

        var serializeOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true
        };

        var serializeRequest = JsonSerializer.Serialize(cardTransactionsRequest, typeof(CardTransactionsRequest), serializeOptions);

        var request = new HttpRequestMessage(HttpMethod.Post, requestPath)
        {
            Content = new StringContent(serializeRequest, Encoding.UTF8, "application/json")
        };

        var responseMessage = await client.SendAsync(request);
        if (!responseMessage.IsSuccessStatusCode)
        {
            responseMessage.RaiseCustomException<TException>(logger, fullUrlPath);
        }

        return await responseMessage.DeserializeResponseContent<T>(logger);
    }
}