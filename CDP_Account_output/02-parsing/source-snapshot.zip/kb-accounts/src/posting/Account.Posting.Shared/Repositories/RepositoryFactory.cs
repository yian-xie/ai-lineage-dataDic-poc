﻿using Account.Posting.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.Posting.Shared.Repositories;

public class RepositoryFactory(
    AccountPostingDbContext dbContext,
    ITmvPostingBatchRepository tmvPostingBatchRepository) : IRepositoryFactory
{
    public AccountPostingDbContext DbContext { get; } = dbContext;
    public IUnitOfWork UnitOfWork { get; } = dbContext;

    public ITmvPostingBatchRepository TmvPostingBatchRepository { get; } =
        tmvPostingBatchRepository;
}