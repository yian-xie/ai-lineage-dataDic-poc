﻿#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Mapping;
using Account.Profile.Processor.Models;
using Account.Profile.Processor.Publishers;
using Account.Profile.Processor.Services;
using Account.Profile.Shared.Constants;
using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Repositories;
using Account.Shared.Configurations;
using Account.Shared.Infrastructure.Exceptions;
using Account.Shared.Services;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Api.Shared.Clients.Events.ThoughtMachine.V1.RestrictionSet;
using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Subscribers;

/// <summary>
/// Consuming TMV Restriction Set events which is related to account profile freeze and unfreeze.
/// Publish the <see cref="AccountProfileEvent"/> after processing the event.
/// </summary>
/// <param name="restrictionSetEventHandlers">A list of implemented <see cref="IRestrictionSetEventHandler"/></param>
/// <param name="sumoLogicClientHelper"><see cref="ISumoLogicClientHelper"/></param>
/// <param name="sumoLogicSettings"><see cref="SumoLogicSettings"/></param>
/// <param name="retrySettings"><see cref="RetrySettings"/></param>
/// <param name="accountProfileEventPublisher"><see cref="IAccountProfileEventPublisher"/></param>
/// <param name="repositoryFactory"><see cref="IRepositoryFactory"/></param>
/// <param name="logger"><see cref="ILogger"/></param>
public class TmvRestrictionEventSubscriber(
    IEnumerable<IRestrictionSetEventHandler> restrictionSetEventHandlers,
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings,
    RetrySettings retrySettings,
    IAccountProfileEventPublisher accountProfileEventPublisher,
    IRepositoryFactory repositoryFactory,
    ILogger<TmvRestrictionEventSubscriber> logger)
    : IIncomingEventSubscriber<RestrictionSetEvent>
{
    /// <summary>
    /// Consuming TMV Restriction Set events.
    /// Expecting RestrictionSetEvent to be either Restriction_set_created or Restriction_set_updated.
    /// </summary>
    /// <param name="context"><see cref="IncomingEventContext"/></param>
    /// <param name="restrictionSetEvent"><see cref="RestrictionSetEvent"/></param>
    /// <param name="cancellationToken"><see cref="CancellationToken"/></param>
    /// <returns><see cref="EventSubscriberResult"/></returns>
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        RestrictionSetEvent restrictionSetEvent,
        CancellationToken cancellationToken)
    {
        Restriction? restriction = null;

        try
        {
            var payload = context.ConsumeResult.Message.Value;

            if (restrictionSetEvent.Restriction_set_created != null)
            {
                restriction = new Restriction(restrictionSetEvent.Event_id,
                    restrictionSetEvent.Change_id,
                    restrictionSetEvent.Restriction_set_created.Restriction_set,
                    restrictionSetEvent.Restriction_set_created.Restriction_set
                        .Effective_timestamp, RestrictionType.Created, payload);
            }
            else if (restrictionSetEvent.Restriction_set_updated != null)
            {
                restriction = new Restriction(restrictionSetEvent.Event_id,
                    restrictionSetEvent.Change_id,
                    restrictionSetEvent.Restriction_set_updated.Restriction_set,
                    restrictionSetEvent.Restriction_set_updated.Restriction_set
                        .Expiry_timestamp, RestrictionType.Updated, payload);
            }

            if (!IsValidRestriction(restriction))
            {
                var exception = new Exception($"Restriction Set Event (EventId: {restrictionSetEvent.Event_id}) has data issue, unable to process.");

                logger.LogError(exception, "Restriction Set Event: {@RestrictionSetEvent}", restrictionSetEvent);

                await RaiseSumoLogicAlertAsync(restrictionSetEvent.Event_id, exception, cancellationToken);

                return new MoveToDlqEventSubscriberResult(exception);
            }

            var accountProfile =
            await repositoryFactory.AccountProfileRepository.GetAccountAsync(
                restriction!.RestrictionSet.Account_id,
                cancellationToken);

            if (accountProfile == null)
            {
                logger.LogWarning("""
                                Received Restriction Set {type} Event (EventId: {eventId}) for non-existing account profile (AccountId: {accountId}).
                                Restriction Set Event: {@Restriction}
                                """, restriction.Type, restriction.EventId, restriction.RestrictionSet.Account_id, restriction);

                throw new Exception($"AccountProfile (AccountId: {restriction.RestrictionSet.Account_id}) does not exist. Force Restriction Set {restriction.Type} Event retry (EventId: {restriction.EventId}).");
            }

            if (accountProfile.Restrictions.Any(x => x.EventId == restriction.EventId))
            {
                logger.LogWarning(
                    """
                    Skipping duplicate Restriction Set Event (EventId: {EventId}).
                    Restriction Set Event: {@RestrictionSetEvent}
                    """,
                    restriction.EventId, restrictionSetEvent);

                return EventSubscriberResults.Skip;
            }

            var isCurrentlyFrozen = accountProfile.Status == nameof(AccountStatus.Frozen);
            var eventHandler = GetRestrictionSetEventHandler(restriction.Type);
            var isHandled = eventHandler.Handle(accountProfile, restriction);

            EventSubscriberResult result;

            if (!isHandled)
            {
                var exception = new Exception($"Failed to process Restriction Set Event (EventId: {restrictionSetEvent.Event_id}). Skipping it.");

                logger.LogError(exception, "Restriction Set Event: {@RestrictionSetEvent}", restrictionSetEvent);

                await RaiseSumoLogicAlertAsync(restrictionSetEvent.Event_id, exception, cancellationToken);

                result = EventSubscriberResults.Skip;
            }
            else
            {
                if (!RestrictionSetEventHelper.ShouldSuppressProfileEvent(isCurrentlyFrozen, restriction, logger))
                {
                    await accountProfileEventPublisher.PublishAccountProfileEventAsync(accountProfile,
                        MetadataType.AccountUpdated,
                        restriction.Time!.Value,
                        null,
                        repositoryFactory.UnitOfWork,
                        cancellationToken);
                }

                logger.LogInformation(
                    "Successfully processed Restriction Set Event (EventId: {EventId}) for AccountId: {AccountId}",
                    restrictionSetEvent.Event_id, accountProfile.AccountId);

                result = EventSubscriberResults.Success;
            }

            await SaveAccountProfileWithRestrictionAsync(accountProfile, restriction, cancellationToken);

            return result;
        }
        catch (Exception ex)
        {
            logger.LogError(
                ex,
                """
                Failed to process Restriction Set Event (EventId: {EventId}). Retrying the message in {RedeliveryInterval} seconds.
                Restriction Set Event: {@Restriction}
                """, restrictionSetEvent.Event_id, retrySettings.RedeliveryInterval, restrictionSetEvent);

            // If the retry attempts has exceeded the threshold, raise sumo logic alert
            if (context.DeliveryAttempt > retrySettings.RetryAttemptAlertThreshold)
            {
                await RaiseSumoLogicAlertAsync(restrictionSetEvent.Event_id, ex, cancellationToken);
                // Temporary hot-fix to clear bad data out of the topic.
                //return new MoveToDlqEventSubscriberResult(ex);
            }

            return new RedeliverMessageEventSubscriberResult(retrySettings.RedeliveryInterval);
        }
    }

    /// <summary>
    /// Ingest log into SumoLogic when failed to process the Restriction Set Event.
    /// </summary>
    /// <param name="eventId">Restriction Set Event ID</param>
    /// <param name="ex"><see cref="Exception"/></param>
    /// <param name="cancellationToken"><see cref="CancellationToken"/></param>
    private async Task RaiseSumoLogicAlertAsync(
        string eventId,
        Exception? ex,
        CancellationToken cancellationToken)
    {
        try
        {
            await sumoLogicClientHelper.IngestLogAsync(
                $"Failed to process Restriction Set Event (EventId: {eventId}). Exception: {ex}",
                sumoLogicSettings.SourceCategory,
                sumoLogicSettings.SourceName + Constants.SumoSourceNames.TmvRestrictionSetEventSubscriber,
                sumoLogicSettings.ApiToken,
                cancellationToken);
        }
        catch (Exception nestedEx)
        {
            logger.LogError(
                nestedEx,
                "Failed to push log into SumoLogic for failed processing of Restriction Set Event (EventId: {EventId})", eventId);
        }
    }

    /// <summary>
    /// Get the corresponding <see cref="IRestrictionSetEventHandler"/> based on the RestrictionType of the incoming Restriction Set Event.
    /// </summary>
    /// <param name="handlerType"><see cref="RestrictionType"/></param>
    /// <returns><see cref="IRestrictionSetEventHandler"/></returns>
    /// <exception cref="AccountDomainException">Throw when there is no matched handler for the incoming Restriction Set Event.</exception>
    private IRestrictionSetEventHandler GetRestrictionSetEventHandler(
        RestrictionType handlerType)
    {
        return restrictionSetEventHandlers.FirstOrDefault(x => x.Type == handlerType)
            ?? throw new AccountDomainException($"No handler found for RestrictionSetEventHandlerType {handlerType}.");
    }

    /// <summary>
    /// Create <see cref="AccountRestriction"/> entity from the processed Restriction Set event.
    /// </summary>
    /// <param name="restriction"><see cref="Restriction"/></param>
    /// <returns><see cref="AccountRestriction"/></returns>
    private static AccountRestriction CreateAccountRestriction(Restriction restriction)
    {
        return new AccountRestriction
        {
            EventId = restriction.EventId,
            RestrictionSetId = restriction.RestrictionSet.Id,
            ChangeId = restriction.ChangeId,
            EffectiveAt = restriction.RestrictionSet.Effective_timestamp,
            ExpiryAt = restriction.RestrictionSet.Expiry_timestamp,
            ProcessingAt = DateTimeOffset.UtcNow,
            Type = FreezeTypeMapper.GetFreezeType(restriction.RestrictionSet.Restriction_set_definition_id),
            Description = restriction.RestrictionSet.Description,
            RestrictionSetEventPayload = restriction.Payload,
            IsActive = restriction.RestrictionSet.Is_active ?? false
        };
    }

    /// <summary>
    /// Persist the processed Restriction Set event into account_restriction table.
    /// TODO: We save the account freeze details in account_profile table, we are going to remove it.
    /// </summary>
    /// <param name="accountProfile"><see cref="AccountProfile"/></param>
    /// <param name="restriction"><see cref="Restriction"/></param>
    /// <param name="cancellationToken"></param>
    private async Task SaveAccountProfileWithRestrictionAsync(
        AccountProfile accountProfile,
        Restriction restriction,
        CancellationToken cancellationToken)
    {
        var accountRestriction = CreateAccountRestriction(restriction);
        accountProfile.Restrictions.Add(accountRestriction);
        repositoryFactory.AccountProfileRepository.Update(accountProfile);
        await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);
    }

    private static bool IsValidRestriction(Restriction? restriction)
    {
        return restriction != null && restriction.Time.HasValue;
    }
}