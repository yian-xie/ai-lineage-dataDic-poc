﻿using Account.Shared.Database;

using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.PaymentInstruction.Shared.Infrastructure.EntityConfigurations;

public class
    PaymentInstructionEntityTypeConfiguration : AccountBaseEntityTypeConfiguration<
    Entities.PaymentInstruction, PaymentInstructionDbContext>
{
    protected override string TableName => "payment_instruction";

    protected override void ConfigureTable(EntityTypeBuilder<Entities.PaymentInstruction> builder)
    {
        builder.HasKey(t => new { t.ClientId, BatchId = t.ClientBatchId });
    }
}