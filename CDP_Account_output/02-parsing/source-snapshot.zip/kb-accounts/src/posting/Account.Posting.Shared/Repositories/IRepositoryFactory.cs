﻿using Account.Posting.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.Posting.Shared.Repositories;

public interface IRepositoryFactory
{
    AccountPostingDbContext DbContext { get; }
    IUnitOfWork UnitOfWork { get; }
    ITmvPostingBatchRepository TmvPostingBatchRepository { get; }
}