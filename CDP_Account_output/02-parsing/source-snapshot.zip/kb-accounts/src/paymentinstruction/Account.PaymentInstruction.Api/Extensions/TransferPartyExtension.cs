﻿using System.Collections.Generic;

using Account.PaymentInstruction.Api.Constants;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchRequest;

using TransactionType = Account.PaymentInstruction.Api.Queries.Types.TransactionType;
using TransferParty = Account.PaymentInstruction.Api.Queries.Types.TransferParty;

namespace Account.PaymentInstruction.Api.Extensions;

public static class TransferPartyExtension
{
    public static InstructionDetails ToInstructionDetailsCredit(
        this TransferParty transfer,
        TransactionType type)
    {
        var instructionDetails = transfer.ToInstructionDetails(type);
        instructionDetails.AdditionalProperties[InstructionDetailsKeys.TransactionCodeCode] = InstructionDetailsValues.TransactionCodeCodeCredit;
        instructionDetails.AdditionalProperties[InstructionDetailsKeys.TransactionCodeSourceCode] = InstructionDetailsValues.TransactionCodeSourceCodeCredit;

        instructionDetails.AdditionalProperties[InstructionDetailsKeys.PaymentInstructionCategory] =
            InstructionDetailsValues.PaymentInstructionCategoryIntraCoreTransfer;

        instructionDetails.AdditionalProperties[InstructionDetailsKeys.PaymentInstructionLeg] =
            InstructionDetailsValues.PaymentInstructionLegCredit;

        return instructionDetails;
    }

    public static InstructionDetails ToInstructionDetailsDebit(
        this TransferParty transfer,
        TransactionType type)
    {
        var instructionDetails = transfer.ToInstructionDetails(type);
        instructionDetails.AdditionalProperties[InstructionDetailsKeys.TransactionCodeCode] = InstructionDetailsValues.TransactionCodeCodeDebit;
        instructionDetails.AdditionalProperties[InstructionDetailsKeys.TransactionCodeSourceCode] = InstructionDetailsValues.TransactionCodeSourceCodeDebit;

        instructionDetails.AdditionalProperties[InstructionDetailsKeys.PaymentInstructionCategory] =
            InstructionDetailsValues.PaymentInstructionCategoryIntraCoreTransfer;

        instructionDetails.AdditionalProperties[InstructionDetailsKeys.PaymentInstructionLeg] =
            InstructionDetailsValues.PaymentInstructionLegDebit;

        return instructionDetails;
    }

    public static InstructionDetails ToInstructionDetails(
        this TransferParty transfer,
        TransactionType type)
    {
        return new InstructionDetails
        {
            AdditionalProperties = new Dictionary<string, object> {
                { InstructionDetailsKeys.Type, type.ToString() },
                { InstructionDetailsKeys.Particulars, transfer.Particulars },
                { InstructionDetailsKeys.Code, transfer.Code },
                { InstructionDetailsKeys.Reference, transfer.Reference }
            }
        };
    }
}