﻿using Account.Shared.Services;
using Account.TopicLogger.Processor.Configurations;
using Account.TopicLogger.Processor.Services;

using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.TopicLogger.Processor.Subscribers;

public class TmvDlqEventSubscriber(
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings,
    IDynatraceMetricsClientHelper dynatraceMetricsClientHelper)
    : IIncomingEventSubscriber<DlqTopicEmptyEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        DlqTopicEmptyEvent @event,
        CancellationToken cancellationToken)
    {
        var result = context.ConsumeResult;

        await Task.WhenAll(
            dynatraceMetricsClientHelper.IngestMetricAsync(result.Topic, cancellationToken),
            sumoLogicClientHelper.IngestLogAsync(
                result.Message.Value,
                sumoLogicSettings.SourceCategory + SumoLogicSourceCategories.OperationalLogs,
                sumoLogicSettings.SourceName + SumoLogicSourceNames.DlqTopic,
                sumoLogicSettings.ApiToken,
                cancellationToken));

        return EventSubscriberResults.Success;
    }
}