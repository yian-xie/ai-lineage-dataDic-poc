﻿using System.Threading;
using System.Threading.Tasks;

namespace Account.Spud.Api.Services;

public interface IAccountCloser
{
    Task CloseAccountAsync(string accountId, string? correlationId, CancellationToken cancellationToken);
}