﻿using System.Net;

namespace Account.Transaction.Api.Queries.Exceptions;

/// <summary>
/// RequiredContextLocalStateInvalidException is thrown when required context local state is invalid.
/// </summary>
public class RequiredContextLocalStateInvalidException : TransactionExceptionBase
{
    /// <summary>
    /// RequiredContextLocalStateInvalidException constructor.
    /// </summary>
    /// <param name="message">The error message</param>
    public RequiredContextLocalStateInvalidException(string message) : base(message) { }

    /// <summary>
    /// RequiredContextLocalStateInvalidException constructor with status code.
    /// </summary>
    /// <param name="message">The error message</param>
    /// <param name="statusCode"><see cref="HttpStatusCode"/></param>
    public RequiredContextLocalStateInvalidException(string message, HttpStatusCode statusCode) : base(message, statusCode) { }
}