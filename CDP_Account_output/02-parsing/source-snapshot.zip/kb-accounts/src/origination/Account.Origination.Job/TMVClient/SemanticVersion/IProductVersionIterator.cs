﻿namespace Account.Origination.Job.TMVClient.SemanticVersion;

public interface IProductVersionIterator
{
    Task<string?> ResolveAsync(
        string productId,
        string version,
        CancellationToken cancellationToken);
}