﻿namespace Account.Shared.Constants.Observability;

public static class MetricNames
{
    public const string TmvApiGetAccountDurationMetric = "tmv-api-get-account-duration";
}