﻿using System;
using System.Globalization;
using System.Linq;

using Account.Transaction.Api.Queries.Types;

using AccountTransactionEntity = Account.Transaction.Shared.Entities.AccountTransaction;

namespace Account.Transaction.Api.Queries.Mapping;

/// <summary>
///     Provide mapping functionality to map <see cref="AccountTransactionEntity" /> to <see cref="AccountTransaction" />.
/// </summary>
public class TmvTransactionMapper : ITransactionMapper<AccountTransactionEntity, AccountTransaction>
{
    /// <summary>
    ///     Mapping the <see cref="AccountTransactionEntity"/> to <see cref="AccountTransaction" />.
    /// </summary>
    /// <param name="query"><see cref="IQueryable{TSource}" /> where TSource is <see cref="AccountTransactionEntity"/></param>
    /// <param name="accountId"></param>
    /// <returns><see cref="IQueryable{TTarget}" /> where TTarget is <see cref="AccountTransaction" /></returns>
    public IQueryable<AccountTransaction> MapTo(
        IQueryable<AccountTransactionEntity> query,
        string accountId)
    {
        return query.Select(x => new AccountTransaction
        {
            Id = x.Id,
            TransactionId = x.Id.ToString(),
            InitiationInstructionId = x.InitiationInstructionId,
            AccountId = x.AccountId,
            PaymentId = x.PaymentId,
            AccountNumber = x.AccountNumber.ToAccountNumber(),
            AccountNumberDisplay = x.AccountNumber.ToAccountNumberDisplay(),
            TransactionDescription = x.TransactionDescription,
            IsoTransactionCode = new IsoTransactionCode
            {
                Domain = x.IsoTransactionCode.Domain,
                Family = x.IsoTransactionCode.Family,
                SubFamily = x.IsoTransactionCode.SubFamily
            },
            FinancialTransactionAmount = new Money
            {
                Value = x.FinancialTransactionAmount.ToString(CultureInfo.InvariantCulture),
                Currency = GetCurrency(x.FinancialTransactionCurrencyCode)
            },
            Status = Enum.Parse<Status>(x.Status, true),
            CreditDebitIndicator =
                    Enum.Parse<CreditDebitIndicator>(x.CreditDebitIndicator, true),
            ValueDateTime = x.ValueDateTime,
            BookingDateTime = x.BookingDateTime,
            OtherPartyName = x.OtherPartyName,
            OtherPartyAccount = x.OtherPartyAccount != null
                    ? new PartyAccount
                    {
                        AccountIdentification = x.OtherPartyAccount.AccountIdentification.ToAccountNumber(),
                        AccountIdentificationDisplay = x.OtherPartyAccount.AccountIdentification.ToAccountNumberDisplay(),
                        AccountIdentificationType = x.OtherPartyAccount.AccountIdentificationType
                    }
                    : null,
            OtherPartyReference = x.OtherPartyReference != null
                    ? new PartyReference
                    {
                        Particulars = x.OtherPartyReference.Particulars,
                        Code = x.OtherPartyReference.Code,
                        Reference = x.OtherPartyReference.Reference
                    }
                    : null,
            ThisPartyReference = x.ThisPartyReference != null
                    ? new PartyReference
                    {
                        Particulars = x.ThisPartyReference.Particulars,
                        Code = x.ThisPartyReference.Code,
                        Reference = x.ThisPartyReference.Reference
                    }
                    : null,
            AccountBalanceInterimBooked =
                    x.AccountBalanceInterimBookedAmount != null &&
                    x.AccountBalanceInterimBookedCurrencyCode != null
                        ? new Money
                        {
                            Value = x.AccountBalanceInterimBookedAmount.ToString() ?? "0",
                            Currency = GetCurrency(x.AccountBalanceInterimBookedCurrencyCode)
                        }
                        : null,
            PaymentInstructionCategory = x.PaymentInstructionCategory,
            TransactionCode = x.TransactionCode,
            TaxDeduction = x.TaxDeduction != null ? new TaxDeduction
            {
                DomesticTaxType = x.TaxDeduction.DomesticTaxType != null ? GetDomesticTaxType(x.TaxDeduction.DomesticTaxType) : null,
                TaxRateValue = x.TaxDeduction.TaxRateValue,
                NominatedTaxPartyId = x.TaxDeduction.NominatedTaxPartyId,
                NonResidentWithholdingTaxCountryAlpha3Code = x.TaxDeduction.NonResidentWithholdingTaxCountryAlpha3Code
            } : null,
            Index = x.BatchInstructionIndex,
            IndustryTransactionCode = x.IndustryTransactionCode,
            InputSourceCode = x.InputSourceCode,
            OriginatingBank = x.OriginatingBank,
            OriginatingBranch = x.OriginatingBranch,
            BatchNumber = x.BatchNumber,
            AuthorisationCode = x.AuthorisationCode,
            Branch = x.Branch,
            Operator = x.Operator,
            LegacyCoreTransactionId = x.LegacyCoreTransactionId,
            InsertionDateTime = x.InsertionDateTime
        })
            .AsQueryable();
    }

    /// <summary>
    ///     Get the <see cref="Currency" /> by the given currency code in string.
    /// </summary>
    /// <param name="currencyCode">ISO 4217 currency code in string format</param>
    /// <returns>
    ///     <see cref="Currency" />
    /// </returns>
    /// <exception cref="InvalidOperationException">The given currency code is not one of the <see cref="Currency" />.</exception>
    private static Currency GetCurrency(string currencyCode)
    {
        if (Enum.TryParse<Currency>(currencyCode, true, out var currency))
        {
            return currency;
        }

        throw new InvalidOperationException($"Invalid currency code: {currencyCode}.");
    }

    /// <summary>
    /// Get the <see cref="DomesticTaxType"/> by the given domestic tax type value in string.
    /// </summary>
    /// <param name="domesticTaxTypeVal">Domestic Tax Type value in string</param>
    /// <returns><see cref="DomesticTaxType"/></returns>
    /// <exception cref="InvalidOperationException">The given domestic tax type is not one of the <see cref="DomesticTaxType"/>.</exception>
    private static DomesticTaxType GetDomesticTaxType(string domesticTaxTypeVal)
    {
        if (Enum.TryParse<DomesticTaxType>(domesticTaxTypeVal, true, out var domesticTaxType))
        {
            return domesticTaxType;
        }

        throw new InvalidOperationException($"Invalid Domestic Tax Type: {domesticTaxTypeVal}.");
    }
}