﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using Enterprise.Shared.Database;

namespace Account.Posting.Processor.Publishers;

/// <summary>
///     Represents an interface for publishing AccountPostingEvent.
/// </summary>
public interface IAccountPostingEventOutboxPublisher
{
    /// <summary>
    ///     Publish AccountPostingEvent.
    /// </summary>
    /// <param name="postingBatchEvent">
    ///     <see cref="PostingBatchEvent" />
    /// </param>
    /// <param name="unitOfWork"></param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns></returns>
    Task PublishAsync(
        PostingBatchEvent postingBatchEvent,
        IUnitOfWork unitOfWork,
        CancellationToken cancellationToken
    );
}