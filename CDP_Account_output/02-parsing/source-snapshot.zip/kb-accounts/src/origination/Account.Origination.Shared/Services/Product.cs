﻿namespace Account.Origination.Shared.Services;

public static class Product
{
    public const string Sv1 = "SV1";
    public const string Spud = "spud";
}