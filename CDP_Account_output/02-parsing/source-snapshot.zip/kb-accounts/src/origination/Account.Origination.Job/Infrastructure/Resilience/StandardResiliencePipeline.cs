﻿using System.Text.Json;

using Account.Origination.Job.Configurations;

using Microsoft.Extensions.Options;

using Polly;
using Polly.Retry;
using Polly.Timeout;
namespace Account.Origination.Job.Infrastructure.Resilience;

/// <summary>
///     Represents a standard resilience pipeline for encapsulating resilience policies
///     to handle transient errors and retries within a specified execution strategy.
/// </summary>
/// <typeparam name="TResult">The type of the result returned by the pipeline execution.</typeparam>
/// <typeparam name="TStrategy">The type of the resilience strategy implementing <see cref="IResilienceExceptionStrategy" />.</typeparam>
/// <typeparam name="TLoggerCategory">The type category used for logging purposes.</typeparam>
public class StandardResiliencePipeline<TResult, TStrategy, TLoggerCategory> : IStandardResiliencePipeline<TResult, TStrategy, TLoggerCategory>
    where TStrategy : IResilienceExceptionStrategy
{
    private const string PayloadKey = "Payload";
    public ResiliencePipeline<TResult> Pipeline { get; }

    public StandardResiliencePipeline(
        ILogger<TLoggerCategory> logger,
        IOptions<ResilienceOptions> options,
        TStrategy strategy)
    {
        var retryAttempts = options.Value.RetryAttempts;
        var timeoutAfterSec = options.Value.TimeoutAfterSeconds;
        var retryDelay = options.Value.RetryDelaySeconds;
        var useJitter = options.Value.UseJitter;

        var builder = new ResiliencePipelineBuilder<TResult>();

        var predicateBuilder = new PredicateBuilder<TResult>().Handle<Exception>(strategy.ShouldRetry);

        builder
            .AddRetry(new RetryStrategyOptions<TResult>
            {
                MaxRetryAttempts = retryAttempts,
                BackoffType = DelayBackoffType.Exponential,
                Delay = TimeSpan.FromSeconds(retryDelay),
                UseJitter = useJitter,
                ShouldHandle = predicateBuilder,
                OnRetry = args =>
                {
                    args.Context.Properties.TryGetValue(new ResiliencePropertyKey<string>(PayloadKey), out var payload);

                    var payloadLog = !string.IsNullOrWhiteSpace(payload) ? $" with payload: {payload}" : string.Empty;

                    logger.LogWarning($"[Polly] Retry {args.AttemptNumber}{payloadLog} after {args.Duration}s due to: {args.Outcome.Exception?.Message}");

                    return ValueTask.CompletedTask;
                }
            })
            .AddTimeout(new TimeoutStrategyOptions
            {
                Timeout = TimeSpan.FromSeconds(timeoutAfterSec),
                OnTimeout = args =>
                {
                    logger.LogWarning($"[Polly] Request invocation timed out after {args.Timeout.TotalSeconds} seconds");
                    return ValueTask.CompletedTask;
                }
            });

        Pipeline = builder.Build();
    }

    public async Task<TResult> ExecuteAsync(Func<CancellationToken, Task<TResult>> callback, CancellationToken cancellationToken, object? state = null)
    {
        var context = ResilienceContextPool.Shared.Get(cancellationToken);

        if (state != null)
        {
            var payload = JsonSerializer.Serialize(state);
            context.Properties.Set(new ResiliencePropertyKey<string>(PayloadKey), payload);
        }

        try
        {
            return await Pipeline.ExecuteAsync(static async (context, state) => await state(context.CancellationToken), context, callback);
        }
        finally
        {
            ResilienceContextPool.Shared.Return(context);
        }
    }
}