﻿using Account.Origination.Job.AccountNumberMiddleware;
using Account.Origination.Job.Infrastructure.Factories;
using Account.Origination.Job.Infrastructure.Resilience;

namespace Account.Origination.Job.Services;

public class AccountNumberAllocationService(
    IWcfChannelFactory<IInvokeAccountChannel> invokeAccountChannelFactory,
    IStandardResiliencePipeline<AllocateAccountNumberResponse, MiddlewareResilienceStrategy, AccountNumberAllocationService> resiliencePipeline,
    ILogger<AccountNumberAllocationService> logger) : IAccountNumberAllocationService
{
    public async Task<long> AllocateAccountNumberAsync(
        int accessNumber,
        string productCode,
        CancellationToken cancellationToken)
    {
        using var wcfChannel = invokeAccountChannelFactory.CreateChannel();

        try
        {
            var result = await resiliencePipeline.ExecuteAsync(async _ =>
                    await wcfChannel.AllocateAccountNumberAsync(new AllocateAccountNumberRequest
                    {
                        AccessNumber = accessNumber,
                        CoreSystem = CoreSystemEnum.TMV,
                        ProductCode = productCode
                    }
                    ),
                cancellationToken,
                new
                {
                    accessNumber,
                    productCode
                });

            if (result.Success)
            {
                return result.AccountNumber;
            }

            var errors = string.Join(", ", result.Errors.Select(e => e.Message));

            logger.LogError(
                "Failed to allocate account number. Errors: {errors}", errors);

            throw new Exception($"Failed to allocate account number. Errors: {errors}");
        }
        catch (Exception e)
        {
            logger.LogError(e, "Failed to invoke AllocateAccountNumber Middleware call");

            throw;
        }
    }
}