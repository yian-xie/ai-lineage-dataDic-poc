﻿using System;

using Account.Shared.Entities;

namespace Account.Profile.Shared.Entities;

public class AccountProfileIdentifier : AccountBaseConcurrentEntity
{
    public Guid RowId { get; set; }
    public string AccountIdentification { get; set; }
    public string AccountIdentificationType { get; set; }
    public AccountProfile Profile { get; set; }
}