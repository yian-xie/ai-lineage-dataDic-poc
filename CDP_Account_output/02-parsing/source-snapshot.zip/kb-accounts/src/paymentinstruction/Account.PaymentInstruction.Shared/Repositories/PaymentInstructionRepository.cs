﻿#nullable enable

using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Shared.Infrastructure;

using Enterprise.Shared.Database;

using Microsoft.EntityFrameworkCore;

namespace Account.PaymentInstruction.Shared.Repositories;

public class PaymentInstructionRepository(PaymentInstructionDbContext dbContext)
    : RepositoryBase<PaymentInstructionDbContext>(dbContext),
        IPaymentInstructionRepository
{
    public void Add(Entities.PaymentInstruction paymentInstruction)
    {
        DbContext.Add(paymentInstruction);
    }

    public async Task<Entities.PaymentInstruction?> GetAsync(
        string clientBatchId,
        string clientId,
        CancellationToken cancellationToken)
    {
        return await DbContext.PaymentInstructions
            .Where(x => x.ClientBatchId == clientBatchId && x.ClientId == clientId)
            .FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<Entities.PaymentInstruction[]> GetAsync(
        string transactionId,
        CancellationToken cancellationToken)
    {
        return await DbContext.PaymentInstructions
            .Where(x => x.TransactionId == transactionId)
            .ToArrayAsync(cancellationToken);
    }
}