## Service Summary

| Field | Details |
|---|---|
| Business purpose | Provides authorised customers and staff with TMV, credit-card, and Ultracs transaction history through GraphQL. |
| Runtime | .NET ASP.NET Core and Hot Chocolate GraphQL; image `accounts/account/transaction-api`. |
| Source | `src/transaction/Account.Transaction.Api` |
| Pipeline | `src/transaction/.pipelineconfig/pipeline.yaml`; deployment values in `src/transaction/Deploy/Account.Transaction.Api` |
| Last reviewed | 2026-10-05 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. OAuth-protected `transactionsV2` requests arrive at `/api/accounts-transaction/graphql`; middleware supplies account and access context.
2. ADDS resolves account origination; `nc_` and `cc_` context routes the request to PostgreSQL/TMV, Cards Transaction API, or Ultracs Proxy API.
3. The resolver validates dates, filters, sorts, pages, records telemetry, and returns the GraphQL result.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Data store | PostgreSQL `account_transaction`, schema `transaction` | TMV transaction reads and SQL readiness | `ConnectionStrings__DefaultConnection`; `AccountTransactionDbContext` |
| Outbound API | Account Domain Directory Service | Resolve account origination and authorisation context | `WebApiClientOptions__BaseUrl` |
| Outbound API | Cards Transaction API | Retrieve `cc_` account transactions over mTLS | `CardsClientOptions`; deployment mTLS settings |
| Outbound API | Ultracs Proxy API and Azure AD | Retrieve Ultracs transactions and authorisations | `UltracsClientOptions`; `AzureAdTokenOptions` |
| Platform | Apollo Federation, Dynatrace, and Sumo Logic | Schema publication and observability | pipeline API settings and repository observability links |

### Interfaces and Schedule

- GraphQL: `POST /api/accounts-transaction/graphql`, operation `transactionsV2`; OAuth 2.0 with app roles `access-kb-customer` or `access-nzhl-customer`.
- Health: `GET /health/liveness` and `GET /health/readiness` on container port 8080; readiness includes SQL health.
- No schedule. Requests are synchronous. The service does not consume Kafka events.
- ACCEPT host: `accept-accounts-transaction.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz`. It is an internal host and laptop reachability is unverified. [TODO: confirm VPN/private-DNS or other access requirements.]

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| `Graphql__IntrospectionEnabled`, `Graphql:Path` | GraphQL exposure | Introspection enabled in ACCEPT and disabled in production values; path is `/api/accounts-transaction/graphql`. |
| `PagingOptions` and `TransactionApi` | Page limits and `nc_`/`cc_` routing | Defaults: 10 items; maximum: 100. |
| `CardsClientOptions` | Cards base URL, path, and 25-second timeout | mTLS material is supplied through deployment configuration. |
| `UltracsClientOptions`, `AzureAdTokenOptions` | Ultracs endpoint and OAuth client | Secret key: `AzureAdTokenOptions__ClientSecret`. |
| `ConnectionStrings__DefaultConnection` | PostgreSQL connectivity | Secret values are injected by the deployment platform. |
| `Kafka__*` | Shared Kafka/outbox infrastructure configuration | Secret keys include SASL username/password and schema-registry API key/secret. |

Environments map to namespaces `accept-transaction-api`, `situat-transaction-api`, `perf0-transaction-api`, `preprod-transaction-api`, and `prod-transaction-api`, all with release `transaction-api`.

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `/health/liveness` | HTTP 200; process is responsive | Probe fails or pods restart. |
| `/health/readiness` | HTTP 200; SQL dependency is healthy | Probe fails for three consecutive five-second periods. |
| GraphQL availability and success | Availability at or above the repository alert threshold of 99.85%; success at or above 99.9% | SLO alert fires or 5xx errors increase. |
| GraphQL response time | 99th percentile at or below one second | Repository response-time alert fires. |
| Downstream metrics and synthetics | ADDS, Cards, and Ultracs calls remain at baseline and environment synthetics pass | Error count, latency, or partial responses rise. |

Observability: <ul><li>[Account Transaction API Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5317033985/Account+Transaction+API+Observability+Dashboard)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33944146)</li></ul>

Non-production verification request: `GET https://accept-accounts-transaction.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz/health/readiness`; expected HTTP 200. Authentication and laptop access are unverified. [TODO: confirm the supported access path and expected response body.]

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the pipeline built `accounts/account/transaction-api`, exported the GraphQL schema, and passed the Account.Transaction.Api unit and integration stages.
2. Review changes to the GraphQL schema, database migrations, ADDS/Cards/Ultracs configuration, mTLS material names, and secret-key mappings.

### After Deployment

1. In the target namespace, confirm the `transaction-api` release reaches its configured replica count and liveness/readiness probes remain healthy.
2. In ACCEPT or the promoted non-production environment, confirm the appropriate TMV, Credit Card, and Ultracs synthetic checks and GraphQL telemetry remain healthy. No endpoint was executed while generating this runbook.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

Use the repository deployment pipeline and environment-specific Helm values. Stop promotion when readiness, GraphQL SLOs, or source-specific synthetics regress. Prefer a fix forward for compatible application/configuration changes; [TODO: confirm the approved pipeline rollback command or UI procedure and decision authority.]

### Recovery Validation

1. Verify liveness and SQL-backed readiness in ACCEPT or the affected non-production environment, then confirm stable pods and no correlated SQL errors.
2. Confirm valid GraphQL operations for every affected source through repository-owned synthetics and verify error rate and latency return to baseline.

Operational guardrail: Do not expose account IDs, access numbers, tokens, certificate values, or GraphQL request variables in incident communications; do not change database state or mTLS/OAuth secrets without an approved procedure.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Account.Transaction.Api source](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Account.Transaction.Api) |
| Dashboards and logs | <ul><li>[Account Transaction API Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5317033985/Account+Transaction+API+Observability+Dashboard)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33944146)</li></ul> |
| Minimum Standard for Runbooks | [Account Domain Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |