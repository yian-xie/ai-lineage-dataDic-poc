﻿using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Infrastructure.EntityConfigurations;
using Account.Shared.Constants;
using Account.Shared.Database;

using Enterprise.Shared.Database.Configurations;

using Microsoft.EntityFrameworkCore;

namespace Account.Profile.Shared.Infrastructure;

public class AccountProfileDbContext(
    DbContextOptions<AccountProfileDbContext> options,
    CustomDbContextOptions customDbContextOptions)
    : AccountBaseDbContext<AccountProfileDbContext>(options, customDbContextOptions),
        IDbContextSchemaName
{
    public DbSet<AccountProfile> AccountProfiles { get; set; }

    public static string SchemaName()
    {
        return DatabaseSchemaName.Profile;
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfiguration(new AccountProfileEntityTypeConfiguration());
    }
}