﻿
using Enterprise.Shared.Configuration;

namespace Account.Transaction.Api.Configurations;

/// <summary>
/// Configuration options for acquiring Azure AD tokens.
/// </summary>
public class AzureAdTokenOptions : IKeyedConfigurationSection
{

    /// <summary>
    ///     The base url of Azure Ad authentication
    /// </summary>
    public required string BaseUrl { get; set; }

    /// <summary>
    ///     The tenant ID for Azure AD authentication.
    /// </summary>
    public required string TenantId { get; set; }

    /// <summary>
    ///     The client ID for Azure AD authentication.
    /// </summary>
    public required string ClientId { get; set; }

    /// <summary>
    ///     The client secret for Azure AD authentication.
    /// </summary>
    public required string ClientSecret { get; set; }

    /// <summary>
    ///     The scopes required for acquiring Azure AD tokens.
    /// </summary>
    public required string[] Scopes { get; set; }

    /// <summary>
    ///     Azure AD token options configuration key.
    /// </summary>
    public static string Key => "AzureAdTokenOptions";
}