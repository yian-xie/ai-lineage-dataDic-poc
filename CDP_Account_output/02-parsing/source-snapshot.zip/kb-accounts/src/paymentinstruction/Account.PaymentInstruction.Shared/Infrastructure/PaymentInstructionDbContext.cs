﻿using Account.PaymentInstruction.Shared.Entities;
using Account.PaymentInstruction.Shared.Infrastructure.EntityConfigurations;
using Account.Shared.Constants;
using Account.Shared.Database;

using Enterprise.Shared.Database.Configurations;

using Microsoft.EntityFrameworkCore;

namespace Account.PaymentInstruction.Shared.Infrastructure;

public class PaymentInstructionDbContext(
    DbContextOptions<PaymentInstructionDbContext> options,
    CustomDbContextOptions customDbContextOptions)
    : AccountBaseDbContext<PaymentInstructionDbContext>(options, customDbContextOptions),
        IDbContextSchemaName
{
    public DbSet<Entities.PaymentInstruction> PaymentInstructions { get; set; }

    public DbSet<PaymentInstructionStatus> PaymentInstructionStatuses { get; set; }

    public static string SchemaName()
    {
        return DatabaseSchemaName.Paymentinstruction;
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfiguration(new PaymentInstructionEntityTypeConfiguration());
        builder.ApplyConfiguration(new PaymentInstructionStatusEntityTypeConfiguration());
    }
}