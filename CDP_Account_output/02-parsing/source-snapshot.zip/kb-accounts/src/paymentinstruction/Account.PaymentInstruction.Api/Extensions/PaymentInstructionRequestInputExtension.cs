﻿using System.Collections.Generic;
using System.Globalization;

using Account.Shared;
using Account.Shared.Constants;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchRequest;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Extensions;

using Input = PaymentInstructionRequestInput;

public static class PaymentInstructionRequestInputExtension
{
    public static List<PostingInstruction> ToPostingInstructions(this Input input)
    {
        var creditInstructionDetail = input
            .PaymentInstruction
            .Transfer
            .Credit
            .ToInstructionDetailsCredit(input.PaymentInstruction.Type);

        var debitInstructionDetail = input
            .PaymentInstruction
            .Transfer
            .Debit
            .ToInstructionDetailsDebit(input.PaymentInstruction.Type);

        return new List<PostingInstruction> {
            new() {
                Client_transaction_id = $"{input.PaymentInstruction.TransactionId}_credit",
                Inbound_hard_settlement = input.ToInboundHardSettlement(),
                Instruction_details = creditInstructionDetail
            },
            new() {
                Client_transaction_id = $"{input.PaymentInstruction.TransactionId}_debit",
                Outbound_hard_settlement = input.ToOutboundHardSettlement(),
                Instruction_details = debitInstructionDetail
            }
        };
    }

    public static HardSettlement ToOutboundHardSettlement(this Input input)
    {
        var outboundHardSettlement = input.ToHardSettlement();

        outboundHardSettlement.Target_account.Account_id = input
            .PaymentInstruction
            .Transfer
            .Debit
            .Payee
            .AccountId;

        return outboundHardSettlement;
    }

    public static HardSettlement ToInboundHardSettlement(this Input input)
    {
        var inboundHardSettlement = input.ToHardSettlement();

        inboundHardSettlement.Target_account.Account_id = input
            .PaymentInstruction
            .Transfer
            .Credit
            .Payee
            .AccountId;

        return inboundHardSettlement;
    }

    public static HardSettlement ToHardSettlement(this Input input)
    {
        var amount = input
            .PaymentInstruction
            .Transfer
            .Amount
            .ToString(CultureInfo.InvariantCulture);

        return new HardSettlement
        {
            Amount = amount,
            Denomination = CurrencyCode.Nzd,
            Internal_account_id = "SPUD_FUNDING",
            Target_account = new TargetAccount()
        };
    }
}