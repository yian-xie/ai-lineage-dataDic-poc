﻿using Account.Shared.Kafka.Publishers;

using Microsoft.Extensions.DependencyInjection;

namespace Account.Shared.Kafka;

public static class Extensions
{
    public static IServiceCollection AddRelatedAccountAuditLogServices(
        this IServiceCollection services)
    {
        return services
            .AddSingleton<IAccountAuditLogEventBuilder, AccountAuditLogEventBuilder>()
            .AddSingleton<IAccountAuditLogEventPublisher, AccountAuditLogEventPublisher>();
    }
}