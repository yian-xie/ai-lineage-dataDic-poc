## Service Summary

| Field | Details |
|---|---|
| Business purpose | Consume TMV Kafka action, audit, alert, and failure events; ingest them into Sumo Logic and emit a Dynatrace metric for DLQ/failure events. |
| Runtime | .NET 10 ASP.NET Core Kafka event processor, deployed as `accounts-topiclogger-processor` with three replicas. |
| Source | `src/topiclogger/Account.TopicLogger.Processor` |
| Pipeline | `src/topiclogger/pipeline.yaml` using `src/topiclogger/Deploy/build_spec.json` and `src/topiclogger/Deploy/deploy_spec.json` |
| Last reviewed | 2026-10-05 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. Reliable consumers connect to the TMV Kafka OAuth cluster, with the configured plain TMV cluster as failover, and subscribe to schema-less action, audit, alert, and failure topics.
2. Action, audit, and failure payloads are sent to environment-specific Sumo Logic operational-log categories; alert payloads are sent to the monitoring-log category.
3. For each failure-topic event, the processor also posts `topiclogger.tmv_dlq.log` to Dynatrace with namespace and topic dimensions.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Inbound events | TMV Kafka OAuth and plain failover clusters | Supply action, audit, alert, DLQ, and failure events | `KafkaClusters`, `Kafka`, and `TmvTopics.cs` |
| Outbound HTTP | Sumo Logic collectors | Store operational, audit, and monitoring logs | `SumoLogicIngestion`; separate operational and monitoring token keys |
| Outbound HTTP | Dynatrace Metrics API | Store `topiclogger.tmv_dlq.log` and application telemetry | `DynatraceMetricPost`, `MetricsOptions`, and `TracingOptions` |
| Authentication | Microsoft Entra ID | Issue OAuth tokens for the primary TMV Kafka cluster | `KafkaClusters__TMVKafkaOAuth__OAuth__*` |

### Interfaces and Schedule

- Continuous Kafka consumer; there is no scheduled trigger.
- Action: `vault.api.v1.action_logs.action_log.created`.
- Audit: `vault.api.v1.audit_logs.audit_log.created`.
- Alert: `vault.core_api.v1.vault_jobs.group.events`.
- Fourteen active DLQ/failure topics are defined in `TmvTopics.cs`. Two additional topics are intentionally disabled because TMV returned `Topic authorization failed`.
- Health interfaces: `GET /health/readiness` and `GET /health/liveness` on container port `8080`.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| Deployment targets | Select namespace, release, and Helm values | Accept: `accept-accounts-topiclogger-processor`; integrate: `situat-...` and `perf0-...`; rehearse: `preprod-...`; deliver: `prod-...`. Release is `accounts-topiclogger-processor`. |
| `Kafka` and `KafkaClusters` | Consumer group, brokers, OAuth, and plain-cluster failover | Environment values override broker URLs, OAuth identity, and group ID. OAuth client secret is injected by the pipeline. |
| `SumoLogicIngestion` and `SumoLogicMonitoringApiToken` | Destination URL, source category/name, and separate operational/monitoring credentials | Source categories use `<environment>/saas/tmv/`; secret values are injected into `accounts-topiclogger-processor`. |
| `DynatraceMetricPost` | DLQ metric destination and name | Metric is `topiclogger.tmv_dlq.log`; API token is injected as a secret. |
| `MetricsOptions` and `TracingOptions` | Runtime telemetry export | Environment name, metric prefix, endpoint, temporality, and token vary by stage. |

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| Readiness and liveness | `GET /health/readiness` and `GET /health/liveness` on port `8080` return HTTP 2xx | Probe failures reach three consecutive failures, a pod stays unready, or restarts increase. |
| Kubernetes workload | Three desired and available containers, with stable CPU/memory and no new restarts | Available containers fall below three, CPU throttling persists, memory approaches the configured limit, or restarts rise. |
| Sumo Logic sources | Recent events appear for active upstream topics under the expected action, audit, alert, and DLQ source names | A source is stale beyond [TODO: confirm expected event cadence] while its upstream topic is active. |
| Kafka consumer groups | Environment group advances without sustained lag | Lag exceeds [TODO: confirm the per-environment lag threshold] or all source families stop together. |
| Dynatrace DLQ metric | `topiclogger.tmv_dlq.log` appears with `k8s.namespace.name` and `topicname` dimensions for handled failure events | Sumo receives a failure event but the matching metric is absent, or the event rate exceeds [TODO: confirm alert threshold]. |

Observability: <ul><li>[Account Topiclogger Processor Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/6310101161/Account+Topiclogger+Processor+Observability+Dashboard)</li><li>[Topiclogger Sumo logs](https://kbprod.au.sumologic.com/library/41314788)</li></ul>

Endpoint execution context: the health URLs are pod-local and not directly reachable from a developer laptop. The repository does not document endpoint authentication or the approved VPN/Kubernetes access and port-forward procedure. [TODO: confirm the access procedure, authentication expectation, and exact successful response body.] Repository-static verification only; no request was sent to rehearse or production.

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the TopicLogger pipeline selected `Deploy/build_spec.json` and built `accounts/account/account_topiclogger_processor` with `COMPONENT_NAME=topiclogger` and `PROJECT_NAME=Account.TopicLogger.Processor`.
2. Confirm the target entry in `Deploy/deploy_spec.json`, environment Helm values, Kafka group/topic permissions, and required secret key names. Do not expose secret values.

### After Deployment

1. In the target namespace, verify three available containers, stable restarts, and HTTP 2xx from both pod-local health endpoints. [TODO: confirm the approved cluster access command.] No environment request was executed while generating this runbook.
2. Confirm new events appear under each active source family and that a rehearse DLQ test event, when an approved fixture exists, produces `topiclogger.tmv_dlq.log`. [TODO: provide the approved non-production test event and expected correlation value.]

Pipeline execution context: build and deployment scripts run on the pipeline runner with pipeline-provided `KB_PIPELINE_STAGE`, credentials, and artifacts. The stage scripts invoke:

```bash
kb.engx.sf.taskrunner foundations.deploy "$KB_PIPELINE_STAGE" --no-helm-debug
```

Expected result: the foundations deployment completes successfully for the stage selected by the pipeline. This command is not documented for developer-laptop execution and was not run while generating this runbook.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

Prefer fix-forward for configuration, Kafka permission, and downstream endpoint issues through `src/topiclogger/pipeline.yaml`. [TODO: confirm the approved Helm release rollback procedure and revision-selection criteria for `accounts-topiclogger-processor` before documenting or running a rollback command.]

### Recovery Validation

1. Verify all three replicas remain healthy and both pod-local health endpoints return HTTP 2xx in the affected namespace.
2. Verify the environment consumer group advances, expected Sumo Logic source names receive new events, and a new failure event produces the Dynatrace metric when applicable.

Operational guardrail: do not reset Kafka offsets, replay events, or enable an unauthorized topic until retry/commit semantics, duplicate effects, and the approved environment-specific procedure are confirmed.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Kiwibank kb-accounts repository](https://github.com/Kiwibank/kb-accounts) |
| Dashboards and logs | <ul><li>[Account Topiclogger Processor Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/6310101161/Account+Topiclogger+Processor+Observability+Dashboard)</li><li>[Topiclogger Sumo logs](https://kbprod.au.sumologic.com/library/41314788)</li></ul> |
| Minimum Standard for Runbooks | [Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |
