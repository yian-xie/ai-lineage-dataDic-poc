﻿using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Shared.EventBuilder;
using Account.PaymentInstruction.Shared.Repositories;
using Account.PaymentInstruction.Shared.Services;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;
using Enterprise.Shared.Kafka.Produce;

using Microsoft.Extensions.Logging;

namespace Account.PaymentInstruction.Tmv.Processor.Subscribers;

/// <summary>
///     Matches PaymentInstructions to PIBs. Emits a PaymentInstructionEvent when there is a match.
/// </summary>
public class TmvPostingInstructionBatchCreatedEventSubscriber(
    IRepositoryFactory repositoryFactory,
    ILogger<TmvPostingInstructionBatchCreatedEventSubscriber> logger,
    IPaymentInstructionStatusCreator paymentInstructionStatusCreator,
    IKafkaEventPublisher<PaymentInstructionEvent> publisher,
    IPaymentInstructionEventBuilder eventBuilder)
    : IIncomingEventSubscriber<PostingBatchEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        PostingBatchEvent incomingEvent,
        CancellationToken cancellationToken)
    {
        var batch = incomingEvent.Posting_instruction_batch;
        var clientBatchId = batch.Client_batch_id;
        var clientId = batch.Client_id;

        var instruction = await repositoryFactory.PaymentInstructionRepository.GetAsync(
            clientBatchId,
            clientId,
            cancellationToken);

        if (instruction is null)
        {
            logger.LogInformation(
                "No matching payment instruction found for client id: {ClientId}, batch id: {BatchId}",
                clientId, clientBatchId);

            return EventSubscriberResults.Success;
        }

        logger.LogInformation(
            "Found payment instruction request id {RequestId} for client id: {ClientId}, batch id: {BatchId}",
            instruction.RequestId, clientId, clientBatchId);

        var paymentInstructionEvent =
            eventBuilder.BuildFromPostingInstructionBatchEvent(incomingEvent, instruction);

        await publisher.PublishAsync(
            paymentInstructionEvent,
            cancellationToken,
            instruction.TransactionId);

        var status = paymentInstructionEvent.Data.AfterState.PaymentInstructionStatus.Status;

        await paymentInstructionStatusCreator.CreateAsync(
            instruction,
            status,
            cancellationToken,
            incomingEvent.Posting_instruction_batch);

        return EventSubscriberResults.Success;
    }
}