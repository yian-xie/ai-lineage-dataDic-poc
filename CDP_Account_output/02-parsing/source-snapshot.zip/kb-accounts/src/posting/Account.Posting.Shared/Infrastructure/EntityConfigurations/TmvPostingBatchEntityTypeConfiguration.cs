﻿using Account.Posting.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using Namotion.Reflection;

namespace Account.Posting.Shared.Infrastructure.EntityConfigurations;

public class TmvPostingBatchEntityTypeConfiguration :
    AccountBaseEntityTypeConfiguration<TmvPostingBatch, AccountPostingDbContext>
{
    protected override string TableName => "tmv_positing_batch";

    protected override void ConfigureTable(EntityTypeBuilder<TmvPostingBatch> builder)
    {
        builder.HasKey(t => t.Id);
        builder.Property(t => t.PostingBatchEventPayload).IsRequired();

        builder.Property(e => e.CreatedAt)
            .ValueGeneratedOnAdd()
            .HasDefaultValueSql("CURRENT_TIMESTAMP");
        builder.Property(e => e.ModifiedAt)
            .ValueGeneratedOnUpdate()
            .HasDefaultValueSql("CURRENT_TIMESTAMP");
    }
}