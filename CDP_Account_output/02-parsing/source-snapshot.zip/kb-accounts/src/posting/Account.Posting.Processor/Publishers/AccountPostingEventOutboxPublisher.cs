﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPostings;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using Enterprise.Shared.Database;
using Enterprise.Shared.Kafka.Produce;

namespace Account.Posting.Processor.Publishers;

/// <summary>
///     Implements IAccountPostingEventOutboxPublisher interface for publishing AccountPostingEvent.
/// </summary>
public class AccountPostingEventOutboxPublisher(
    IAccountPostingEventBuilder eventBuilder,
    IOutboxEventPublisher<AccountPostingEvent> publisher)
    : IAccountPostingEventOutboxPublisher
{
    public async Task PublishAsync(
        PostingBatchEvent postingBatchEvent,
        IUnitOfWork unitOfWork,
        CancellationToken cancellationToken)
    {
        await publisher.PublishAsync(
            eventBuilder.BuildEvent(postingBatchEvent),
            unitOfWork,
            cancellationToken);
    }
}