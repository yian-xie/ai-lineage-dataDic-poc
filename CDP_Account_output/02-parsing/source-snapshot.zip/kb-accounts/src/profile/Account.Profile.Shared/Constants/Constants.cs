﻿namespace Account.Profile.Shared.Constants;

public static class Constants
{
    public static class SumoSourceNames
    {
        public const string TmvAccountEventSubscriber = "account-event-subscriber";
        public const string TmvContractNotificationSubscriber = "contract-notification-event-subscriber";
        public const string TmvRestrictionSetEventSubscriber = "restriction-set-event-subscriber";
    }

    public static class Telemetry
    {
        public const string ActivitySourceName = "account_profile";
    }
}