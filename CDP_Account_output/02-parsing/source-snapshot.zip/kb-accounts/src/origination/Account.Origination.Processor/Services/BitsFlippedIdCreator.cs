﻿namespace Account.Origination.Processor.Services;

public class BitsFlippedIdCreator : IAccountIdCreator
{
    public string Create(Guid incomingId)
    {
        var bytes = incomingId.ToByteArray();
        var flipped = bytes.Select(x => (byte)~x).ToArray();

        return new Guid(flipped).ToString("D");
    }
}