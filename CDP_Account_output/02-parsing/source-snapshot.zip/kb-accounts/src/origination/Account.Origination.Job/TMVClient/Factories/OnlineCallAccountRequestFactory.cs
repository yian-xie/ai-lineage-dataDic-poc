﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Constants;
using Account.Origination.Shared.Entities;
using Account.Shared.FeatureFlags;

using Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount;

using Kb.TMV.Client.Abstractions.Account;
namespace Account.Origination.Job.TMVClient.Factories
{
    public class OnlineCallAccountRequestFactory : IOnlineCallAccountRequestFactory
    {
        private const ParameterValueHierarchyNodeId ParameterValueHierarchyNodeId = Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount.ParameterValueHierarchyNodeId.Product_SV1;
        private const string AccountOrganisationUnitId = "KB";
        private const string MinimumNumberOfAuthoriserValue = "1";
        private readonly IFeatureService featureService;

        public OnlineCallAccountRequestFactory(IFeatureService featureService)
        {
            this.featureService = featureService;
        }

        public CreateOnlineCallAccountRequest Create(
            AccountOpening accountOpening,
            ICollection<PartyResultDto> partyResults,
            string semanticVersionId,
            string accountName
        )
        {
            var partyResultDto = ValidateCreateArguments(accountOpening, partyResults);

            var bankRelationshipTypeName =
                ResolveBankRelationship(accountOpening, partyResults).BankingRelationshipTypeName;

            var request = new CreateOnlineCallAccountRequest
            {
                Request_id = accountOpening.AccountId + "_create",
                Account = new AccountCreate
                {
                    Id = accountOpening.AccountId,
                    Type = AccountType.ACCOUNT_TYPE_CUSTOMER,
                    Status = AccountStatus.ACCOUNT_STATUS_OPEN,
                    Stakeholder_ids = [accountOpening.PartyId.ToString()],
                    Smart_contract_version_id = semanticVersionId,
                    Parameter_value_hierarchy_node_id = ParameterValueHierarchyNodeId,
                    Details = new Details
                    {
                        AccountAlias = accountOpening.AlternateAccountName,
                        MinimumNumberOfAuthoriser = MinimumNumberOfAuthoriserValue,
                        AccountName = accountName,
                        ProductPropositionId = accountOpening.ProductPropositionId.ToString(),
                        ProductFacilityId = accountOpening.ProductFacilityId.ToString(),
                        BankingProductId = accountOpening.BankingProductId.ToString(),
                        BankingProductVersionId = accountOpening.BankingProductVersionId.ToString(),
                        BankingRelationshipId = accountOpening.BankingRelationshipId.ToString(),
                        BankingRelationshipType = bankRelationshipTypeName.ToString(),
                        NzBankAccountNumber = accountOpening.AccountNumber,
                        AccountOrganisationUnitId = AccountOrganisationUnitId
                    }
                },
                Create_options = new CreateOptions
                {
                    Parameter_values = new Parameter_values
                    {
                        Withholding_tax_nominated_tax_party_id = new()
                        {
                            String_value = partyResultDto.PartyId
                        },
                        Withholding_tax_pct_1 = new()
                        {
                            Decimal_value = partyResultDto.WithHoldingTaxRateValue
                        },
                        Withholding_tax_type = new()
                        {
                            Enumeration_value = (Withholding_tax_typeEnumeration_value)
                                (int)partyResultDto.WithHoldingTaxRateType!.Value
                        }
                    }
                }
            };

            return request;
        }

        public Kb.TMV.Client.Actions.CreateOnlineCallAccount.Requests.CreateOnlineCallAccountRequest CreateV2AccountRequest(
            AccountOpening accountOpening,
            ICollection<PartyResultDto> partyResults,
            string semanticVersionId,
            string accountName)
        {
            // TODO: AB#804747 - Remove this feature flag and associated branching once fully rolled out
            var decoupleBankingRelationship = featureService.IsFeatureEnabled(
                FeatureFlag.EnableDecoupleBankingRelationship,
                defaultValue: false);
            var partyResultDto = ValidateCreateArguments(accountOpening, partyResults, decoupleBankingRelationship);
            var bankingRelationshipId = decoupleBankingRelationship
                ? string.Empty
                : accountOpening.BankingRelationshipId.ToString() ?? string.Empty;
            var bankingRelationshipType = decoupleBankingRelationship
                ? string.Empty
                : ResolveBankRelationship(accountOpening, partyResults).BankingRelationshipTypeName.ToString() ?? string.Empty;

            var tmvV2AccountDetails = new TmvV2AccountDetails(
                        accountAlias: accountOpening.AlternateAccountName ?? string.Empty,
                        minimumNumberOfAuthoriser: MinimumNumberOfAuthoriserValue,
                        accountName: accountName,
                        productPropositionId: accountOpening.ProductPropositionId.ToString() ?? string.Empty,
                        productFacilityId: accountOpening.ProductFacilityId.ToString() ?? string.Empty,
                        bankingProductId: accountOpening.BankingProductId.ToString() ?? string.Empty,
                        bankingProductVersionId: accountOpening.BankingProductVersionId.ToString() ?? string.Empty,
                        bankingRelationshipId: bankingRelationshipId,
                        bankingRelationshipType: bankingRelationshipType,
                        nzBankAccountNumber: accountOpening.AccountNumber ?? string.Empty,
                        accountOrganisationUnitId: AccountOrganisationUnitId
                    );

            var withholdingTaxParameters = new TmvWithholdingTaxParameters(
                    nominatedTaxPartyId: partyResultDto.PartyId,
                    pct: partyResultDto.WithHoldingTaxRateValue ?? string.Empty,
                    type: (TmvWithholdingTaxType)(int)partyResultDto.WithHoldingTaxRateType!.Value
                );

            var request = new Kb.TMV.Client.Actions.CreateOnlineCallAccount.Requests.CreateOnlineCallAccountRequest(
                accountId: accountOpening.AccountId,
                correlationId: accountOpening.CorrelationId.ToString(),
                requestId: accountOpening.AccountId + "_create",
                stakeholderIds: new List<string> { accountOpening.PartyId.ToString() },
                smartContractVersionId: semanticVersionId,
                parameterValueHierarchyNodeId: TmvParameterValueHierarchyNodeId.ProductSv1,
                details: tmvV2AccountDetails,
                withholdingTax: withholdingTaxParameters);

            return request;
        }

        private static PartyResultDto ValidateCreateArguments(
            AccountOpening accountOpening,
            ICollection<PartyResultDto> partyResults,
            bool decoupleBankingRelationship = false)
        {
            ArgumentNullException.ThrowIfNull(accountOpening);
            ArgumentNullException.ThrowIfNull(accountOpening.PartyId);
            if (!decoupleBankingRelationship)
            {
                ArgumentNullException.ThrowIfNull(accountOpening.BankingRelationshipId);
            }
            ArgumentNullException.ThrowIfNull(partyResults);
            ArgumentNullException.ThrowIfNull(accountOpening.AlternateAccountName);
            ArgumentNullException.ThrowIfNull(accountOpening.ProductPropositionId);
            ArgumentNullException.ThrowIfNull(accountOpening.ProductFacilityId);
            ArgumentNullException.ThrowIfNull(accountOpening.BankingProductId);
            ArgumentNullException.ThrowIfNull(accountOpening.BankingProductVersionId);
            ArgumentNullException.ThrowIfNull(accountOpening.AccountNumber);

            if (partyResults.Count == 0)
            {
                throw new ArgumentException("Party results must contain at least one item.",
                    nameof(partyResults));
            }

            var partyResultDto = partyResults
                    .FirstOrDefault(p => p.PartyId == accountOpening.PartyId.ToString()) ??
                throw new InvalidOperationException(
                    $"Party {accountOpening.PartyId} not found in party results.");

            ArgumentNullException.ThrowIfNull(partyResultDto.WithHoldingTaxRateType);
            ArgumentNullException.ThrowIfNull(partyResultDto.WithHoldingTaxRateValue);

            return partyResultDto;
        }

        private static PartyBankingRelationshipDto ResolveBankRelationship(
            AccountOpening accountOpening,
            ICollection<PartyResultDto> partyResults)
        {
            return partyResults
                    .SelectMany(p =>
                        p.BankingRelationships ?? Array.Empty<PartyBankingRelationshipDto>())
                    .FirstOrDefault(r =>
                        r.BankingRelationshipId ==
                        accountOpening.BankingRelationshipId.ToString()
                    ) ??
                throw new InvalidOperationException(
                    $"Banking relationship {accountOpening.BankingRelationshipId} not found in party results.");
        }

    }
}