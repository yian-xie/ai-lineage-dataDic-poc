## Service Summary

| Field | Details |
|---|---|
| Business purpose | Polls scheduled internal-account jobs, retrieves end-of-day ledger balances from TMV Core API, publishes internal-account balance events to ESP, and removes successfully completed jobs. |
| Runtime | .NET 10 ASP.NET Core hosted background worker in a Linux container; HTTP health port 8080. Polling worker and Kafka producer. |
| Source | [Internal-account worker source](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Worker) |
| Pipeline | [Transaction pipeline](https://github.com/Kiwibank/kb-accounts/blob/main/src/transaction/.pipelineconfig/pipeline.yaml), using [component deployment values](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Deploy/Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Worker) |
| Last reviewed | 2026-10-01 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. The hosted service polls PostgreSQL every 30 seconds when no work is found; eligible alive jobs are due by `scheduled_at` and outside the one-minute retry interval, with row locking to distribute work.
2. For one selected job, the worker fetches paginated TMV ledger balances at the job's completed-run timestamp; an empty result becomes a default zero NZD committed balance.
3. The worker publishes `account.balance.end-of-day.internal-account.v1.event` to ESP and deletes the job on success; failures update persisted retry state and can mark the job inactive after six hours.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Persistence / trigger | PostgreSQL transaction datastore | Supplies and tracks `internal_account_eod_balance_job` records. | `ConnectionStrings__DefaultConnection`; shared job repository and DbContext. |
| Outbound REST | TMV Core Ledger Balances API | Retrieves balances by account and completed-run timestamp. | `ThoughtMachineVault__BaseApiUrl`, `ThoughtMachineVault__ApiToken`; ledger-balance service. |
| Outbound Kafka | ESP Kafka and Schema Registry | Publishes internal-account end-of-day balance events keyed by account ID. | `Kafka__*`, `Kafka__SchemaRegistry__*`; topic `account.balance.end-of-day.internal-account.v1.event`. |
| Observability | Dynatrace and SumoLogic | Receives job metrics/traces and threshold/terminal failure logs. | `MetricsOptions__*`, `TracingOptions__*`, `SumoLogicIngestion__*`. |

### Interfaces and Schedule

- Poll interval when idle: 30 seconds.
- Failed alive jobs become eligible again after one minute.
- TMV API failure reporting begins after 30 minutes from `scheduled_at`; terminal failure handling begins after six hours.
- Success deletes the job. Terminal failure sets `alive=false` only after SumoLogic ingestion succeeds.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| Pipeline stages | Builds, tests, and deploys the transaction component. | `accept`, `integrate` (`perf0` and `situat`), `rehearse` (`preprod`), and `deliver` (`prod`) are mapped in the transaction pipeline and deploy spec. |
| Image and workload | Selects the immutable worker image and Kubernetes app. | Image `accounts/account/transaction-eod-tmv-internalaccount-worker`; app/release `transaction-eod-tmv-internalaccount-worker`; base replicas 3, `maxUnavailable` 1. |
| PostgreSQL polling | Configures job persistence and selection cadence. | `ConnectionStrings__DefaultConnection`; `EndOfDayTmvInternalAccountWorkerOptions__PollingTimeSeconds` defaults to 30. |
| TMV and ESP | Configures ledger-balance retrieval and event publication. | `ThoughtMachineVault__*`, `Kafka__*`, and `Kafka__SchemaRegistry__*` vary by environment. |

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `GET http://transaction-eod-tmv-internalaccount-worker/health/readiness` on service port 80 (target 8080), no application authentication configured | HTTP 200; starts after 10 seconds, polls every 5 seconds, and marks unready after 3 failures. Cluster-internal and not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and infrastructure authentication requirements]. | Non-200, timeout over 3 seconds, or a replica remains unready. |
| `GET http://transaction-eod-tmv-internalaccount-worker/health/liveness` on service port 80 (target 8080), no application authentication configured | HTTP 200; starts after 10 seconds, polls every 5 seconds, and restarts after 3 failures. Cluster-internal and not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and infrastructure authentication requirements]. | Non-200, timeout over 2 seconds, or repeated restarts. |
| Job processing | `job-process-total-jobs` and `job-process-success-jobs` reflect due work; successful rows are deleted. | Eligible jobs accumulate, success stops, retry counts rise, or jobs become inactive. [TODO: confirm queue-age/count thresholds and approved job-query access]. |
| Output correctness | One event per successfully processed account/run contains TMV balances or the documented default zero entry. | Output is absent/duplicated or balances differ from TMV at the completed-run timestamp. |

Observability: [Account Transaction End-of-Day Balance TMV Internal Account Worker](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203297784/Account+Transaction+End-of-Day+Balance+TMV+Internal+Account+Worker)

Local verification from the repository root; requires the integration-test dependencies and credentials documented by the repository:

```powershell
dotnet test .\src\transaction\Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Worker.IntegrationTests\Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Worker.IntegrationTests.csproj
```

Expected result: exit code 0; tests exercise job selection, TMV balance retrieval, publication, retry-state updates, and job deletion. This command was not executed during runbook generation and does not validate a deployed environment.

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the transaction pipeline builds `accounts/account/transaction-eod-tmv-internalaccount-worker` from the named project and candidate unit/integration evidence passes.
2. Review shared transaction migrations and target values for PostgreSQL, TMV Core API, ESP Kafka/Schema Registry, telemetry, polling/retry thresholds, and secret references.
3. Promote through SITUAT and PREPROD before PROD; rehearse with non-production jobs and record duplicate-event checks.

### After Deployment

1. Confirm the expected image tag and replicas, and verify both cluster-internal health requests return HTTP 200 through the approved access path.
2. Confirm polling remains active with no critical background-service shutdown, PostgreSQL, TMV API, Kafka, Schema Registry, or SumoLogic errors.
3. In SITUAT or PREPROD, verify one due job publishes the expected event and is deleted; verify one handled failure persists retry state without duplicate publication.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

- Prefer fix-forward when shared database migrations, persisted retry state, or externally visible events are involved.
- For an application-only regression, redeploy the last approved immutable image through the transaction pipeline. [TODO: confirm the pipeline rollback action, release identifier, required approval, and database-migration rollback policy].
- Do not reactivate/delete jobs, publish manually, or reverse migrations without an approved procedure and a duplicate-event check.

### Recovery Validation

1. Confirm replicas remain ready/live, polling and success metrics resume, and eligible job age/count returns toward the pre-incident baseline.
2. Verify each recovered account/run has the expected output exactly once and no duplicate eligible or inactive job remains.

Operational guardrail: Publishing to Kafka and deleting the PostgreSQL job cross system boundaries; establish publish status before retrying or modifying any retained job.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Kiwibank kb-accounts](https://github.com/Kiwibank/kb-accounts) |
| Dashboards and logs | [Account Transaction End-of-Day Balance TMV Internal Account Worker](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203297784/Account+Transaction+End-of-Day+Balance+TMV+Internal+Account+Worker) |
| Minimum Standard for Runbooks | [Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |