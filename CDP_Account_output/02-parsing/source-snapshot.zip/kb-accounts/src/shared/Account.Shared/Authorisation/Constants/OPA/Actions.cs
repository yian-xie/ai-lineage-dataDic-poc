﻿namespace Account.Shared.Authorisation.Constants.OPA;

public static class Actions
{
    public const string AccountView = "accounts:View";
    public const string AccountEdit = "accounts:Edit";
}