﻿using HotChocolate;

namespace Account.PaymentInstruction.Api.Queries.Types;

[GraphQLName("TransferParty")]
public class TransferParty
{
    [GraphQLName("payee")] public AccountPayee Payee { get; set; }

    [GraphQLName("particulars")] public string? Particulars { get; set; }

    [GraphQLName("code")] public string? Code { get; set; }

    [GraphQLName("reference")] public string? Reference { get; set; }
}