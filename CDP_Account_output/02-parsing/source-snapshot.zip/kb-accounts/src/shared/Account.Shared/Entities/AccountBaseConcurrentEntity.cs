﻿namespace Account.Shared.Entities;

/// <summary>
///     The account domain concurrent entity abstract class to support EF core optimistic currency to manage the
///     concurrency token.
///     <see href="https://learn.microsoft.com/en-us/ef/core/saving/concurrency?tabs=data-annotations" />
/// </summary>
public abstract class AccountBaseConcurrentEntity
{
    /// <summary>
    ///     Concurrency token.
    ///     <see href="https://www.npgsql.org/efcore/modeling/concurrency.html?tabs=fluent-api" />
    /// </summary>
    public uint Version { get; set; }
}