## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Worker (`transaction-eod-tmv-internalaccount-worker`) |
| Customer or business impact | End-of-day internal-account balance events can be delayed or absent, affecting downstream reconciliation and CDP consumers. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | [Account Transaction End-of-Day Balance TMV Internal Account Worker](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203297784/Account+Transaction+End-of-Day+Balance+TMV+Internal+Account+Worker) |

## Common Scenarios and Recovery

<details>
<summary>Eligible jobs are not being picked up</summary>

**Symptoms**

- `internal_account_eod_balance_job` records remain alive with `scheduled_at` in the past and eligible `last_retry` values.
- `job-process-total-jobs` does not increase; no success or failure log appears for the affected job.

**Actions**

1. In the [observability page](https://kiwibank.atlassian.net/wiki/x/_AUkNgE) dashboards, check worker liveness, readiness, restarts, and job-processing metrics.
2. Confirm the processor created jobs with `alive=true`, `scheduled_at` elapsed, and no one-minute retry exclusion. [TODO: confirm the approved read-only job query and database access path for each environment].
3. Check PostgreSQL connectivity and lock/transaction errors; selection uses `FOR UPDATE SKIP LOCKED` to distribute jobs among replicas.
4. Restore database access or deploy a tested worker/repository fix. Do not edit job timestamps or retry fields manually.

**Recovery check**

- `job-process-total-jobs` advances, affected rows are selected, and each successful row is deleted after its output event is published.

**Escalation**

- Use the incident escalation path when eligible jobs continue accumulating, all replicas are affected, or the database access procedure is unavailable.

</details>

<details>
<summary>TMV ledger-balance API failures keep jobs retrying</summary>

**Symptoms**

- Logs contain `Failed to call TMV API to process internal account EOD balance Job`.
- The job remains alive; `retry_count`, `last_retry`, and `failed_at` advance at no less than the one-minute redelivery interval.
- After 30 minutes from `scheduled_at`, `api_failure_reported_at` is set when SumoLogic reporting succeeds.

**Actions**

1. Capture job ID, account ID, scheduled time, retry count, HTTP status, and exception.
2. Confirm the environment's `ThoughtMachineVault__BaseApiUrl`, token secret reference and TMV Core Ledger Balances API status without exposing credentials.
3. Restore TMV access or deploy a tested client fix; leave the persisted job alive for automatic retry.
4. Monitor the six-hour maximum measured from `scheduled_at`; after it is exceeded, successful failure reporting marks the job inactive.

**Recovery check**

- The API call succeeds, one output event is published, the job row is deleted, and `job-process-success-jobs` increments.

**Escalation**

- Use the incident escalation path when TMV remains unavailable, authorization cannot be restored, or jobs approach the six-hour terminal threshold.

</details>

<details>
<summary>ESP Kafka or Schema Registry blocks publication</summary>

**Symptoms**

- TMV ledger balances are fetched, but logs contain `Error processing EOD balance job`; no `account.balance.end-of-day.internal-account.v1.event` appears.
- The job remains alive and retries until the six-hour threshold, then becomes inactive when terminal failure reporting succeeds.

**Actions**

1. Correlate job/account ID with Kafka or Schema Registry exceptions for the output topic.
2. Check ESP Kafka and Schema Registry availability, topic configuration, and deployed `Kafka__*` secret references without exposing values.
3. Restore the dependency or deploy a tested publisher/schema fix; allow the stored job to retry.
4. Check for a prior successful publish before intervening because publication and job deletion are not one atomic external transaction. [TODO: confirm the approved duplicate-event check and inactive-job reactivation procedure].

**Recovery check**

- Exactly one expected output event is confirmed for the account/run, the job is deleted, and success metrics resume.

**Escalation**

- Use the incident escalation path when publication remains unavailable, duplicate status cannot be established, or inactive jobs require recovery.

</details>

<details>
<summary>Jobs become inactive after the six-hour retry period</summary>

**Symptoms**

- A job has `alive=false`, `failed_at` populated, and remains in `internal_account_eod_balance_job`.
- SumoLogic contains `Failed to process internal account EOD balance Job`; the row is no longer selected by the worker.

**Actions**

1. Capture job ID, account ID, scheduled time, completed-run timestamp, retry count, final exception, and whether an output event already exists.
2. Resolve the underlying TMV API, ESP Kafka, Schema Registry, PostgreSQL, or application failure.
3. Do not set `alive=true`, delete the row, or publish manually without the approved recovery process. [TODO: confirm the approved inactive-job review, reactivation/recreation, authorization, and duplicate-check procedure].
4. Rehearse the chosen recovery in SITUAT or PREPROD and record the target, access path, and result before production use.

**Recovery check**

- The approved recovery produces the expected event once for the affected account/completed-run timestamp and leaves no eligible or inactive duplicate job.

**Escalation**

- Use the incident escalation path for any inactive production job, unknown publish status, or recovery requiring database modification.

</details>

<details>
<summary>SumoLogic failure prevents terminal job inactivation</summary>

**Symptoms**

- Logs contain `Failed to push log into SumoLogic for EOD balance Job`.
- A job older than six hours remains `alive=true` and continues retrying because code marks it inactive only after failure ingestion succeeds.

**Actions**

1. Use workload logs and Dynatrace signals from the observability page as the temporary source of truth.
2. Verify `SumoLogicIngestion__SourceCategory`, source name, collector reachability, and `SumoLogicIngestion__ApiToken` secret reference without exposing values.
3. Restore SumoLogic ingestion and observe the next eligible retry; do not edit `alive` or `api_failure_reported_at` manually.
4. Continue resolving the underlying processing failure independently.

**Recovery check**

- Failure reporting succeeds; a still-failing exhausted job becomes inactive, or a recovered job publishes successfully and is deleted.

**Escalation**

- Use the incident escalation path when alert ingestion remains unavailable or repeated processing risks duplicate downstream effects.

</details>

<details>
<summary>Worker exits after an unhandled background exception</summary>

**Symptoms**

- Logs contain `Exception occurred in ExecuteAsync. Stopping EndOfDayTmvInternalAccountService` at Critical level.
- The process stops, replicas restart or enter a restart loop, and job-processing metrics cease.

**Actions**

1. Capture the first critical exception and stack trace before subsequent restart noise.
2. Determine whether the exception occurred outside the handled per-job path, such as job selection, transaction creation/commit, or polling infrastructure.
3. Check PostgreSQL availability and deployment configuration, then deploy a tested fix if the exception is application-specific.
4. Do not rely on repeated restarts as recovery; persisted jobs remain for later selection, but the failing precondition must be removed.

**Recovery check**

- Replicas remain live/ready without critical shutdown logs, polling resumes, and eligible jobs progress to success or handled retry state.

**Escalation**

- Use the incident escalation path when all replicas restart, no worker can poll, or the root exception is not attributable to a recoverable dependency.

</details>

<details>
<summary>TMV returns no ledger balances for an account</summary>

**Symptoms**

- TMV returns an empty ledger-balance list, but processing succeeds and the output contains the documented default zero NZD committed balance at address `DEFAULT`.
- A downstream consumer reports the zero balance as unexpected.

**Actions**

1. Capture job ID, account ID, completed-run timestamp, and output event ID.
2. Confirm TMV returned zero records for that exact account and timestamp; the worker deliberately publishes a default zero entry.
3. Compare the account's expected TMV ledger state and timing with the completed-run timestamp. [TODO: confirm the approved TMV ledger-balance lookup procedure].
4. Correct an upstream TMV data/timing defect before any replay; first establish whether the default event was already consumed downstream.

**Recovery check**

- A non-production verification returns the expected balances and publishes them once, or the zero default is confirmed as correct for the account/run.

**Escalation**

- Use the incident escalation path when TMV and published balances disagree, multiple accounts are affected, or reconciliation is blocked.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>