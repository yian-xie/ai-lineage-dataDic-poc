# Account Transaction Subdomain

Account Transaction (aka Account Entry) and balance related functionality are provided by this subdomain. 

Responsible for 
- Consumption and transformation of Posting data into Kiwibank EDM format
- APIs for Transaction and Balance data 

