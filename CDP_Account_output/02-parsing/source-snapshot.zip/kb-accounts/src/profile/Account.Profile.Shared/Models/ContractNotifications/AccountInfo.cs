﻿using System;
using System.Collections.Generic;

using Newtonsoft.Json;

namespace Account.Profile.Shared.Models.ContractNotifications;

public class AccountInfo
{
    [JsonProperty("event_source")]
    public string EventSource { get; set; }

    [JsonProperty("parameters")]
    public List<Parameter> Parameters { get; set; }
}