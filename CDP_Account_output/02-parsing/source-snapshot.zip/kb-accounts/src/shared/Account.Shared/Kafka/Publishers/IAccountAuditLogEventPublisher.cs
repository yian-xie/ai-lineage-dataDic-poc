﻿using System.Threading;
using System.Threading.Tasks;

using HotChocolate.Resolvers;

using Microsoft.AspNetCore.Http;

namespace Account.Shared.Kafka.Publishers;

public interface IAccountAuditLogEventPublisher
{
    Task PublishAccountAuditLogEventAsync(
        IMiddlewareContext middlewareContext,
        HttpContext httpContext,
        string appName,
        CancellationToken cancellationToken);
}