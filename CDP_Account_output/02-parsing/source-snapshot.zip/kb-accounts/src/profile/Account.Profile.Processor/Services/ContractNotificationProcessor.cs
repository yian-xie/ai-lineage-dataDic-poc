﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Services;

public class ContractNotificationProcessor(IAccountProfileChangeSetCreator accountProfileChangeSetCreator,
    ILogger<ContractNotificationProcessor> logger,
    IParameterValueCreator parameterValueCreator) : IContractNotificationProcessor
{
    public async Task ProcessEvent(IncomingEventContext context,
        ContractNotification incomingEvent,
        CancellationToken cancellationToken)
    {
        var accountProfileChangeSet =
            accountProfileChangeSetCreator.CreateAccountProfileChangeSetFromContractNotification(
                incomingEvent);

        if (accountProfileChangeSet is null)
        {
            logger.LogInformation("No relevant changes found in ContractNotification with eventId: {eventId} " +
                                  "notificationType: {notificationType} for resource {resourceId}.",
                incomingEvent.Event_id,
                incomingEvent.Notification_type,
                incomingEvent.Resource_id);

            return;
        }

        await parameterValueCreator.CreateAsync(
            accountProfileChangeSet,
            GetEventTimestamp(context, incomingEvent),
            cancellationToken);

        logger.LogInformation("Successfully processed ContractNotification with eventId: {eventId} " +
                              "notificationType: {notificationType} for resource {resourceId}.",
            incomingEvent.Event_id,
            incomingEvent.Notification_type,
            incomingEvent.Resource_id);
    }

    private DateTimeOffset GetEventTimestamp(IncomingEventContext context, ContractNotification incomingEvent)
    {
        // Currently, we require a timestamp value to set for "accountStatusDateTime" property in the
        // outgoing accountUpdate event.  The account status does NOT get updated through TMV contract notification events,
        // it gets updated through TMV account events.  However, our current implementation does
        // not store this value explicitly in the account_profile table (though it does store created/opened/closed timestamps).
        // So every time we publish an account profile event, we need to pass a timestamp value to use for the accountStatusDateTime
        // property.  So, for now, for contract notification events, we use the implementation below for the timestamp.
        // TODO: This should be refactored in a future ticket
        //
        if (incomingEvent.Notification_details.Effective_datetime is null)
        {
            logger.LogWarning("Contract Notification event with eventId: {EventId} has null effective datetime. " +
                "Defaulting to message timestamp: {MessageTimestamp} ",
                incomingEvent.Event_id,
                context.ConsumeResult.Message.Timestamp.UtcDateTime);

            return context.ConsumeResult.Message.Timestamp.UtcDateTime;
        }

        return incomingEvent.Notification_details.Effective_datetime.Value;
    }
}