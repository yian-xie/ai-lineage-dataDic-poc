﻿using System.Linq;

using Account.Transaction.Api.Queries.Types;

using AccountTransaction = Account.Transaction.Shared.Entities.AccountTransaction;

namespace Account.Transaction.Api.Queries.Filtering;

/// <summary>
///     Provide filtering functionality for <see cref="AccountTransaction" /> queries.
/// </summary>
public interface IFilteringService
{
    /// <summary>
    ///     Filtering the query based on the <see cref="Types.AccountTransactionQueryParams" />.
    ///     Mandatory fields:
    ///     <see cref="AccountTransactionQueryParams.AccountId" />
    ///     <see cref="AccountTransactionQueryParams.TransactionDateTo" /> is null, use system current time
    ///     Optional fields:
    ///     <see cref="AccountTransactionQueryParams.TransactionDateFrom" />
    ///     <see cref="AccountTransactionQueryParams.CreditDebitIndicator" />
    /// </summary>
    /// <param name="query"><see cref="IQueryable{T}" /> of <see cref="Shared.Entities.AccountTransaction" /></param>
    /// <param name="queryParams">
    ///     <see cref="Types.AccountTransactionQueryParams" />
    /// </param>
    /// <returns><see cref="IQueryable" /> where T is <see cref="AccountTransaction" /></returns>
    IQueryable<AccountTransaction> ApplyFilter(
        IQueryable<AccountTransaction> query,
        AccountTransactionQueryParams queryParams);
}