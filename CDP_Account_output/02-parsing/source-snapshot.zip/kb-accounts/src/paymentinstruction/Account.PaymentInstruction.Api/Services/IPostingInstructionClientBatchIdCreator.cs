﻿namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     The interface to generate a Posting Instruction Client Batch id.
/// </summary>
public interface IPostingInstructionClientBatchIdCreator
{
    /// <summary>
    ///     Create an UUID in string format.
    /// </summary>
    /// <param name="src">The source name</param>
    /// <returns>An UUID in string format.</returns>
    string Create();
}