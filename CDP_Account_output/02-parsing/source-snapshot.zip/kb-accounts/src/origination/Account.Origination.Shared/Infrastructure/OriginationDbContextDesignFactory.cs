﻿using Enterprise.Shared.Database.Configurations;
using Enterprise.Shared.Infrastructure.Configuration.Extensions;

using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Account.Origination.Shared.Infrastructure;

public class OriginationDbContextDesignFactory : IDesignTimeDbContextFactory<OriginationDbContext>
{
    public OriginationDbContext CreateDbContext(string[] args)
    {
        var configuration =
            new ConfigurationBuilder().BuildConfig(
                Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"), args);

        return new OriginationDbContext(
            configuration.CreateSqlServerDbContextOptionBuilder<OriginationDbContext>().Options,
            new CustomDbContextOptions { IsPooled = false });
    }
}