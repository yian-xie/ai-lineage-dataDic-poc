﻿using System;

namespace Account.Profile.Shared.Entities;

public class AccountProfileProductFacility
{
    public string ProductFacilityId { get; set; }
    public string BankingProductId { get; set; }
    public string BankingProductVersionId { get; set; }

    public string BankingProductCode { get; set; }
    public string InterestRate { get; set; }
    public DateTimeOffset? InterestRateValidFrom { get; set; }
    public string InterestRatePlanChangeId { get; set; }
}