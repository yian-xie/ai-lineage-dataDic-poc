﻿using System.ServiceModel;

namespace Account.Origination.Job.Infrastructure.Resilience;

public class MiddlewareResilienceStrategy : DefaultResilienceStrategy
{
    /// <summary>
    ///     This strategy is designed to handle CommunicationException which can occur when there are transient issues with the
    ///     middleware communication.
    /// </summary>
    public override bool ShouldRetry(Exception ex)
    {
        return ex is CommunicationException || base.ShouldRetry(ex);
    }
}