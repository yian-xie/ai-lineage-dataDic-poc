﻿using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Mapping;
using Account.Profile.Processor.Models;
using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Api.Shared.Clients.Events.ThoughtMachine.V1.RestrictionSet;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Services;

/// <summary>
/// Handling TMV Restriction Set Updated events which is related to account profile unfreeze or update.
/// </summary>
/// <param name="logger"><see cref="ILogger"/></param>
public class RestrictionSetUpdatedEventHandler(
    ILogger<RestrictionSetUpdatedEventHandler> logger) : IRestrictionSetEventHandler
{
    public RestrictionType Type => RestrictionType.Updated;

    /// <summary>
    /// Handling TMV Restriction Set Updated event for account freeze update and unfreeze.
    /// Unfreeze the account by removing the account freeze details in account profile when the Restriction Set is set to inactive.
    /// Update the account freeze details in account profile when the incoming Restriction Set Updated Event Id is same as the existing Restriction Set Id but with newer Change Id.
    /// </summary>
    /// <param name="accountProfile"><see cref="AccountProfile"/></param>
    /// <param name="restriction"><see cref="Restriction"/></param>
    /// <returns>True if the Restriction is successfully handled, otherwise false.</returns>
    public bool Handle(AccountProfile accountProfile, Restriction restriction)
    {
        logger.LogInformation("Processing Restriction Set Updated Event (EventId: {eventId}).", restriction.EventId);

        RestrictionSetEventHelper.CheckAccountStatus(restriction, accountProfile, logger);

        if (RestrictionSetEventHelper.IsLatestRestriction(restriction, accountProfile, logger))
        {
            if (restriction.RestrictionSet.Is_active.HasValue &&
                !restriction.RestrictionSet.Is_active.Value)
            {
                // Unfreeze the account.
                accountProfile.Status = AccountStatusHelper.AccountStatusStringFromTmvStatusString(accountProfile.TmvStatus);
                accountProfile.AccountFreezeDetails = new AccountFreezeDetails();

                logger.LogInformation(
                    "Unfreeze the account freeze details (EventId: {eventId}) for account profile (AccountId: {accountId}).",
                    restriction.EventId, accountProfile.AccountId);

                return true;
            }

            logger.LogWarning("""
                              Expecting the Restriction Set Updated Event Is_active is set to false for unfreezing account profile (AccountId: {accountId}), but the event has Is_active: {IsActive}. Will update the account freeze details with the incoming Restriction Set Updated Event.
                              Existing Restriction: {@existingRestriction}
                              New Restriction: {@Restriction}
                              """, accountProfile.AccountId, restriction.RestrictionSet.Is_active,
                accountProfile.AccountFreezeDetails, restriction);

            // Update the account freeze details.
            accountProfile.AccountFreezeDetails = CreateAccountFreezeDetails(
                restriction.RestrictionSet,
                restriction.ChangeId);
            // Set Kiwibank status to Frozen.
            accountProfile.Status = nameof(AccountStatus.Frozen);

            return true;
        }

        logger.LogWarning("""
                          Restriction Set Updated Event (EventId: {eventId}) is out of order for specific account for account profile (AccountId: {accountId}).
                          Existing Restriction: {@existingRestriction}
                          New Restriction: {@Restriction}
                          """, restriction.EventId, accountProfile.AccountId, accountProfile.AccountFreezeDetails, restriction);

        return false;
    }

    private static AccountFreezeDetails CreateAccountFreezeDetails(Restriction_set restrictionSet, int? changeId)
    {
        return new AccountFreezeDetails
        {
            FreezeType = FreezeTypeMapper.GetFreezeType(restrictionSet.Restriction_set_definition_id),
            FreezeDescription = restrictionSet.Description,
            ChangeId = changeId,
            RestrictionSetId = restrictionSet.Id,
            Effective = restrictionSet.Effective_timestamp,
            Expiration = restrictionSet.Expiry_timestamp
        };
    }
}