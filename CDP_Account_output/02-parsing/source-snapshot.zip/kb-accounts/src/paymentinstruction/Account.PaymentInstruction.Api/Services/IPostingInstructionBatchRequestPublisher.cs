﻿using System.Threading;
using System.Threading.Tasks;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Services;

public interface IPostingInstructionBatchRequestPublisher
{
    Task PublishAsync(
        PaymentInstructionRequestInput input,
        string clientBatchId,
        CancellationToken cancellationToken);
}