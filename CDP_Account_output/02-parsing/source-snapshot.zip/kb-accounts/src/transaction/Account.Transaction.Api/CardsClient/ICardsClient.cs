﻿using System.Threading;
using System.Threading.Tasks;

using Account.Transaction.Api.CardsClient.Models;

namespace Account.Transaction.Api.CardsClient;

/// <summary>
/// A client interface for communicating with the cards service API to retrieve credit card transactions.
/// </summary>
public interface ICardsClient
{
    /// <summary>
    /// SendTransactionsRequestAsync
    /// </summary>
    /// <param name="cardTransactionsRequest"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    Task<CardTransactionsResponse> SendTransactionsRequestAsync(CardTransactionsRequest cardTransactionsRequest, CancellationToken cancellationToken);
}