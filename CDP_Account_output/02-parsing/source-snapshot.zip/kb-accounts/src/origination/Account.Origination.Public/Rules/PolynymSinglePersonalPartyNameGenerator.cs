﻿namespace Account.Origination.Public.Rules
{
    internal class PolynymSinglePersonalPartyNameGenerator : BasePartyNameGenerator
    {
        internal PolynymSinglePersonalPartyNameGenerator() { }
        /// <summary>
        /// This function checks that if this rule can be applied to generate a name for a party.
        /// The following conditions should be met to apply this name generation rule.
        /// 1- Only one party is involved.
        /// 2- Party type is personal.
        /// 3- More than one name property is populated.
        /// </summary>
        /// <param name="parties"></param>
        /// <returns>bool</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public override bool IsMatch(Party[] parties)
        {
            if (!ParametersAreValid(parties))
            {
                return false;
            }

            return parties.Length == 1 &&
                string.Equals(parties.First().PartyType, PartyTypes.Personal, StringComparison.OrdinalIgnoreCase) &&
                IsMultipleNameFieldProvided(parties.First());
        }

        /// <summary>
        /// This method return initials ofr first name and middle name followed by last name all in capital.
        /// This method should be used only if preceded IsMatch() invocation returns true.
        /// </summary>
        /// <param name="parties"></param>
        /// <returns>string</returns>
        public override string GenerateName(Party[] parties)
        {
            var p = parties.First();

            var result = string.Join(" ", new[] {
                p.GetFirstNameInitials(),
                p.GetMiddleNameInitials(),
                p.GetLastNameCapital()
            }.Where(_ => !string.IsNullOrWhiteSpace(_)));

            return result;
        }
    }
}