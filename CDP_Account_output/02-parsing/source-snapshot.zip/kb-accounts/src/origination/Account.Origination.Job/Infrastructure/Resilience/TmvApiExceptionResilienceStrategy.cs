﻿using System.Net;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Origination.Job.Infrastructure.Resilience;

/// <summary>
///     This strategy is designed to handle specific ApiException of the TMV API
/// </summary>
/// <seealso cref="DefaultResilienceStrategy" />
public class TmvApiExceptionResilienceStrategy : DefaultResilienceStrategy
{
    private static readonly HashSet<HttpStatusCode> RetryableStatusCodes =
    [
        HttpStatusCode.RequestTimeout,
        HttpStatusCode.TooManyRequests,
        HttpStatusCode.GatewayTimeout,
        HttpStatusCode.BadGateway,
        HttpStatusCode.InternalServerError,
        HttpStatusCode.ServiceUnavailable
    ];

    public override bool ShouldRetry(Exception ex)
    {
        if (ex is ApiException apiException)
        {
            return RetryableStatusCodes.Contains((HttpStatusCode)apiException.StatusCode);
        }

        return base.ShouldRetry(ex);
    }
}