# Decision record template 

This is the template in [Documenting architecture decisions - Michael Nygard](http://thinkrelevance.com/blog/2011/11/15/documenting-architecture-decisions).

File naming format: 

```
adr-<number>-<title_with_underscores>.md

eg:
adr-001-title_of_adr.md
```

In each ADR file, write these sections:



# Title

## Status

What is the status, such as proposed, accepted, rejected, deprecated, superseded, etc.?

## Context

What is the issue that we're seeing that is motivating this decision or change?

## Decision

What is the change that we're proposing and/or doing?

Link to any decision records, spikes or supporting documentation

## Consequences

What becomes easier or more difficult to do because of this change?