﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class RemoveProfileProcessingFailuresTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "profile_processing_failure",
                schema: "profile");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "profile_processing_failure",
                schema: "profile",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    account_id = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "CURRENT_TIMESTAMP"),
                    event_id = table.Column<string>(type: "text", nullable: true),
                    event_name = table.Column<string>(type: "text", nullable: true),
                    failed_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    failure_reported_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    last_retry = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true, defaultValueSql: "CURRENT_TIMESTAMP"),
                    remarks = table.Column<string>(type: "text", nullable: true),
                    retry_count = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_profile_processing_failure", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "ix_profile_processing_failure_account_id",
                schema: "profile",
                table: "profile_processing_failure",
                column: "account_id");

            migrationBuilder.CreateIndex(
                name: "ix_profile_processing_failure_event_id",
                schema: "profile",
                table: "profile_processing_failure",
                column: "event_id");
        }
    }
}