﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class CascadeDeleteIdentifier : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_account_profile_identifier_account_profile_account_profile_",
                schema: "profile",
                table: "account_profile_identifier");

            migrationBuilder.RenameColumn(
                name: "account_profile_account_id",
                schema: "profile",
                table: "account_profile_identifier",
                newName: "profile_account_id");

            migrationBuilder.RenameIndex(
                name: "ix_account_profile_identifier_account_profile_account_id",
                schema: "profile",
                table: "account_profile_identifier",
                newName: "ix_account_profile_identifier_profile_account_id");

            migrationBuilder.AddForeignKey(
                name: "fk_account_profile_identifier_account_profile_profile_account_",
                schema: "profile",
                table: "account_profile_identifier",
                column: "profile_account_id",
                principalSchema: "profile",
                principalTable: "account_profile",
                principalColumn: "account_id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_account_profile_identifier_account_profile_profile_account_",
                schema: "profile",
                table: "account_profile_identifier");

            migrationBuilder.RenameColumn(
                name: "profile_account_id",
                schema: "profile",
                table: "account_profile_identifier",
                newName: "account_profile_account_id");

            migrationBuilder.RenameIndex(
                name: "ix_account_profile_identifier_profile_account_id",
                schema: "profile",
                table: "account_profile_identifier",
                newName: "ix_account_profile_identifier_account_profile_account_id");

            migrationBuilder.AddForeignKey(
                name: "fk_account_profile_identifier_account_profile_account_profile_",
                schema: "profile",
                table: "account_profile_identifier",
                column: "account_profile_account_id",
                principalSchema: "profile",
                principalTable: "account_profile",
                principalColumn: "account_id");
        }
    }
}