﻿using System;

namespace Account.Spud.Api.Exceptions;

public class CloseAccountException(string code, string message)
    : Exception($"[{code}] {message}")
{
    public string Code { get; } = code;
}