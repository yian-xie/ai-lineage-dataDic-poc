## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account.Profile.Processor (`accounts-profile-processor`) |
| Customer or business impact | Account Profile data and emitted `account.profile.v1.event` events can be delayed, incomplete, or absent, affecting consumers of customer account status, tax, product, and freeze information. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Profile Processor Observability Dashboard (confluence)](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5223645397/Account+Profile+Processor+Observability+Dashboard)</li><li>[Account Profile Processor Observability Dashboard (dynatrace)](https://xye92727.live.dynatrace.com/#dashboard;gtf=-24h%20to%20now;gf=all;id=834f618d-443f-47a4-a54b-a278dfabe6a1)</li><li>[Sumo Logic Library](https://kbprod.au.sumologic.com/library/33964165)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Account event moved to DLQ for missing required data</summary>

**Symptoms**

- Log contains `Move to DLQ as the message does not have required fields` and PostgreSQL SQL state `23502`.
- The account create or update is absent from the Profile datastore and no corresponding profile event is emitted.

**Actions**

1. In the [logs](https://kbprod.au.sumologic.com/library/33964165), identify the account ID, event ID and first failure time.
2. Confirm the failure is the handled not-null violation rather than a redelivery failure.
3. Compare the failed payload with the active `vault.core_api.v2.accounts.account.events` schema and identify the missing required field.
4. Do not replay or alter data until the producer payload or processor/database contract is corrected.

**Recovery check**

- A corrected event logs `Successfully processed account creation` or `Successfully processed account updates`, the Profile datastore contains the expected state, and a matching `account.profile.v1.event` is emitted.

**Escalation**

- Use the incident escalation path when multiple events are affected, the contract owner cannot correct the payload, or recovery requires a schema/database change.

</details>

<details>
<summary>Subscriber repeatedly redelivers after dependency or persistence failure</summary>

**Symptoms**

- Logs contain `Retrying the message in 00:00:05 seconds` for account, contract-notification, or restriction events.
- Alerts begin after delivery attempt 3; consumer progress slows or stops.

**Actions**

1. Group failures by subscriber source name and exception in the [logs](https://kbprod.au.sumologic.com/library/33964165).
2. Determine whether the exception points to PostgreSQL, the TMV Kafka OAuth/plain clusters, ESP Kafka, Schema Registry, or processor code.
3. Confirm readiness and liveness state, then check the identified dependency in its owning platform.
4. Restore the dependency or deploy a tested fix. Do not reset offsets or restart the workload without confirming the failed operation is safe to repeat.

**Recovery check**

- Redelivery errors stop, successful-processing logs resume, and consumer lag trends back toward its pre-incident level. [TODO: confirm lag thresholds and access procedure].

**Escalation**

- Use the incident escalation path if all replicas are affected, lag continues increasing after dependency recovery, or the exception cannot be assigned to a dependency.

</details>

<details>
<summary>Parameter change waits for a missing account profile</summary>

**Symptoms**

- Logs contain `AccountProfile does not exist. Force message retry` or `does not exist yet for received Contract Notification / parameter_change Event`.
- Tax, interest-rate, or product fields remain stale for the account.

**Actions**

1. Capture the account ID and contract-notification event ID from the [logs](https://kbprod.au.sumologic.com/library/33964165).
2. Check whether the corresponding account create/update event was consumed and whether the account exists in the Profile datastore.[TODO: Does anybody have access to Production DB?]
3. If account processing is merely delayed, allow the five-second redelivery path to recover after the account appears.
4. If the account event is absent or failed, resolve that upstream/account-event failure first. [TODO: confirm the approved datastore lookup and Kafka event-correlation procedure].

**Recovery check**

- The parameter event logs successful processing, the expected Profile fields are populated, and an updated `account.profile.v1.event` is emitted.

**Escalation**

- Use the incident escalation path when the account event cannot be found, retries persist after the account exists, or multiple accounts are affected.

</details>

<details>
<summary>Restriction event waits for a missing account profile</summary>

**Symptoms**

- Logs contain `Force Restriction Set Created Event retry` or `Force Restriction Set Updated Event retry` for a non-existing account profile.
- Freeze or unfreeze state is not reflected in Account Profile and redelivery continues every five seconds.

**Actions**

1. Capture the account ID, restriction event ID and restriction type.
2. Confirm whether the account create/update event has completed and whether the Profile row exists. [TODO: Does anybody have access to Production DB?]
3. Resolve the account-event or datastore failure; the subscriber is designed to retry cross-topic out-of-order delivery.
4. Do not manually apply freeze state or reset offsets. [TODO: confirm the approved restriction-event replay procedure if automatic redelivery cannot recover].

**Recovery check**

- Logs contain `Successfully processed Restriction Set Event`, the stored restriction/freeze state matches the source event, and the expected profile update event is emitted unless suppression rules apply.

**Escalation**

- Use the incident escalation path when retries continue after the account exists, the source account event is missing, or customer access is affected.

</details>

<details>
<summary>Restriction event has invalid or unsupported data</summary>

**Symptoms**

- Logs contain `has data issue, unable to process` and the event moves to DLQ, or `Failed to process Restriction Set Event ... Skipping it`.
- Freeze or unfreeze state does not change for the affected account.

**Actions**

1. Identify the event ID and whether the event was created, updated, or neither.
2. Compare required restriction fields and timestamps with the active TMV restriction-set schema.
3. Confirm whether the event type lacks a registered handler or failed handler validation.
4. Correct the producer data or deploy a tested handler fix before replay. [TODO: confirm the approved DLQ inspection and replay procedure].

**Recovery check**

- The corrected event logs successful processing and the Profile datastore records the restriction event ID and expected state.

**Escalation**

- Use the incident escalation path for repeated malformed events, an unannounced schema change, or missing handler support.

</details>

<details>
<summary>Account updates are skipped, out of sequence, or concurrent</summary>

**Symptoms**

- Logs report a change ID lower than the stored change ID and ignore the message, a skipped update gap, or `Concurrency conflict of updating account profile`.
- Profile state appears stale or jumps over an expected intermediate update.

**Actions**

1. Capture account ID, event ID, incoming change ID, stored change ID, and timestamps.
2. Distinguish an expected duplicate/old event from a missing intermediate event or concurrent write.
3. For a forward gap, verify the processor rebuilt state from the full account update and emitted the warning to SumoLogic.
4. For a concurrency exception, monitor redelivery and verify the final stored change ID. [TODO: confirm the approved event-history query and replay procedure when an intermediate update is missing].

**Recovery check**

- The datastore reflects the latest TMV change ID and account state, successful-processing logs resume, and downstream profile events contain the current state.

**Escalation**

- Use the incident escalation path when the latest source state cannot be established, concurrency redeliveries persist, or state differs across systems.

</details>

<details>
<summary>Expected updates are intentionally filtered or ignored</summary>

**Symptoms**

- Logs report an internal account was skipped, a contract notification is not the target notification/resource type, or an unsupported parameter EDM attribute was ignored.
- No Profile update is emitted for the source event.

**Actions**

1. Match the log to the source event type and payload.
2. Confirm internal accounts are out of scope and contract notifications target `PARAMETER_CHANGE` on `RESOURCE_ACCOUNT`.
3. For an unsupported EDM attribute, confirm with the product owner whether it should affect Account Profile.
4. If behavior must change, add processor and integration coverage and deploy through the profile pipeline; do not replay until support is deployed.

**Recovery check**

- For expected filtering, no action is required. For newly supported data, a non-production test updates the datastore and emits `account.profile.v1.event` before promotion.

**Escalation**

- Use the incident escalation path only when repository behavior conflicts with the agreed business contract or causes customer impact.

</details>

<details>
<summary>Failure alerts are missing from SumoLogic</summary>

**Symptoms**

- Application logs contain `Failed to push log into SumoLogic` after a processing failure.
- Processor redelivery or DLQ behavior occurs without the expected SumoLogic alert.

**Actions**

1. Use [Dynatrace Dashboard](https://xye92727.live.dynatrace.com/#dashboard;gtf=-24h%20to%20now;gf=all;id=834f618d-443f-47a4-a54b-a278dfabe6a1) and [Logs](https://kbprod.au.sumologic.com/library/33964165) as the temporary source of truth.
2. Verify the `SumoLogicIngestion__SourceCategory`, source name, endpoint reachability, and the `accounts-profile-processor` secret reference without exposing secret values.
3. Restore log ingestion independently of event recovery; subscriber code catches alert-ingestion failures.

**Recovery check**

- A controlled non-production processing failure reaches the expected SumoLogic source and normal processing remains unaffected. [TODO: confirm the approved synthetic alert test].

**Escalation**

- Use the incident escalation path if alerting remains unavailable or processing failures may have gone unnoticed.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>