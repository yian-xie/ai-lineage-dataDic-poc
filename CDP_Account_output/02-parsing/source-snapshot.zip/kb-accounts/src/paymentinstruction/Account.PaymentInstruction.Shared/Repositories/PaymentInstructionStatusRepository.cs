﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Shared.Entities;
using Account.PaymentInstruction.Shared.Infrastructure;

using Enterprise.Shared.Database;

using Microsoft.EntityFrameworkCore;

namespace Account.PaymentInstruction.Shared.Repositories;

public class PaymentInstructionStatusRepository(PaymentInstructionDbContext dbContext)
    : RepositoryBase<PaymentInstructionDbContext>(dbContext),
        IPaymentInstructionStatusRepository
{
    public void Add(PaymentInstructionStatus paymentInstructionStatus)
    {
        DbContext.Add(paymentInstructionStatus);
    }

    public async Task<PaymentInstructionStatus[]> GetAsync(
        string clientBatchId,
        string clientId,
        CancellationToken cancellationToken)
    {
        return await DbContext.PaymentInstructionStatuses
            .Where(x => x.ClientBatchId == clientBatchId && x.ClientId == clientId)
            .ToArrayAsync(cancellationToken);
    }
}