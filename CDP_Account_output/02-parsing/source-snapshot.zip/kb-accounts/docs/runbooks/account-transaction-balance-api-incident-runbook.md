## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | `Account.Transaction.Balance.Api` |
| Customer or business impact | Authorised clients and staff cannot retrieve current balances, or ADPS cannot create cached balances and interim-booked transactions before TMV events arrive. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Transaction Balance API Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/B4BAKAE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33974169)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Balance API unavailable or readiness failing</summary>

**Symptoms**

- Availability, success-rate, or `5xx` alerts fire for `accounts-transaction-balance-api`.
- Pods in the affected `*-transaction-balance-api` namespace are not ready.
- GraphQL balance queries and `POST /api/posting-instruction-batch` fail together.

**Actions**

1. For a non-production check, request `GET https://accept-accounts-transaction-balance.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz/health/readiness`; expected result is HTTP 200. Probe authentication is not specified and this internal host is not verified as laptop-reachable. [TODO: confirm VPN/private-DNS or other access requirements and the expected response body.]
2. Filter [logs](https://kbprod.au.sumologic.com/library/33974169) by the affected namespace and correlate SQL errors with readiness failures and deployment time.
3. If the incident began with a release, stop promotion and use the approved fix-forward or rollback process. [TODO: confirm the approved pipeline rollback procedure.]

**Recovery check**

- Readiness returns HTTP 200, pods remain ready, and GraphQL and REST success rates return to baseline.

**Escalate when**

- PostgreSQL remains unavailable, production readiness remains failed, or both API interfaces remain unavailable after the deployment is healthy.

</details>

<details>
<summary>Account audit events missing or cannot be emitted</summary>

**Symptoms**

- Balance GraphQL requests are received, but the `audit.events.emitted` metric does not increase for the affected requests.
- The corresponding account audit event is absent or has an unexpected outcome, even though the balance response is available.
- Logs or traces for `accounts-transaction-balance-api` show an audit publisher or outbox persistence error.

**Actions**

1. Correlate the affected request trace with the audit event data produced by `AccountAuditLogEventBuilder`: event type `AccountAuditLogCreated`, source `urn:nz:co:kiwibank:account:audit`, account primary record IDs, and `SUCCESS` or `FAILURE` matching the GraphQL middleware error state.
2. Check the service logs and configured Kafka/outbox path for the same trace or client log request ID. The application uses the v2 audit outbox publisher and the environment-specific Kafka credentials named `Kafka__SaslUsername`, `Kafka__SaslPassword`, `Kafka__SchemaRegistry__ApiKey`, and `Kafka__SchemaRegistry__SecretKey`.
3. Do not manually republish events or alter the outbox. [TODO: confirm the approved audit-event replay or outbox-recovery procedure and the authorised audit-event verification tool.]

**Recovery check**

- GraphQL balance request increments `audit.events.emitted`, and the authorised audit-event verification shows one `AccountAuditLogCreated` event with the expected account ID and outcome.

**Escalate when**

- Audit emission remains lower than GraphQL request volume, the outbox/Kafka path rejects valid events, event account IDs or outcomes are incorrect, or the recovery procedure would require manual event publication or data changes.

</details>

<details>
<summary>Cached balance write reports false success</summary>

**Symptoms**

- ADPS receives `201 Created` with balance IDs, but those cached balances are absent from later reads.
- Logs contain `Failed to persist cached balances for Posting Instruction Batch (PIB) with batchId` followed by `StoreCachedBalancesAsync completed`.
- Balance queries continue to return an older balance until the TMV processor writes the actual balance.

**Actions**

1. Filter service logs for both exact messages and correlate on `batchId`; the persistence helper clears tracked changes and returns generated IDs after a failed save.
2. Check PostgreSQL/readiness errors at the same timestamp and determine whether the failure is isolated to cached-balance persistence.
3. Confirm the affected account through approved audit tooling without placing account IDs in incident communications.
4. Do not replay the ADPS request until idempotency and an approved replay procedure are confirmed. [TODO: confirm the supported ADPS PIB replay procedure and database verification query.]

**Recovery check**

- A new PIB request produces `StoreCachedBalancesAsync completed` without a preceding persistence error, and the resulting cached balance is returned by the balance query.

**Escalate when**

- A 201 response cannot be reconciled to a stored balance, multiple batches are affected, or actual TMV balances do not supersede the missing cache entry.

</details>

<details>
<summary>Interim-booked transactions missing after PIB success</summary>

**Symptoms**

- Cached balances are present, but corresponding interim-booked account transactions are absent.
- Logs contain `Failed to map interim-booked balance entry`, `Failed to persist account transactions`, or `Failed to roll back account transaction persistence`.
- `StoreCachedBalancesAsync completed` reports `saved transaction count: 0`; duplicate identities may instead log `Skipping account transactions`.

**Actions**

1. Correlate the exact messages by `batchId` and `postingInstructionId`; distinguish expected duplicate-constraint skips from mapping or database failures.
2. Check whether cached-balance persistence succeeded independently before the account-transaction transaction rolled back.
3. Confirm the downstream impact through the Transaction API and approved database/audit tooling. [TODO: confirm the approved non-production verification query.]
4. Do not manually insert or replay transactions; the two stores are intentionally independent and an unreviewed replay can create conflicting balances or duplicates.

**Recovery check**

- A new PIB persists both cached balances and a non-zero transaction count, or a duplicate skip is reconciled to an existing transaction.

**Escalate when**

- Mapping errors affect valid payloads, rollback fails, or cached balances and transaction history remain inconsistent.

</details>

<details>
<summary>Posting instruction batch validation failures spike</summary>

**Symptoms**

- `POST /api/posting-instruction-batch` returns HTTP 400 with `ValidationProblemDetails`.
- Logs contain `Validation failed for` with failures for required fields, empty posting instructions, or committed postings missing account, amount, or denomination data.
- GraphQL reads remain healthy.

**Actions**

1. Group `400` responses and validation logs by validation message and caller; do not record complete PIB payloads in incident communications.
2. Compare the first occurrence with the ADPS release or schema change timeline.
3. Confirm the endpoint contract in non-production Swagger at `https://situat-accounts-transaction-balance.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz/swagger/index.html`. The host is internal and laptop reachability is unverified. [TODO: confirm the supported access path.]
4. Treat isolated malformed requests as caller errors; treat a broad spike from previously valid traffic as an integration incident.

**Recovery check**

- A request returns HTTP 201 with an `ids` array, and validation failures return to their prior rate. No request was sent during runbook generation.

**Escalate when**

- Previously accepted payloads fail after a release, all ADPS requests are rejected, or the caller and API contracts disagree.

</details>

<details>
<summary>Balance reads are stale, empty, or failing</summary>

**Symptoms**

- `tmvAccountBalances` or `tmvAccountsBalances` returns stale/empty data or GraphQL server errors.
- Database and API health may be green while no current actual or cached balance exists.
- The issue follows delayed TMV processing or failed cached-balance creation.

**Actions**

1. In the linked observability page, isolate the GraphQL operation, SQL duration/errors, and the affected time window.
2. Confirm whether a later cached or actual balance exists; selection orders by insertion time, balance time, batch index, then prefers actual over cached when those values tie.
3. Correlate the batch with Balance API cache-write logs and `Account.Transaction.Tmv.Processor` success/redelivery logs.
4. Do not alter `is_cached_balance` or timestamps manually. [TODO: confirm the approved reconciliation and replay procedure.]

**Recovery check**

- The latest valid balance is returned for the affected account and actual balances supersede cached balances for the same PIB.

**Escalate when**

- Persisted rows exist but selection returns the wrong balance, multiple accounts are stale, or the TMV processor cannot produce actual balances.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>