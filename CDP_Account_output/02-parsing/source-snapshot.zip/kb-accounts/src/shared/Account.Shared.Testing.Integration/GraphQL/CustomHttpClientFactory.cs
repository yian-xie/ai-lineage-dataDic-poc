﻿using System.Net.Http.Headers;

using Flurl;

using Microsoft.AspNetCore.Mvc.Testing;

namespace Account.Shared.Testing.Integration.GraphQL;

/// <summary>
///     The CustomHttpClientFactory class is used to create an <see cref="HttpClient" /> by the given
///     <see cref="WebApplicationFactory{TEntryPoint}" />.
///     The created <see cref="HttpClient" /> is used by Strawberry.Shake GraphQL client to send the request to the server.
///     e.g. See line 1732 in TransactionClient.Client.cs: `clientFactory.CreateClient("TransactionClient")`
/// </summary>
/// <typeparam name="T">The entry point type for the WebApplicationFactory</typeparam>
/// <param name="webApplicationFactory">
///     <see cref="WebApplicationFactory{TEntryPoint}" />
/// </param>
/// <param name="httpClientName">The name of the HttpClient</param>
/// <param name="path">The path to the GraphQL endpoint</param>
public class CustomHttpClientFactory<T>(
    WebApplicationFactory<T> webApplicationFactory,
    string httpClientName,
    string path)
    : IHttpClientFactory where T : class
{
    private static readonly AsyncLocal<CustomHttpClientAuthorizationSettings>
        AuthorizationSettings = new();

    /// <summary>
    ///     Set the authorization settings for the current thread.
    /// </summary>
    /// <param name="authorizationSettings">
    ///     <see cref="AuthorizationSettings" />
    /// </param>
    public static void SetAuthorizationSettings(
        CustomHttpClientAuthorizationSettings authorizationSettings)
    {
        AuthorizationSettings.Value = authorizationSettings;
    }

    /// <summary>
    ///     Creates a new instance of an HttpClient by <see cref="WebApplicationFactory{TEntryPoint}" /> that is used to send a
    ///     request to the server.
    ///     Expects the name to be the given httpClientName. Otherwise throw the <see cref="ArgumentException" />.
    ///     It sets the base address to the GraphQL endpoint and sets the authorization header with the token.
    /// </summary>
    /// <param name="name">The HttpClient name</param>
    /// <returns>
    ///     <see cref="HttpClient" />
    /// </returns>
    public HttpClient CreateClient(string name)
    {
        if (name != httpClientName)
        {
            throw new ArgumentException(
                $"Invalid client name: {name}. Expected: {httpClientName}.");
        }

        var httpClient = webApplicationFactory.CreateDefaultClient();

        httpClient.BaseAddress =
            new Uri(httpClient.BaseAddress.AppendPathSegment(path));

        httpClient.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer",
                AuthorizationSettings.Value!.authorizationToken);

        if (!string.IsNullOrWhiteSpace(AuthorizationSettings.Value.CustomerIntrospectionToken))
        {
            httpClient.DefaultRequestHeaders.Add(
                AuthorizationSettings.Value.authorizationOptions.IntrospectionHeader,
                AuthorizationSettings.Value.CustomerIntrospectionToken);
        }

        return httpClient;
    }
}