﻿using HotChocolate;

namespace Account.PaymentInstruction.Api.Queries.Types;

[GraphQLName("Transfer")]
public class Transfer
{
    [GraphQLName("amount")] public decimal Amount { get; set; }

    [GraphQLName("credit")] public TransferParty Credit { get; set; }

    [GraphQLName("debit")] public TransferParty Debit { get; set; }
}