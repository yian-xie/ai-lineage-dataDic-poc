﻿using System;
using System.Globalization;

namespace Account.Transaction.Api.Queries.Services.Models;

/// <summary>
/// Date Range that is used for filtering Credit Card and Ultracs transactions.
/// </summary>
/// <param name="fromDate">From date <see cref="DateTime"/></param>
/// <param name="toDate">To date <see cref="DateTime"/></param>
/// <param name="currentDate">Current date <see cref="DateTime"/></param>
public record DateRange(
    DateTime FromDate,
    DateTime ToDate,
    DateTime CurrentDate)
{
    /// <summary>
    /// Override ToString() method to return the date range.
    /// </summary>
    /// <returns>The date range presentations.</returns>
    public override string ToString()
    {
        return $"FromDate: {FormatDate(FromDate)}, ToDate: {FormatDate(ToDate)}, CurrentDate: {FormatDate(CurrentDate)}";

        string FormatDate(DateTime date) =>
            date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
    }
}