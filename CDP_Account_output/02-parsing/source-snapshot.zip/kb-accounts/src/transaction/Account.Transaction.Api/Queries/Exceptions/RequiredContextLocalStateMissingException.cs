﻿using System.Net;

namespace Account.Transaction.Api.Queries.Exceptions;

/// <summary>
/// Exception thrown when required context local state is missing.
/// </summary>
public class RequiredContextLocalStateMissingException : TransactionExceptionBase
{
    /// <summary>
    /// RequiredContextLocalStateMissingException constructor.
    /// </summary>
    /// <param name="message">The error message</param>
    public RequiredContextLocalStateMissingException(string message) : base(message) { }

    /// <summary>
    /// RequiredContextLocalStateMissingException constructor with status code.
    /// </summary>
    /// <param name="message">The error message</param>
    /// <param name="statusCode"><see cref="HttpStatusCode"/></param>
    public RequiredContextLocalStateMissingException(string message, HttpStatusCode statusCode) : base(message, statusCode) { }
}