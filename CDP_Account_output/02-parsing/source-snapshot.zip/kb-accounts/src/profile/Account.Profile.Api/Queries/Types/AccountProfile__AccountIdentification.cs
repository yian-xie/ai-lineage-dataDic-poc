﻿using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__AccountIdentification")]
public class AccountProfile__AccountIdentification
{
    [GraphQLName("accountIdentification")] public string AccountIdentification { get; set; }

    [GraphQLName("accountIdentificationType")]
    public string AccountIdentificationType { get; set; }
}