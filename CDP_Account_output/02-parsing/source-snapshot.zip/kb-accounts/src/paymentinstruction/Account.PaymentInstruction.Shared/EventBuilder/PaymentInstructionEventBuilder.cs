﻿using System;
using System.Diagnostics;

using Account.Shared.Constants.Tmv;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

namespace Account.PaymentInstruction.Shared.EventBuilder;

/// <summary>
///     Build Payment Instruction Events
/// </summary>
public class PaymentInstructionEventBuilder(TimeProvider timeProvider)
    : IPaymentInstructionEventBuilder
{
    private const string MetadataSubject = "PaymentInstructionAcceptance";
    private const string MetadataActor = "Subscriber";

    private const string MetadataSource =
        "urn:nz:co:kiwibank:kb-accounts:account-paymentinstruction-tmv-processor";

    /// <summary>
    ///     Build the PaymentInstruction event from a PIB
    /// </summary>
    /// <param name="incomingEvent">
    ///     <see cref="PostingBatchEvent" />
    /// </param>
    /// <param name="instruction">Matched Payment Instruction</param>
    /// <returns>Payment Instruction Event</returns>
    public PaymentInstructionEvent BuildFromPostingInstructionBatchEvent(
        PostingBatchEvent incomingEvent,
        Entities.PaymentInstruction instruction)
    {
        var paymentInstructionStatus = GetPaymentInstructionStatus(
            incomingEvent.Posting_instruction_batch.Status,
            incomingEvent.Timestamp);

        return DoInternal(instruction, paymentInstructionStatus);
    }

    /// <summary>
    ///     Builds an PaymentInstruction event from a PIB with the status set to Error
    /// </summary>
    /// <param name="instruction"></param>
    /// <returns></returns>
    public PaymentInstructionEvent BuildErrorFromPostingInstructionBatch(
        Entities.PaymentInstruction instruction)
    {
        var paymentInstructionStatus = GetPaymentInstructionStatus(
            PostingInstructionBatchStatuses.Error,
            timeProvider.GetUtcNow());

        return DoInternal(instruction, paymentInstructionStatus);
    }

    public PaymentInstructionEvent BuildWithStatus(
        Entities.PaymentInstruction paymentInstruction,
        PaymentInstructionStatusStatus status)
    {
        return DoInternal(
            paymentInstruction,
            new PaymentInstructionStatus
            { Status = status, UpdatedDateTime = timeProvider.GetUtcNow() });
    }

    private PaymentInstructionEvent DoInternal(
        Entities.PaymentInstruction instruction,
        PaymentInstructionStatus paymentInstructionStatus)
    {
        var paymentInstruction = CreateEventPaymentInstruction(instruction);

        var paymentInstructionEvent = new PaymentInstructionEvent
        {
            Metadata = new Metadata
            {
                Type = MetadataType.PaymentInstructionUpdated,
                Actor = MetadataActor,
                Id = Guid.NewGuid(),
                Time = timeProvider.GetUtcNow(),
                Source = MetadataSource,
                Subject = MetadataSubject,
                CorrelationId = Guid.Empty
            },
            Data = new Data
            {
                AfterState = new PaymentInstructionStatusUpdate
                {
                    PaymentInstruction = paymentInstruction,
                    PaymentInstructionStatus = paymentInstructionStatus
                }
            }
        };

        return paymentInstructionEvent;
    }

    private Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult.PaymentInstruction
        CreateEventPaymentInstruction(Entities.PaymentInstruction paymentInstruction)
    {
        return new Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult.
            PaymentInstruction
        {
            Lifecycle = paymentInstruction.Lifecycle,
            TransactionId = paymentInstruction.TransactionId,
            PaymentInstructionType = paymentInstruction.Type,
            PostingInstructionId = paymentInstruction.ClientBatchId
        };
    }

    /// <summary>
    ///     Either Accepted or Rejected based on a provided error
    /// </summary>
    /// <param name="postingInstructionBatchStatus">The Posting Instruction Batch status</param>
    /// <param name="postingInstructionBatchTime">The time to set as status time. Use system time if it is null</param>
    /// <returns></returns>
    private PaymentInstructionStatus GetPaymentInstructionStatus(
        string postingInstructionBatchStatus,
        DateTimeOffset? postingInstructionBatchTime)
    {
        var statusTimestamp = postingInstructionBatchTime ?? timeProvider.GetUtcNow();

        var status = postingInstructionBatchStatus switch
        {
            PostingInstructionBatchStatuses.Rejected => PaymentInstructionStatusStatus.Rejected,
            PostingInstructionBatchStatuses.Accepted => PaymentInstructionStatusStatus.Accepted,
            PostingInstructionBatchStatuses.Error => PaymentInstructionStatusStatus.Error,
            { } unknown => throw new UnreachableException(
                $"Batch Status is unexpected: '{unknown}'"),
            null => throw new UnreachableException("Batch Status is null")
        };

        return new PaymentInstructionStatus
        {
            Status = status,
            UpdatedDateTime = statusTimestamp
        };
    }
}