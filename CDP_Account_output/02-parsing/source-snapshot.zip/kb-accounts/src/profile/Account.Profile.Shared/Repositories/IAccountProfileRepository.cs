﻿#nullable enable

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;

using Enterprise.Shared.Database;

namespace Account.Profile.Shared.Repositories;

public interface IAccountProfileRepository : IRepository
{
    /// <summary>
    ///     Insert the account profile.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="Account.Profile.Shared.Entities.AccountProfile" />
    /// </param>
    /// <returns></returns>
    void Add(AccountProfile accountProfile);

    /// <summary>
    ///     Update the account profile.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="Account.Profile.Shared.Entities.AccountProfile" />
    /// </param>
    /// <returns></returns>
    void Update(AccountProfile accountProfile);

    /// <summary>
    ///     Get the AccountProfile by Account Id.
    /// </summary>
    /// <param name="accountId">Account id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfile" />
    /// </returns>
    Task<AccountProfile?> GetAccountAsync(string accountId, CancellationToken cancellationToken);

    /// <summary>
    ///     Get the <see cref="AccountProfile" /> using given list of account IDs.
    /// </summary>
    /// <param name="accountIds">Account IDs</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>A list of <see cref="AccountProfile" /></returns>
    Task<AccountProfile[]> GetAccountsByAccountIdsAsync(
        IReadOnlyCollection<string> accountIds,
        CancellationToken cancellationToken);
}