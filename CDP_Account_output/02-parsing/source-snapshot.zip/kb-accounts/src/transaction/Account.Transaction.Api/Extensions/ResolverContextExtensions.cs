﻿using System.Collections.Generic;

using Account.Transaction.Api.CardsClient.Models;

using HotChocolate;
using HotChocolate.Resolvers;

namespace Account.Transaction.Api.Extensions;

/// <summary>
/// IResolver context extensions.
/// </summary>
public static class ResolverContextExtensions
{
    /// <summary>
    /// Extension for resolver context to report credit card transaction partial success response warnings.
    /// </summary>
    /// <param name="context"><see cref="IResolverContext"/></param>
    /// <param name="warnings">A collection of <see cref="Warning"/></param>
    public static void ReportResolverErrors(this IResolverContext context, IReadOnlyCollection<Warning> warnings)
    {
        foreach (var warning in warnings)
        {
            var error = ErrorBuilder
                .New()
                .SetMessage($"{warning.Message}")
                .SetCode($"{warning.Code}")
                .Build();

            context.ReportError(error);
        }
    }
}