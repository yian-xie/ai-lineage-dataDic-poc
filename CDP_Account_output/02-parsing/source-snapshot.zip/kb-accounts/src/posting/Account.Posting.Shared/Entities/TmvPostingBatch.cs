﻿using Account.Shared.Entities;

namespace Account.Posting.Shared.Entities;

public class TmvPostingBatch : AccountBaseEntity
{
    /// <summary>
    ///     Posting Instruction Id
    /// </summary>
    public new required string Id { get; set; }

    /// <summary>
    ///     The raw payload of the TMV Posting Batch Event.
    /// </summary>
    public required byte[] PostingBatchEventPayload { get; set; }
}