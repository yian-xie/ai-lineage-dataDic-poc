﻿using System.Net;

using Account.Transaction.Api.Queries.Exceptions;

namespace Account.Transaction.Api.CardsClient.Exceptions;

/// <summary>
/// Exception thrown when an error occurs while retrieving credit card transactions
/// </summary>
public class CreditCardTransactionsException : TransactionExceptionBase
{
    /// <summary>
    /// Initializes a new instance of the <see cref="CreditCardTransactionsException"/> class with a specified error message
    /// </summary>
    /// <param name="message">The error message that explains the reason for the exception</param>
    public CreditCardTransactionsException(string message) : base(message) { }

    /// <summary>
    /// Initializes a new instance of the <see cref="CreditCardTransactionsException"/> class with a specified error message and HTTP status code
    /// </summary>
    /// <param name="message">The error message that explains the reason for the exception</param>
    /// <param name="statusCode">The HTTP status code returned from the API</param>
    public CreditCardTransactionsException(string message, HttpStatusCode statusCode) : base(message, statusCode) { }
}