﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "profile");

            migrationBuilder.AlterDatabase()
                .Annotation("Npgsql:PostgresExtension:uuid-ossp", ",,");

            migrationBuilder.CreateTable(
                name: "account_profile",
                schema: "profile",
                columns: table => new
                {
                    account_id = table.Column<string>(type: "text", nullable: false),
                    status = table.Column<string>(type: "text", nullable: true),
                    party_role_ids = table.Column<string[]>(type: "text[]", nullable: true),
                    change_id = table.Column<long>(type: "bigint", nullable: false),
                    created = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    opened = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    closed = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    trace_context = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_account_profile", x => x.account_id);
                });

            migrationBuilder.CreateTable(
                name: "outbox",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    timestamp = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    payload = table.Column<byte[]>(type: "bytea", nullable: false),
                    topic = table.Column<string>(type: "text", nullable: false),
                    type = table.Column<string>(type: "text", nullable: false),
                    retry_count = table.Column<int>(type: "integer", nullable: false),
                    headers = table.Column<string>(type: "text", nullable: false),
                    last_retry = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    key = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_outbox", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "account_profile",
                schema: "profile");

            migrationBuilder.DropTable(
                name: "outbox");
        }
    }
}