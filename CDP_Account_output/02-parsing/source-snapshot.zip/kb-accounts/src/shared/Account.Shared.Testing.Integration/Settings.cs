﻿namespace Account.Shared.Testing.Integration;

public class Settings
{
    public const string Key = "Settings";
    public TimeSpan MaxWaitTimeUntilMessageIsProcessed { get; set; }
}