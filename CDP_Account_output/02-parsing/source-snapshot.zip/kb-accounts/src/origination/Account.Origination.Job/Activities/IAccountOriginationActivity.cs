﻿using System.Diagnostics;

using Account.Origination.Shared.Entities;

namespace Account.Origination.Job.Activities;

public interface IAccountOriginationActivity
{
    /// <summary>
    ///     Start activity from propagation context.
    /// </summary>
    /// <param name="activityName">Activity name</param>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <returns>
    ///     <see cref="Activity" />
    /// </returns>
    Activity? StartActivityFromPropagationContext(
        string activityName,
        AccountOpening accountOpening);
}