﻿using System.Threading;
using System.Threading.Tasks;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     The interface to create the <see cref="Shared.Entities.PaymentInstruction" /> with the given
///     <see cref="PaymentInstructionRequestInput" />.
/// </summary>
public interface IPaymentInstructionCreator
{
    /// <summary>
    ///     Process the given <see cref="PaymentInstructionRequestInput" />, create the
    ///     <see cref="Shared.Entities.PaymentInstruction" /> and insert into payment_instruction table.
    /// </summary>
    /// <param name="paymentInstructionRequestInput">
    ///     <see cref="PaymentInstructionRequestInput" />
    /// </param>
    /// <param name="clientBatchId">Client Batch id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns></returns>
    Task<Shared.Entities.PaymentInstruction> CreateAsync(
        PaymentInstructionRequestInput paymentInstructionRequestInput,
        string clientBatchId,
        CancellationToken cancellationToken);
}