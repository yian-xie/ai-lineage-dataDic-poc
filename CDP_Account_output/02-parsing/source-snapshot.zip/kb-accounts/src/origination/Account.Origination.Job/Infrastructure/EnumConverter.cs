﻿namespace Account.Origination.Job.Infrastructure
{
    public static class EnumConverter
    {
        /// <summary>
        /// Converts a string to its corresponding enum value. 
        /// Returns a default value if the conversion fails.
        /// </summary>
        public static T ToEnum<T>(string value, T defaultValue, bool ignoreCase = true) where T : struct, Enum
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return defaultValue;
            }

            // Performs case-insensitive parsing by default
            return Enum.TryParse<T>(value, ignoreCase, out T result) ? result : defaultValue;
        }
    }
}