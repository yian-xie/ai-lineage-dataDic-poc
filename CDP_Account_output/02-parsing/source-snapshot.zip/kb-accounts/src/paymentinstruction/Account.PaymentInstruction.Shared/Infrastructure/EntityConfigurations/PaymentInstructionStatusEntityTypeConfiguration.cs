﻿using Account.PaymentInstruction.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.PaymentInstruction.Shared.Infrastructure.EntityConfigurations;

public class
    PaymentInstructionStatusEntityTypeConfiguration : AccountBaseEntityTypeConfiguration<
    PaymentInstructionStatus, PaymentInstructionDbContext>
{
    protected override string TableName => "payment_instruction_status";

    protected override void ConfigureTable(EntityTypeBuilder<PaymentInstructionStatus> builder)
    {
        builder.HasKey(t => t.Id);
    }
}