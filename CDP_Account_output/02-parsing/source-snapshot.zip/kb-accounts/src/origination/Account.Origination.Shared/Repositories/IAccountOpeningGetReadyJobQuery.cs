﻿#nullable enable
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure;

namespace Account.Origination.Shared.Repositories;

public interface IAccountOpeningGetReadyJobQuery
{
    /// <summary>
    ///     Return the query to execute to get the <see cref="AccountOpening" />.
    /// </summary>
    /// <returns>
    ///     A generic delegate with the <see cref="OriginationDbContext" /> and <see cref="DateTimeOffset" /> input parameters
    ///     and the output parameter is a task of <see cref="AccountOpening" />
    /// </returns>
    abstract static
        Func<OriginationDbContext, DateTimeOffset, DateTimeOffset, Task<AccountOpening?>>
        GetQuery();
}