﻿#nullable enable
namespace Account.Origination.Shared;

public static class Telemetry
{
    public const string ActivitySourceName = "account_origination";
}