﻿using System;

namespace Account.Profile.Shared.Entities;

public class AccountFreezeDetails
{
    /// <summary>
    /// Restriction Set Id.
    /// </summary>
    public string RestrictionSetId { get; set; }
    /// <summary>
    /// Freeze type -- TMV Values Account_DebitFreeze, Account_DebitAndCreditFreeze
    /// </summary>
    public string FreezeType { get; set; }
    /// <summary>
    /// Freeze description
    /// </summary>
    public string FreezeDescription { get; set; }
    /// <summary>
    /// Change id for a given TMV restriction set for account freeze
    /// </summary>
    public long? ChangeId { get; set; }
    /// <summary>
    /// Restriction effective date time.
    /// </summary>
    public DateTimeOffset? Effective { get; set; }
    /// <summary>
    /// Restriction expiration date time.
    /// </summary>
    public DateTimeOffset? Expiration { get; set; }
}