﻿#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Publishers;
using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Repositories;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;

using Microsoft.Extensions.Logging;

using DomesticTaxRate = Account.Profile.Shared.Entities.DomesticTaxRate;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Implements IAccountProfileCreator interface for creating AccountProfile in the database.
/// </summary>
public class AccountProfileCreator(
    IRepositoryFactory repositoryFactory,
    IAccountProfileChangeSetCreator accountProfileChangeSetCreator,
    IAccountProfileEventPublisher accountProfileEventPublisher,
    ILogger<AccountProfileCreator> logger)
    : IAccountProfileCreator
{
    public async Task<AccountProfile> CreateAndPublishAsync(
        AccountEvent accountEvent,
        DateTimeOffset accountStatusTimestamp,
        bool ignoreAccountExistenceCheck,
        CancellationToken cancellationToken)
    {
        var accountId = accountEvent.Account_created?.Account.Id ??
            accountEvent.Account_updated?.Account.Id ?? string.Empty;

        if (!ignoreAccountExistenceCheck)
        {
            var existingAccountProfile =
                await repositoryFactory.AccountProfileRepository.GetAccountAsync(
                    accountId,
                    cancellationToken);

            if (existingAccountProfile != null)
            {
                logger.LogWarning(
                    $"Received Account Creation Event for AccountId {accountId} which is already exists. Ignore the event.");

                return existingAccountProfile;
            }
        }

        var accountProfileChangeSet = accountProfileChangeSetCreator.CreateAccountProfileChangeSet(accountEvent);

        var accountProfile = new AccountProfile
        {
            AccountId = accountProfileChangeSet.AccountId,
            Name = accountProfileChangeSet.AccountName,
            AlternateName = accountProfileChangeSet.AlternateAccountName,
            Status = AccountStatusHelper.AccountStatusStringFromTmvStatusString(accountProfileChangeSet.Status),
            TmvStatus = accountProfileChangeSet.Status,
            TSide = accountProfileChangeSet.TSide,
            CorrelationId = accountEvent.GetCorrelationId(logger) ?? Guid.Empty,
            ChangeId = accountProfileChangeSet.ChangeId,
            Created = accountProfileChangeSet.Created,
            Opened = accountProfileChangeSet.Opened,
            Closed = accountProfileChangeSet.Closed,
            Identifiers = new List<AccountProfileIdentifier>(),
            AccountOrganisationUnitId = accountProfileChangeSet.AccountOrganisationUnitId,
            MinimumNumberOfAuthoriser = accountProfileChangeSet.MinimumNumberOfAuthoriser,
            AccountCreatedUserId = accountProfileChangeSet.AccountCreatedUserId,
            DomesticTaxRate = new DomesticTaxRate
            {
                DomesticTaxType = accountProfileChangeSet.WithholdingTaxType,
                RateValue = accountProfileChangeSet.WithholdingTaxRate,
                CountryAlpha3Code = accountProfileChangeSet.CountryAlpha3Code
            },
            ProductFacility = new AccountProfileProductFacility
            {
                ProductFacilityId = accountProfileChangeSet.ProductFacilityId,
                BankingProductId = accountProfileChangeSet.BankingProductId,
                BankingProductVersionId = accountProfileChangeSet.BankingProductVersionId,
                BankingProductCode = accountProfileChangeSet.BankingProductCode
            },
            BankingRelationship = new AccountBankingRelationship
            {
                BankingRelationshipId = accountProfileChangeSet.BankingRelationshipId,
                BankingRelationshipType = accountProfileChangeSet.BankingRelationshipType,
                NominatedTaxPartyId = accountProfileChangeSet.NominatedTaxPartyId,
                PartyIds = accountProfileChangeSet.PartyIds
            },
            AccountCurrencies = accountProfileChangeSet.AccountCurrencies
                .Select(accountCurrency =>
                    new Shared.Entities.AccountCurrency
                    {
                        Currency = accountCurrency.Currency,
                        CurrencyType = accountCurrency.CurrencyType
                    })
                .ToList()
        };

        if (accountProfileChangeSet.NzBankAccountNumber != null)
        {
            accountProfile.Identifiers.Add(
                new AccountProfileIdentifier
                {
                    AccountIdentification = accountProfileChangeSet.NzBankAccountNumber,
                    AccountIdentificationType = ProfileKeys.Details.NzBankAccountNumber
                });
        }

        if (accountProfileChangeSet.LegacyCoreAccountId != null)
        {
            accountProfile.Identifiers.Add(
                new AccountProfileIdentifier
                {
                    AccountIdentification = accountProfileChangeSet.LegacyCoreAccountId,
                    AccountIdentificationType = ProfileKeys.Details.LegacyCoreAccountId
                });
        }

        if (accountProfileChangeSet.BaseAccountNumber != null)
        {
            accountProfile.Identifiers.Add(
                new AccountProfileIdentifier
                {
                    AccountIdentification = accountProfileChangeSet.BaseAccountNumber,
                    AccountIdentificationType = ProfileKeys.Details.BaseAccountNumber
                });
        }

        repositoryFactory.AccountProfileRepository.Add(accountProfile);
        await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);

        logger.LogInformation(
            "The AccountProfile for account id {accountId} with changeId {changeId} is created.",
            accountProfile.AccountId,
            accountProfile.ChangeId);

        await accountProfileEventPublisher.PublishAccountProfileEventAsync(
              accountProfile,
              MetadataType.AccountCreated,
              accountStatusTimestamp,
              accountEvent.GetCorrelationId(logger),
              repositoryFactory.UnitOfWork,
              cancellationToken);

        return accountProfile;
    }
}