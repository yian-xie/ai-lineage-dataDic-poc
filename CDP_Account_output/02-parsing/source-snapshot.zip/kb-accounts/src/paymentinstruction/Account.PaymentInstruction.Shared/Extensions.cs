﻿using Account.PaymentInstruction.Shared.Repositories;

using Microsoft.Extensions.DependencyInjection;

namespace Account.PaymentInstruction.Shared;

public static class Extensions
{
    public static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        return services
            .AddScoped<IRepositoryFactory, RepositoryFactory>()
            .AddScoped<IPaymentInstructionRepository, PaymentInstructionRepository>()
            .AddScoped<IPaymentInstructionStatusRepository, PaymentInstructionStatusRepository>();
    }
}