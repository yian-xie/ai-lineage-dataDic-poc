﻿using System.Net;

namespace Account.Transaction.Api.Queries.Exceptions;

/// <summary>
/// Request validation exception for missing required fields that marked `requireFields` directive in transaction GraphQL request.
/// </summary>
public class RequestRequiredFieldMissingException : TransactionExceptionBase
{
    /// <summary>
    /// Request validation exception constructor
    /// </summary>
    /// <param name="message">The error message</param>
    public RequestRequiredFieldMissingException(string message) : base(message) { }

    /// <summary>
    /// Request validation exception constructor with status code
    /// </summary>
    /// <param name="message">The error message</param>
    /// <param name="statusCode"><see cref="HttpStatusCode"/></param>
    public RequestRequiredFieldMissingException(string message, HttpStatusCode statusCode) : base(message, statusCode) { }
}