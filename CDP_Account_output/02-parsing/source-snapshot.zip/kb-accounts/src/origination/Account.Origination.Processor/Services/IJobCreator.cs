﻿using Account.Origination.Shared.Entities;

namespace Account.Origination.Processor.Services;

public interface IJobCreator
{
    /// <summary>
    ///     Insert AccountOpening into database.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns></returns>
    Task<AccountOpening?> CreateAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken);
}