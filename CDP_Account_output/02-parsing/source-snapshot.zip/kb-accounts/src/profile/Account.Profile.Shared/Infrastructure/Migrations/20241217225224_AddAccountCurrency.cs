﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAccountCurrency : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "account_currency",
                schema: "profile",
                columns: table => new
                {
                    row_id = table.Column<Guid>(type: "uuid", nullable: false),
                    currency = table.Column<string>(type: "text", nullable: true),
                    currency_type = table.Column<string>(type: "text", nullable: true),
                    profile_account_id = table.Column<string>(type: "text", nullable: true),
                    xmin = table.Column<uint>(type: "xid", rowVersion: true, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_account_currency", x => x.row_id);
                    table.ForeignKey(
                        name: "fk_account_currency_account_profile_profile_account_id",
                        column: x => x.profile_account_id,
                        principalSchema: "profile",
                        principalTable: "account_profile",
                        principalColumn: "account_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_account_currency_profile_account_id",
                schema: "profile",
                table: "account_currency",
                column: "profile_account_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "account_currency",
                schema: "profile");
        }
    }
}