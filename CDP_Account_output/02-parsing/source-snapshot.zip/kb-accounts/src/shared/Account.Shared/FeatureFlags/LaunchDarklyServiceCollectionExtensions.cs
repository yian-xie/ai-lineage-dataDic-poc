﻿using System.Collections.Generic;
using System.Linq;

using LaunchDarkly.Logging;
using LaunchDarkly.Sdk;
using LaunchDarkly.Sdk.Server;
using LaunchDarkly.Sdk.Server.Integrations;
using LaunchDarkly.Sdk.Server.Interfaces;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Account.Shared.FeatureFlags;

public static class LaunchDarklyServiceCollectionExtensions
{
    public static IServiceCollection AddLaunchDarkly(this IServiceCollection services)
    {
        services.AddOptions<LaunchDarklyOptions>()
            .BindConfiguration(LaunchDarklyOptions.ConfigurationKey)
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddSingleton<ILdClient>(sp =>
        {
            var options = sp.GetRequiredService<IOptions<LaunchDarklyOptions>>().Value;
            var loggerFactory = sp.GetRequiredService<ILoggerFactory>();

            var ldConfigBuilder = Configuration.Builder(options.SdkKey)
                .Logging(LdMicrosoftLogging.Adapter(loggerFactory));

            if (string.IsNullOrWhiteSpace(options.SdkKey) && options.FlagValues.Any())
            {
                // Leverage the Configuration system to load feature flags from sources like appsettings.json or env variables
                // Note: FlagValues is case-insensitive here so you can copy-paste from a simple-format feature-flags.json
                ldConfigBuilder.DataSource(BuildDataSource(options.FlagValues));

                ldConfigBuilder.Events(Components.NoEvents);
            }

            var ldConfig = ldConfigBuilder.Build();

            return new LdClient(ldConfig);
        });

        services.AddSingleton<IFeatureService, FeatureService>();

        return services;
    }

    private static TestData BuildDataSource(Dictionary<string, string> values)
    {
        var source = TestData.DataSource();

        foreach (var kvp in values)
        {
            source.Update(bool.TryParse(kvp.Value, out var boolValue)
                ? source.Flag(kvp.Key).ValueForAll(LdValue.Of(boolValue))
                : source.Flag(kvp.Key).ValueForAll(LdValue.Of(kvp.Value)));
        }

        return source;
    }
}