﻿using Enterprise.Shared.Configuration;

namespace Account.Origination.Job.Configurations;

public record TmvProductsSettings : IKeyedConfigurationSection
{
    public required string SpudProductVersion { get; set; }
    public required string CurrentAndSavingProductVersion { get; set; }
    public required string Sv1ProductVersion { get; set; }
    public static string Key => "TmvProducts";
}