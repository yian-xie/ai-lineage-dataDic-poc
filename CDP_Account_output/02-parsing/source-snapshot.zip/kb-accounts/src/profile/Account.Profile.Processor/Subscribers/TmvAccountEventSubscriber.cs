﻿#nullable enable

using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Services;
using Account.Profile.Shared.Constants;
using Account.Shared.Configurations;
using Account.Shared.Services;

using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;
using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Npgsql;

namespace Account.Profile.Processor.Subscribers;

public class TmvAccountEventSubscriber(
    IAccountProfileCreator accountProfileCreator,
    IAccountProfileUpdater accountProfileUpdater,
    ISumoLogicClientHelper sumoLogicClientHelper,
    ILogger<TmvAccountEventSubscriber> logger,
    SumoLogicSettings sumoLogicSettings,
    RetrySettings retrySettings)
    : IIncomingEventSubscriber<AccountEvent>
{


    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        AccountEvent accountEvent,
        CancellationToken cancellationToken)
    {
        var accountId = accountEvent.GetAccountId();

        if (accountEvent.IsInternalAccount())
        {
            logger.LogWarning($"Event for internal accountId - {accountId} is skipped.");

            return EventSubscriberResults.Skip;
        }

        try
        {
            var accountStatusTimestamp = accountEvent.Timestamp ?? context.ConsumeResult.Message.Timestamp.UtcDateTime;

            if (accountEvent.Account_created != null)
            {
                await accountProfileCreator.CreateAndPublishAsync(
                    accountEvent,
                    accountStatusTimestamp,
                    false,
                    cancellationToken);

                logger.LogInformation(
                    $"Successfully processed account creation for AccountId: {accountId} and EventId: {accountEvent.Event_id}");
            }
            else if (accountEvent.Account_updated != null)
            {
                await accountProfileUpdater.UpdateAndPublishAsync(
                    accountEvent,
                    accountStatusTimestamp,
                    cancellationToken);

                logger.LogInformation(
                    $"Successfully processed account updates for AccountId: {accountId} and EventId: {accountEvent.Event_id}");
            }

            return EventSubscriberResults.Success;
        }
        catch (DbUpdateException dbEx) when (dbEx.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.NotNullViolation
        })
        {
            logger.LogError(
                dbEx,
                $"Failed to process Account Event for AccountId: {accountId} and EventId: {accountEvent.Event_id}. Move to DLQ as the message does not have required fields.");

            await RaiseSumoLogicAlertAsync(accountId, accountEvent.Event_id, dbEx, cancellationToken);

            return new MoveToDlqEventSubscriberResult(dbEx);
        }

        catch (Exception ex)
        {
            logger.LogError(
                ex,
                $"Failed to process Account Event for AccountId: {accountId} and EventId: {accountEvent.Event_id}. Retrying the message in {retrySettings.RedeliveryInterval} seconds.");

            // If the retry attempts has exceeded the threshold, raise sumologic alert
            if (context.DeliveryAttempt > retrySettings.RetryAttemptAlertThreshold)
            {
                await RaiseSumoLogicAlertAsync(accountId, accountEvent.Event_id, ex, cancellationToken);
            }

            return new RedeliverMessageEventSubscriberResult(retrySettings.RedeliveryInterval);
        }
    }



    private async Task RaiseSumoLogicAlertAsync(
        string accountId,
        string eventId,
        Exception ex,
        CancellationToken cancellationToken)
    {
        try
        {
            await sumoLogicClientHelper.IngestLogAsync(
                $"Failed to process Account Event for AccountId: {accountId} and EventId: {eventId}. Exception: {ex}",
                sumoLogicSettings.SourceCategory,
                sumoLogicSettings.SourceName + Constants.SumoSourceNames.TmvAccountEventSubscriber,
                sumoLogicSettings.ApiToken,
                cancellationToken);
        }
        catch (Exception nestedEx)
        {
            logger.LogError(
                nestedEx,
                $"Failed to push log into SumoLogic for failed processing of Account Event for AccountId: {accountId} and EventId: {eventId}");
        }
    }
}