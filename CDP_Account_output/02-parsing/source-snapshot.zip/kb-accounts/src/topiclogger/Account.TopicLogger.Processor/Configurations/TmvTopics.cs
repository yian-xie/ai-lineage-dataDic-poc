﻿namespace Account.TopicLogger.Processor.Configurations;

/// <summary>
///     The class return the topics for TMV Audit, Action, and DLQs
/// </summary>
public static class TmvTopics
{
    public static readonly IReadOnlyCollection<string> ActionTopics = new List<string>
        { "vault.api.v1.action_logs.action_log.created" };

    public static readonly IReadOnlyCollection<string> AuditTopics = new List<string>
        { "vault.api.v1.audit_logs.audit_log.created" };

    public static readonly IReadOnlyCollection<string> DqlTopics = new List<string> {
        "vault.core.postings.requests.dlq.v1",
        "vault.core_api.v1.accounts.account_post_posting_execution_failure.events.failures",
        "vault.core_api.v1.accounts.account_schedule_job_execution_failure.events.failures",
        // The following topics are disabled because TMV Kafka returns Topic authorization failed.
        // "vault.core.contracts.journeys.account_schedule.responses.dlq",
        "vault.core_api.v2.accounts.account.events.failures",
        "vault.core_api.v1.calendar.calendar.events.failures",
        "vault.core_api.v1.calendar.calendar_event.events.failures",
        "vault.core_api.v1.calendar.calendar_period.events.failures",
        "vault.core_api.v1.contracts.contract_notification.events.failures",
        "vault.api.v1.customers.customer.created.failures",
        "vault.api.v1.customers.customer.customer_details.updated.failures",
        "vault.core_api.v1.customers.customer_address.events.failures",
        "vault.core_api.v1.scheduler.operation.events.failures",
        // The following topics are disabled because TMV Kafka returns Topic authorization failed.
        // "vault.core.balances.account_balance.events.contract_post_balance_update_processor.dlq",
        "vault.core_api.v1.parameters.parameter_value.events.failures",
        "vault.core_api.v1.restrictions.restriction_set.events.failures"
    };

    public static readonly IReadOnlyCollection<string> AlertTopics = new List<string>
        { "vault.core_api.v1.vault_jobs.group.events" };
}