﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.Profile.Processor.Services;

public interface IContractNotificationProcessor
{
    Task ProcessEvent(
        IncomingEventContext context,
        ContractNotification incomingEvent,
        CancellationToken cancellationToken);
}