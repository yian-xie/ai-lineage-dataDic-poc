﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Posting.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddTmvPostingBatch : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "account_posting",
                schema: "posting");

            migrationBuilder.CreateTable(
                name: "tmv_positing_batch",
                schema: "posting",
                columns: table => new
                {
                    id = table.Column<string>(type: "text", nullable: false),
                    posting_batch_event_payload = table.Column<byte[]>(type: "bytea", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tmv_positing_batch", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tmv_positing_batch",
                schema: "posting");

            migrationBuilder.CreateTable(
                name: "account_posting",
                schema: "posting",
                columns: table => new
                {
                    id = table.Column<string>(type: "text", nullable: false),
                    row_index = table.Column<int>(type: "integer", nullable: false),
                    account_id = table.Column<string>(type: "text", nullable: false),
                    address = table.Column<string>(type: "text", nullable: false),
                    amount = table.Column<decimal>(type: "numeric", nullable: false),
                    asset = table.Column<string>(type: "text", nullable: false),
                    batch_id = table.Column<string>(type: "text", nullable: false),
                    client_id = table.Column<string>(type: "text", nullable: false),
                    credit = table.Column<bool>(type: "boolean", nullable: false),
                    denomination = table.Column<string>(type: "text", nullable: false),
                    phase = table.Column<string>(type: "text", nullable: false),
                    trace_context = table.Column<string>(type: "text", nullable: true),
                    transaction_code = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_account_posting", x => new { x.id, x.row_index });
                });
        }
    }
}