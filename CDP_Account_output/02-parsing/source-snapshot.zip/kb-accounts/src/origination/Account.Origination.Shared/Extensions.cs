﻿using Account.Origination.Shared.Repositories;

using Microsoft.Extensions.DependencyInjection;

namespace Account.Origination.Shared;

public static class Extensions
{
    public static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        return services
            .AddScoped<IRepositoryFactory, RepositoryFactory>()
            .AddScoped<IAccountOpeningRepository, AccountOpeningRepository>();
    }
}