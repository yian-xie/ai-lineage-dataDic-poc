﻿using System.Collections.Generic;

using Account.Transaction.Api.Queries.Services.Models;

namespace Account.Transaction.Api.CardsClient.Models;

/// <summary>
/// Response from the Cards Transactions API
/// </summary>
public record CardTransactionsResponse
{
    /// <summary>
    /// List of Transactions returned by the Cards Transactions API
    /// </summary>
    public List<CreditCardTransaction> Transactions { get; set; } = [];

    /// <summary>
    /// List of <see cref="Warning"/> Information about what lead to a PARTIAL_SUCCESS status
    /// </summary>
    public List<Warning> Warnings { get; set; } = [];

    /// <summary>
    /// Response status. Has a value of either "SUCCESS" or "PARTIAL_SUCCESS"
    /// </summary>
    public string Status { get; set; } = string.Empty;
}