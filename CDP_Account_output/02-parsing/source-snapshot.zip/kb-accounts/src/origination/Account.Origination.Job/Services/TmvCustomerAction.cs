﻿using System.Net;

using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Infrastructure;
using Account.Origination.Job.Infrastructure.Resilience;
using Account.Origination.Shared.Infrastructure.Exceptions;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Kb.TMV.Client.Actions.CreateCustomer.Requests;
using Kb.TMV.Client.Actions.GetCustomer.Constants;
using Kb.TMV.Client.Actions.GetCustomer.Requests;

using ApiException = Api.Shared.Clients.Rest.ThoughtMachine.V5.Core.ApiException;
using TmvClient = Kb.TMV.Client.ITmvClient;

namespace Account.Origination.Job.Services;

public class TmvCustomerAction(
    ICoreAPICustomersClient customersClient,
    ILogger<TmvCustomerAction> logger,
    IStandardResiliencePipeline<V1customersCustomer, TmvApiExceptionResilienceStrategy, ICoreAPICustomersClient> resiliencePipeline,
    TmvClient tmvClient)
    : ITmvCustomerAction
{
    private readonly TmvClient _tmvClient = tmvClient;

    public async Task<V1customersCustomer?> GetAsync(string id, CancellationToken cancellationToken)
    {
        try
        {
            return await customersClient.GetCustomerAsync(id, cancellationToken);
        }
        catch (ApiException ex)
        {
            if ((HttpStatusCode)ex.StatusCode == HttpStatusCode.NotFound)
            {
                logger.LogWarning("TMV customer {customerId} not found.", id);

                return null;
            }

            logger.LogWarning(ex,
                "Expecting 404 exception for GET customer with id = {id}, but something other than 404 was caught.",
                id);

            throw;
        }
    }

    public async Task<V1customersCustomer?> GetAsync(string id, string correlationId, CancellationToken cancellationToken)
    {
        try
        {
            var request = new GetCustomerRequest(id, correlationId);

            var result = await _tmvClient.GetCustomerAsync(request, cancellationToken);

            if (!result.IsSuccess)
            {
                if (result.Failure.Errors[0].Code == GetCustomerConstants.ErrorCode.CustomerNotExist)
                {
                    logger.LogWarning("TMV customer {customerId} not found.", id);
                    return null;
                }

                var error = result.Failure.Errors[0];

                logger.LogError("Failed to get TMV customer {customerId}. Error: {error}",
                    id, result.Failure.Errors[0].Message);

                throw new AccountOriginationException($"Failed to get TMV customer {id}: [{error.Code}] {error.Message}");
            }

            var customer = result.Success;

            return new V1customersCustomer
            {
                Id = customer.CustomerId,
                Status = EnumConverter.ToEnum(customer.Status, V1customersCustomerStatus.CUSTOMER_STATUS_UNKNOWN)
            };

        }
        catch (ApiException ex)
        {
            if ((HttpStatusCode)ex.StatusCode == HttpStatusCode.NotFound)
            {
                logger.LogWarning("TMV customer {customerId} not found.", id);

                return null;
            }

            logger.LogError(ex,
                "While executing GET customer with id = {id}, something other than 404 was caught.",
                id);
            throw;
        }
    }

    public async Task<V1customersCustomer> CreateAsync(
        string id,
        PartyResultDto? party,
        CancellationToken cancellationToken)
    {
        try
        {
            ArgumentNullException.ThrowIfNull(party);
            ArgumentNullException.ThrowIfNull(party.FirstName, nameof(party.FirstName));
            ArgumentNullException.ThrowIfNull(party.LastName, nameof(party.LastName));
            ArgumentNullException.ThrowIfNull(party.AccessNumber, nameof(party.AccessNumber));

            var customerDetails = new V1customersCustomerDetails
            {
                First_name = party.FirstName,
                Last_name = party.LastName,
                External_customer_id = party.AccessNumber
            };

            var request = new V1customersCreateCustomerRequest
            {
                Request_id = Guid.NewGuid().ToString(),
                Customer = new V1customersCustomer
                {
                    Id = id,
                    Status = V1customersCustomerStatus.CUSTOMER_STATUS_ACTIVE,
                    Customer_details = customerDetails
                }
            };

            return await resiliencePipeline.ExecuteAsync(
                async ct => await customersClient.CreateCustomerAsync(request, ct),
                cancellationToken,
                new { CustomerId = id });
        }
        catch (ApiException ex)
        {
            logger.LogError(ex, "Failed to create TMV customer {customerId}.", id);

            throw;
        }
    }

    public async Task<V1customersCustomer> CreateAsync(
        string id,
        string correlationId,
        PartyResultDto? party,
        CancellationToken cancellationToken)
    {
        try
        {
            ArgumentNullException.ThrowIfNull(party);
            ArgumentNullException.ThrowIfNull(party.FirstName, nameof(party.FirstName));
            ArgumentNullException.ThrowIfNull(party.LastName, nameof(party.LastName));
            ArgumentNullException.ThrowIfNull(party.AccessNumber, nameof(party.AccessNumber));

            var request = new CreateCustomerRequest(
                customerId: id,
                correlationId: correlationId,
                requestId: Guid.NewGuid().ToString(),
                firstName: party.FirstName,
                lastName: party.LastName,
                externalCustomerId: party.AccessNumber);

            var result = await _tmvClient.CreateCustomerAsync(request, cancellationToken);

            if (!result.IsSuccess)
            {
                var error = result.Failure.Errors[0];
                logger.LogError("Failed to create TMV customer {customerId}: [{code}] {message}.", id, error.Code, error.Message);
                throw new InvalidOperationException($"Failed to create TMV customer {id}: [{error.Code}] {error.Message}");
            }

            logger.LogInformation("Created TMV customer {customerId}.", id);

            if (!Enum.TryParse<V1customersCustomerStatus>(result.Success.CustomerStatus, out var status))
            {
                throw new InvalidOperationException(
                $"TMV customer {id} returned unrecognised status: {result.Success.CustomerStatus}");
            }

            return new V1customersCustomer
            {
                Id = result.Success.CustomerId,
                Status = status,
            };

        }
        catch (ApiException ex)
        {
            logger.LogError(ex, "Failed to create TMV customer {customerId}.", id);

            throw;
        }
    }

}