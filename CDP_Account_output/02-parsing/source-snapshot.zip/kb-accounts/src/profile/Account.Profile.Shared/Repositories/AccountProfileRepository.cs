﻿#nullable enable

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Infrastructure;

using Enterprise.Shared.Database;

using Microsoft.EntityFrameworkCore;

namespace Account.Profile.Shared.Repositories;

public class AccountProfileRepository(AccountProfileDbContext dbContext)
    : RepositoryBase<AccountProfileDbContext>(dbContext),
        IAccountProfileRepository
{
    public void Add(AccountProfile accountProfile)
    {
        DbContext.Add(accountProfile);
    }

    public void Update(AccountProfile accountProfile)
    {
        DbContext.Update(accountProfile);
    }

    public async Task<AccountProfile?> GetAccountAsync(
        string accountId,
        CancellationToken cancellationToken)
    {
        return await DbContext.AccountProfiles
            .Include(x => x.Identifiers)
            .Include(x => x.AccountCurrencies)
            .Include(x => x.Restrictions)
            .AsSplitQuery()
            .FirstOrDefaultAsync(x => x.AccountId == accountId, cancellationToken);
    }

    public async Task<AccountProfile[]> GetAccountsByAccountIdsAsync(
        IReadOnlyCollection<string> accountIds,
        CancellationToken cancellationToken)
    {
        return await DbContext.AccountProfiles
            .Include(x => x.Identifiers)
            .Include(x => x.AccountCurrencies)
            .Include(x => x.Restrictions)
            .AsSplitQuery()
            .Where(x => accountIds.Contains(x.AccountId))
            .ToArrayAsync(cancellationToken);
    }
}