﻿using System;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     Generate a posting instruction Client Batch id.
/// </summary>
public class PostingInstructionClientBatchIdCreator : IPostingInstructionClientBatchIdCreator
{
    public string Create()
    {
        return Guid.NewGuid().ToString();
    }
}