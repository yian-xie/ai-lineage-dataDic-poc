﻿using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchRequest;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Services;

public interface IPostingInstructionModelTranslator
{
    /// <summary>
    ///     Translates model from <see cref="Mutations.Types.PaymentInstructionInput" /> to
    ///     <see cref="PostingInstructionBatchRequest" />
    ///     with Client Batch id and Client id specified
    /// </summary>
    PostingInstructionBatchRequest Translate(
        PaymentInstructionRequestInput input,
        string clientId,
        string clientBatchId
    );
}