﻿using Account.PaymentInstruction.Shared;
using Account.PaymentInstruction.Shared.EventBuilder;
using Account.PaymentInstruction.Shared.Infrastructure;
using Account.PaymentInstruction.Shared.Services;
using Account.PaymentInstruction.Tmv.Processor.Subscribers;
using Account.Shared;
using Account.Shared.Metrics.Decorator;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchErrorRequest;

using Enterprise.Shared.Kafka;
using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.PaymentInstruction.Tmv.Processor;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        AddPooledDbContextWithOutbox<PaymentInstructionDbContext>(services);

        services
            .AddRepositories()
            .AddSingleton<IPaymentInstructionEventBuilder, PaymentInstructionEventBuilder>()
            .AddScoped<IPaymentInstructionStatusCreator, PaymentInstructionStatusCreator>();

        var kafkaSettings = GetKafkaSettings();
        var tmvKafkaSettings = GetTmvKafkaSettings();

        UseKafka(services);

        services
            .AddKafkaReliableEventConsumers<TmvPostingInstructionBatchCreatedEventSubscriber, string
                , PostingBatchEvent>(tmvKafkaSettings, kafkaSettings)
            .AddKafkaReliableEventConsumers<TmvPostingInstructionBatchErrorRequestSubscriber, string
                , PostingInstructionBatchErrorRequest>(tmvKafkaSettings, kafkaSettings);

        services
            .Decorate<IIncomingEventSubscriber<PostingBatchEvent>,
                AccountIncomingEventSubscriberMetricDecorator<PostingBatchEvent>>()
            .Decorate<IIncomingEventSubscriber<PostingInstructionBatchErrorRequest>,
                AccountIncomingEventSubscriberMetricDecorator<
                    PostingInstructionBatchErrorRequest>>();
    }
}