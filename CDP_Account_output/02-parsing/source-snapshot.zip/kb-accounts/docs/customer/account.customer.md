# Account Domain - Customer Subdomain

![Customer Container Diagram](./container/account.customer.svg)


## Account.Customer.Processor

[Implementation Details](../../Account.Customer.Processor/README.md)