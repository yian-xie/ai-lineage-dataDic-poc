﻿namespace Account.TopicLogger.Processor.Services;

/// <summary>
///     Provides helper methods for file operations.
/// </summary>
public interface IFileHelper
{
    /// <summary>
    ///     Checks if a file exists at the specified path.
    /// </summary>
    /// <param name="path">The path to the file.</param>
    /// <returns>True if the file exists; otherwise, false.</returns>
    bool Exists(string path);

    /// <summary>
    ///     Reads all text from a file.
    /// </summary>
    /// <param name="path">The path to the file.</param>
    /// <returns>The contents as a string.</returns>
    string ReadAllText(string path);
}