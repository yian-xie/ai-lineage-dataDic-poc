﻿using System.Threading;
using System.Threading.Tasks;

using Enterprise.Shared.Database;

namespace Account.PaymentInstruction.Shared.Repositories;

public interface IPaymentInstructionRepository : IRepository
{
    /// <summary>
    ///     Insert <see cref="Entities.PaymentInstruction" /> into the database.
    /// </summary>
    /// <param name="paymentInstruction">
    ///     <see cref="Entities.PaymentInstruction" />
    /// </param>
    void Add(Entities.PaymentInstruction paymentInstruction);

    /// <summary>
    ///     Get <see cref="Entities.PaymentInstruction" /> from the database by Client Batch id and Client id.
    /// </summary>
    /// <param name="clientBatchId">Client Batch id</param>
    /// <param name="clientId">Client id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    Task<Entities.PaymentInstruction?> GetAsync(
        string clientBatchId,
        string clientId,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Get a list of <see cref="Entities.PaymentInstruction" /> from the database by transaction id.
    /// </summary>
    /// <param name="transactionId">Transaction Id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    Task<Entities.PaymentInstruction[]> GetAsync(
        string transactionId,
        CancellationToken cancellationToken);
}