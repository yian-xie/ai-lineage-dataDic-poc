﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

using Account.Domain.Directory.Service.WebApiClient;
using Account.Shared.Metrics;
using Account.Transaction.Api.Observability;

using Kb.Api.Infrastructure.ErrorHandling.Exceptions;
using Kb.Api.Observability.Metrics;

using Microsoft.Extensions.Logging;

namespace Account.Transaction.Api.Queries.Services;

/// <inheritdoc />
public class AccountDomainDirectoryService(IAccountsClient accountsClient, ILogger<AccountDomainDirectoryService> logger, IProfilingMetrics metrics) : IAccountDomainDirectoryService
{
    /// <inheritdoc />
    public async Task<AccountsResultDto> GetAccount(string accessNumber, string accountId)
    {
        var stopwatch = Stopwatch.StartNew();
        var outcome = TelemetryTagKeys.Outcomes.Success;
        try
        {
            var result = await accountsClient.GetAccountsAsync(accessNumber, [accountId], false);

            return result.First();
        }
        catch (ApiException ex) when (ex.StatusCode == 404)
        {
            // A 404 from ADDS means the user has requested an account that either does not exist
            // or is not associated with the provided access number.  Either way, this is treated
            //  as an unauthorized access attempt in this context.
            //
            logger.LogError(ex, "Account with ID: {AccountId} was not found in the Account Domain Directory Service.", accountId);
            outcome = ex.StatusCode.ToString();
            RecordError(outcome);
            throw new UnauthorizedException(
                $"Failed to retrieve the transactions of account {accountId} due to unauthorized request.");
        }
        catch (ApiException ex) when (ex.StatusCode == (int)HttpStatusCode.Unauthorized)
        {
            // ADDS rejected the token that was propagated from the user's request as Unauthorized so
            // we throw UnauthorizedException here as this indicates a problem with the user's token not the server.
            // Note that ideally this type of issue would be caught by the istio policy before we even get here,
            // but in case it isn't we want to make sure we are treating this as an unauthorized access attempt and
            // not a server error.
            //
            logger.LogWarning(ex, "Token auth failure from downstream for account {AccountId}.", accountId);
            outcome = ex.StatusCode.ToString();
            RecordError(outcome);
            throw new UnauthorizedException($"Authentication failure retrieving account {accountId}. Your session may have expired.");
        }
        catch (ApiException ex) when (ex.StatusCode == (int)HttpStatusCode.Forbidden)
        {
            // ADDS rejected the token that was propagated from the user's request as Forbidden so
            // we throw ForbiddenException here as this indicates a problem with the user's token not the server.
            // Note that ideally this type of issue would be caught by the istio policy before we even get here,
            // but in case it isn't we want to make sure we are treating this as an unauthorized access attempt and
            // not a server error.
            //
            logger.LogWarning(ex, "Forbidden from downstream for account {AccountId}.", accountId);
            outcome = ex.StatusCode.ToString();
            RecordError(outcome);
            throw new ForbiddenException($"Access denied retrieving account {accountId}.  Please check your credentials.");
        }
        catch (ApiException ex)
        {
            // Any other ApiException from ADDS is treated as a server error as it indicates something went wrong with the call to ADDS
            // that is not related to the user's token or request.
            // We catch this exception explicitly here so we can access the status code.
            //
            logger.LogError(ex, "ApiException occurred with StatusCode: {StatusCode} while retrieving account with ID: {AccountId}.", ex.StatusCode, accountId);
            outcome = ex.StatusCode.ToString();
            RecordError(outcome);
            throw new Exception($"An ApiException occurred with StatusCode: {ex.StatusCode} while retrieving account {accountId} from the Account Domain Directory Service.");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected exception occurred retrieving account with ID: {AccountId}.", accountId);
            // No status code available for general exceptions, so we log the exception type as the outcome for metrics purposes.
            outcome = ex.GetType().Name;
            RecordError(outcome);
            throw new Exception($"An unexpected exception occurred while retrieving account {accountId} from the Account Domain Directory Service.");
        }
        finally
        {
            metrics.Histogram(MetricNames.AccountDomainDirectoryServiceCallDurationMetric, stopwatch.ElapsedMilliseconds, GetMetricTags(outcome));
        }
    }

    private void RecordError(string outcome)
    {
        metrics.Counter(MetricNames.AccountDomainDirectoryServiceErrorCountMetric, 1, GetMetricTags(outcome));
    }

    private TagList GetMetricTags(string outcome)
    {
        return [
            new KeyValuePair<string, object?>(TelemetryTagKeys.DownStreamServiceName,
                MetricNames.AccountDomainDirectoryServiceApi),
            new KeyValuePair<string, object?>(TelemetryTagKeys.Outcome, outcome)
        ];
    }
}