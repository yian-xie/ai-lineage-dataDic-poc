﻿namespace Account.Origination.Job.Constants
{
    public static class Metrics
    {
        public const string OriginationJob = "origination-job";
        public const string RequestTotal = "-total-requests";
        public const string RequestSuccess = "-success-requests";
        public const string Exception = "-exceptions";
        public const string Duration = "-duration";
    }
}