﻿namespace Account.Shared.Constants.Tmv;

/// <summary>
///     TMV restriction set definition ids.
/// </summary>
public static class RestrictionSetDefinitionIds
{
    /// <summary>
    /// Account_DebitAndCreditFreeze
    /// </summary>
    public const string AccountDebitAndCreditFreeze = "Account_DebitAndCreditFreeze";
    /// <summary>
    /// Account_DebitFreeze
    /// </summary>
    public const string AccountDebitFreeze = "Account_DebitFreeze";
}