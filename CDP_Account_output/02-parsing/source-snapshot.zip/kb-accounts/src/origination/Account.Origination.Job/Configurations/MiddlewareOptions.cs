﻿namespace Account.Origination.Job.Configurations;

public class MiddlewareOptions
{
    public required string MiddlewareUrl { get; set; }
    public required string ChannelIdentifier { get; set; }
    public required int MaxRetryAttempts { get; set; }
}