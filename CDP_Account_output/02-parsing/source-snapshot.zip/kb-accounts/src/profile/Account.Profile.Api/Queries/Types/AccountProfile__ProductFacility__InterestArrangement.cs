﻿using System;

using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__ProductFacility__InterestArrangement")]
public class AccountProfile__ProductFacility__InterestArrangement
{
    [GraphQLName("rate")] public string? Rate { get; set; }
    [GraphQLName("validFrom")] public DateTimeOffset? ValidFrom { get; set; }
    [GraphQLName("ratePlanChangeId")] public string? RatePlanChangeId { get; set; }
}