﻿#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;

using Account.Profile.Processor.Helper;
using Account.Profile.Shared;
using Account.Profile.Shared.Models.ContractNotifications;
using Account.Shared.Infrastructure.Exceptions;
using Account.Shared.Mappers;

using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;
using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Microsoft.Extensions.Logging;

using AccountInfo = Api.Shared.Clients.Events.ThoughtMachine.V2.Account.Account;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Implements IAccountProfileChangeSetCreator interface for creating AccountProfileChangeSet.
/// </summary>
public class AccountProfileChangeSetCreator(ILogger<AccountProfileChangeSetCreator> logger) : IAccountProfileChangeSetCreator
{
    public AccountProfileChangeSet CreateAccountProfileChangeSet(
        AccountEvent accountEvent)
    {
        var accountInfo = accountEvent.Account_created is null ? accountEvent.Account_updated.Account : accountEvent.Account_created.Account;

        var accountProfileChangeSet = new AccountProfileChangeSet
        {
            AccountId = accountInfo.Id,
            AccountName =
                accountInfo.Details.AdditionalProperties.GetEntry(ProfileKeys.Details.Name),
            AlternateAccountName =
                accountInfo.Details.AdditionalProperties.GetEntry(ProfileKeys.Details.Alias),
            Status = accountInfo.Status,
            TSide = GetTSide(accountInfo),
            ChangeId = accountEvent.Change_id,
            CorrelationId = accountEvent.GetCorrelationId(logger) ?? Guid.Empty,
            Created = accountInfo.Source_create_timestamp,
            Opened = accountInfo.Source_open_timestamp,
            Closed = accountInfo.Source_close_timestamp,
            AccountClosureReason = accountInfo.Details.AdditionalProperties.GetEntry(ProfileKeys.Details.AccountClosureReason),
            ProductFacilityId =
                accountInfo.Details.AdditionalProperties.GetEntry(
                    ProfileKeys.Details.ProductFacilityId),
            NzBankAccountNumber =
                accountInfo.Details.AdditionalProperties.GetEntry(
                    ProfileKeys.Details.NzBankAccountNumber),
            LegacyCoreAccountId =
                accountInfo.Details.AdditionalProperties.GetEntry(
                    ProfileKeys.Details.UltracsAccountId),
            AccountCreatedUserId =
                accountInfo.Details.AdditionalProperties.GetEntry(
                    ProfileKeys.Details.AccountCreatedUserId),
            BankingRelationshipId = accountInfo.Details.AdditionalProperties.GetEntry(
                ProfileKeys.Details.BankingRelationshipId),
            BankingRelationshipType = accountInfo.Details.AdditionalProperties.GetEntry(
                ProfileKeys.Details.BankingRelationshipType),
            PartyIds = accountInfo.Stakeholder_ids.ToArray(),
            BaseAccountNumber =
                accountInfo.Details.AdditionalProperties.GetEntry(
                    ProfileKeys.Details.BaseAccountNumber),
            AccountCurrencies = GetAccountCurrencies(accountInfo.Permitted_denominations),
            AccountOrganisationUnitId = accountInfo.Details.AdditionalProperties.GetEntry(ProfileKeys.Details.AccountOrganisationUnitId),
            MinimumNumberOfAuthoriser = accountInfo.Details.AdditionalProperties.GetEntry(ProfileKeys.Details.MinimumNumberOfAuthoriser)
        };

        return accountProfileChangeSet;
    }

    public AccountProfileChangeSet CreateAccountProfileChangeSetForUpdate(
        AccountEvent accountEvent)
    {
        var updateAccountProfile = new AccountProfileChangeSet
        {
            AccountId = accountEvent.Account_updated.Account.Id,
            ChangeId = accountEvent.Change_id,
            CorrelationId = accountEvent.GetCorrelationId(logger) ?? Guid.Empty,
            Created = accountEvent.Account_updated.Account.Source_create_timestamp,
            AccountCurrencies =
                GetAccountCurrencies(accountEvent.Account_updated.Account.Permitted_denominations)
        };

        var updatedFields = accountEvent.Account_updated.Update_mask.Paths;

        foreach (var item in updatedFields)
        {
            UpdateChangeSet(accountEvent, item, updateAccountProfile);
        }

        return updateAccountProfile;
    }

    public AccountProfileChangeSet? CreateAccountProfileChangeSetFromContractNotification(
        ContractNotification contractNotification)
    {
        var parameterChange = contractNotification.Notification_details
            .GetTypedNotification<ParameterChangeNotification>(ThoughtMachineNotificationTypes.ParameterChange);

        if (parameterChange?.AccountInfo?.Parameters == null)
        {
            logger.LogError("Missing parameter change details in ContractNotification with eventId: {EventId} " +
                "Notification_type: {NotificationType} ResourceId: {ResourceId}",
                contractNotification.Event_id,
                contractNotification.Notification_type,
                contractNotification.Resource_id);
            throw new ArgumentException($"Missing parameter change details in ContractNotification for Event_id: {contractNotification.Event_id}");
        }

        var accountProfileChangeSet = new AccountProfileChangeSet
        {
            AccountId = contractNotification.Resource_id
        };

        var unMatchedParams = 0;
        foreach (var param in parameterChange.AccountInfo.Parameters)
        {
            var edmAttribute = param.Edm?.Attribute;
            switch (edmAttribute)
            {
                case ParameterChangeEdmAttributeKeys.WithholdingTaxType:
                    accountProfileChangeSet.WithholdingTaxType = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.WithholdingTaxPercentage:
                    accountProfileChangeSet.WithholdingTaxRate = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.WithholdingTaxNonResidentCountryCode:
                    accountProfileChangeSet.CountryAlpha3Code = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.WithholdingNominatedTaxPartyId:
                    accountProfileChangeSet.NominatedTaxPartyId = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.CreditInterestRatePercentage:
                    accountProfileChangeSet.InterestRate = param.Value;
                    accountProfileChangeSet.InterestRateValidFrom = contractNotification
                        .Notification_details.Effective_datetime;
                    break;

                case ParameterChangeEdmAttributeKeys.StandardCreditInterestRatePlanChangeId:
                    accountProfileChangeSet.InterestRatePlanChangeId = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.BankingProductCode:
                    accountProfileChangeSet.BankingProductCode = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.BankingProductId:
                    accountProfileChangeSet.BankingProductId = param.Value;
                    break;

                case ParameterChangeEdmAttributeKeys.BankingProductVersionId:
                    accountProfileChangeSet.BankingProductVersionId = param.Value;
                    break;

                default:
                    logger.LogWarning("Ignoring unsupported parameter change with EdmAttribute: {EdmAttribute} for AccountId: {AccountId}",
                        edmAttribute,
                        contractNotification.Resource_id);
                    unMatchedParams++;
                    break;
            }
        }

        if ((parameterChange.AccountInfo.Parameters.Count - unMatchedParams) > 0)
        {
            return accountProfileChangeSet;
        }

        return null;
    }

    private static List<AccountCurrency> GetAccountCurrencies(ICollection<string> denominations)
    {
        return denominations
            .Select(denomination =>
                new AccountCurrency
                {
                    Currency = denomination,
                    CurrencyType = ProfileKeys.AccountCurrencyType.AccountBaseCurrency
                })
            .ToList();
    }

    private static void UpdateChangeSet(
        AccountEvent accountEvent,
        string item,
        AccountProfileChangeSet updateAccountProfile)
    {
        var account = accountEvent.Account_updated.Account;

        switch (item)
        {
            case not null when item == AccountEventUpdateMaskSettings.Status:
                updateAccountProfile.Status = account.Status;
                break;

            case not null when item == AccountEventUpdateMaskSettings.PartyIds:
                updateAccountProfile.PartyIds = account.Stakeholder_ids.ToArray();
                break;

            case not null when item == AccountEventUpdateMaskSettings.Opened:
                updateAccountProfile.Status = account.Status;
                updateAccountProfile.Opened = account.Source_open_timestamp;
                break;

            case not null when item == AccountEventUpdateMaskSettings.Closed:
                updateAccountProfile.Closed = account.Source_close_timestamp;
                break;

            case not null when item == AccountEventUpdateMaskSettings.Details:
                var detailVals = account.Details.AdditionalProperties;
                updateAccountProfile.AccountName = detailVals.GetEntry(ProfileKeys.Details.Name);

                updateAccountProfile.AlternateAccountName =
                    detailVals.GetEntry(ProfileKeys.Details.Alias);

                updateAccountProfile.NzBankAccountNumber =
                    detailVals.GetEntry(ProfileKeys.Details.NzBankAccountNumber);

                updateAccountProfile.LegacyCoreAccountId =
                    detailVals.GetEntry(ProfileKeys.Details.UltracsAccountId);

                updateAccountProfile.AccountCreatedUserId =
                    detailVals.GetEntry(ProfileKeys.Details.AccountCreatedUserId);

                updateAccountProfile.ProductFacilityId =
                    detailVals.GetEntry(ProfileKeys.Details.ProductFacilityId);

                updateAccountProfile.BankingRelationshipId =
                    detailVals.GetEntry(ProfileKeys.Details.BankingRelationshipId);

                updateAccountProfile.BankingRelationshipType =
                    detailVals.GetEntry(ProfileKeys.Details.BankingRelationshipType);

                updateAccountProfile.AccountOrganisationUnitId =
                    detailVals.GetEntry(ProfileKeys.Details.AccountOrganisationUnitId);

                updateAccountProfile.MinimumNumberOfAuthoriser =
                    detailVals.GetEntry(ProfileKeys.Details.MinimumNumberOfAuthoriser);

                updateAccountProfile.AccountClosureReason =
                    detailVals.GetEntry(ProfileKeys.Details.AccountClosureReason);

                break;
        }
    }

    public static string GetTSide(
        AccountInfo accountInfo)
    {
        var tSide = accountInfo.T_side ?? throw new ArgumentException($"Missing TSide in Account Created event for EventId: {accountInfo.Id}.");

        return Enum.TryParse(tSide, out V2accountsTSide accountTSide)
            ? accountTSide.GetTSideName()
            : throw new UnexpectedTSideException(tSide);
    }
}