﻿using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Mapping;
using Account.Profile.Processor.Models;
using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Api.Shared.Clients.Events.ThoughtMachine.V1.RestrictionSet;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Services;

/// <summary>
/// Handling TMV Restriction Set Created events which is related to account profile freeze.
/// </summary>
/// <param name="repositoryFactory"></param>
/// <param name="logger"></param>
public class RestrictionSetCreatedEventHandler(
    ILogger<RestrictionSetCreatedEventHandler> logger) : IRestrictionSetEventHandler
{
    public RestrictionType Type => RestrictionType.Created;

    /// <summary>
    /// Handling TMV Restriction Set Created event for account freeze.
    /// Freeze the non-restricted account by creating the account freeze details in account profile.
    /// </summary>
    /// <param name="accountProfile"><see cref="AccountProfile"/></param>
    /// <param name="restriction"><see cref="Restriction"/></param>
    /// <returns>True if the Restriction is successfully handled, otherwise false.</returns>
    public bool Handle(AccountProfile accountProfile, Restriction restriction)
    {
        logger.LogInformation("Processing Restriction Set Created Event (EventId: {EventId}).", restriction.EventId);

        RestrictionSetEventHelper.CheckAccountStatus(restriction, accountProfile, logger);

        // Account is in TMV status Opened.
        if (RestrictionSetEventHelper.IsLatestRestriction(restriction, accountProfile, logger))
        {
            accountProfile.AccountFreezeDetails = CreateAccountFreezeDetails(
                restriction.RestrictionSet,
                restriction.ChangeId);
            // Set Kiwibank status to Frozen.
            accountProfile.Status = nameof(AccountStatus.Frozen);

            logger.LogInformation("Created the account freeze details (EventId: {eventId}) for account profile (AccountId: {accountId}).", restriction.EventId, accountProfile.AccountId);

            return true;
        }

        logger.LogWarning("""
                          Restriction Set Created Event (EventId: {eventId}) is not the latest for account profile (AccountId: {accountId}).
                          Existing Restriction: {@existingRestriction}
                          New Restriction: {@Restriction}
                          """, restriction.EventId, accountProfile.AccountId, accountProfile.AccountFreezeDetails, restriction);

        return false;
    }

    private static AccountFreezeDetails CreateAccountFreezeDetails(Restriction_set restrictionSet, int? changeId)
    {
        return new AccountFreezeDetails
        {
            FreezeType = FreezeTypeMapper.GetFreezeType(restrictionSet.Restriction_set_definition_id),
            FreezeDescription = restrictionSet.Description,
            ChangeId = changeId,
            RestrictionSetId = restrictionSet.Id,
            Effective = restrictionSet.Effective_timestamp,
            Expiration = restrictionSet.Expiry_timestamp
        };
    }
}