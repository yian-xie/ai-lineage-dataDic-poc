## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Processor (`transaction-eod-tmv-internalaccount-processor`) |
| Customer or business impact | End-of-day internal-account jobs can be delayed or absent, preventing the worker from publishing internal-account balance events to downstream reconciliation and CDP consumers. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Transaction EoD Internal Accounts Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203001987/Account+Transaction+EoD+Internal+Accounts+Observability+Dashboard)</li><li>[EoD Components Runbook logs](https://kiwibank.atlassian.net/wiki/x/CQG6PwE)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>TMV account-list API fails for 30 minutes or longer</summary>

**Symptoms**

- Logs contain `Failed to call TMV API to process OperationCreatedEvent` after the 30-minute API-failure threshold.
- `tmv-api-list-internal-accounts-duration` metric degrades, one-minute redelivery continues, and no jobs are created for the scheduler event.

**Actions**

1. In sumo capture the event ID, first delivery time, HTTP status, and exception.
2. Confirm the target `ThoughtMachineVault__BaseApiUrl`, token secret reference and TMV Core Accounts API status without exposing credentials depending on the HTTP status code that appears in the logs.
3. Restore TMV access or deploy a tested client fix; allow the built-in one-minute redelivery to continue.
4. If the event reaches six hours from first delivery, confirm its DLQ outcome. [TODO: confirm the approved DLQ inspection and replay procedure for each environment].

**Recovery check**

- Logs contain `Processed OperationCreatedEvent ... Fetched ... accounts` and `... jobs created`; API errors and redelivery stop for the event.

**Escalation**

- Use the incident escalation path when the API remains unavailable, authentication cannot be restored, or the event approaches the six-hour DLQ threshold.

</details>

<details>
<summary>PostgreSQL job creation fails and the event redelivers</summary>

**Symptoms**

- Internal accounts are fetched, but the `... jobs created` log is absent and the exception identifies the transaction datastore, transaction commit, or job insert.
- The scheduler event redelivers every minute and moves to DLQ after six hours if the failure persists.

**Actions**

1. Confirm PODs are up and running & verify the deployed `ConnectionStrings__DefaultConnection` reference without exposing its value.
2. Check for schema/migration or deterministic job-ID constraint errors.
3. Restore database access or deploy a tested persistence fix; do not manually insert jobs or reset Kafka offsets. [TODO: confirm the approved duplicate-job and DLQ recovery procedure].

**Recovery check**

- The event logs a successful job count, the worker begins processing eligible records after their scheduled time, and redelivery stops without duplicate live jobs.

**Escalation**

- Use the incident escalation path when database writes remain unavailable, duplicate constraints cannot be explained, or the retry window is at risk.

</details>

<details>
<summary>Expected END_OF_DAY_AST scheduler event is missing</summary>

**Symptoms**

- No `Received OperationCreatedEvent` appears for the end-of-day run, and no internal-account jobs are created.
- Consumer throughput is absent or lag rises for the TMV consumer group.

**Actions**

1. Establish the expected scheduler event time from TMV operations evidence. [TODO: confirm the expected daily arrival window and alert threshold].
2. Check processor liveness/readiness and the TMV Kafka consumer-group signals in the observability page (dashboards).
3. Confirm TMV Kafka broker access, group ID, and topic prefix from the deployed values; do not reset offsets.
4. If the producer did not emit the event, engage the TMV scheduler dependency through the incident process. [TODO: confirm the approved event reissue procedure].

**Recovery check**

- The expected event is received once, internal accounts are fetched, and jobs are created with the configured ten-minute wait.

**Escalation**

- Use the incident escalation path when the expected event is absent, all replicas cannot consume, or job creation misses the operational window.

</details>

<details>
<summary>Scheduler operation is skipped because its tag is not END_OF_DAY_AST</summary>

**Symptoms**

- `Received OperationCreatedEvent` is logged, but no account-fetch or job-creation log follows.
- The event's `operation_created.operation.tag_name` is not `END_OF_DAY_AST`.

**Actions**

1. Capture the event ID, tag and operation timestamp.
2. Treat a non-`END_OF_DAY_AST` tag as an expected skip and confirm the consumer advances to later events.
3. If end-of-day processing was expected, investigate the TMV scheduler producer; do not alter or replay the differently tagged event.

**Recovery check**

- Expected skips do not impede consumption; a valid tagged event fetches accounts and creates jobs.

**Escalation**

- Use the incident escalation path when TMV emits an incorrect tag for the end-of-day operation or consumer progress stops after the skip.

</details>

<details>
<summary>TMV returns an unexpected empty internal-account list</summary>

**Symptoms**

- Logs contain `Processed OperationCreatedEvent ... Fetched 0 accounts` followed by `0 jobs created`.
- The event succeeds, so no automatic redelivery occurs, but the worker receives no work for the run.

**Actions**

1. Capture event ID, operation timestamp, TMV API response status, and fetched count.
2. Confirm the Core Accounts API request used the internal-account type and completed all pagination.
3. Compare the result with the expected TMV internal-account inventory. [TODO: confirm the approved inventory query and minimum expected count per environment].
4. Correct the TMV data/API issue before reissuing or replaying the scheduler event. [TODO: confirm the approved replay procedure].

**Recovery check**

- A non-production verification fetches the expected non-zero inventory and creates one scheduled job per returned account without duplicates.

**Escalation**

- Use the incident escalation path when the inventory is unexpectedly empty or the missed run affects downstream end-of-day completion.

</details>

<details>
<summary>Failure reporting to SumoLogic is unavailable</summary>

**Symptoms**

- Application logs contain `Failed to push log into SumoLogic for OperationCreatedEvent`.
- The 30-minute API alert is missing; after six hours, an event can remain on redelivery because failure reporting failed before the DLQ result was returned.

**Actions**

1. Use workload logs and Dynatrace from the observability page as the temporary source of truth.
2. Verify `SumoLogicIngestion__SourceCategory`, source name, collector reachability, and `SumoLogicIngestion__ApiToken` secret reference without exposing values.
3. Restore ingestion and observe the next one-minute redelivery attempt.
4. Continue resolving the underlying TMV API or persistence failure independently.

**Recovery check**

- The failure reaches the configured SumoLogic source, one alert is recorded for the event, and an exhausted failure can complete its DLQ path.

**Escalation**

- Use the incident escalation path when failure visibility remains unavailable or redelivery continues beyond the configured maximum period.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>