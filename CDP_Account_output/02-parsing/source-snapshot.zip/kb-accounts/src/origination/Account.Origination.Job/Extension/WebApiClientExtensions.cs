﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Configurations;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Extension;

public static class WebApiClientExtensions
{
    private const string BaseUrlNullOrEmptyErrorMessage = "Base Url can't be null or empty.";

    public static IHttpClientBuilder AddAccountsClients(this IServiceCollection services)
    {
        return
            services.AddHttpClient<IAccountsClient, AccountsClient>((provider, client) =>
        {
            var baseUrl = provider.GetRequiredService<IOptions<WebApiClientOptions>>().Value.BaseUrl;

            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                throw new InvalidOperationException(BaseUrlNullOrEmptyErrorMessage);
            }

            client.BaseAddress = new Uri(baseUrl);
        });
    }

    public static IHttpClientBuilder AddPartyClients(this IServiceCollection services)
    {
        return services.AddHttpClient<IPartyClient, PartyClient>((provider, client) =>
         {
             var baseUrl = provider.GetRequiredService<IOptions<WebApiClientOptions>>()
                 .Value.BaseUrl;

             if (string.IsNullOrWhiteSpace(baseUrl))
             {
                 throw new InvalidOperationException(BaseUrlNullOrEmptyErrorMessage);
             }

             client.BaseAddress = new Uri(baseUrl);
         });
    }
}