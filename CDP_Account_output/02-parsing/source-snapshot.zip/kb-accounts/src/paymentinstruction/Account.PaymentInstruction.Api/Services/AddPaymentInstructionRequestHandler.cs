﻿using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Api.Infrastructure;
using Account.PaymentInstruction.Shared.EventBuilder;
using Account.PaymentInstruction.Shared.Services;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;

using Enterprise.Shared.Kafka.Produce;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;
using PaymentInstructionStatus =
    Account.PaymentInstruction.Shared.Entities.PaymentInstructionStatus;
using PaymentInstructionWithStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionWithStatus;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     A wrapper that encapsulates dependencies needed to handle <see cref="PaymentInstructionRequestInput" />
/// </summary>
public class AddPaymentInstructionRequestHandler(
    IPostingInstructionBatchRequestPublisher postingInstructionBatchRequestPublisher,
    IPaymentInstructionCreator paymentInstructionCreator,
    IKafkaEventPublisher<PaymentInstructionEvent> publisher,
    IPaymentInstructionStatusCreator paymentInstructionStatusCreator,
    IPostingInstructionClientBatchIdCreator postingInstructionClientClientBatchIdCreator,
    IPaymentInstructionEventBuilder eventBuilder)
    : IAddPaymentInstructionRequestHandler
{
    /// <summary>
    ///     Handles <see cref="PaymentInstructionRequestInput" />
    /// </summary>
    public async Task<PaymentInstructionWithStatus> HandleAsync(
        PaymentInstructionRequestInput input,
        CancellationToken cancellationToken)
    {
        var clientBatchId = postingInstructionClientClientBatchIdCreator.Create();

        var paymentInstruction =
            await paymentInstructionCreator.CreateAsync(input, clientBatchId, cancellationToken);

        var createdStatus = await AddCreatedStatusToDb(paymentInstruction, cancellationToken);

        await PublishCreatedStatusEvent(paymentInstruction, cancellationToken);

        await PublishRequestToTmv(input, cancellationToken, clientBatchId);

        var postedStatus = await AddPostedStatusToDb(paymentInstruction, cancellationToken);

        await PublishPostedStatusEvent(paymentInstruction, cancellationToken);

        return paymentInstruction.ToPaymentInstructionWithStatus([createdStatus, postedStatus]);
    }

    private async Task<PaymentInstructionStatus> AddCreatedStatusToDb(
        Shared.Entities.PaymentInstruction paymentInstruction,
        CancellationToken cancellationToken)
    {
        var createdStatus = await paymentInstructionStatusCreator.CreateAsync(paymentInstruction,
            PaymentInstructionStatusStatus.Created,
            cancellationToken);

        return createdStatus;
    }

    private async Task<PaymentInstructionStatus> AddPostedStatusToDb(
        Shared.Entities.PaymentInstruction paymentInstruction,
        CancellationToken cancellationToken)
    {
        var postedStatus = await paymentInstructionStatusCreator.CreateAsync(paymentInstruction,
            PaymentInstructionStatusStatus.Posted,
            cancellationToken);

        return postedStatus;
    }

    private async Task PublishRequestToTmv(
        PaymentInstructionRequestInput input,
        CancellationToken cancellationToken,
        string clientBatchId)
    {
        await postingInstructionBatchRequestPublisher.PublishAsync(
            input,
            clientBatchId,
            cancellationToken);
    }

    /// <summary>
    ///     Create event with created status
    /// </summary>
    private async Task PublishCreatedStatusEvent(
        Shared.Entities.PaymentInstruction paymentInstruction,
        CancellationToken cancellationToken)
    {
        var createdEvent = eventBuilder.BuildWithStatus(
            paymentInstruction,
            PaymentInstructionStatusStatus.Created);

        await publisher.PublishAsync(
            createdEvent,
            cancellationToken,
            paymentInstruction.TransactionId);
    }

    /// <summary>
    ///     Create event with posted status
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <param name="paymentInstruction"></param>
    private async Task PublishPostedStatusEvent(
        Shared.Entities.PaymentInstruction paymentInstruction,
        CancellationToken cancellationToken)
    {
        var postedEvent = eventBuilder.BuildWithStatus(
            paymentInstruction,
            PaymentInstructionStatusStatus.Posted);

        await publisher.PublishAsync(
            postedEvent,
            cancellationToken,
            paymentInstruction.TransactionId);
    }
}