# DI-1 First Internal Product Detail Design



# Overview
Context in scope for First Internal Product (FIP).

![FIP Subdomain Context View](context/di-1.subdomain.container.svg)



# Principles
- Aim to design and build systems that are not tactical/throw away where possible. 
- Leverage existing effort across the enterprise where appropriate
- Req/Res APIs are GraphQL based. 
- Initial effort won't be integrated into the SuperGraph but should consider integration as a near future step. 
- EDM should be used as basis for data contracts

# Infrastructure

Follow established patterns already provided by the integration layer and CIP platform:

- Each component will be built as a Docker container and deployed in the CIP platform (Kubernetes)
- The CIP CI/CD platform will be used for build and deployment using standard stages 
 - Leverage common Service Foundation CICD framework and templates
 - TODO: 
   - Confluent Cloud
   - RDS deployment
   - K8S cluster


# Observability & Logging
- Should meet our baseline : [Observability Baseline](https://kiwibank.atlassian.net/wiki/spaces/OBSV/pages/3926594390)
- Traces from workloads should be instrumented with OpenTelemetry and send to [Dynatrace tracing endpoint](https://www.dynatrace.com/support/help/extend-dynatrace/opentelemetry/opentelemetry-traces/opentelemetry-ingest/opent-dotnet#tabgroup--dynatrace-docs--without-oneagent).
- Deliver a set of dashboards, showing operational metrics for the platform including availability and latency.  Tag dimensions in Dynatrace - dashboards should provisioned automatically by Terraform on the kb-tf-dynatrace repo.
- Logging via SumoLogic. See ELM - [Sumologic Success Criteria](https://kiwibank.atlassian.net/wiki/spaces/OBSV/pages/3948579631).



# Container View

High level container view of items in scope for FIP. 
Goals are
- Build future-state service as much as possible
- Wrap FIP specific functionality in specialised services to limit surface area attack of domain services that would have wider audiences. 
- Subdomain constructs are a logical internal seperation of similar use cases. This will help partition workloads, simplify design and draw distinct project bounderies for delivery. 
- The use of `FIP` in naming was determined to not represent the lower level purpose of this use-case. 
  - `spud` is the long lasting We have named FIP specific functionalty '`spud`. 
- Fixed `partyRoleId` will be used for queries and mutations
  - TODO: Agree FIP/Spud `party` and `partyRoleId` with Party Domain
  - Manual `TMV Customer` record will be created 
 

![FIP Containers](./container/di-1.container.svg)

- `AzureAD/OPA` full interaction will be described in more detailed views to reduce diagramming complexity. Assume all API services

# Component View

## Staff Portal 
New subdomain that encapsulates staff specific operations, services and any internal-specific functionality/


- `kb-staff-portal` will be used as the Staff Portal app. This is built and hosted outside of Account Domain but logically will sit within the `account/staff-portal` subdomain for diagramming purposes. 
- `Account.Spud.API` is a lightweight, internal use only API that wraps the specific FIP functions.  

![Staff Portal Components](./component/di-1.staff-portal.component.svg)

path: `./src/staff-portal`

[Design Details](./staff-portal/README.md)

Proposed [`Account.Spud.API` graphql schema](../../../api-schemas/gql/spud.graphql)

## Account Origination

path: `./src/origination`

- FIP/Spud specific account creation logic is handled within `Account.Spud.API` to provide a gql interface into the `origination` subsystem. 
- Fixed `partyRoleId` will be used to create accounts
- Leverage existing `origination` subsystem account create pattern 
- Account creation is asynchonous in nature. Upstream systems will be notified of account creation via `account profile` subsystem.

- FIP/Spud account closure is a direct call to TMV. No pre-account closure business functionality such as zero balance checks will be performed. 
  - If an account cannot be closed, just return the failure. 
  - Pre-account closure activtiy will be handled manually by transacting the account-to-be-close into a zero balance. 


![Account Origination Components](./component/di-1.origination.component.svg)

### FIP Internal Party and PartyRoleId
An internal FIP party customer is required to perform actions on behalf of. 

We should agree with Party on the creation of a Party customer record with a PartyRoleId. 
```
// party
{
  "partyId": "??",
  "partyType": "Person",
  
  "preferredName": "FirstInternalProduct user"
  "partyRoles: [
    {
      "partyRoleId": "??", // this is the ID we need
      "partyRoleTypeName": "Bank"      
    }
  ]
}
```




## Account Profile
path: `./src/profile`

Once an account has been created, responsibilty moves from `origination` into `account profile` subdomain. 

Account Profile subdomain is also responsible for future `account maintenance` functions as the `Account.Profile.Store` will contain data on all account profiles and can act on account/product wide change. 

- Staff Portal will poll `GetAccountProfiles` to retrieve an updated list of `account profiles` when a new account has been created.
- Fixed `partyRoleId` will be used to query account profiles.


![Account Profile Components](./component/di-1.account-profile.component.svg)

## Transaction 
path: `./src/transaction`

Provides storage and access to account entries, transactions, and balances.

- Fixed FIP `partyRoledId` to be used for queries and mutations. 


![Account Transaction Components](./component/di-1.transaction.component.svg)




## Azure AD / OPA
External component. 
TODO: Define/link to detailed operation. Work with Rhys to further




# Functional Views

## Login to Staff Portal
![](./functional/login-staff-portal/login-and-resource-request.high-level-sequence.svg)

## Create FIP Account

Describes the round trip of creating an FIP account and subsequent display of new account profile for front-end. Solution is intentionally low tech to limit scope of effort. 

![High level sequence](./functional/create-fip-account/create-view-account.high-level-sequence.svg)

## View FIP Accounts

![High level sequence](./functional/view-fip-account/view-fip-account.high-level-sequence.svg)


## View FIP Account

![High level sequence](./functional/view-fip-account/get-account-profile.high-level-sequence.svg)

## View FIP Account Transactions
> DESIGN IN PROGRESS

![High level sequence](./functional/transaction/view-fip-transactions.high-level-sequence.svg)

## Create FIP Transaction
> DESIGN IN PROGRESS

![High level sequence](./functional/transaction/create-fip-transaction.high-level-sequence.svg)

## Transactions Lifecycle
> DESIGN IN PROGRESS
Functional views describing the lifecycle of when a transaction is requested, how it feeds through TMV and back into our transactions stores.

> DESIGN IN PROGRESS
### Create Transaction to Account Transaction, Entry, Balance lifecycle

![High level sequence](./functional/transaction/transaction-lifecycle.high-level-sequence.svg)

### Composite Transaction lifecycle
> DESIGN IN PROGRESS

![High level sequence](./functional/transaction/composite-transaction.high-level-sequence.svg)

