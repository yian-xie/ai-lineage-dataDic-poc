﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

using Account.Transaction.Api.Queries.Services.Filtering;
using Account.Transaction.Api.Queries.Types;

using Ultracs.Integration.Client;

namespace Account.Transaction.Api.Queries.Mapping;

/// <summary>
/// Maps <see cref="TransactionItem"/> from Ultracs to <see cref="AccountTransaction"/> for the Account Transactions API.
/// </summary>
public class UltracsTransactionMapper : ITransactionMapper<TransactionItem, AccountTransaction>
{
    /// <summary>
    ///     Mapping the <see cref="TransactionItem"/> to <see cref="AccountTransaction" />.
    /// </summary>
    /// <param name="query"><see cref="IQueryable{TSource}" /> where TSource is <see cref="TransactionItem"/></param>
    /// <param name="accountId"></param>
    /// <returns><see cref="IQueryable{TTarget}" /> where TTarget is <see cref="AccountTransaction" /></returns>
    /// <remarks>Reference: <see href="https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/6037635467/ATS+Ultracs+Transaction+Fields+Mapping"/></remarks>
    public IQueryable<AccountTransaction> MapTo(IQueryable<TransactionItem> query, string accountId)
    {
        var items = query.AsEnumerable().ToList();
        var count = items.Count;
        return query.AsEnumerable()
            .Select((x, index) =>
            {
                var key = CreateDeterministicGuid(x, index, accountId);

                var isInternalSuspenseAccount =
                    IsInternalSuspenseAccount(x.OtherPayeeAccountNumber);

                var valueDateTime = new DateTimeOffset(x.TransactionDate,
                    TimeZoneInfo.FindSystemTimeZoneById(TimeZoneIds.NewZealandStandardTime)
                        .GetUtcOffset(x.TransactionDate));

                return new AccountTransaction
                {
                    Id = key,
                    Index = count - index,
                    TransactionId = x.TransactionId,
                    AccountId = accountId,
                    AccountNumber = x.AccountNumber.ToAccountNumber(),
                    AccountNumberDisplay = x.AccountNumber.ToAccountNumberDisplay(),
                    MaskedCardNumber = GetCardNumber(x.NonValueTransactionItems),
                    TransactionDescription = x.Description,
                    FinancialTransactionAmount = new Money
                    {
                        Value = (x.DebitAmount > 0 ? x.DebitAmount : x.CreditAmount).ToString(CultureInfo.InvariantCulture),
                        Currency = Currency.NZD
                    },
                    BookingDateTime = new DateTimeOffset(x.EffectiveDate, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneIds.NewZealandStandardTime).GetUtcOffset(x.EffectiveDate)),
                    ValueDateTime = valueDateTime,
                    TransactionCode = x.TransactionCode,
                    Status = Status.Executed,
                    CreditDebitIndicator = x.DebitAmount > 0 ? CreditDebitIndicator.Debit : CreditDebitIndicator.Credit,
                    Branch = x.Branch,
                    Operator = x.Operator,
                    Cheque = x.Cheque,
                    OtherPartyName = isInternalSuspenseAccount ? null : x.OtherPayeeName,
                    OtherPartyAccount = !string.IsNullOrEmpty(x.OtherPayeeAccountNumber) && !isInternalSuspenseAccount ? new PartyAccount
                    {
                        AccountIdentification = x.OtherPayeeAccountNumber.ToAccountNumber(),
                        AccountIdentificationDisplay = x.OtherPayeeAccountNumber.ToAccountNumberDisplay(),
                        AccountIdentificationType = string.Empty
                    } : null,
                    OtherPartyReference = !string.IsNullOrWhiteSpace(x.OtherPayeePart) || !string.IsNullOrWhiteSpace(x.OtherPayeeCode) || !string.IsNullOrWhiteSpace(x.OtherPayeeRef) ? new PartyReference
                    {
                        Particulars = x.OtherPayeePart,
                        Code = x.OtherPayeeCode,
                        Reference = x.OtherPayeeRef
                    } : null,
                    ThisPartyReference = !string.IsNullOrWhiteSpace(x.ThisPayeePart) || !string.IsNullOrWhiteSpace(x.ThisPayeeCode) || !string.IsNullOrWhiteSpace(x.ThisPayeeRef) ? new PartyReference
                    {
                        Particulars = x.ThisPayeePart,
                        Code = x.ThisPayeeCode,
                        Reference = x.ThisPayeeRef
                    } : null,
                    AccountBalanceInterimBooked = new Money
                    {
                        Value = x.Balance.ToString(CultureInfo.InvariantCulture),
                        Currency = Currency.NZD
                    },
                    ReferenceId = GetReferenceId(x.NonValueTransactionItems),
                    UltracsNonValueTransactions = x.NonValueTransactionItems.Select(y => new UltracsNonValueTransaction
                    {
                        TransactionId = y.NonValueTransactionId,
                        Code = y.NonValueTransactionCode,
                        Description = y.NonValueTransactionDescription
                    }).ToList(),
                    // Set InsertedDateTime to ValueDateTime as the Ultracs API does not provide an inserted date, and ValueDateTime
                    // is the closest approximation to when the transaction occurred.
                    InsertionDateTime = valueDateTime
                };
            })
            .AsQueryable();
    }

    /// <summary>
    /// Use MD5 has of the <see cref="TransactionItem.TransactionId"/> and account ID to create a deterministic Guid.
    /// </summary>
    /// <param name="transactionItem"><see cref="TransactionItem"/></param>
    /// <param name="index">The index of <see cref="TransactionItem"/> in the list</param>
    /// <param name="accountId">The account ID for uniqueness</param>
    /// <returns><see cref="Guid"/></returns>
    public static Guid CreateDeterministicGuid(TransactionItem transactionItem, int index, string accountId)
    {
        var key = $"{accountId}|{transactionItem.TransactionId}|{index}";
        var hash = MD5.HashData(Encoding.UTF8.GetBytes(key));

        return new Guid(hash);
    }

    // Applies positional heuristic to detect internal suspense accounts (middleware parity rule).
    // Only hyphens are stripped before evaluation. Returns true if internal, else false.
    private static bool IsInternalSuspenseAccount(string? accountNumber)
    {
        if (string.IsNullOrEmpty(accountNumber))
        {
            return false; // Null/empty treated as non-internal
        }
        var stripped = accountNumber.Replace("-", string.Empty);
        if (stripped.Length < 9)
        {
            return false; // Too short to match rule => non-internal
        }
        var index = stripped.Length - 9; // Starting position for 3-char slice
        var slice = stripped.Substring(index, 3);
        return slice == "099"; // Internal suspense indicator
    }

    /// <summary>
    /// Get card number from a collection of <see cref="NonValueTransactionItem"/>
    /// </summary>
    /// <param name="nonValueTransactions">A collection of <see cref="NonValueTransactionItem"/></param>
    /// <returns>Card number. Null if it is not found.</returns>
    private static string? GetCardNumber(ICollection<NonValueTransactionItem> nonValueTransactions)
    {
        var result = nonValueTransactions.FirstOrDefault(f => f.NonValueTransactionDescription.Contains("Card Number|"))?.NonValueTransactionDescription;
        return result?.Split("|")[1];
    }

    /// <summary>
    /// Get reference Id from a collection of <see cref="NonValueTransactionItem"/>
    /// </summary>
    /// <param name="nonValueTransactions">A collection of <see cref="NonValueTransactionItem"/></param>
    /// <returns>Reference Id. Null if it is not found.</returns>
    private static string? GetReferenceId(ICollection<NonValueTransactionItem> nonValueTransactions)
    {
        var result = nonValueTransactions.FirstOrDefault(f => f.NonValueTransactionDescription.Contains("Reference|"))?.NonValueTransactionDescription;
        return result?.Split("|")[1];
    }
}