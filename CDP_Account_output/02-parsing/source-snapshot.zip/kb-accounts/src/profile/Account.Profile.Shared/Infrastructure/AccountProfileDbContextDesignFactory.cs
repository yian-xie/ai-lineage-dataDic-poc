﻿using System;

using Enterprise.Shared.Database.Configurations;
using Enterprise.Shared.Infrastructure.Configuration.Extensions;

using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Account.Profile.Shared.Infrastructure;

public class
    AccountProfileDbContextDesignFactory : IDesignTimeDbContextFactory<AccountProfileDbContext>
{
    public AccountProfileDbContext CreateDbContext(string[] args)
    {
        var configuration =
            new ConfigurationBuilder().BuildConfig(
                Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"), args);

        return new AccountProfileDbContext(
            configuration.CreateSqlServerDbContextOptionBuilder<AccountProfileDbContext>().Options,
            new CustomDbContextOptions { IsPooled = false });
    }
}