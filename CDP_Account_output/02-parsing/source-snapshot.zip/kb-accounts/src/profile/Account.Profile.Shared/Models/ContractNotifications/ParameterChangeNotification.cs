﻿using Newtonsoft.Json;

namespace Account.Profile.Shared.Models.ContractNotifications;

public class ParameterChangeNotification
{
    [JsonProperty("account_info")]
    public AccountInfo AccountInfo { get; set; }
}