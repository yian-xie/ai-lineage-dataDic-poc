﻿using System;
using System.Collections.Generic;

using Account.Shared.Entities;

namespace Account.Profile.Shared.Entities;

public class AccountProfile : AccountBaseConcurrentEntity
{
    /// <summary>
    ///     Account id.
    /// </summary>
    public required string AccountId { get; set; }

    /// <summary>
    ///     The user id who create this account
    /// </summary>
    public string AccountCreatedUserId { get; set; }

    /// <summary>
    ///     TSide.
    /// </summary>
    public required string TSide { get; set; }

    /// <summary>
    ///     Account status.
    /// </summary>
    public required string Status { get; set; }

    /// <summary>
    ///     Account status in TMV.
    /// </summary>
    public required string TmvStatus { get; set; }

    /// <summary>
    /// An artifact used to correlate Kafka messages from account creation back to the source so that we can confirm to the user that the account creation was successful.
    /// This is only used during account creation.
    /// </summary>
    public Guid CorrelationId { get; set; }

    /// <summary>
    ///     Change id.
    /// </summary>
    public required long ChangeId { get; set; }

    /// <summary>
    ///     Account creation date.
    /// </summary>
    public DateTimeOffset? Created { get; set; }

    /// <summary>
    ///     Account open date.
    /// </summary>
    public DateTimeOffset? Opened { get; set; }

    /// <summary>
    ///     Account close date.
    /// </summary>
    public DateTimeOffset? Closed { get; set; }

    /// <summary>
    ///     Account name.
    /// </summary>
    public required string Name { get; set; }

    /// <summary>
    ///     Account alternate name that set by customer.
    /// </summary>
    public string AlternateName { get; set; }

    /// <summary>
    ///     Reason that the account was closed.
    /// </summary>
    public string AccountClosureReason { get; set; }

    /// <summary>
    /// The organisation unit that the account is serviced by, e.g. Kiwibank, NZHL, etc.
    /// </summary>
    public string AccountOrganisationUnitId { get; set; }

    /// <summary>
    /// Minimum number of signatories set for an account
    /// </summary>
    public string MinimumNumberOfAuthoriser { get; set; }

    public ICollection<AccountProfileIdentifier> Identifiers { get; set; } = [];
    public ICollection<AccountCurrency> AccountCurrencies { get; set; } = [];

    public DomesticTaxRate DomesticTaxRate { get; set; } = new();
    public AccountProfileProductFacility ProductFacility { get; set; } = new();

    public AccountBankingRelationship BankingRelationship { get; set; } = new();
    public AccountFreezeDetails AccountFreezeDetails { get; set; } = new();

    /// <summary>
    /// Collection of account restrictions.
    /// </summary>
    public ICollection<AccountRestriction> Restrictions { get; set; } = [];
}