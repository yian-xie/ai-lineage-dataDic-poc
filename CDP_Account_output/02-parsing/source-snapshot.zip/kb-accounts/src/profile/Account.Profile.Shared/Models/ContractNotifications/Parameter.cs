﻿using Newtonsoft.Json;

namespace Account.Profile.Shared.Models.ContractNotifications;

public class Parameter
{
    [JsonProperty("id")]
    public string Id { get; set; }

    [JsonProperty("value")]
    public string Value { get; set; }

    [JsonProperty("edm")]
    public Edm Edm { get; set; }
}