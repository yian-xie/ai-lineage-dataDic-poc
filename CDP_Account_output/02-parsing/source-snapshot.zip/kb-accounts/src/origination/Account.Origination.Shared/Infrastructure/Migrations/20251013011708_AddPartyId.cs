﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddPartyId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "party_id",
                schema: "origination",
                table: "account_opening",
                type: "uuid",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "party_id",
                schema: "origination",
                table: "account_opening");
        }
    }
}