﻿using Account.PaymentInstruction.Api.Mutations;
using Account.PaymentInstruction.Api.Observability;
using Account.PaymentInstruction.Api.Queries;
using Account.PaymentInstruction.Api.Services;
using Account.PaymentInstruction.Shared;
using Account.PaymentInstruction.Shared.EventBuilder;
using Account.PaymentInstruction.Shared.Infrastructure;
using Account.PaymentInstruction.Shared.Services;
using Account.Shared;
using Account.Shared.Graphql;
using Account.Shared.Kafka;
using Account.Shared.Kafka.Produce;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchRequest;

using Confluent.Kafka;

using Enterprise.Shared.Kafka.Produce;

using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.PaymentInstruction.Api;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        services
            .AddRepositories()
            .AddSingleton<IPostingInstructionModelTranslator, PostingInstructionModelTranslator>()
            .AddScoped<IPaymentInstructionCreator, PaymentInstructionCreator>()
            .AddScoped<IPaymentInstructionStatusCreator, PaymentInstructionStatusCreator>()
            .AddScoped<IPaymentInstructionGetter, PaymentInstructionGetter>()
            .AddSingleton<IPostingInstructionClientBatchIdCreator,
                PostingInstructionClientBatchIdCreator>()
            .AddSingleton<IPaymentInstructionEventBuilder, PaymentInstructionEventBuilder>()
            .AddScoped<IAddPaymentInstructionRequestHandler,
                AddPaymentInstructionRequestHandler>();

        services.Configure<PaymentInstructionSettings>
            (Configuration.GetSection(nameof(PaymentInstructionSettings)));

        UseKafka(services);

        services
            .AddSingleton<
                ITmvEventPublisher<PostingInstructionBatchRequest>,
                TmvEventPublisher<PostingInstructionBatchRequest>
            >()
            .AddSingleton<
                IPostingInstructionBatchRequestPublisher,
                PostingInstructionBatchRequestPublisher>();

        UsePooledDbContext<PaymentInstructionDbContext>(services);

        services
            .UseGraphql<PaymentInstructionQuery, PaymentInstructionMutation>(Configuration)
            .ModifyOptions(x => x.UseXmlDocumentation = true);

        services
            .Decorate<IAddPaymentInstructionRequestHandler,
                PaymentInstructionRequestHandlerMetricsDecorator>();

        FixTmvServiceSettings(services);
    }

    /// <summary>
    ///     AB#376718 set up the tmv producer for PostingInstructionBatchRequest
    /// </summary>
    /// <remarks>
    ///     The Producer Factory for TMV related kafka is receiving the wrong settings. This adjusts that till it's fixed.
    /// </remarks>
    /// <param name="services"></param>
    private static void FixTmvServiceSettings(IServiceCollection services)
    {
        services
            .Insert(0, ServiceDescriptor.Describe(
                typeof(IProducer<Null, PostingInstructionBatchRequest>),
                provider => provider.GetRequiredService<IProducerFactory>()
                    .Build<Null, PostingInstructionBatchRequest>(
                        provider.GetRequiredService<TmvKafkaSettings>()),
                ServiceLifetime.Singleton));
    }
}