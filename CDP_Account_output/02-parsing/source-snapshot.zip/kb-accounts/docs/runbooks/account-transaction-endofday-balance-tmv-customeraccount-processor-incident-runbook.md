## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account.Transaction.EndOfDay.Balance.Tmv.CustomerAccount.Processor (`transaction-eod-tmv-customeraccount-processor`) |
| Customer or business impact | End-of-day customer-account balance events can be delayed, missing, or contain unexpected zero balances, delaying the downstream CDP data product and reconciliation consumers. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Transaction EoD Customer Accounts Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203297869/Account+Transaction+EoD+Customer+Accounts+Observability+Dashboard)</li><li>[EoD Components Runbook logs](https://kiwibank.atlassian.net/wiki/x/CQG6PwE)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Invalid contract notification moved directly to DLQ</summary>

**Symptoms**

- [Logs](https://kbprod.au.sumologic.com/log-search#H4sIAAAAAAAACn2RYW%2FTMBCG%2F4q5T4ASkqIVaKRIQ%2B2QkNZ26tineYqMcw1GsS87O2UV8N8nt8nYEOyb7%2B659%2B49%2F4TbHnkPBVTG1XhXatNVSmvqXfCVcVvG22qWS%2FdxtRCVp541zlXAhnhfdkx1pk2XjQ3Za3EknbLoO6WxHEtpYOW80sGQGyBNLijjkMtHtRSpToPdpbr3gSzyIJB2TBq9J5bul%2Fjuowq01Lw5tRKS4f2FlcbP9Z%2FEaStBKC%2FOqVmi96rBRAxQEpPnuMNWrNaLzfoi6v74hoyP6HFHLyTMyQVWOqwomK3R6uAEd%2BiCBEH8n67Rhhh8SJAuy56f9EmZFmsJIsse2pGZWNgj%2FJfE0UVZCglnEXs648XLf0%2B52KwXV%2FOzzXPbz9ery6tlZF7F83jiIL7uRTAWfVC2EzV6LUSstcaaIN7meR6jrcG29k9u%2FfAB48aQQKdYWQzIHorrmwSi8Ea5BqG4nryfTfJ30%2Fxk9iGfJjGaTCcnh%2BgmAe4dFIF7PIh445ol1QgFqD4Q%2FL4HEnVvmNgCAAA%3D) contain `Moving ContractNotification event ... to DLQ due to invalid data`.
- The `END_OF_DAY` notification has a blank `resource_id` or missing `effective_datetime`; no customer balance event is published.

**Actions**

1. Compare the failed payload with the active `vault.core_api.v1.contract.notification.event` contract and have the producer correct the missing field.
2. Do not replay until the payload is corrected. [TODO: confirm the approved DLQ inspection and replay procedure for each environment].

**Recovery check**

- The corrected event logs `Successfully processed end of the day event`, and a matching `account.balance.end-of-day.customer-account.v1.event` appears for the resource ID and effective datetime.

**Escalation**

- Use the incident escalation path when malformed events recur, the producer cannot correct the payload, or multiple accounts are affected.

</details>

<details>
<summary>PostgreSQL balance retrieval repeatedly fails</summary>

**Symptoms**

- Processing does not log the `Retrieved {BalanceCount} balance(s) for account {AccountId} as at {EffectiveDatetime}, of which {CachedBalanceCount} are cached balances.` log & the exception identifies PostgreSQL or `AccountTransactionDbContext`.
- Kafka redelivery continues at one-minute intervals and may end in DLQ after six hours from first delivery.

**Actions**

1. Correlate the event ID, account ID, effective datetime, and exception in sumo.
2. Confirm pods are running and whether failures affect all balance queries or if its a single event that's failing.
3. Check the transaction PostgreSQL service and the deployed `ConnectionStrings__DefaultConnection` secret reference without exposing its value.
4. Restore database connectivity or deploy a tested query fix; allow the built-in redelivery path to retry. Do not reset offsets.

**Recovery check**

- Log `Retrieved {BalanceCount} balance(s) for account {AccountId} as at {EffectiveDatetime}, of which {CachedBalanceCount} are cached balances.` and `Successfully processed end of the day event` logs resume & error logs drop in sumo; redelivery stops and the output event is present.

**Escalation**

- Use the incident escalation path if database access remains unavailable, the event approaches the six-hour limit, or lag continues rising after recovery.

</details>

<details>
<summary>ESP Kafka or Schema Registry blocks publication</summary>

**Symptoms**

- No `account.balance.end-of-day.customer-account.v1.event` is emitted.
- Exceptions identify the ESP Kafka producer, topic, authentication, or a Schema Registry issue; redelivery occurs every minute and moves to DLQ after six hours.

**Actions**

1. Check ESP Kafka and Schema Registry availability and the deployed `Kafka__*` and `Kafka__SchemaRegistry__*` secret references without exposing values.
2. Confirm the topic and schema version match the deployment values.
3. Restore the dependency or deploy a tested publisher/schema fix, then let redelivery complete. [TODO: confirm the approved DLQ replay procedure for events that exhausted retries].
4. Check [ESP Support ](https://teams.microsoft.com/l/channel/19%3AOUczqvpL2j_7CnB-CYsE86SPmDefz7zJUfWX5YODYmM1%40thread.tacv2/ESP%20support?groupId=e7a307ca-92e9-4457-a2cf-f866cbd89c73&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc&ngc=true&allowXTenantAccess=true)for similar failures.

**Recovery check**

- Publish exceptions stop, success metrics resume, and one output event exists for the affected account and effective datetime; check for duplicates before closure.

**Escalation**

- Use the incident escalation path when the dependency owner cannot restore service, authorization remains invalid, or the six-hour retry window is at risk.

</details>

<details>
<summary>Unexpected zero balances are published</summary>

**Symptoms**

- Logs report zero matching balances, or the output contains the documented default NZD zero values for `InterimBooked` or `InterimAvailable`.
- Downstream consumers report an unexpected zero end-of-day balance.

**Actions**

1. Capture account ID, effective datetime, balance type, and output event ID.
2. Confirm whether `transaction.account_balance` had an eligible actual or cached balance at that effective datetime; repository logic deliberately defaults a missing supported balance type to zero NZD.
3. Compare source posting/balance ingestion timing with the contract notification effective datetime.
4. Correct the upstream balance data or timing defect before any replay. [TODO: confirm the approved account-balance lookup and event replay procedure].

**Recovery check**

- The expected balance is returned using the actual-before-cached ordering, and the corrected output carries the expected `InterimBooked` and `InterimAvailable` values.

**Escalation**

- Use the incident escalation path when source and published balances differ, multiple accounts are affected, or downstream reconciliation is blocked.

</details>

<details>
<summary>Non-END_OF_DAY notifications appear unprocessed</summary>

**Symptoms**

- Logs contain `Skipped ContractNotification event ... It is not END_OF_DAY event type`.
- No customer end-of-day balance event is emitted for that notification.

**Actions**

1. Confirm the source `notification_details.event_type` and resource ID.
2. If the type is not `END_OF_DAY`, treat the skip as expected and verify the consumer continues processing later events.
3. If an end-of-day event was expected, investigate the upstream TMV notification producer; do not replay the differently typed event as end-of-day data.

**Recovery check**

- Expected skips continue normally; a valid `END_OF_DAY` notification subsequently logs successful processing and emits the customer balance event.

**Escalation**

- Use the incident escalation path when TMV emits the wrong event type for end-of-day processing or consumer progress stops after the skip.

</details>

<details>
<summary>Failure reporting to SumoLogic is unavailable</summary>

**Symptoms**

- Application logs contain `Failed to push log into SumoLogic for customer account`.
- The event remains on redelivery when failure reporting prevents the exhausted event from taking its DLQ return path.

**Actions**

1. Use workload logs and Dynatrace signals from the observability page as the temporary source of truth.
2. Check `SumoLogicIngestion__SourceCategory`, source name, collector reachability, and the `SumoLogicIngestion__ApiToken` secret reference without exposing values.
3. Restore SumoLogic ingestion, then observe the next one-minute redelivery attempt.
4. Keep the underlying PostgreSQL or publication incident open; restoring alert ingestion alone does not recover event processing.

**Recovery check**

- Failure records reach the configured SumoLogic source and an exhausted event can complete its DLQ path; normal events continue processing.

**Escalation**

- Use the incident escalation path if failure visibility remains unavailable or events continue redelivering beyond the six-hour threshold.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>