﻿
using System.Threading;
using System.Threading.Tasks;

namespace Account.Transaction.Api.Providers;

/// <summary>
///    Interface for acquiring Azure AD tokens based on provided options.
/// </summary>
public interface IAzureAdTokenProvider
{
    /// <summary>
    ///     Acquires an Azure AD token based on the provided options.
    /// </summary>
    /// <returns>A task that represents the asynchronous operation. The task result contains the acquired Azure AD token.</returns>
    Task<string> GetTokenAsync(CancellationToken cancellationToken = default);
}