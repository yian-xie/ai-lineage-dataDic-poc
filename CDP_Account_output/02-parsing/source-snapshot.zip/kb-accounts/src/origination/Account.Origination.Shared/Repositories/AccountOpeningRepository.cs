﻿#nullable enable

using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure;

using Microsoft.EntityFrameworkCore;

namespace Account.Origination.Shared.Repositories;

/// <summary>
///     Implement <see cref="IAccountOpeningRepository" />. The <see cref="AccountOpening" /> repository.
/// </summary>
public class AccountOpeningRepository(OriginationDbContext dbContext)
    : IAccountOpeningRepository
{
    public void Add(AccountOpening accountOpening)
    {
        dbContext.Add(accountOpening);
    }

    public void Update(AccountOpening accountOpening)
    {
        dbContext.Update(accountOpening);
    }

    public async Task<AccountOpening?> GetJobAsync(
        Guid eventId,
        CancellationToken cancellationToken)
    {
        return await dbContext.AccountOpenings.FirstOrDefaultAsync(
            x => x.EventId == eventId,
            cancellationToken);
    }
}