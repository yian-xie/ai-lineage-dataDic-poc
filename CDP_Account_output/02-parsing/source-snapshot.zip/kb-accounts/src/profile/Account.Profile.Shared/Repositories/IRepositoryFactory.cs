﻿using Account.Profile.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.Profile.Shared.Repositories;

public interface IRepositoryFactory
{
    AccountProfileDbContext DbContext { get; }
    IUnitOfWork UnitOfWork { get; }
    IAccountProfileRepository AccountProfileRepository { get; }
}