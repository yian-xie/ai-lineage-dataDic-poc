﻿using System;

using Account.Shared.Constants.Tmv;

namespace Account.Profile.Processor.Mapping;

public static class FreezeTypeMapper
{
    // TODO Add these values as enums in the account profile event schema (breaking change)
    // then reference them from there and remove these constants here
    //
    public const string FreezeTypePreventDebit = "PreventDebit";
    public const string FreezeTypePreventDebitAndCredit = "PreventDebitAndCredit";
    public static string GetFreezeType(string restrictionSetDefinitionId)
    {
        return restrictionSetDefinitionId switch
        {
            RestrictionSetDefinitionIds.AccountDebitAndCreditFreeze => FreezeTypePreventDebitAndCredit,
            RestrictionSetDefinitionIds.AccountDebitFreeze => FreezeTypePreventDebit,
            _ => throw new ArgumentException($"Unsupported restriction set definition id: {restrictionSetDefinitionId}", nameof(restrictionSetDefinitionId))
        };
    }
}