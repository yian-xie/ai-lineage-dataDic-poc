﻿using System;

using Account.Shared.Authorisation;

using Enterprise.Shared.Configuration;
using Enterprise.Shared.GraphQL;

using HotChocolate.Execution.Configuration;

using Kb.Api.Infrastructure.GraphQL;
using Kb.Api.Observability.GraphQL;
using Kb.Api.Observability.Utility;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Shared.Graphql;

public static class GraphqlExtension
{
    /// <summary>
    ///     Use Graphql extension with enabling or disabling allow introspection that set in Graphql settings.
    /// </summary>
    /// <param name="services">
    ///     <see cref="IServiceCollection" />
    /// </param>
    /// <param name="configuration">
    ///     <see cref="IConfiguration" />
    /// </param>
    /// <param name="useAuthorization">
    ///    A value indicating whether to use OPA authorization.
    /// </param>
    /// <returns></returns>
    private static IRequestExecutorBuilder UseGraphql(
        this IServiceCollection services,
        IConfiguration configuration,
        bool useAuthorization = true)
    {
        var graphqlConfig = GetGraphqlConfig(configuration);

        services.AddSingleton<IJsonLogProcessor, JsonLogProcessor>();

        var graphQlBuilder = services
            .AddErrorFilter<FilterValidationErrorFilter>()
            .AddGraphQLServer()
            .AddGqlObservability()
            .AddGqlHotChocolateInstrumentation()
            .DisableIntrospection(!graphqlConfig.IntrospectionEnabled)
            .AddFairyBread(options => { options.ThrowIfNoValidatorsFound = false; })
            .AddAccountAuthorization()
            .InitializeOnStartup();

        if (useAuthorization)
        {
            services.AddAccountAuthorization(configuration);
            graphQlBuilder.AddAccountAuthorization();
        }

        return graphQlBuilder;
    }

    public static IRequestExecutorBuilder UseGraphql<TQuery>(
        this IServiceCollection services,
        IConfiguration configuration,
        bool useAuthorization = true) where TQuery : class
    {
        return services.UseGraphql(configuration, useAuthorization).AddQueryType<TQuery>();
    }


    public static IRequestExecutorBuilder UseGraphql<TQuery, TMutation>(
        this IServiceCollection services,
        IConfiguration configuration) where TMutation : class where TQuery : class
    {
        return services.UseGraphql<TQuery>(configuration).AddMutationType<TMutation>();
    }


    /// <summary>
    ///     Get <see cref="GraphqlConfig" />.
    /// </summary>
    /// <param name="configuration">
    ///     <see cref="IConfiguration" />
    /// </param>
    /// <returns></returns>
    /// <exception cref="ArgumentException">Throw the exception when there is no Graphql settings found.</exception>
    private static GraphqlConfig GetGraphqlConfig(IConfiguration configuration)
    {
        var graphqlConfig = configuration.GetConfigurationSection<GraphqlConfig>();

        if (graphqlConfig is null)
        {
            throw new ArgumentException(
                $"GraphQL settings not found at key: {GraphqlConfig.Key}",
                nameof(configuration));
        }

        return graphqlConfig;
    }
}