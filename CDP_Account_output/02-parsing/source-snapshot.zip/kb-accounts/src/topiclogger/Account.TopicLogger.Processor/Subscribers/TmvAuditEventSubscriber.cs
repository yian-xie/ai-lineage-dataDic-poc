﻿using Account.Shared.Services;
using Account.TopicLogger.Processor.Configurations;

using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.TopicLogger.Processor.Subscribers;

public class TmvAuditEventSubscriber(
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings)
    : IIncomingEventSubscriber<AuditTopicEmptyEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        AuditTopicEmptyEvent @event,
        CancellationToken cancellationToken)
    {
        var result = context.ConsumeResult;

        await sumoLogicClientHelper.IngestLogAsync(
            result.Message.Value,
            sumoLogicSettings.SourceCategory + SumoLogicSourceCategories.OperationalLogs,
            sumoLogicSettings.SourceName + SumoLogicSourceNames.AuditTopic,
            sumoLogicSettings.ApiToken,
            cancellationToken);

        return EventSubscriberResults.Success;
    }
}