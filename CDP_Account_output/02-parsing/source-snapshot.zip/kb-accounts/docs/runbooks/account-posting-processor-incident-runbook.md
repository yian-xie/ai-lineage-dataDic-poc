## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account Posting Processor (`accounts-posting-processor`) |
| Customer or business impact | Accepted TMV posting batches may not produce `account.posting.v1.event` events, delaying downstream account-entry processing. [TODO: confirm the customer impact statement and business criticality] |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Posting Processor Observability Dashboard (confluence)](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5476974966/Account+Posting+Processor+Observability+Dashboard)</li><li>[Account Posting Processor Observability Dashboard (dynatrace)](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all)</li><li>[Sumo Logic Library](https://kbprod.au.sumologic.com/library/41624834)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Workload unavailable or probes failing</summary>

**Symptoms**

- Dynatrace shows fewer running pods than the configured three replicas, increasing container restarts, or reduced availability for `accounts-posting-processor`.
- 'SLO - Availability' tile on production dashboard shows reduced availability.

**Actions**

1. In the [Account Posting Processor Observability Dashboard](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all), inspect **Pods**, **Container restarts**, CPU, memory, and the availability SLO for `accounts-posting-processor`.
2. Correlate the first failure with the `accounts-posting` pipeline deployment and image tag. The workload is deployed from `src/posting/Deploy/Account.Posting.Processor/values.yaml` plus the production values file (`values-deliver.yaml`).
3. Inspect the failing pod's readiness/liveness result (as shown by the 'SLO - Availability' tile on the dashboard) and application startup logs.
4. If the failure started with a release, stop promotion and follow the approved rollback or fix-forward procedure. [TODO: confirm the pipeline rollback procedure]

**Recovery check**

- Running pods return to the desired replica count, container restarts stop increasing, both probes pass, and Kafka event success requests resume.
- Probe requests are cluster-local in the repository configuration; no ingress or developer-laptop access path is defined. Use the 'SLO - Availability' tile on the dashboard to confirm probes are passing.

**Escalate when**

- Desired capacity cannot be restored, probes continue failing, or posting events remain stalled after workload health recovers. Use the Incident Management Processes link in the quick reference.

</details>

<details>
<summary>TMV posting batches are not being consumed</summary>

**Symptoms**

- `Number of Post Batch Events Received` and `Number of Post Batch Events Successfully Processed` on the dynatrace dashboard show no activity while TMV is publishing `vault.api.v1.postings.posting_instruction_batch.created` events.
- No `Successfully processed Posting Instruction Batch (PIB)` logs appear, or Kafka authentication/connection errors appear for the environment's TMV consumer group.

**Actions**

1. Use the [Account Posting Processor Observability Dashboard](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all) to compare total, success, exception, and redelivery metrics for the affected environment.
2. The expected production consumer group is `cg_tmv_accounts_account_posting_prod`.
3. Check TMV broker connectivity and authentication configuration. Non-production uses `TMVKafkaOAuth` with the environment-specific client-secret key; production explicitly selects `TMVKafka` and configures the OAuth URL as empty.
4. Confirm lag and partition assignment for the exact topic and consumer group. [TODO: provide the approved Kafka tooling/access path, saved lag query, and production alert threshold]
5. Do not rotate credentials or change the consumer group during incident response without an approved change; these procedures are not repository-defined.

**Recovery check**

- Total and success request counts increase, redelivery does not continue rising, and the affected consumer group catches up. [TODO: confirm the acceptable consumer-lag recovery threshold]

**Escalate when**

- TMV is publishing but the consumer cannot authenticate, obtain partitions, or reduce lag after service health is restored. Use the Incident Management Processes link in the quick reference.

</details>

<details>
<summary>PostgreSQL transaction failures cause redelivery</summary>

**Symptoms**

- `Number of Post Batch Event Exception` and `Number of Post Batch Event Redeliver` tiles on the dynatrace dashboard show current activity.
- Logs repeatedly contain `Failed to process PIB create Event with batch Id:` for one or more batch IDs.
- Dynatrace shows database connection failures or increased database child-call time for the environment's account posting database.

**Actions**

1. In the [Account Posting Processor Observability Dashboard](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all), inspect **DB connection failure rate**, database call count/time, exceptions, and redeliveries for `accounts-posting-processor`.
2. Filter application logs by the exact failure text and a batch ID to distinguish lookup, transaction creation, save, and commit failures. See [Sumo Logic Library](https://kbprod.au.sumologic.com/library/41624834). [TODO: provide a specific saved Sumo query for this.]
3. Confirm the deployment has the correct `ConnectionStrings__DefaultConnection` key and production database name. Do not expose connection values or secret material.
4. Check the mapped RDS/database deployment status through the approved operational tooling. [TODO: confirm database access tooling, permissions, and a production connectivity check?]
5. Do not manually edit `tmv_positing_batch` or `outbox`; the subscriber writes de-duplication and outbox records in one transaction and automatically redelivers after five seconds on failure.

**Recovery check**

- Database connection failures stop, redelivery stabilizes, and `Successfully processed Posting Instruction Batch (PIB) for batchId:` appears for affected batches.

**Escalate when**

- Database availability cannot be restored, redelivery remains sustained, or there is evidence of inconsistent `tmv_positing_batch` and `outbox` state. Use the Incident Management Processes link in the quick reference.

</details>

<details>
<summary>A posting batch is repeatedly redelivered</summary>

**Symptoms**

- Redelivery and exception metrics rise every five seconds while failures repeatedly name the same batch ID.
- The batch never produces `Successfully processed Posting Instruction Batch (PIB)`.
- The accepted event may lack data used by the event builder, such as batch details, posting instructions, instruction details, or committed postings.

**Actions**

1. Filter service logs for `Failed to process PIB create Event with batch Id:` and identify whether one batch ID dominates failures. [TODO: provide a specific saved Sumo query]
2. Compare the exception type with the event-builder path that creates `account.posting.v1.event`; null transaction codes are supported, but required nested posting data is dereferenced during transformation.
3. Ask the upstream owner to validate the source event against the TMV posting batch schema. Treat payloads as restricted, sensitive financial/customer data and do not paste them into incident channels.
4. Do not delete the de-duplication record or alter offsets. [TODO: confirm the approved poison-event quarantine, skip, or replay procedure]

**Recovery check**

- The affected batch processes once, its redelivery stops, and success requests increase without a new exception for that batch ID.

**Escalate when**

- A source event cannot be corrected or safely isolated, or repeated redelivery is blocking partition progress. Use the Incident Management Processes link in the quick reference.

</details>

<details>
<summary>Accepted batches are processed but output events are missing</summary>

**Symptoms**

- Logs show successful processing for accepted batch IDs, but consumers do not observe the `prod.account.posting.v1.event` topic.
- The service remains healthy while the Kafka outbox accumulates retries or downstream Kafka/schema-registry errors occur.

**Actions**

1. Confirm the successful subscriber log for the affected batch ID and verify the incoming batch status was accepted; non-accepted batches are persisted without publishing an account posting event.
2. Inspect Kafka outbox telemetry registered by `AddKafkaOutboxTelemetry()` and producer/schema-registry errors for `accounts-posting-processor`. [TODO: provide the saved dashboard view or query and alert threshold for outbox backlog/retries]
3. Check connectivity and authorization to the production Confluent Kafka bootstrap servers and schema registry configured by `Kafka__*` keys. [TODO: provide the approved Kafka diagnostic tooling and access path]
4. Confirm the expected output topic uses the `prod.account.posting.v1.event`; do not manually insert, update, or delete outbox rows.
5. If a schema or producer configuration change caused the outage, use the approved fix-forward or rollback procedure. [TODO: confirm the pipeline rollback procedure]

**Recovery check**

- Outbox retries/backlog return to normal and the expected posting events become visible on the output topic. [TODO: confirm the normal outbox backlog threshold and approved event verification method]

**Escalate when**

- Outbox delivery cannot recover, schema compatibility blocks publication, or there is risk of duplicate/missing downstream events. Use the Incident Management Processes link in the quick reference.

</details>

<details>
<summary>Failure alerts are not reaching Sumo Logic</summary>

**Symptoms**

- Application logs contain `Failed to push log into SumoLogic for failed processing of PIB create with batch Id:`.
- Kafka exception/redelivery metrics increase without corresponding failure-ingestion records in the configured Sumo source category.

**Actions**

1. Use Dynatrace exception and redelivery metrics as the temporary source of truth.
2. Check `SumoLogicIngestion__SourceCategory`, `SumoLogicIngestion__SourceName`, and the presence of the `SumoLogicIngestion__ApiToken` secret key without exposing its value.
3. Check connectivity from the workload to the configured Sumo collector endpoint. [TODO: confirm the approved production connectivity check and execution context]
4. Treat this as observability degradation in addition to the underlying posting failure; fixing Sumo ingestion does not resolve the batch-processing exception.

**Recovery check**

- New processing failures are ingested into the expected environment source category and the nested Sumo failure log stops appearing.

**Escalate when**

- Failure ingestion remains unavailable or loss of alerting prevents safe operation of the processor. Use the Incident Management Processes link in the quick reference.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>