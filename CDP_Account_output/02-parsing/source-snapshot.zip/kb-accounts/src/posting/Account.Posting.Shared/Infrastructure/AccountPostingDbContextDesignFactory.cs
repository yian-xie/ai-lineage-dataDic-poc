﻿using System;

using Enterprise.Shared.Database.Configurations;
using Enterprise.Shared.Infrastructure.Configuration.Extensions;

using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Account.Posting.Shared.Infrastructure;

public class
    AccountPostingDbContextDesignFactory : IDesignTimeDbContextFactory<AccountPostingDbContext>
{
    public AccountPostingDbContext CreateDbContext(string[] args)
    {
        var configuration =
            new ConfigurationBuilder().BuildConfig(
                Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"), args);

        return new AccountPostingDbContext(
            configuration.CreateSqlServerDbContextOptionBuilder<AccountPostingDbContext>().Options,
            new CustomDbContextOptions { IsPooled = false });
    }
}