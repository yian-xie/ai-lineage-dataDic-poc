﻿namespace Account.Shared.Constants.Tmv;

public static class PostingInstructionBatchStatuses
{
    public const string Rejected = "POSTING_INSTRUCTION_BATCH_STATUS_REJECTED";
    public const string Accepted = "POSTING_INSTRUCTION_BATCH_STATUS_ACCEPTED";
    public const string Error = "POSTING_INSTRUCTION_BATCH_STATUS_ERROR";
    public const string UNKNOWN = "POSTING_INSTRUCTION_BATCH_STATUS_UNKNOWN";
}