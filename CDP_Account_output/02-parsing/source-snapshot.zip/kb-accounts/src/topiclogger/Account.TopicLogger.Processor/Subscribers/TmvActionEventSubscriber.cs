﻿using Account.Shared.Services;
using Account.TopicLogger.Processor.Configurations;

using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.TopicLogger.Processor.Subscribers;

public class TmvActionEventSubscriber(
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings)
    : IIncomingEventSubscriber<ActionTopicEmptyEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        ActionTopicEmptyEvent @event,
        CancellationToken cancellationToken)
    {
        var result = context.ConsumeResult;

        await sumoLogicClientHelper.IngestLogAsync(
            result.Message.Value,
            sumoLogicSettings.SourceCategory + SumoLogicSourceCategories.OperationalLogs,
            sumoLogicSettings.SourceName + SumoLogicSourceNames.ActionTopic,
            sumoLogicSettings.ApiToken,
            cancellationToken);

        return EventSubscriberResults.Success;
    }
}