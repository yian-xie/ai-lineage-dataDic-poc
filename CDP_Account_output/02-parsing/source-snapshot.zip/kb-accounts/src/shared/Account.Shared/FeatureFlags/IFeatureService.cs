﻿using LaunchDarkly.Sdk;

namespace Account.Shared.FeatureFlags;

public interface IFeatureService
{
    /// <summary>
    /// Evaluates whether a feature is enabled.
    /// Could use an implicit user context or an anonymous context.
    /// </summary>
    /// <param name="featureName">name of the feature</param>
    /// <param name="defaultValue">default value</param>
    public bool IsFeatureEnabled(string featureName, bool defaultValue = false);

    /// <summary>
    /// Evaluates whether a feature is enabled for the user context
    /// </summary>
    /// <param name="featureName">name of the feature</param>
    /// <param name="userKey">user key</param>
    /// <param name="defaultValue">default value</param>
    public bool IsFeatureEnabled(
        string featureName,
        string userKey,
        bool defaultValue = false);

    /// <summary>
    /// Evaluates whether a feature is enabled in a specific context other than the "user" context
    /// </summary>
    /// <param name="featureName">name of the feature</param>
    /// <param name="context">context</param>
    /// <param name="defaultValue">default value</param>
    public bool IsFeatureEnabled(
        string featureName,
        Context context,
        bool defaultValue = false);
}