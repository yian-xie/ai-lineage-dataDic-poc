﻿namespace Account.Origination.Job.Configurations;

public class TmvSemanticOptionCollection
{
    public required List<TmvSemanticOption> Options { get; set; }
}

public class TmvSemanticOption
{
    public required string Key { get; set; }
    public required string TmvProductCode { get; set; }
    public required string Version { get; set; }
}