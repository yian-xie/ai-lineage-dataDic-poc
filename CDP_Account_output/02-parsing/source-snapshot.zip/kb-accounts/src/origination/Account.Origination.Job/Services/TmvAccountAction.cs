﻿using System.Net;

using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Constants;
using Account.Origination.Job.TMVClient.SemanticVersion;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure.Exceptions;
using Account.Shared.FeatureFlags;

using Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Kb.TMV.Client.Actions.GetAccount.Constants;
using Kb.TMV.Client.Actions.GetAccount.Requests;
using Kb.TMV.Client.Actions.OpenAccount.Requests;

using ApiException = Api.Shared.Clients.Rest.ThoughtMachine.V5.Core.ApiException;
using TmvClient = Kb.TMV.Client.ITmvClient;

namespace Account.Origination.Job.Services;

public abstract class TmvAccountAction(
    string product,
    ICoreAPIAccountsClient coreApiAccountsClient,
    IOnlineCallClient onlineCallClient,
    ISemanticVersionResolver semanticVersionResolver,
    ILogger<TmvAccountAction> logger,
    IFeatureService featureService,
    TmvClient tmvClient
)
    : ITmvAccountAction
{
    protected readonly ICoreAPIAccountsClient CoreApiAccountsClient = coreApiAccountsClient;
    protected readonly ISemanticVersionResolver SemanticVersionResolver = semanticVersionResolver;
    protected readonly IOnlineCallClient OnlineCallClient = onlineCallClient;
    protected readonly ILogger<TmvAccountAction> Logger = logger;
    protected readonly IFeatureService FeatureService = featureService;
    protected readonly TmvClient _tmvClient = tmvClient;
    public string Product { get; } = product;

    public abstract Task<V1accountsAccount> CreateAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken);

    public abstract Task<CreateOnlineCallAccountResponse> CreateV2Async(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        CancellationToken cancellationToken);

    public async Task<V1accountsAccount> OpenAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken)
    {
        try
        {
            var useTMVLibrary = FeatureService.IsFeatureEnabled(
                FeatureFlag.UseTmvRestApiClient,
                defaultValue: false);

            if (useTMVLibrary == true)
            {
                var openAccountRequest = new OpenAccountRequest(
                    accountId: accountOpening.AccountId,
                    correlationId: accountOpening.CorrelationId.ToString(),
                    requestId: $"{accountOpening.EventId}_update"
                    );

                var tmvAccount = await _tmvClient.OpenAccountAsync(openAccountRequest, cancellationToken);

                if (!tmvAccount.IsSuccess)
                {
                    var error = tmvAccount.Failure.Errors[0];
                    Logger.LogError("Failed to open TMV account {accountId}: [{code}] {message}.", accountOpening.AccountId, error.Code, error.Message);
                    throw new AccountOriginationException($"Failed to open TMV account {accountOpening.AccountId}: [{error.Code}] {error.Message}");
                }

                if (!Enum.TryParse<V1accounts_commonAccountStatus>(tmvAccount.Success.AccountStatus, out var status))
                {
                    Logger.LogError("TMV account {accountId} returned unrecognised status: {AccountStatus}", accountOpening.AccountId, tmvAccount.Success.AccountStatus);
                    throw new AccountOriginationException(
                        $"TMV account {accountOpening.AccountId} returned unrecognised status: {tmvAccount.Success.AccountStatus}");
                }

                if (status != V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN)
                {
                    throw new AccountOriginationException(
                        $"Expecting the returned TMV account {accountOpening.AccountId} status is {V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN} after opening account but the status is {status}");
                }

                Logger.LogInformation("Opened TMV account {accountId}.", accountOpening.AccountId);

                return new V1accountsAccount
                {
                    Id = tmvAccount.Success.AccountId,
                    Status = status,
                };
            }
            else
            {
                var updateRequest = CreateUpdateAccountStatusToOpenRequest(accountOpening);

                var tmvAccount = await CoreApiAccountsClient.UpdateAccountAsync(
                    accountOpening.AccountId,
                    updateRequest,
                    cancellationToken);

                if (tmvAccount.Status != V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN)
                {
                    throw new AccountOriginationException(
                        $"Expecting the returned TMV account {accountOpening.AccountId} status is {V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN} after opening account but the status is {tmvAccount.Status}");
                }

                Logger.LogInformation("Opened TMV account {accountId}.", accountOpening.AccountId);

                return tmvAccount;
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(
                ex,
                "Failed to open TMV account {accountId} for ProductApplicationEvent {eventId}.",
                accountOpening.AccountId,
                accountOpening.EventId);

            throw;
        }
    }

    // TODO: Can Remove Old method once we always use tmv library after successful transition
    public async Task<V1accountsAccount?> GetAsync(
        string id,
        CancellationToken cancellationToken)
    {
        try
        {
            return await CoreApiAccountsClient.GetAccountAsync(id,
                null,
                null,
                cancellationToken);
        }
        catch (ApiException ex)
        {
            if ((HttpStatusCode)ex.StatusCode == HttpStatusCode.NotFound)
            {
                Logger.LogWarning("TMV account {accountId} not found.", id);

                return null;
            }

            Logger.LogWarning(
                ex,
                "Expecting 404 exception for GET account with id = {id}, but something other than 404 was caught.",
                id);

            throw;
        }
    }



    public async Task<V1accountsAccount?> GetAsync(
        string id,
        string correlationId,
        CancellationToken cancellationToken)
    {
        try
        {
            var request = new GetAccountRequest(
            accountId: id,
            correlationId: correlationId);

            var result = await _tmvClient.GetAccountAsync(request, cancellationToken);

            if (!result.IsSuccess)
            {
                if (result.Failure.Errors[0].Code == GetAccountConstants.ErrorCode.AccountNotExist)
                {
                    Logger.LogWarning("TMV account {accountId} not found.", id);
                    return null;
                }

                var error = result.Failure.Errors[0];
                Logger.LogError("GET account {accountId} failed: [{code}] {message}.", id, error.Code, error.Message);
                throw new AccountOriginationException($"Failed to get TMV account {id}: [{error.Code}] {error.Message}");
            }

            if (!Enum.TryParse<V1accounts_commonAccountStatus>(result.Success.AccountStatus, out var status))
            {
                Logger.LogError("TMV account {id} returned unrecognised status: {AccountStatus}", id, result.Success.AccountStatus);
                throw new AccountOriginationException(
                    $"TMV account {id} returned unrecognised status: {result.Success.AccountStatus}");
            }

            return new V1accountsAccount
            {
                Id = result.Success.AccountId,
                Status = status,
                Opening_timestamp = result.Success.AccountUpdatedDatetime
            };

        }
        catch (ApiException ex)
        {
            if ((HttpStatusCode)ex.StatusCode == HttpStatusCode.NotFound)
            {
                Logger.LogWarning("TMV account {accountId} not found.", id);

                return null;
            }

            Logger.LogWarning(
                ex,
                "Exception for GET account with id = {id}, but something other than 404 was caught.",
                id);

            throw;
        }
    }

    /// <inheritdoc />
    public virtual AccountOpeningState? GetPrerequisiteState(AccountOpening accountOpening)
    {
        return null;
    }

    /// <summary>
    ///     Create AccountsUpdateAccountRequest with account status ACCOUNT_STATUS_OPEN.
    /// </summary>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <returns>
    ///     <see cref="V1accountsUpdateAccountRequest" />
    /// </returns>
    private static V1accountsUpdateAccountRequest CreateUpdateAccountStatusToOpenRequest(
        AccountOpening accountOpening)
    {
        var updateRequest = new V1accountsUpdateAccountRequest
        {
            Request_id = $"{accountOpening.EventId}_update",

            Account = new V1accountsAccount
            {
                Status = V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN
            },
            Update_mask = new TmachineprotobufFieldMask
            {
                Paths = ["status"]
            }
        };

        return updateRequest;
    }
}