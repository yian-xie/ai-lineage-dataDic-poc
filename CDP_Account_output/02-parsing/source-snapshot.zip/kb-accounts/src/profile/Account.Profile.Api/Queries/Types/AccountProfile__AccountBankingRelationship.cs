﻿using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__AccountBankingRelationship")]
public class AccountProfile__AccountBankingRelationship
{
    [GraphQLName("bankingRelationshipId")] public string BankingRelationshipId { get; set; }

    [GraphQLName("bankingRelationshipType")]
    public string BankingRelationshipType { get; set; }

    [GraphQLName("nominatedTaxPartyId")] public string NominatedTaxPartyId { get; set; }

    [GraphQLName("partyIds")] public string[] PartyIds { get; set; }
}