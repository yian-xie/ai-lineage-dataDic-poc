﻿namespace Account.Transaction.Api.CardsClient.Configuration;

/// <summary>
/// Configuration settings for the cards service client, including API endpoint, request path, and timeout settings.
/// </summary>
public class CardsClientConfiguration
{
    /// <summary>
    /// The name of the configuration section in the appsettings file.
    /// </summary>
    public const string Key = "CardsClientOptions";

    /// <summary>
    /// The base URL of the cards service API.
    /// </summary>
    public string BaseUrl { get; set; } = string.Empty;

    /// <summary>
    /// The request path used for forming API requests.
    /// </summary>
    public string RequestPath { get; set; } = string.Empty;

    /// <summary>
    /// The duration in seconds before a timeout occurs if the API does not respond.
    /// </summary>
    public double TimeoutInSeconds { get; set; }
}