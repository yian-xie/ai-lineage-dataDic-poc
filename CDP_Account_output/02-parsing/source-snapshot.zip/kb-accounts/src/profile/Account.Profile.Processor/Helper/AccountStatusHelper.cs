﻿using System;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Profile.Processor.Helper;

public static class AccountStatusHelper
{
    /// <summary>
    ///     Get account profile Kiwibank/CDP account status enum from the string value.
    /// </summary>
    /// <param name="value">The String of Kiwibank/CDP status</param>
    public static AccountStatus AccountStatusFromString(string value)
    {
        return Enum.TryParse(value, out AccountStatus status)
            ? status
            : throw new NotSupportedException($"Unsupported account status: {value}");
    }

    /// <summary>
    ///     Get account profile Kiwibank/CDP account status from the TMV account status.
    /// </summary>
    /// <param name="value">The String of TMV Status</param>
    public static AccountStatus AccountStatusFromTmvStatusString(string value)
    {
        return Enum.TryParse(value, out V2accountsAccountStatus status)
            ? status switch
            {
                V2accountsAccountStatus.ACCOUNT_STATUS_CANCELLED => AccountStatus.Cancelled,
                V2accountsAccountStatus.ACCOUNT_STATUS_CLOSED => AccountStatus.Closed,
                V2accountsAccountStatus.ACCOUNT_STATUS_CLOSING => AccountStatus.Closing,
                V2accountsAccountStatus.ACCOUNT_STATUS_PENDING => AccountStatus.Pending,
                V2accountsAccountStatus.ACCOUNT_STATUS_OPEN => AccountStatus.Opened,
                V2accountsAccountStatus.ACCOUNT_STATUS_OPENING => AccountStatus.Opening,
                V2accountsAccountStatus.ACCOUNT_STATUS_PENDING_OPENING => AccountStatus
                    .PendingOpening,
                V2accountsAccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE => AccountStatus
                    .PendingClosure,
                V2accountsAccountStatus.ACCOUNT_STATUS_UNKNOWN => AccountStatus.Unknown,
                _ => throw new NotSupportedException($"Unsupported TMV account status: {value}")
                //_ => AccountStatus.Unknown
            }
            : throw new NotSupportedException($"Unsupported TMV account status: {value}");
        //: AccountStatus.Unknown;
    }

    /// <summary>
    ///     Get account profile TMV account status from the Kiwibank/CDP account status.
    /// </summary>
    /// <param name="value">The String of Kiwibank/CDP Status</param>
    public static string AccountStatusStringFromTmvStatusString(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return null;
        }
        return AccountStatusFromTmvStatusString(value).ToString();
    }

    /// <summary>
    ///     Get account profile TMV account status enum from the string value.
    /// </summary>
    /// <param name="value">The String of TMV status</param>
    public static V2accountsAccountStatus TmvAccountStatusFromString(string value)
    {
        return Enum.TryParse(value, out V2accountsAccountStatus status)
            ? status
            : throw new NotSupportedException($"Unsupported TMV account status: {value}");
    }

    /// <summary>
    ///     Get account profile TMV account status from the Kiwibank/CDP account status.
    /// </summary>
    /// <param name="value">The String of Kiwibank/CDP Status</param>
    public static V2accountsAccountStatus TmvAccountStatusFromStatusString(string value)
    {
        return Enum.TryParse(value, out AccountStatus status)
            ? status switch
            {
                AccountStatus.Cancelled => V2accountsAccountStatus.ACCOUNT_STATUS_CANCELLED,
                AccountStatus.Closed => V2accountsAccountStatus.ACCOUNT_STATUS_CLOSED,
                AccountStatus.Closing => V2accountsAccountStatus.ACCOUNT_STATUS_CLOSING,
                AccountStatus.Pending => V2accountsAccountStatus.ACCOUNT_STATUS_PENDING,
                AccountStatus.Opened => V2accountsAccountStatus.ACCOUNT_STATUS_OPEN,
                AccountStatus.Frozen => V2accountsAccountStatus.ACCOUNT_STATUS_OPEN,
                AccountStatus.Opening => V2accountsAccountStatus.ACCOUNT_STATUS_OPENING,
                AccountStatus.PendingOpening => V2accountsAccountStatus
                    .ACCOUNT_STATUS_PENDING_OPENING,
                AccountStatus.PendingClosure => V2accountsAccountStatus
                    .ACCOUNT_STATUS_PENDING_CLOSURE,
                AccountStatus.Unknown => V2accountsAccountStatus.ACCOUNT_STATUS_UNKNOWN,
                //_ => V2accountsAccountStatus.ACCOUNT_STATUS_UNKNOWN
                _ => throw new NotSupportedException($"Unsupported account status: {value}")
            }
            : throw new NotSupportedException($"Unsupported account status: {value}");
        //: V2accountsAccountStatus.ACCOUNT_STATUS_UNKNOWN;
    }

    /// <summary>
    ///     Get account profile TMV account status from the Kiwibank/CDP account status.
    /// </summary>
    /// <param name="value">The String of Kiwibank/CDP Status</param>
    public static string TmvAccountStatusStringFromStatusString(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return null;
        }
        return TmvAccountStatusFromStatusString(value).ToString();
    }

    /// <summary>
    ///     Returns true if the specified TMV account status string represents a state that occurs before an account is fully opened.
    /// </summary>
    /// <param name="value">The String of TMV Status</param>
    public static bool IsTmvAccountStatusPreOpen(string value)
    {
        return value is nameof(V2accountsAccountStatus.ACCOUNT_STATUS_PENDING)
            or nameof(V2accountsAccountStatus.ACCOUNT_STATUS_OPENING)
            or nameof(V2accountsAccountStatus.ACCOUNT_STATUS_PENDING_OPENING)
            or nameof(V2accountsAccountStatus.ACCOUNT_STATUS_UNKNOWN);
    }

    /// <summary>
    ///     Returns true if the specified TMV account status string represents a state that occurs after (or instead of) an account is fully opened.
    /// </summary>
    /// <param name="value">The String of TMV Status</param>
    public static bool IsTmvAccountStatusPostOpen(string value)
    {
        return value is nameof(V2accountsAccountStatus.ACCOUNT_STATUS_CANCELLED)
            or nameof(V2accountsAccountStatus.ACCOUNT_STATUS_CLOSING)
            or nameof(V2accountsAccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE)
            or nameof(V2accountsAccountStatus.ACCOUNT_STATUS_CLOSED);
    }
}