# Account Domain

Maintains the customer’s bank accounts (establishment, details and balances). The domain currently provides required information to be displayed in the Customer Portal web app.

It also maintains core banking customer and account create and update functionality.

Thought Machine Vault (tmv) is the core banking system this domain currently communicates with.
