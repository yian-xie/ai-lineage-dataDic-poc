﻿using System.Net;

namespace Account.Transaction.Api.Queries.Exceptions;

/// <summary>
/// Request validation exception for invalid transaction requests.
/// </summary>
public class RequestValidationException : TransactionExceptionBase
{
    /// <summary>
    /// Request validation exception constructor
    /// </summary>
    /// <param name="message">The error message</param>
    public RequestValidationException(string message) : base(message) { }

    /// <summary>
    /// Request validation exception constructor with status code
    /// </summary>
    /// <param name="message">The error message</param>
    /// <param name="statusCode"><see cref="HttpStatusCode"/></param>
    public RequestValidationException(string message, HttpStatusCode statusCode) : base(message, statusCode) { }
}