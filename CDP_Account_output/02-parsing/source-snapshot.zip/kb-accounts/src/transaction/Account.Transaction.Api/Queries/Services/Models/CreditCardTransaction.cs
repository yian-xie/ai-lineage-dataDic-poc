﻿namespace Account.Transaction.Api.Queries.Services.Models;

/// <summary>
/// Credit Card Transaction details
/// </summary>
/// <param name="MaskedCardNumber">Masked account number</param>
/// <param name="TransactionDescription">Transaction description</param>
/// <param name="TransactionAmount">Transaction amount in NZ dollars</param>
/// <param name="PurchasingDate">Purchasing date time</param>
/// <param name="PostedDate">Posted date. Optional. Won't show for authorisation transactions</param>
/// <param name="OriginalAmountDetails">Original amount details. Optional. Holds foreign currency and original currency price for international transactions. Won't show for authorisation transaction.</param>
public record CreditCardTransaction(string MaskedCardNumber, string TransactionDescription, decimal TransactionAmount, string PurchasingDate, string? PostedDate, string? OriginalAmountDetails);