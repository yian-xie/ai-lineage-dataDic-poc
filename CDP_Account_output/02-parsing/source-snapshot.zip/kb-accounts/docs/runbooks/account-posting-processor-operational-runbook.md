## Service Summary

| Field | Details |
|---|---|
| Business purpose | Consume TMV posting-instruction-batch events, persist each batch for de-duplication, and emit committed account postings to ESP through Kafka. |
| Runtime | .NET 10 ASP.NET Core Linux service; continuous Kafka event consumer with PostgreSQL-backed outbox, deployed to Kubernetes as `accounts-posting-processor` |
| Source | `src/posting/Account.Posting.Processor` |
| Pipeline | `src/posting/.pipelineconfig/pipeline.yaml`; image Dockerfile `src/posting/.pipelineconfig/account-posting-processor/Dockerfile`; Helm values `src/posting/Deploy/Account.Posting.Processor/` |
| Last reviewed | 2026-09-30 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. Continuously consume `vault.api.v1.postings.posting_instruction_batch.created` from the configured TMV Kafka cluster and check PostgreSQL for the batch ID.
2. In one database transaction, persist the source payload in `tmv_positing_batch`; for accepted batches, transform committed postings and enqueue `prod.account.posting.v1.event` in the outbox.
3. Commit the transaction and let the hosted outbox service publish to the enterprise Kafka topic; duplicate batch IDs are skipped and processing failures are redelivered after five seconds.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Inbound Kafka | TMV Kafka: `vault.api.v1.postings.posting_instruction_batch.created` | Source posting batches; OAuth cluster is primary in non-production, while production explicitly selects the plain SSL cluster | `Consumers__DefaultConsumers`, `KafkaClusters__TMVKafka`, `KafkaClusters__TMVKafkaOAuth` |
| Data store | PostgreSQL account posting database | De-duplication table and transactional Kafka outbox | `ConnectionStrings__DefaultConnection`; `AccountPostingDbContext` |
| Outbound Kafka | Confluent Kafka and schema registry:  `prod.account.posting.v1.event` | Publish committed account postings for downstream consumers | `Kafka__BootstrapServers`, `Kafka__OutgoingTopicPrefix`, `Kafka__SchemaRegistry` |
| Observability | Dynatrace and Sumo Logic | Metrics, traces, workload/DB status, SLOs, and processing-failure ingestion | `MetricsOptions__*`, `TracingOptions__*`, `SumoLogicIngestion__*` |

### Interfaces and Schedule

- Service type: Kafka event consumer and producer with a background outbox publisher. It has no schedule and runs continuously.
- Production consumer group: `cg_tmv_accounts_account_posting_prod`.
- Only accepted TMV posting batches produce output events. Other statuses are persisted and acknowledged without output.
- No business API route is defined. Kubernetes probes target pod port `8080` at `/health/readiness` and `/health/liveness`.
- Laptop reachability: the repository defines pod probes and an internal service but no ingress or developer access procedure, so direct laptop reachability is not established. [TODO: confirm the exact probe URLs, authentication behavior, namespace mapping, and approved production port-forward procedure.]

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| `ENVIRONMENT`, `TENANT` | Select runtime environment and tenant | Values define `accept`, `situat`, `perf0`, `preprod`, and `prod`; tenant is `accounts_code_account` |
| `ConnectionStrings__DefaultConnection` | Connect to the account posting PostgreSQL database | Pipeline maps `situat_account_v2_posting`, `preprod_account_v2_posting`, and `prod_account_v2_posting`; perf0 derives `perf0_account_v2_posting` |
| `Kafka__*` | Enterprise Kafka producer, topic prefixes, and schema registry | Environment values define bootstrap server, incoming/outgoing prefix, SASL, and schema-registry keys |
| `KafkaClusters__TMVKafka*` | TMV source brokers and OAuth settings | Non-production configures OAuth client ID/scope and secret key; production sets the OAuth URL empty and selects `TMVKafka` |
| `Consumers__DefaultConsumers__0__GroupId` | Isolate offsets by environment | Uses the environment-specific `cg_tmv_accounts_account_posting_*` group listed above |
| `Retry__RedeliveryInterval` | Delay before failed input is delivered again | `00:00:05` in `appsettings.json` |
| `SumoLogicIngestion__*` | Send a secondary failure record to the environment source category | API token is supplied by secret; categories are environment-specific |
| Replica and probe settings | Maintain workload availability | Three replicas by default, maximum one unavailable; accept overrides to two replicas; readiness/liveness run every five seconds |

Secret keys used by deployment include `kafka_key`, `kafka_secret`, `kafka_schema_key`, `kafka_schema_secret`, environment-specific `account_posting_processor_tmv_kafka_client_secret*`, `dynatrace_api_key`, and `sumo_logic_ingestion_monitoring_logs_api_key*`.


</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| Readiness `/health/readiness` and liveness `/health/liveness` on pod port `8080` | Probes pass across the desired replica count | Any probe fails for three consecutive five-second periods, pods are not ready, or restarts increase |
| Kafka success and exception metrics | `cip.<environment>.accounts-posting-processor.kafka-event-success-requests.count` increases with input; exceptions and redeliveries remain at normal levels | Success stops while TMV publishes, or exception/redelivery counts rise; [TODO: confirm alert thresholds and acceptable quiet periods] |
| Processing logs | Each completed batch logs `Successfully processed Posting Instruction Batch (PIB) for batchId:` | Repeated `Failed to process PIB create Event with batch Id:` or Sumo ingestion failures appear |
| Database signals | Connection failures remain absent and database call latency is stable | `builtin:service.dbconnections.failureRate` rises or database child-call time increases |
| Workload and SLOs | Desired/running containers match; repository-linked alerts use availability `99.85%`, latency `95%`, and success rate `99.9%` thresholds | A linked SLO alert fires, capacity drops, or container restarts increase |

Observability: 
- [Account Posting Processor Observability Dashboard (confluence)](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5476974966/Account+Posting+Processor+Observability+Dashboard)
- [Account Posting Processor Observability Dashboard (dynatrace)](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all)
- [Sumo Logic Library](https://kbprod.au.sumologic.com/library/41624834)

The repository does not define an exact cluster host, authentication requirement, or laptop access path. [TODO: confirm a copyable production `GET` request for each health endpoint, its expected status/body, and the required VPN/cluster setup]

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the `accounts-posting` pipeline builds `accounts/account/account-posting-processor` from `src/posting/.pipelineconfig/account-posting-processor/Dockerfile` and uses the intended environment files under `src/posting/Deploy/Account.Posting.Processor/`.
2. Require the Docker build's unit/mutation/coverage stage and `post-build.sh` processor integration tests to pass. Before production promotion, require the pipeline's `situat` and `preprod` system integration tests and account posting database migrations to pass.

### After Deployment

1. In the [Account Posting Processor Observability Dashboard](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all), confirm desired/running pods match, probes pass, and container restarts, service failure rate, and DB connection failures do not increase.
2. Confirm Kafka total and success request counts resume in the deployed environment, and exception/redelivery counts remain normal.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

The repository pipeline deploys immutable image tag `$UNIQUE_TAG` with environment-specific Helm values. Prefer fix-forward for configuration/schema defects when consumer state and the outbox must be preserved. [TODO: confirm the approved pipeline rollback procedure, who may invoke it, and how database migrations are handled during rollback]

[TODO: confirm service recovery-time and recovery-point objectives]

### Recovery Validation

1. Verify desired replicas and both Kubernetes probes are healthy, database connection failures stop, and Kafka exception/redelivery metrics return to normal.
2. Verify that `prod.account.posting.v1.event` events are being published.

Operational guardrail: Never manually alter consumer offsets, `tmv_positing_batch`, or `outbox` records without an approved recovery procedure; the database transaction provides de-duplication and atomic outbox enqueueing.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Kiwibank/kb-accounts](https://github.com/Kiwibank/kb-accounts) |
| Dashboards and logs | <ul><li>[Account Posting Processor Observability Dashboard (confluence)](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5476974966/Account+Posting+Processor+Observability+Dashboard)</li><li>[Account Posting Processor Observability Dashboard (dynatrace)](https://xye92727.live.dynatrace.com/#dashboard;id=42634162-3ade-47bd-8fbf-691e30fb4f2e;gtf=-24h%20to%20now;gf=all)</li><li>[Sumo Logic Library](https://kbprod.au.sumologic.com/library/41624834)</li></ul> |
