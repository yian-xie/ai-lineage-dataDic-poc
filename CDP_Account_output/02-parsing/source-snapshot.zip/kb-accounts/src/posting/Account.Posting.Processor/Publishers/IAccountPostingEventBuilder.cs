﻿using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using AsyncAPI = Api.Shared.Clients.Events.Kiwibank.V1.AccountPostings;

namespace Account.Posting.Processor.Publishers;

public interface IAccountPostingEventBuilder
{
    /// <summary>
    ///     Build AccountProfileEvent.
    /// </summary>
    /// <param name="postingBatchEvent">
    ///     <see cref="PostingBatchEvent" />
    /// </param>
    /// <returns>
    ///     <see cref="AsyncAPI.AccountPostingEvent" />
    /// </returns>
    public AsyncAPI.AccountPostingEvent BuildEvent(PostingBatchEvent postingBatchEvent);
}