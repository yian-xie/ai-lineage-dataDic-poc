﻿using System;

namespace Account.Shared.Entities;

public class AccountBaseEntity
{
    /// <summary>
    ///     GUID
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    ///     Created DateTime.
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    ///     Modified DateTime.
    /// </summary>
    public DateTimeOffset? ModifiedAt { get; set; }
}