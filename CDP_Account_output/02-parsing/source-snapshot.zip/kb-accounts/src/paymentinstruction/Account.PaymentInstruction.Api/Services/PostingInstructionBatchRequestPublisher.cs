﻿using System.Threading;
using System.Threading.Tasks;

using Account.Shared.Kafka.Produce;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchRequest;

using Microsoft.Extensions.Options;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     Publisher that publish <see cref="PostingInstructionBatchRequest" /> to TMV Kafka
/// </summary>
public class PostingInstructionBatchRequestPublisher : IPostingInstructionBatchRequestPublisher
{
    private readonly string _clientId;
    private readonly IPostingInstructionModelTranslator _postingInstructionModelTranslator;
    private readonly ITmvEventPublisher<PostingInstructionBatchRequest> _tmvPublisher;

    public PostingInstructionBatchRequestPublisher(
        ITmvEventPublisher<PostingInstructionBatchRequest> tmvEventPublisher,
        IPostingInstructionModelTranslator postingInstructionModelTranslator,
        IOptions<PaymentInstructionSettings> paymentInstructionSettings)
    {
        _tmvPublisher = tmvEventPublisher;
        _postingInstructionModelTranslator = postingInstructionModelTranslator;
        _clientId = paymentInstructionSettings.Value.ClientId;
    }

    /// <summary>
    ///     Publish <see cref="PostingInstructionBatchRequest" /> to TMV Kafka
    /// </summary>
    /// <param name="input">
    ///     <see cref="PaymentInstructionRequestInput" />
    /// </param>
    /// <param name="clientBatchId">Client Batch id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    public async Task PublishAsync(
        PaymentInstructionRequestInput input,
        string clientBatchId,
        CancellationToken cancellationToken)
    {
        var request = _postingInstructionModelTranslator
            .Translate(input, _clientId, clientBatchId);
        await _tmvPublisher.PublishAsync(request, cancellationToken);
    }
}