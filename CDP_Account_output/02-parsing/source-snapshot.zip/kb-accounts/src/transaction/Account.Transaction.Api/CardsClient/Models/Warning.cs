﻿namespace Account.Transaction.Api.CardsClient.Models;
/// <summary>
/// Holds a Message/Code combination returned by the Cards Transactions API when a partial success occurs.
/// Will contain messages about failures to retrieve SXT (posted) or AUE (authorised) transactions.
/// </summary>
/// <param name="Message">warning message</param>
/// <param name="Code">warning code</param>
public record Warning(string Message, string Code);