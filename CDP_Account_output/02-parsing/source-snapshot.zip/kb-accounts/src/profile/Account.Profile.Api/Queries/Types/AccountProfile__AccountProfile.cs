﻿using System;

using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__AccountProfile")]
public class AccountProfile__AccountProfile
{
    [GraphQLName("accountId")] public string AccountId { get; set; }

    [GraphQLName("accountCreatedUserId")] public string AccountCreatedUserId { get; set; }

    [GraphQLName("accountOrganisationUnitId")] public string AccountOrganisationUnitId { get; set; }

    [GraphQLName("createdDateTime")] public DateTimeOffset CreatedDateTime { get; set; }

    [GraphQLName("accountStatus")] public string AccountStatus { get; set; }

    [GraphQLName("openedDateTime")] public DateTimeOffset? OpenedDateTime { get; set; }

    [GraphQLName("closedDateTime")] public DateTimeOffset? ClosedDateTime { get; set; }

    [GraphQLName("minimumNumberOfAuthoriser")] public string? MinimumNumberOfAuthoriser { get; set; }

    [GraphQLName("productFacilities")]
    public AccountProfile__ProductFacility ProductFacilities { get; set; }

    [GraphQLName("bankingRelationship")]
    public AccountProfile__AccountBankingRelationship BankingRelationship { get; set; }

    [GraphQLName("accountCurrencies")]
    public AccountProfile__AccountCurrency[] AccountCurrencies { get; set; }

    [GraphQLName("accountIdentifications")]
    public AccountProfile__AccountIdentification[] AccountIdentifications { get; set; }

    [GraphQLName("accountName")] public string AccountName { get; set; }

    [GraphQLName("alternateName")] public string? AlternateName { get; set; }

    [GraphQLName("accountClosureReason")] public string? AccountClosureReason { get; set; }

    [GraphQLName("freezeType")] public string? FreezeType { get; set; }

    [GraphQLName("freezeDescription")] public string? FreezeDescription { get; set; }

    [GraphQLName("frozenDateTime")] public DateTimeOffset? FrozenDateTime { get; set; }

    [GraphQLName("tside")] public string Tside { get; set; }

    [GraphQLName("accountIdLocation")] public string AccountIdLocation { get; set; }

    [GraphQLDeprecated("WithholdingTax will be deprecated. Use DomesticTaxRate instead.")]
    [GraphQLName("withholdingTax")]
    public AccountProfile__WithholdingTax? WithholdingTax { get; set; }

    [GraphQLName("domesticTaxRate")]
    public AccountProfile__DomesticTaxRate DomesticTaxRate { get; set; }
}