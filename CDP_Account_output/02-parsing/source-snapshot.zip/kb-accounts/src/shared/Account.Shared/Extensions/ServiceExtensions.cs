﻿using System;

using Account.Shared.Services;

using Api.Shared.Clients.Rest.SumoLogic;
using Api.Shared.Clients.Rest.SumoLogic.V1.SumoLogicIngestionManual;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Shared.Extensions;

public static class ServiceExtensions
{
    public static IServiceCollection AddAlertingServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services
            .AddHttpClient<ISumoLogicClient, SumoLogicClient>(SumoLogicClientUtils.Configure);

        var sumoLogicSettings = configuration.GetSection(SumoLogicSettings.Key).Get<SumoLogicSettings>()
            ?? throw new InvalidOperationException($"Missing required configuration section: {SumoLogicSettings.Key}");

        return services
            .AddSingleton(sumoLogicSettings)
            .AddSingleton<ISumoLogicClientHelper, SumoLogicClientHelper>();
    }
}