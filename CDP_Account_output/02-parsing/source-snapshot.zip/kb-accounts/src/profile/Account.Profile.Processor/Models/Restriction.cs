﻿using System;

using Account.Profile.Processor.Services;

using Api.Shared.Clients.Events.ThoughtMachine.V1.RestrictionSet;

namespace Account.Profile.Processor.Models;

public record Restriction(
    string EventId,
    int? ChangeId,
    Restriction_set RestrictionSet,
    DateTimeOffset? Time,
    RestrictionType Type,
    byte[] Payload);