# Account Opening States (Target Design)

This document describes the **target state machine design** for `AccountOpening` after code refactoring. This represents the desired end state with an explicit `State` enum.

> **Note:** This is a design target document. See [AccountOpeningStateMachine-CurrentAndMigration.md](./AccountOpeningStateMachine-CurrentAndMigration.md) for the current implementation and migration guide.

## Overview

The target design uses an explicit `AccountOpeningState` enum instead of inferring state from column combinations. This provides clarity, type safety, and simpler query logic.

## Entity Design

### AccountOpening Entity

```csharp
public enum AccountOpeningState
{
    PendingNumberAllocation,  // For SV1 products awaiting account number
    Initial,                  // Awaiting account creation in TMV
    Created,                  // Account created in TMV, awaiting opening
    Opened,                   // Account successfully opened (terminal state)
    Failed                    // Account opening failed (terminal state)
}

public class AccountOpening
{
    public required AccountOpeningState State { get; set; }
    
    // Audit timestamps (no longer used for state inference)
    public DateTimeOffset? Created { get; set; }
    public DateTimeOffset? Opened { get; set; }
    public DateTimeOffset? Failed { get; set; }
    
    // Retry metadata
    public int RetryCount { get; set; }
    public DateTimeOffset? LastRetry { get; set; }
    
    // Other properties...
    public required string AccountId { get; set; }
    public DateTimeOffset ScheduledOpen { get; set; }
    public DateTimeOffset ValidUntil { get; set; }
    public string? AccountNumber { get; set; }
    public string? ProductCode { get; set; }
    // ...
}
```

## State Definitions

### 1. Initial

**Enum Value:** `AccountOpeningState.Initial`

**Description:**
The single entry point for all account opening requests. `TmvAccountCreationJob` processes this state and either creates the account directly or, for SV1 products without an account number, transitions to `PendingNumberAllocation`.

**Entry Conditions:**
- New account opening request created (all products)

**Processed By:** `TmvAccountCreationJob`

**Possible Transitions:**
- → `PendingNumberAllocation` - When SV1 account has no `AccountNumber` yet
- → `Created` - When account successfully created in TMV with `ACCOUNT_STATUS_PENDING`
- → `Opened` - When account already exists in TMV with `ACCOUNT_STATUS_OPEN` (edge case)
- → `Failed` - When `ValidUntil` expired

**Retry Behavior:** Can have `RetryCount > 0` for failed creation attempts

---

### 2. PendingNumberAllocation

**Enum Value:** `AccountOpeningState.PendingNumberAllocation`

**Description:**
An intermediate state for SV1 products. Entered when `TmvAccountCreationJob` detects an `Initial` SV1 record without an account number. Once a number is allocated, the record transitions back to `Initial` so the creation job can proceed.

**Entry Conditions:**
- Transitioned from `Initial` when `ProductCode == "SV1"` and `AccountNumber == null`

**Processed By:** `TmvAccountNumberAllocationJob`

**Possible Transitions:**
- → `Initial` - When account number successfully allocated (back for creation)
- → `Failed` - When `ValidUntil` expired

**Retry Behavior:** Can have `RetryCount > 0` for failed allocation attempts

---

### 3. Created

**Enum Value:** `AccountOpeningState.Created`

**Description:**
Account has been created in TMV with status `ACCOUNT_STATUS_PENDING`. Awaiting the scheduled opening time.

**Entry Conditions:**
- Transitioned from `Initial` after successful TMV account creation

**Processed By:** `TmvAccountOpeningJob`

**Possible Transitions:**
- → `Opened` - When account successfully opened in TMV (status changed to `ACCOUNT_STATUS_OPEN`)
- → `Failed` - When `ValidUntil` expired

**Processing Condition:** Only processed when `ScheduledOpen <= now`

**Retry Behavior:** Can have `RetryCount > 0` for failed opening attempts

---

### 4. Opened

**Enum Value:** `AccountOpeningState.Opened`

**Description:**
Terminal success state. The account has been successfully opened in TMV with status `ACCOUNT_STATUS_OPEN`.

**Entry Conditions:**
- Transitioned from `Created` (or rarely `Initial`) after successful opening in TMV

**Processed By:** No job (terminal state)

**Possible Transitions:** None (terminal state)

---

### 5. Failed

**Enum Value:** `AccountOpeningState.Failed`

**Description:**
Terminal failure state. The account opening has permanently failed, typically because `ValidUntil` expired before completion.

**Entry Conditions:**
- Transitioned from any non-terminal state when `ValidUntil` expired

**Processed By:** No job (terminal state)

**Possible Transitions:** None (terminal state)

**Event:** Failure event published to `account.profile.v1.event` topic

---

## State Transitions

```mermaid
stateDiagram-v2
    [*] --> Initial: Account Opening Created

    Initial --> PendingNumberAllocation: SV1 without AccountNumber
    Initial --> Created: Account Created
    Initial --> Initial: Retry (creation failed)
    Initial --> Opened: Already Opened in TMV
    Initial --> Failed: ValidUntil Expired

    PendingNumberAllocation --> Initial: Number Allocated
    PendingNumberAllocation --> PendingNumberAllocation: Retry (allocation failed)
    PendingNumberAllocation --> Failed: ValidUntil Expired
    
    Created --> Opened: Account Opened
    Created --> Created: Retry (opening failed)
    Created --> Failed: ValidUntil Expired
    
    Opened --> [*]: Success
    Failed --> [*]: Permanent Failure
```

**Note:** Self-transitions (e.g., `Initial --> Initial`) represent retries where `RetryCount` is incremented but the state remains unchanged.

## Retry Behavior

Retry behavior is a cross-cutting concern that applies to all non-terminal states (PendingNumberAllocation, Initial, and Created). It is not a separate state but rather a property of the current state.

**Retry Metadata:**
- `RetryCount` (int) - Number of retry attempts (0 means no retries yet)
- `LastRetry` (DateTimeOffset?) - Timestamp of the last retry attempt

**Retry Logic:**
- Jobs will retry after a configured retry interval (typically configured in `AccountOriginationJobOptions`)
- Retry queries check: `RetryCount == 0 OR (LastRetry.HasValue && LastRetry <= retryTimeThreshold)`
- Records are ordered by `RetryCount` (ascending), then `ScheduledOpen`, then `AccountId`
- Retries continue until success or `ValidUntil` expires

**Common Retry Causes:**
- Customer not found in TMV (customer creation is attempted)
- TMV service exceptions
- Network issues (handled by Polly resilience policies)
- Account number allocation failures (SV1 only)

**Retry Process:**
1. `RetryCount` is incremented
2. `LastRetry` is updated to current timestamp
3. The record remains in its current state (PendingNumberAllocation, Initial, or Created)
4. The job will pick it up again after the retry interval has elapsed

**Expiration:**
- When `ValidUntil` is reached and the account is still not opened, the state transitions to `Failed`
- This prevents indefinite retry loops for records that cannot succeed

## State Transition Details

### From Initial

**SV1 Blocking Path:**
- `TmvAccountCreationJob` detects `ProductCode == SV1` and `AccountNumber == null`
- State transitions to `PendingNumberAllocation`
- No TMV call is made

**Success Path:**
- Account is successfully created in TMV with `ACCOUNT_STATUS_PENDING`
- `Created` timestamp is set
- State transitions to `Created`

**Alternative Success Path:**
- In rare cases, account may already be opened in TMV (edge case handling)
- State transitions directly to `Opened`
- `Opened` timestamp is set

**Retry Path:**
- Account creation fails (e.g., TMV unavailable, customer not found)
- If customer not found, attempt to create customer first
- `RetryCount` incremented, `LastRetry` updated
- State remains `Initial`
- Job will retry after the retry interval

**Failure Path:**
- `ValidUntil` expires before successful creation
- State transitions to `Failed`
- `Failed` timestamp is set

### From PendingNumberAllocation

**Success Path:**
- Account number is successfully allocated from TMV
- `AccountNumber` field is populated
- State transitions back to `Initial` for creation to proceed

**Retry Path:**
- Number allocation fails (e.g., TMV unavailable, allocation service error)
- `RetryCount` incremented, `LastRetry` updated
- State remains `PendingNumberAllocation`
- Job will retry after the retry interval

**Failure Path:**
- `ValidUntil` expires before successful allocation
- State transitions to `Failed`
- `Failed` timestamp is set

### From Created

**Success Path:**
- `ScheduledOpen` time is reached
- Account status is successfully changed in TMV from `ACCOUNT_STATUS_PENDING` to `ACCOUNT_STATUS_OPEN`
- `Opened` timestamp is set
- State transitions to `Opened`

**Retry Path:**
- Account opening fails (e.g., TMV unavailable, validation error)
- `RetryCount` incremented, `LastRetry` updated
- State remains `Created`
- Job will retry after the retry interval (but only after `ScheduledOpen` is reached)

**Failure Path:**
- `ValidUntil` expires before successful opening
- State transitions to `Failed`
- `Failed` timestamp is set

## Job Queries

### TmvAccountNumberAllocationJob Query

```csharp
Where(x => x.State == AccountOpeningState.PendingNumberAllocation)
Where(x => x.RetryCount == 0 || 
           (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
OrderBy(x => x.RetryCount)
ThenBy(x => x.ScheduledOpen)
ThenBy(x => x.AccountId)
```

### TmvAccountCreationJob Query

```csharp
Where(x => x.State == AccountOpeningState.Initial)
Where(x => x.RetryCount == 0 || 
           (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
OrderBy(x => x.RetryCount)
ThenBy(x => x.ScheduledOpen)
ThenBy(x => x.AccountId)
```

### TmvAccountOpeningJob Query

```csharp
Where(x => x.State == AccountOpeningState.Created)
Where(x => x.ScheduledOpen <= now)
Where(x => x.RetryCount == 0 || 
           (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
OrderBy(x => x.RetryCount)
ThenBy(x => x.ScheduledOpen)
ThenBy(x => x.AccountId)
```

## State Transition Logic

### In TmvAccountCreationJob

```csharp
// SV1 without AccountNumber: transition to PendingNumberAllocation
var prerequisiteState = tmvAccountAction.GetPrerequisiteState(accountOpening);
if (prerequisiteState.HasValue)
{
    accountOpening.State = prerequisiteState.Value; // PendingNumberAllocation
    return null;
}

// Success case
accountOpening.Created = timeProvider.GetUtcNow();
accountOpening.State = AccountOpeningState.Created;

// Already opened case
if (tmvAccount.Status == ACCOUNT_STATUS_OPEN)
{
    accountOpening.State = AccountOpeningState.Opened;
    accountOpening.Opened = tmvAccount.Opening_timestamp;
}

// Retry case
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains Initial

// Failure case
if (timeProvider.GetUtcNow() > accountOpening.ValidUntil)
{
    accountOpening.State = AccountOpeningState.Failed;
    accountOpening.Failed = timeProvider.GetUtcNow();
}
```

### In TmvAccountNumberAllocationJob

```csharp
// Success case: transition back to Initial for creation
accountOpening.AccountNumber = allocatedNumber;
accountOpening.State = AccountOpeningState.Initial;

// Retry case
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains PendingNumberAllocation

// Failure case
if (timeProvider.GetUtcNow() > accountOpening.ValidUntil)
{
    accountOpening.State = AccountOpeningState.Failed;
    accountOpening.Failed = timeProvider.GetUtcNow();
}
```

### In TmvAccountOpeningJob

```csharp
// Success case
accountOpening.Opened = tmvAccount.Opening_timestamp;
accountOpening.State = AccountOpeningState.Opened;

// Retry case
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains Created

// Failure case
if (timeProvider.GetUtcNow() > accountOpening.ValidUntil)
{
    accountOpening.State = AccountOpeningState.Failed;
    accountOpening.Failed = timeProvider.GetUtcNow();
}
```

## Benefits of This Design

### 1. Clarity and Maintainability
- **Explicit state**: No need to infer state from multiple column combinations
- **Single source of truth**: `State` column clearly indicates current status
- **Easier debugging**: State is immediately visible in database queries and logs

### 2. Simpler Queries
- Jobs query by explicit state value instead of complex column combinations
- Reduced risk of query bugs from missing conditions
- More efficient database indexes on enum column

### 3. Better Type Safety
- Compile-time checking of state values
- IDE autocomplete for state transitions
- Easier to add new states in the future

### 4. Improved Observability
- State transitions can be easily tracked and logged
- Metrics can be collected per state
- Dashboards can show state distribution

### 5. Audit Trail Preservation
- Timestamp columns (`Created`, `Opened`, `Failed`) retained for audit purposes
- Clear separation between state and metadata
- Historical data remains queryable

## Related Documentation

- [Current Implementation & Migration Guide](./AccountOpeningStateMachine-CurrentAndMigration.md) - Current implicit state machine and refactoring instructions
- [Account Origination Job README](../../../src/origination/Account.Origination.Job/README.md)
- [State Diagram (PlantUML)](./account.origination.state.plantuml)
