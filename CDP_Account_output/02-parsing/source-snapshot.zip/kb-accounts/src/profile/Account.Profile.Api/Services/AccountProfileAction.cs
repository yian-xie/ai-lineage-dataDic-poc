﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Api.Queries.Types;
using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Repositories;
using Account.Shared.Constants;

using AccountProfile__AccountBankingRelationship =
    Account.Profile.Api.Queries.Types.AccountProfile__AccountBankingRelationship;
using AccountProfile__AccountCurrency =
    Account.Profile.Api.Queries.Types.AccountProfile__AccountCurrency;
using AccountProfile__AccountIdentification =
    Account.Profile.Api.Queries.Types.AccountProfile__AccountIdentification;
using AccountProfile__AccountProfile =
    Account.Profile.Api.Queries.Types.AccountProfile__AccountProfile;
using AccountProfile__ProductFacility =
    Account.Profile.Api.Queries.Types.AccountProfile__ProductFacility;

namespace Account.Profile.Api.Services;

/// <summary>
///     Implemented <see cref="IAccountProfileAction" /> to query the <see cref="AccountProfile" /> entity from
///     profile.account_profile table and map the entity to Graphql <see cref="AccountProfile__AccountProfile" />.
/// </summary>
public class AccountProfileAction(IRepositoryFactory repositoryFactory)
    : IAccountProfileAction
{
    private const string AccountIdLocation = "TMV";

    /// <summary>
    ///     Get account profiles by  account ids
    /// </summary>
    /// <param name="accountIds">Account ids</param>
    /// <param name="auditLogDataProvider"></param>
    /// <param name="isStaff">Flag indicating if the user is a staff member, not currently used</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     Account Profiles <see cref="AccountProfile__AccountProfile"/>
    /// </returns>
    public async Task<AccountProfile__AccountProfile[]> GetAccountProfilesByAccountIdsAsync(
        IReadOnlyCollection<string> accountIds,
        IProfileAuditLogDataProvider auditLogDataProvider,
        bool isStaff,
        CancellationToken cancellationToken)
    {
        var accountProfileEntities =
            await repositoryFactory.AccountProfileRepository.GetAccountsByAccountIdsAsync(
                accountIds,
                cancellationToken);

        auditLogDataProvider.AccountIds = accountProfileEntities.Select(x => x.AccountId).ToList();
        auditLogDataProvider.AccountNumbers = accountProfileEntities.SelectMany(x => x.Identifiers)
            .Where(x => x.AccountIdentificationType == "nzBankAccountNumber")
            .Select(x => x.AccountIdentification)
            .ToList();

        return accountProfileEntities.Select(profile => ToGraphql(profile, isStaff)).ToArray();
    }

    /// <summary>
    ///     Get account profile by account id
    /// </summary>
    /// <param name="accountId">Account id</param>
    /// <param name="auditLogDataProvider"></param>
    /// <param name="isStaff">Flag indicating if the user is a staff member, not currently used</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken"/>
    /// </param>
    /// <returns>
    ///     Account Profile <see cref="AccountProfile__AccountProfile"/>
    /// </returns>
    public async Task<AccountProfile__AccountProfile?> GetAccountProfileAsync(
        string accountId,
        IProfileAuditLogDataProvider auditLogDataProvider,
        bool isStaff,
        CancellationToken cancellationToken)
    {
        var profile =
            await repositoryFactory.AccountProfileRepository.GetAccountAsync(accountId,
                cancellationToken);

        if (profile is not null)
        {
            auditLogDataProvider.AccountIds = [profile.AccountId];
            var accountNumber = profile.Identifiers
                .FirstOrDefault(item => item.AccountIdentificationType == "nzBankAccountNumber");
            auditLogDataProvider.AccountNumbers =
                accountNumber is null ? [] : [accountNumber.AccountIdentification];

            return ToGraphql(profile, isStaff);
        }

        return null;
    }

    private static AccountProfile__AccountProfile ToGraphql(AccountProfile profile, bool isStaff)
    {
        // Hard coding here until finding out where this comes from
        const string currencyType = "AccountBaseCurrency";

        var identifiers = profile.Identifiers.Select(ToGraphql).ToArray();

        return new AccountProfile__AccountProfile
        {
            AccountId = profile.AccountId,
            AccountCreatedUserId = profile.AccountCreatedUserId ?? string.Empty,
            AccountOrganisationUnitId = profile.AccountOrganisationUnitId ?? string.Empty,
            MinimumNumberOfAuthoriser = profile.MinimumNumberOfAuthoriser,
            AccountStatus = profile.Status,
            AccountCurrencies = [
                new AccountProfile__AccountCurrency {
                    AccountCurrency = CurrencyCode.Nzd, AccountCurrencyType = currencyType
                }
            ],
            CreatedDateTime = profile.Created ?? DateTimeOffset.MinValue,
            OpenedDateTime = profile.Opened,
            ClosedDateTime = profile.Closed,
            AccountIdentifications = identifiers,
            AccountName = profile.Name,
            AlternateName = profile.AlternateName,
            AccountClosureReason = profile.AccountClosureReason,
            // Requirements change, display freeze details for all users, but leave the staff flag mechanism in place for the future.
            FreezeType = profile.AccountFreezeDetails.FreezeType,
            FreezeDescription = profile.AccountFreezeDetails.FreezeDescription,
            FrozenDateTime = profile.AccountFreezeDetails.Effective,
            //FreezeType = isStaff ? profile.AccountFreezeDetails.FreezeType : null,
            //FreezeDescription = isStaff ? profile.AccountFreezeDetails.FreezeDescription : null,
            //FrozenDateTime = isStaff ? profile.AccountFreezeDetails.Effective : null,
            Tside = profile.TSide,
            AccountIdLocation = AccountIdLocation,
            ProductFacilities = ToGraphql(profile.ProductFacility),
            BankingRelationship = ToGraphql(profile.BankingRelationship),
            WithholdingTax = WithholdingTaxToGraphql(profile.DomesticTaxRate.RateValue, profile.DomesticTaxRate.DomesticTaxType),
            DomesticTaxRate = ToGraphql(profile.DomesticTaxRate)
        };
    }

    private static AccountProfile__WithholdingTax WithholdingTaxToGraphql(string? rateValue, string? taxType)
    {
        return new AccountProfile__WithholdingTax
        {
            WithholdingTaxRate = rateValue ?? string.Empty,
            WithholdingTaxType = taxType ?? string.Empty
        };
    }

    private static AccountProfile__DomesticTaxRate ToGraphql(DomesticTaxRate domesticTaxRate)
    {
        return new AccountProfile__DomesticTaxRate
        {
            RateValue = domesticTaxRate.RateValue ?? string.Empty,
            DomesticTaxType = domesticTaxRate.DomesticTaxType ?? string.Empty,
            CountryAlpha3Code = domesticTaxRate.CountryAlpha3Code ?? string.Empty
        };
    }

    private static AccountProfile__ProductFacility ToGraphql(
        AccountProfileProductFacility profileProductFacility)
    {
        return new AccountProfile__ProductFacility
        {
            ProductFacilityId = profileProductFacility.ProductFacilityId ?? string.Empty,
            BankingProductId = profileProductFacility.BankingProductId ?? string.Empty,
            BankingProductVersionId =
                profileProductFacility.BankingProductVersionId ?? string.Empty,
            BankingProductCode = profileProductFacility.BankingProductCode ?? string.Empty,
            InterestArrangement = new AccountProfile__ProductFacility__InterestArrangement
            {
                Rate = profileProductFacility.InterestRate,
                ValidFrom = profileProductFacility.InterestRateValidFrom,
                RatePlanChangeId = profileProductFacility.InterestRatePlanChangeId
            }
        };
    }

    private static AccountProfile__AccountBankingRelationship ToGraphql(
        AccountBankingRelationship accountBankingRelationship)
    {
        return new AccountProfile__AccountBankingRelationship
        {
            BankingRelationshipId =
                accountBankingRelationship.BankingRelationshipId ?? string.Empty,
            BankingRelationshipType =
                accountBankingRelationship.BankingRelationshipType ?? string.Empty,
            NominatedTaxPartyId = accountBankingRelationship.NominatedTaxPartyId ?? string.Empty,
            PartyIds = accountBankingRelationship.PartyIds.ToArray()
        };
    }

    private static AccountProfile__AccountIdentification ToGraphql(
        AccountProfileIdentifier accountIdentification)
    {
        return new AccountProfile__AccountIdentification
        {
            AccountIdentification = accountIdentification.AccountIdentification ?? string.Empty,
            AccountIdentificationType =
                accountIdentification.AccountIdentificationType ?? string.Empty
        };
    }
}