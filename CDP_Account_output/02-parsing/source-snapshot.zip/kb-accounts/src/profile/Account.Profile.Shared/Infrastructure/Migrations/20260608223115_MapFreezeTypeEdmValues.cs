﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MapFreezeTypeEdmValues : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
            DO $$
            BEGIN
                IF EXISTS (
                    SELECT 1
                    FROM profile.account_profile
                    WHERE account_freeze_details_freeze_type IS NOT NULL
                      AND account_freeze_details_freeze_type NOT IN (
                        'Account_DebitAndCreditFreeze',
                        'Account_DebitFreeze'
                      )
                ) THEN
                    RAISE EXCEPTION 'Unexpected account_freeze_details_freeze_type present in profile.account_profile';
                END IF;

                UPDATE profile.account_profile
                SET account_freeze_details_freeze_type = CASE
                    WHEN account_freeze_details_freeze_type = 'Account_DebitAndCreditFreeze' THEN 'PreventDebitAndCredit'
                    WHEN account_freeze_details_freeze_type = 'Account_DebitFreeze' THEN 'PreventDebit'
                    ELSE account_freeze_details_freeze_type
                END;
            END
            $$;
        ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
            DO $$
            BEGIN
                IF EXISTS (
                    SELECT 1
                    FROM profile.account_profile
                    WHERE account_freeze_details_freeze_type IS NOT NULL
                      AND account_freeze_details_freeze_type NOT IN (
                        'PreventDebitAndCredit',
                        'PreventDebit'
                      )
                ) THEN
                    RAISE EXCEPTION 'Unexpected account_freeze_details_freeze_type present in profile.account_profile (Down)';
                END IF;

                UPDATE profile.account_profile
                SET account_freeze_details_freeze_type = CASE
                    WHEN account_freeze_details_freeze_type = 'PreventDebitAndCredit' THEN 'Account_DebitAndCreditFreeze'
                    WHEN account_freeze_details_freeze_type = 'PreventDebit' THEN 'Account_DebitFreeze'
                    ELSE account_freeze_details_freeze_type
                END;
            END
            $$;
        ");
        }
    }
}