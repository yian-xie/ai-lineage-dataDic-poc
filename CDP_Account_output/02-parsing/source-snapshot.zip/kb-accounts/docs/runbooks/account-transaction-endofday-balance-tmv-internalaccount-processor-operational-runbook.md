## Service Summary

| Field | Details |
|---|---|
| Business purpose | Processes TMV `END_OF_DAY_AST` scheduler operations, retrieves all internal-account IDs from TMV Core API, and creates delayed PostgreSQL jobs for the internal-account worker. |
| Runtime | .NET 10 ASP.NET Core executable in a Linux container; HTTP port 8080. Kafka event processor and TMV REST client. |
| Source | [Internal-account processor source](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Processor) |
| Pipeline | [Transaction pipeline](https://github.com/Kiwibank/kb-accounts/blob/main/src/transaction/.pipelineconfig/pipeline.yaml), using [component deployment values](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Deploy/Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Processor) |
| Last reviewed | 2026-10-01 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. A reliable Kafka subscriber consumes TMV `vault.core_api.v1.scheduler.operation.event` records and skips operations not tagged `END_OF_DAY_AST`.
2. The processor calls the TMV Core Accounts V2 API, paging through internal accounts, then schedules each account at the operation timestamp plus ten minutes.
3. It inserts `internal_account_eod_balance_job` records in one PostgreSQL transaction for the worker; failures redeliver every minute for up to six hours before DLQ.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Inbound Kafka | TMV Kafka | Supplies scheduler operation events. | `TmvKafka__*`; topic `vault.core_api.v1.scheduler.operation.event`. |
| Outbound REST | TMV Core Accounts API | Lists all internal accounts with pagination. | `ThoughtMachineVault__BaseApiUrl`, `ThoughtMachineVault__ApiToken`; `TmvAccountsLoader`. |
| Persistence | PostgreSQL transaction datastore | Stores `internal_account_eod_balance_job` records for the worker. | `ConnectionStrings__DefaultConnection`; shared transaction DbContext/repository. |
| Observability | Dynatrace and SumoLogic | Receives processing metrics/traces and threshold/terminal failure logs. | `MetricsOptions__*`, `TracingOptions__*`, `SumoLogicIngestion__*`. |

### Interfaces and Schedule

- Event-driven from the TMV scheduler; the repository does not define the upstream daily schedule.
- Only `operation_created.operation.tag_name=END_OF_DAY_AST` is processed.
- Jobs become eligible ten minutes after the source operation timestamp.
- Redelivery is one minute; TMV API failures are reported after 30 minutes; terminal DLQ threshold is six hours from first delivery.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| Pipeline stages | Builds, tests, and deploys the transaction component. | `accept`, `integrate` (`perf0` and `situat`), `rehearse` (`preprod`), and `deliver` (`prod`) are mapped in the transaction pipeline and deploy spec. |
| Image and workload | Selects the immutable image and Kubernetes app. | Image `accounts/account/transaction-eod-tmv-internalaccount-processor`; app/release `transaction-eod-tmv-internalaccount-processor`; base replicas 3, `maxUnavailable` 1. |
| TMV Kafka and Core API | Configures scheduler consumption and internal-account retrieval. | `TmvKafka__*`, `ThoughtMachineVault__BaseApiUrl`, and token secret reference vary by environment. |
| PostgreSQL and scheduling | Configures job persistence and eligibility delay. | `ConnectionStrings__DefaultConnection`; `EndOfDayJobOptions__WaitTimeInMinutes` defaults to 10. |

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `GET http://transaction-eod-tmv-internalaccount-processor/health/readiness` on service port 80 (target 8080), no application authentication configured | HTTP 200; starts after 10 seconds, polls every 5 seconds, and marks unready after 3 failures. Cluster-internal and not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and infrastructure authentication requirements]. | Non-200, timeout over 3 seconds, or a replica remains unready. |
| `GET http://transaction-eod-tmv-internalaccount-processor/health/liveness` on service port 80 (target 8080), no application authentication configured | HTTP 200; starts after 10 seconds, polls every 5 seconds, and restarts after 3 failures. Cluster-internal and not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and infrastructure authentication requirements]. | Non-200, timeout over 2 seconds, or repeated restarts. |
| Scheduler processing | One valid operation fetches the expected internal-account count and creates the same number of jobs. | Input is absent, fetched count is unexpectedly zero, redelivery/DLQ rises, or consumer lag grows. [TODO: confirm arrival window, expected account-count range, lag thresholds, and consumer-group access procedure]. |
| Worker hand-off | Jobs are scheduled ten minutes after the operation timestamp and become available to the worker. | Created jobs are absent, duplicated, scheduled incorrectly, or remain eligible without worker progress. |

Observability: <ul><li>[Account Transaction EoD Internal Accounts Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203001987/Account+Transaction+EoD+Internal+Accounts+Observability+Dashboard)</li><li>[EoD Components Runbook logs](https://kiwibank.atlassian.net/wiki/x/CQG6PwE)</li></ul>

Local verification from the repository root; requires the integration-test dependencies and credentials documented by the repository:

```powershell
dotnet test .\src\transaction\Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Processor.IntegrationTests\Account.Transaction.EndOfDay.Balance.Tmv.InternalAccount.Processor.IntegrationTests.csproj
```

Expected result: exit code 0; tests exercise scheduler-event handling, TMV API interaction, job persistence, retry, and failure reporting. This command was not executed during runbook generation and does not validate a deployed environment.

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the transaction pipeline builds `accounts/account/transaction-eod-tmv-internalaccount-processor` from the named project and candidate unit/integration evidence passes.
2. Review shared transaction migrations and target values for PostgreSQL, TMV Kafka/Core API, telemetry, ten-minute job delay, retry thresholds, group ID, and secret references.
3. Promote through SITUAT and PREPROD before PROD; use a non-production scheduler event for rehearsal.

### After Deployment

1. Confirm the expected image tag and replicas, and verify both cluster-internal health requests return HTTP 200 through the approved access path.
2. Confirm the processor consumes only the expected tagged operation and no new Kafka, TMV API, PostgreSQL, redelivery, or DLQ errors appear.
3. In SITUAT or PREPROD, verify a representative event fetches accounts and creates correctly scheduled jobs; record environment and result in change evidence.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

- Prefer fix-forward when shared database migrations or job rows have already been created.
- For an application-only regression, redeploy the last approved immutable image through the transaction pipeline. [TODO: confirm the pipeline rollback action, release identifier, required approval, and database-migration rollback policy].
- Do not reset offsets, replay DLQ records, create/delete jobs manually, or reverse migrations without an approved environment-specific procedure.

### Recovery Validation

1. Confirm all replicas are ready/live, TMV API and persistence errors stop, and the valid scheduler event completes without redelivery.
2. Verify the expected account count maps to correctly scheduled worker jobs and check for duplicate job IDs before closing recovery.

Operational guardrail: Job IDs include the source event and account; preserve this idempotency boundary and validate existing rows before any replay.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Kiwibank kb-accounts](https://github.com/Kiwibank/kb-accounts) |
| Dashboards and logs | <ul><li>[Account Transaction EoD Internal Accounts Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5203001987/Account+Transaction+EoD+Internal+Accounts+Observability+Dashboard)</li><li>[EoD Components Runbook logs](https://kiwibank.atlassian.net/wiki/x/CQG6PwE)</li></ul> |