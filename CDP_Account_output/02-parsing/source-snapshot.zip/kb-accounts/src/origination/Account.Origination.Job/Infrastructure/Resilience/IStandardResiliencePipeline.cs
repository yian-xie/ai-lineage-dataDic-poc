﻿using Polly;
namespace Account.Origination.Job.Infrastructure.Resilience;

public interface IStandardResiliencePipeline<TResult, TStrategy, TLoggerCategory>
    where TStrategy : IResilienceExceptionStrategy
{
    ResiliencePipeline<TResult> Pipeline { get; }
    Task<TResult> ExecuteAsync(Func<CancellationToken, Task<TResult>> callback, CancellationToken cancellationToken, object? state = null);
}