﻿namespace Account.Origination.Job.Domain;

public class Account
{
    // Account Identifier. Account Ids are unique, immutable, and guid for all product types,
    // except for SPUD where the Account Id is prefixed with "spud-".
    // Keeping the type as string to accommodate both guid and prefixed string.
    public string AccountId { get; init; }
}