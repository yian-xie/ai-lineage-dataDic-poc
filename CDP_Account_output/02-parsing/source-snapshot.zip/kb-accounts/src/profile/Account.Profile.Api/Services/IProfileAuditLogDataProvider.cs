﻿using System.Collections.Generic;

namespace Account.Profile.Api.Services;

/// <summary>
///     A data provider to provide audit log data that defines only in Account Profile Api
/// </summary>
public interface IProfileAuditLogDataProvider
{
    /// <summary>
    ///     A list of Account Ids
    /// </summary>
    List<string> AccountIds { get; set; }

    /// <summary>
    ///     A list of Account Numbers
    /// </summary>
    List<string> AccountNumbers { get; set; }
}