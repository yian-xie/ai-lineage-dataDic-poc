﻿using System.Threading;
using System.Threading.Tasks;

using Account.Transaction.Api.Queries.Services.Models;
using Account.Transaction.Api.Queries.Types;

namespace Account.Transaction.Api.Queries.Services;

/// <summary>
/// The credit card transactions service interface.
/// </summary>
public interface ICreditCardTransactionsService
{
    /// <summary>
    /// Gets the credit card transactions.
    /// </summary>
    /// <param name="queryParams"><see cref="AccountTransactionQueryParams"/></param>
    /// <param name="cancellationToken"><see cref="CancellationToken"/></param>
    /// <returns><see cref="CardTransactionsResponseState"/></returns>
    Task<CardTransactionsResponseState> GetCreditCardTransactionsAsync(
        AccountTransactionQueryParams queryParams, CancellationToken cancellationToken);
}