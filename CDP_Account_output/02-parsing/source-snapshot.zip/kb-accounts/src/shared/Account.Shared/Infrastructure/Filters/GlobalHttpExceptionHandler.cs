﻿using System.Net;

using Account.Shared.Infrastructure.Exceptions;

using Enterprise.Shared.Infrastructure.Filters;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Account.Shared.Infrastructure.Filters
{
    public class GlobalHttpExceptionHandler : IGlobalHttpExceptionHandler
    {
        public bool HandleException(ExceptionContext context)
        {
            if (context.Exception.GetType() != typeof(AccountDomainException))
            {
                return false;
            }

            var problemDetails = new ValidationProblemDetails
            {
                Instance = context.HttpContext.Request.Path,
                Status = StatusCodes.Status400BadRequest,
                Detail = "Please refer to the errors property for additional details."
            };

            problemDetails.Errors.Add("DomainValidations", new[] { context.Exception.Message });

            context.Result = new BadRequestObjectResult(problemDetails);
            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;

            return true;
        }
    }
}