﻿using System;
using System.Globalization;
using System.Linq;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using AsyncAPI = Api.Shared.Clients.Events.Kiwibank.V1.AccountPostings;
using MetadataType = Api.Shared.Clients.Events.Kiwibank.V1.AccountPostings.MetadataType;

namespace Account.Posting.Processor.Publishers;

public class AccountPostingEventBuilder : IAccountPostingEventBuilder
{
    public AsyncAPI.AccountPostingEvent BuildEvent(PostingBatchEvent postingBatchEvent)
    {
        var paymentId = postingBatchEvent.Posting_instruction_batch.Batch_details
            .AdditionalProperties
            .TryGetValue("payment_id", out var paymentIdValue)
            ? paymentIdValue.ToString()
            : null;

        var tmvPostingInstructions =
            postingBatchEvent.Posting_instruction_batch.Posting_instructions;

        return new AsyncAPI.AccountPostingEvent
        {
            Metadata = AsyncAPI.AccountPostingEvent.NewMetadata(
                Constants.ApplicationSource,
                MetadataType.AccountPostingCommitted,
                null,
                Guid.Empty),
            Data = new AsyncAPI.Data
            {
                AfterState = new AsyncAPI.AfterState
                {
                    PostingInstructionBatch = new AsyncAPI.PostingInstructionBatch
                    {
                        PaymentId = paymentId,
                        PostingInstructionBatchId = postingBatchEvent.Posting_instruction_batch.Id,
                        Result = AsyncAPI.PostingInstructionBatchResult.Committed,
                        PostingInstructions = tmvPostingInstructions.Select(tmvPostingInstruction =>
                            {
                                var postingInstructionId = tmvPostingInstruction.Id;
                                var instructionDetails = tmvPostingInstruction.Instruction_details;

                                var tmvIsoTransactionCode = tmvPostingInstruction.Transaction_code;
                                var isoTransactionCode = tmvIsoTransactionCode is null
                                    ? null
                                    : new AsyncAPI.IsoTransactionCode
                                    {
                                        Domain = tmvIsoTransactionCode.Domain,
                                        Family = tmvIsoTransactionCode.Family,
                                        Subfamily = tmvIsoTransactionCode.Subfamily
                                    };

                                var accountPostings = tmvPostingInstruction.Committed_postings
                                    .Select(committedPosting =>
                                    {
                                        return new AsyncAPI.AccountPosting
                                        {
                                            AccountId = committedPosting.Account_id,
                                            AccountAddressName =
                                                committedPosting.Account_address,
                                            Phase = committedPosting.Phase switch
                                            {
                                                PostingPhase.POSTING_PHASE_COMMITTED =>
                                                    AsyncAPI.AccountPostingPhase.Committed,
                                                PostingPhase.POSTING_PHASE_PENDING_INCOMING =>
                                                    AsyncAPI.AccountPostingPhase.PendingIncoming,
                                                PostingPhase.POSTING_PHASE_PENDING_OUTGOING =>
                                                    AsyncAPI.AccountPostingPhase.PendingOutgoing,
                                                PostingPhase.POSTING_PHASE_UNKNOWN =>
                                                    AsyncAPI.AccountPostingPhase.Unknown
                                            },
                                            AssetType = committedPosting.Asset,
                                            CreditDebitIndicator =
                                                committedPosting.Credit
                                                    ? AsyncAPI.AccountPostingCreditDebitIndicator
                                                        .Credit
                                                    : AsyncAPI.AccountPostingCreditDebitIndicator
                                                        .Debit,
                                            AccountPostingAmount =
                                                new AsyncAPI.AccountPostingAmount
                                                {
                                                    Amount = committedPosting.Amount
                                                        .ToString(CultureInfo.InvariantCulture),
                                                    CurrencyCode = committedPosting.Denomination
                                                }
                                        };
                                    })
                                    .ToList();


                                return new AsyncAPI.PostingInstruction
                                {
                                    PostingInstructionId = postingInstructionId,
                                    InitiationInstructionId = instructionDetails.PaymentInstruction_id,
                                    PaymentInstructionCategory = instructionDetails.PaymentInstruction_category,
                                    TransactionCode = instructionDetails.TransactionTransaction_code,
                                    IsoTransactionCode = isoTransactionCode,
                                    InsertDateTime = tmvPostingInstruction.Insertion_timestamp,
                                    BookDateTime = tmvPostingInstruction.Booking_timestamp,
                                    ValueDateTime = tmvPostingInstruction.Value_timestamp,
                                    Description = instructionDetails.TransactionDescription,
                                    AccountPostings = accountPostings
                                };
                            })
                            .ToList()
                    }
                }
            }
        };
    }
}