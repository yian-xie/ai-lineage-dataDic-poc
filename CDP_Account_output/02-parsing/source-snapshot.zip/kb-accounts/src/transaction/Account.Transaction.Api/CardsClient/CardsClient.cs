﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

using Account.Shared.Metrics;
using Account.Transaction.Api.CardsClient.Configuration;
using Account.Transaction.Api.CardsClient.Exceptions;
using Account.Transaction.Api.CardsClient.Extensions;
using Account.Transaction.Api.CardsClient.Models;
using Account.Transaction.Api.Observability;

using Kb.Api.Observability.Metrics;

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Account.Transaction.Api.CardsClient;

/// <summary>
/// Represents a client for communicating with the cards service API to retrieve credit card transactions.
/// </summary>
public class CardsClient(ILogger<CardsClient> logger, HttpClient httpClient, IOptions<CardsClientConfiguration> options, IProfilingMetrics metrics) : ICardsClient
{
    private readonly Stopwatch _timer = new();
    private const string CallDurationMetric = "call-duration";

    private readonly TagList _tagList = [
        new KeyValuePair<string, object?>(TelemetryTagKeys.DownStreamServiceName, MetricNames.CardsApi)
    ];

    /// <summary>
    /// Asynchronously retrieves the account details for a given access number.
    /// </summary>
    /// <param name="cardTransactionsRequest">The query parameters needed to perform the request.</param>
    /// <param name="cancellationToken">The token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the <see cref="CardTransactionsResponse"/> with transaction details.</returns>
    /// <exception cref="CreditCardTransactionsException">Thrown when there is an error during the API call.</exception>
    public async Task<CardTransactionsResponse> SendTransactionsRequestAsync(CardTransactionsRequest cardTransactionsRequest, CancellationToken cancellationToken)
    {
        _timer.Start();

        try
        {
            var cardsResponse = await httpClient.SendAsync<CardTransactionsResponse, CreditCardTransactionsException>(options.Value.RequestPath, cardTransactionsRequest, logger);
            return cardsResponse;
        }
        finally
        {
            _timer.Stop();
            metrics.Histogram(CallDurationMetric, _timer.ElapsedMilliseconds, _tagList);
            _timer.Reset();
        }
    }
}