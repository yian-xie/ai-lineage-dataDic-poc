﻿using Api.Shared.Clients.Rest.Dynatrace;
using Api.Shared.Clients.Rest.Dynatrace.V2.DynatraceMetrics;

namespace Account.TopicLogger.Processor.Services;

/// <summary>
///     Helper class for interacting with the Dynatrace Metrics API.
///     This class is responsible for ingesting metrics into Dynatrace using the provided
///     Dynatrace client and settings.
/// </summary>
public class DynatraceMetricsClientHelper(
    IDynatraceMetricsClient dynatraceMetricsClient,
    DynatraceSettings dynatraceSettings,
    IKubernetesHelper kubernetesHelper) : IDynatraceMetricsClientHelper
{
    /// <summary>
    ///     Ingests a metric into Dynatrace.
    /// </summary>
    /// <param name="topicName">The name of the topic associated with the metric.</param>
    /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task IngestMetricAsync(string topicName, CancellationToken cancellationToken)
    {
        var metric =
            $"{dynatraceSettings.MetricName},k8s.namespace.name={kubernetesHelper.GetCurrentNamespace()},topicname=\"{topicName}\" 1";

        await dynatraceMetricsClient.IngestMetricAsync(
            $"Api-Token {dynatraceSettings.ApiToken}",
            metric,
            cancellationToken);
    }
}