﻿#nullable enable

using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Publishers;
using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Repositories;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;

using Microsoft.Extensions.Logging;

using DomesticTaxRate = Account.Profile.Shared.Entities.DomesticTaxRate;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Implements IParameterValueCreator interface for creating parameter values by updating existing records in the
///     database.
/// </summary>
public class ParameterValueCreator(
    IRepositoryFactory repositoryFactory,
    IAccountProfileEventPublisher accountProfileEventPublisher,
    ILogger<ParameterValueCreator> logger)
    : IParameterValueCreator
{
    public async Task<AccountProfile> CreateAsync(
        AccountProfileChangeSet accountProfileChangeSet,
        DateTimeOffset parameterValueTimestamp,
        CancellationToken cancellationToken)
    {
        try
        {
            var existingAccountProfile =
                await repositoryFactory.AccountProfileRepository.GetAccountAsync(
                    accountProfileChangeSet.AccountId,
                    cancellationToken);

            if (existingAccountProfile == null)
            {
                logger.LogWarning(
                    "AccountId: {accountId} does not exist yet for received Contract Notification / parameter_change Event",
                    accountProfileChangeSet.AccountId);

                throw new Exception("AccountProfile does not exist. Force message retry");
            }

            existingAccountProfile.DomesticTaxRate ??= new DomesticTaxRate();

            if (accountProfileChangeSet.WithholdingTaxType != null)
            {
                existingAccountProfile.DomesticTaxRate.DomesticTaxType =
                    accountProfileChangeSet.WithholdingTaxType;
            }

            if (accountProfileChangeSet.WithholdingTaxRate != null)
            {
                existingAccountProfile.DomesticTaxRate.RateValue =
                    accountProfileChangeSet.WithholdingTaxRate;
            }

            if (accountProfileChangeSet.CountryAlpha3Code != null)
            {
                existingAccountProfile.DomesticTaxRate.CountryAlpha3Code =
                    accountProfileChangeSet.CountryAlpha3Code;
            }

            if (accountProfileChangeSet.NominatedTaxPartyId != null)
            {
                existingAccountProfile.BankingRelationship.NominatedTaxPartyId =
                    accountProfileChangeSet.NominatedTaxPartyId;
            }

            if (accountProfileChangeSet.InterestRate != null)
            {
                existingAccountProfile.ProductFacility.InterestRate =
                    accountProfileChangeSet.InterestRate;
            }

            if (accountProfileChangeSet.InterestRateValidFrom != null)
            {
                existingAccountProfile.ProductFacility.InterestRateValidFrom =
                    accountProfileChangeSet.InterestRateValidFrom.Value;
            }

            if (accountProfileChangeSet.InterestRatePlanChangeId != null)
            {
                existingAccountProfile.ProductFacility.InterestRatePlanChangeId =
                    accountProfileChangeSet.InterestRatePlanChangeId;
            }

            if (accountProfileChangeSet.BankingProductCode != null)
            {
                existingAccountProfile.ProductFacility.BankingProductCode =
                    accountProfileChangeSet.BankingProductCode;
            }

            if (accountProfileChangeSet.BankingProductId != null)
            {
                existingAccountProfile.ProductFacility.BankingProductId =
                    accountProfileChangeSet.BankingProductId;
            }

            if (accountProfileChangeSet.BankingProductVersionId != null)
            {
                existingAccountProfile.ProductFacility.BankingProductVersionId =
                    accountProfileChangeSet.BankingProductVersionId;
            }

            repositoryFactory.AccountProfileRepository.Update(existingAccountProfile);

            await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);

            await accountProfileEventPublisher.PublishAccountProfileEventAsync(
                existingAccountProfile,
                MetadataType.AccountUpdated,
                parameterValueTimestamp,
                existingAccountProfile.CorrelationId,
                repositoryFactory.UnitOfWork,
                cancellationToken);

            logger.LogInformation(
                "The ParameterValue for account id {accountId} is created.",
                existingAccountProfile.AccountId);

            return existingAccountProfile;
        }
        catch (Exception ex)
        {
            logger.LogError(
                ex,
                "Failed to create Parameter Value for Account {accountId}.",
                accountProfileChangeSet.AccountId);

            throw;
        }
    }
}