﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Services.Rest.Kiwibank.V1.Spud;

namespace Account.Spud.Api.Services;

public interface IAccountOpening
{
    /// <summary>
    ///     Spud account opening.
    /// </summary>
    /// <param name="accountId"></param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="OpenAccountResponse" />
    /// </returns>
    Task<OpenAccountResponse> OpenAccountAsync(
        string accountId,
        CancellationToken cancellationToken);
}