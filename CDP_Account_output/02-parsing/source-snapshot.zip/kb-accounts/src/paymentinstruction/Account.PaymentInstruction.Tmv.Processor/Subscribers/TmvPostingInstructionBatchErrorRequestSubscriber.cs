﻿using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Shared.EventBuilder;
using Account.PaymentInstruction.Shared.Repositories;
using Account.PaymentInstruction.Shared.Services;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchErrorRequest;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;
using Enterprise.Shared.Kafka.Produce;

using Microsoft.Extensions.Logging;

namespace Account.PaymentInstruction.Tmv.Processor.Subscribers;

public class TmvPostingInstructionBatchErrorRequestSubscriber(
    IRepositoryFactory repositoryFactory,
    IPaymentInstructionStatusCreator paymentInstructionStatusCreator,
    IPaymentInstructionEventBuilder paymentInstructionEventBuilder,
    IOutboxEventPublisher<PaymentInstructionEvent> publisher,
    ILogger<TmvPostingInstructionBatchCreatedEventSubscriber> logger)
    : IIncomingEventSubscriber<PostingInstructionBatchErrorRequest>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        PostingInstructionBatchErrorRequest incomingEvent,
        CancellationToken cancellationToken)
    {
        var clientBatchId = incomingEvent.Posting_instruction_batch.Client_batch_id;
        var clientId = incomingEvent.Posting_instruction_batch.Client_id;

        var paymentInstruction =
            await repositoryFactory.PaymentInstructionRepository.GetAsync(clientBatchId, clientId,
                cancellationToken);

        if (paymentInstruction is null)
        {
            logger.LogInformation(
                "No matching payment instruction found for client batch id: {clientBatchId}, client id: {clientId}",
                clientBatchId, clientId);

            return EventSubscriberResults.Success;
        }

        logger.LogInformation(
            "Found payment instruction request id {RequestId} for client batch id: {clientBatchId}, client id: {clientId}",
            paymentInstruction.RequestId, clientBatchId, clientId);

        var paymentInstructionEvent =
            paymentInstructionEventBuilder.BuildErrorFromPostingInstructionBatch(
                paymentInstruction);

        await publisher.PublishAsync(
            paymentInstruction.TransactionId,
            paymentInstructionEvent,
            repositoryFactory.UnitOfWork,
            cancellationToken);

        await paymentInstructionStatusCreator.CreateAsync(
            paymentInstruction,
            PaymentInstructionStatusStatus.Error,
            cancellationToken);

        return EventSubscriberResults.Success;
    }
}