﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events.Internal.V1.AccountAuditLog;

using Enterprise.Shared.Kafka.Produce;

using HotChocolate.Resolvers;

using Microsoft.AspNetCore.Http;

namespace Account.Shared.Kafka.Publishers;

public class AccountAuditLogEventPublisher(
    IAccountAuditLogEventBuilder accountAuditLogEventBuilder,
    IKafkaPublisher<string, AccountAuditLogEvent> publisher)
    : IAccountAuditLogEventPublisher
{
    public async Task PublishAccountAuditLogEventAsync(
        IMiddlewareContext middlewareContext,
        HttpContext httpContext,
        string appName,
        CancellationToken cancellationToken)
    {
        var accountAuditLogEvent = accountAuditLogEventBuilder.BuildEvent(
            middlewareContext,
            httpContext,
            appName);

        await publisher.PublishAsync(
            accountAuditLogEvent.ClientLogRequestId,
            accountAuditLogEvent,
            cancellationToken);
    }
}