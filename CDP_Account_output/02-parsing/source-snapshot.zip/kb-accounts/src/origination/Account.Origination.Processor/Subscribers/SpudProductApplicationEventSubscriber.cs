﻿using Account.Origination.Processor.Services;
using Account.Origination.Shared.Entities;
using Account.Shared;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountSpudProductApplication;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.Origination.Processor.Subscribers;

public class SpudProductApplicationEventSubscriber(
    IJobCreator jobCreator,
    TimeProvider timeProvider)
    : IIncomingEventSubscriber<SpudProductApplicationEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        SpudProductApplicationEvent incomingEvent,
        CancellationToken cancellationToken)
    {
        var accountOpening = CreateAccountOpening(incomingEvent);
        await jobCreator.CreateAsync(accountOpening, cancellationToken);

        return EventSubscriberResults.Success;
    }

    /// <summary>
    ///     Create account_opening entry.
    /// </summary>
    /// <param name="spudProductApplicationEvent">
    ///     <see cref="SpudProductApplicationEvent" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountOpening" />
    /// </returns>
    private AccountOpening CreateAccountOpening(
        SpudProductApplicationEvent spudProductApplicationEvent)
    {
        return new AccountOpening
        {
            EventId = spudProductApplicationEvent.Metadata.Id,
            AccountId = GetAccountId(spudProductApplicationEvent),
            CorrelationId = spudProductApplicationEvent.Metadata.CorrelationId,
            PartyRoleIds = [spudProductApplicationEvent.Data.AfterState.PartyRoleId],
            ScheduledOpen = timeProvider.GetUtcNow(),
            ValidUntil = spudProductApplicationEvent.Data.AfterState.ValidUntil,
            State = AccountOpeningState.Initial
        };
    }

    /// <summary>
    ///     Gets the Account Id from the additional properties
    /// </summary>
    /// <param name="spudProductApplicationEvent"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private static string GetAccountId(SpudProductApplicationEvent spudProductApplicationEvent)
    {
        const string propertyKey = AdditionalPropertyKeys.RequestedAccountId;
        var properties = spudProductApplicationEvent.Data.AfterState.AdditionalProperties;
        var accountId = properties[propertyKey] as string;

        if (string.IsNullOrWhiteSpace(accountId))
        {
            throw new Exception($"Invalid {propertyKey}: {accountId}");
        }

        return accountId;
    }
}