﻿using Account.Shared;
using Account.Shared.Authorisation;
using Account.Spud.Api.Services;

using Kb.TMV.Client.DependencyInjection;

using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Spud.Api;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, TelemetrySourceName)
{
    public const string TelemetrySourceName = "account_spud";

    protected override void AddApplicationServices(IServiceCollection services)
    {
        services.Configure<SpudAccountSettings>(
            Configuration.GetSection(nameof(SpudAccountSettings)));

        UseKafka(services);

        services
            .AddScoped<IAccountCloser, AccountCloser>()
            .AddSingleton<IAccountOpening, SpudAccountOpening>();

        services.AddAccountAuthorization(Configuration);

        services.AddTmvClient(configuration);
        services.AddSupportForCloseAccount();
    }
}