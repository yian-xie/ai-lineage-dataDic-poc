﻿namespace Account.Spud.Api.Services;

public class SpudAccountSettings
{
    /// <summary>
    ///     The auto repository polling time seconds.
    /// </summary>
    public string PartyRoleId { get; set; }

    /// <summary>
    ///     SPUD account creation and opening valid time.
    /// </summary>
    public int ValidUntilTimeInSecond { get; set; }
}