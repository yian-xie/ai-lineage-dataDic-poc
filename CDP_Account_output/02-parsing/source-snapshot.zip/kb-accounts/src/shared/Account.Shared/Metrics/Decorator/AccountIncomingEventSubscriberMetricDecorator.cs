﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Kb.Api.Observability.Metrics;

namespace Account.Shared.Metrics.Decorator;

/// <summary>
///     The metrics decorator to subscribe the account domain event that extends <see cref="IEvent" />.
/// </summary>
/// <typeparam name="T">Type of <see cref="IEvent" /></typeparam>
public class AccountIncomingEventSubscriberMetricDecorator<T>(
    IIncomingEventSubscriber<T> incomingEventSubscriber,
    IProfilingMetrics metrics)
    : IIncomingEventSubscriber<T>
    where T : IEvent
{
    private const string KafkaEventMetricName = "kafka-event";
    private const string RequestTotalSuffix = "-total-requests";
    private const string RequestSuccessSuffix = "-success-requests";
    private const string RequestSkipSuffix = "-skip-requests";
    private const string RequestRedeliverSuffix = "-redeliver-requests";
    private const string RequestMoveToDlqSuffix = "-moved-to-dlq-requests";
    private const string ExceptionMetricSuffix = "-exceptions";
    private const string DurationMetricSuffix = "-duration";

    private readonly TagList _tagList = [
        new KeyValuePair<string, object>(TelemetryTagKeys.EventType, typeof(T).FullName)
    ];

    /// <summary>
    ///     Measure the number of and duration of handling the incoming event <see cref="IEvent" /> by the given event
    ///     subscriber.
    /// </summary>
    /// <param name="context">
    ///     <see cref="IncomingEventContext" />
    /// </param>
    /// <param name="incomingEvent">The event extends <see cref="IEvent" /></param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        T incomingEvent,
        CancellationToken cancellationToken)
    {
        var queryTimer = Stopwatch.StartNew();

        metrics.Counter(KafkaEventMetricName + RequestTotalSuffix, 1, _tagList);

        try
        {
            var result = await incomingEventSubscriber.HandleAsync(context, incomingEvent,
                cancellationToken);

            switch (result)
            {
                case RedeliverMessageEventSubscriberResult:
                    metrics.Counter(KafkaEventMetricName + RequestRedeliverSuffix, 1, _tagList);

                    break;
                case MoveToDlqEventSubscriberResult:
                    metrics.Counter(KafkaEventMetricName + RequestMoveToDlqSuffix, 1, _tagList);

                    break;
                case SkipEventSubscriberResult:
                    metrics.Counter(KafkaEventMetricName + RequestSkipSuffix, 1, _tagList);

                    break;
                case SuccessEventSubscriberResult:
                    metrics.Counter(KafkaEventMetricName + RequestSuccessSuffix, 1, _tagList);

                    break;
            }

            return result;
        }
        catch (Exception ex)
        {
            var exceptionTag =
                new KeyValuePair<string, object>(TelemetryTagKeys.ExceptionType, ex.GetType().Name);

            metrics.Counter(KafkaEventMetricName + ExceptionMetricSuffix, 1,
                [.. _tagList, exceptionTag]);

            throw;
        }
        finally
        {
            queryTimer.Stop();
            var lastExecutionDuration = queryTimer.Elapsed;

            metrics.Histogram(KafkaEventMetricName + DurationMetricSuffix,
                (long)lastExecutionDuration.TotalMilliseconds, _tagList);
        }
    }
}