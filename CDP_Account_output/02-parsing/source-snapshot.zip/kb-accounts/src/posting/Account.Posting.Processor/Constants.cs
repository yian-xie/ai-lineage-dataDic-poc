﻿namespace Account.Posting.Processor;

public static class Constants
{
    public const string ApplicationSource = "urn:nz:co:kiwibank:kb-accounts:account-posting-processor";
}