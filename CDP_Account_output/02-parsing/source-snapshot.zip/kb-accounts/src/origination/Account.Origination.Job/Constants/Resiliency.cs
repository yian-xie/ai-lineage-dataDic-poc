﻿namespace Account.Origination.Job.Constants
{
    public static class Resiliency
    {
        public const int DefaultRetryAttempts = 3;
        public const int DefaultTimeoutAfterSeconds = 10;
        public const int DefaultBackOffAttempt = 5;
        public const int DefaultRetryDelaySeconds = 2;
        public const bool DefaultUseJitter = true;
    }
}