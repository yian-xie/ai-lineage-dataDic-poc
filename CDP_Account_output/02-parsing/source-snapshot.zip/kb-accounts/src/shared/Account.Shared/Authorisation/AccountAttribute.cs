﻿using System.Reflection;

using Account.Shared.Kafka.Publishers;

using HotChocolate.Types;
using HotChocolate.Types.Descriptors;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Account.Shared.Authorisation;

public class AccountAttribute : ObjectFieldDescriptorAttribute
{
    protected override void OnConfigure(
        IDescriptorContext context,
        IObjectFieldDescriptor descriptor,
        MemberInfo member)
    {
        descriptor.Use((provider, @delegate) =>
        {
            var httpContextAccessor = provider.GetRequiredService<IHttpContextAccessor>();
            var hostEnvironment = provider.GetRequiredService<IHostEnvironment>();
            var publisher = provider.GetRequiredService<IAccountAuditLogEventPublisher>();
            var preAccountMiddlewareInitializer = provider.GetService<IPreAccountMiddlewareInitializer>();

            return new AccountMiddleware(
                @delegate,
                httpContextAccessor,
                hostEnvironment,
                publisher,
                preAccountMiddlewareInitializer);
        });
    }
}