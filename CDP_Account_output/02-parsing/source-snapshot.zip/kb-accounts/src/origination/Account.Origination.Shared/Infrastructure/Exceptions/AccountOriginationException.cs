﻿namespace Account.Origination.Shared.Infrastructure.Exceptions;

/// <summary>
///     Exception type for app exceptions
/// </summary>
public class AccountOriginationException : Exception
{
    public AccountOriginationException() { }

    public AccountOriginationException(string message)
        : base(message) { }

    public AccountOriginationException(string message, Exception innerException)
        : base(message, innerException) { }
}