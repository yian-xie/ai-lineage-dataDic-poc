﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Posting.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddBaseColumnsToPostingTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "created_at",
                schema: "posting",
                table: "tmv_positing_batch",
                type: "timestamp with time zone",
                nullable: true,
                defaultValueSql: "CURRENT_TIMESTAMP");

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "modified_at",
                schema: "posting",
                table: "tmv_positing_batch",
                type: "timestamp with time zone",
                nullable: true,
                defaultValueSql: "CURRENT_TIMESTAMP");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "created_at",
                schema: "posting",
                table: "tmv_positing_batch");

            migrationBuilder.DropColumn(
                name: "modified_at",
                schema: "posting",
                table: "tmv_positing_batch");
        }
    }
}