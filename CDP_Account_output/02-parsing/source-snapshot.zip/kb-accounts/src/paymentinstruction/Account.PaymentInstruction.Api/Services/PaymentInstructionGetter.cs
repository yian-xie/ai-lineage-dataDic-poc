﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Api.Infrastructure;
using Account.PaymentInstruction.Shared.Repositories;

using PaymentInstructionWithStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionWithStatus;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     Retrieve <see cref="PaymentInstructionWithStatus" />.
/// </summary>
public class PaymentInstructionGetter(IRepositoryFactory repositoryFactory)
    : IPaymentInstructionGetter
{
    public async Task<PaymentInstructionWithStatus?> GetAsync(
        string clientBatchId,
        string clientId,
        CancellationToken cancellationToken)
    {
        var paymentInstruction = await repositoryFactory.PaymentInstructionRepository.GetAsync(
            clientBatchId,
            clientId,
            cancellationToken);

        if (paymentInstruction == null)
        {
            return null;
        }

        var statuses = await repositoryFactory.PaymentInstructionStatusRepository.GetAsync(
            clientBatchId,
            clientId,
            cancellationToken);

        return paymentInstruction.ToPaymentInstructionWithStatus(statuses);
    }

    public async Task<PaymentInstructionWithStatus[]> GetAsync(
        string transactionId,
        CancellationToken cancellationToken)
    {
        var paymentInstructionWithStatusList = new List<PaymentInstructionWithStatus>();

        var paymentInstructions =
            await repositoryFactory.PaymentInstructionRepository.GetAsync(transactionId,
                cancellationToken);

        foreach (var paymentInstruction in paymentInstructions)
        {
            var statuses = await repositoryFactory.PaymentInstructionStatusRepository.GetAsync(
                paymentInstruction.ClientBatchId,
                paymentInstruction.ClientId,
                cancellationToken);

            var paymentInstructionWithStatus =
                paymentInstruction.ToPaymentInstructionWithStatus(statuses);
            paymentInstructionWithStatusList.Add(paymentInstructionWithStatus);
        }

        return paymentInstructionWithStatusList.ToArray();
    }
}