﻿#nullable enable
using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Represents an interface for updating AccountProfile in the database and publish event to Enterprise topic.
/// </summary>
public interface IAccountProfileUpdater
{
    /// <summary>
    ///     Update AccountProfile in the database and publish event to Enterprise topic.
    /// </summary>
    /// <param name="accountEvent"></param>
    /// <param name="accountStatusTimestamp"></param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfile" />
    /// </returns>
    Task<AccountProfile?> UpdateAndPublishAsync(
        AccountEvent accountEvent,
        DateTimeOffset accountStatusTimestamp,
        CancellationToken cancellationToken);
}