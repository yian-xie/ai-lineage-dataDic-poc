﻿using System;
using System.Net;

namespace Account.Transaction.Api.Queries.Exceptions;

/// <summary>
/// Transaction exception base class for transaction related errors.
/// </summary>
public abstract class TransactionExceptionBase : Exception
{
    /// <summary>
    /// Gets or sets the HTTP status code associated with the exception
    /// </summary>
    public HttpStatusCode StatusCode { get; set; }

    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionExceptionBase"/> class with a specified error message
    /// </summary>
    /// <param name="message">The error message that explains the reason for the exception</param>
    protected TransactionExceptionBase(string message) : base(message)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionExceptionBase"/> class with a specified error message and HTTP status code
    /// </summary>
    /// <param name="message">The error message that explains the reason for the exception</param>
    /// <param name="statusCode">The HTTP status code returned from the API</param>
    protected TransactionExceptionBase(string message, HttpStatusCode statusCode) : base(message)
    {
        StatusCode = statusCode;
    }
}