﻿using System.Threading;
using System.Threading.Tasks;

using PaymentInstructionWithStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionWithStatus;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     The interface to retrieve <see cref="PaymentInstructionWithStatus" />.
/// </summary>
public interface IPaymentInstructionGetter
{
    /// <summary>
    ///     Get <see cref="PaymentInstructionWithStatus" /> by Client Batch id and Client id.
    /// </summary>
    /// <param name="clientBatchId">Client Batch id</param>
    /// <param name="clientId">Client id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="PaymentInstructionWithStatus" />
    /// </returns>
    Task<PaymentInstructionWithStatus?> GetAsync(
        string clientBatchId,
        string clientId,
        CancellationToken cancellationToken);

    /// <summary>
    ///     Get a list of <see cref="PaymentInstructionWithStatus" /> by transaction id.
    /// </summary>
    /// <param name="transactionId">The transaction id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>A list of <see cref="PaymentInstructionWithStatus" /></returns>
    Task<PaymentInstructionWithStatus[]> GetAsync(
        string transactionId,
        CancellationToken cancellationToken);
}