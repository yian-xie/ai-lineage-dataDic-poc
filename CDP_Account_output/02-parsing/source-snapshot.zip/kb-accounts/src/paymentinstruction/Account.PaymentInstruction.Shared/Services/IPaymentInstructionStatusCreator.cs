﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using PaymentInstructionStatus =
    Account.PaymentInstruction.Shared.Entities.PaymentInstructionStatus;

namespace Account.PaymentInstruction.Shared.Services;

/// <summary>
///     The interface to create the <see cref="PaymentInstructionStatus" /> with the given
///     <see cref="Shared.Entities.PaymentInstruction" /> and <see cref="Status" />.
/// </summary>
public interface IPaymentInstructionStatusCreator
{
    /// <summary>
    ///     Process the given <see cref="Shared.Entities.PaymentInstruction" />, create the
    ///     <see cref="PaymentInstructionStatus" /> with the given <see cref="Status" /> and insert into payment_instruction
    ///     table.
    /// </summary>
    /// <param name="paymentInstruction">
    ///     <see cref="Shared.Entities.PaymentInstruction" />
    /// </param>
    /// <param name="status">
    ///     <see cref="PaymentInstructionStatusStatus" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <param name="postingInstructionBatch">
    ///     <see cref="PostingInstructionBatch" />
    /// </param>
    /// <returns>
    ///     <see cref="PaymentInstructionStatus" />
    /// </returns>
    Task<PaymentInstructionStatus> CreateAsync(
        Entities.PaymentInstruction paymentInstruction,
        PaymentInstructionStatusStatus status,
        CancellationToken cancellationToken,
        PostingInstructionBatch postingInstructionBatch = null);
}