﻿using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Api.Mutations.Types;
using Account.PaymentInstruction.Api.Queries.Types;
using Account.PaymentInstruction.Api.Services;

using HotChocolate;
using HotChocolate.Authorization;
using HotChocolate.Types;

namespace Account.PaymentInstruction.Api.Mutations;

/// <summary>
///     The Payment Instruction Api mutation to process the
///     <see cref="PaymentInstructionRequestInput" />.
/// </summary>
public class PaymentInstructionMutation
{
    [Authorize(Policy = "PaymentInstructionMaintain")]
    [UseResolverScope]
    public async Task<PaymentInstructionWithStatus?> AddPaymentInstructionRequestAsync(
        [GraphQLName("input")] PaymentInstructionRequestInput input,
        [Service] IAddPaymentInstructionRequestHandler addPaymentInstructionRequestHandler,
        CancellationToken cancellationToken)
    {
        return await addPaymentInstructionRequestHandler.HandleAsync(input, cancellationToken);
    }
}