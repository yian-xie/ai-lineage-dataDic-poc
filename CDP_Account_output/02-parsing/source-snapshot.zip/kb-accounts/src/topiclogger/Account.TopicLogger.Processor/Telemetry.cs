﻿namespace Account.TopicLogger.Processor;

public static class Telemetry
{
    public const string ActivitySourceName = "account_topiclogger";
}