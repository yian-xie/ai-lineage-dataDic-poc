## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account.Profile.Api (`accounts-profile-api`) |
| Customer or business impact | [TODO: confirm business criticality and customer impact statement] |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/AYBBKAE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33954157)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Readiness probe or PostgreSQL failure</summary>

- **Symptoms:** the `/health/readiness` probe fails, or profile GraphQL reads fail or time out. The API reads `profile.account_profile` through `AccountProfileDbContext`; readiness includes the SQL health check.
- **Actions:**
  1. In the PROD API pod's network namespace, issue `GET http://127.0.0.1:8080/health/readiness`. No application bearer token is configured for the probe; expect HTTP 2xx. This loopback endpoint is not laptop-reachable. `[TODO: confirm the approved PROD pod-access procedure and required role]`.
  2. Correlate the failure time with API request errors and PostgreSQL connection or timeout errors. Do not expose connection strings or secret values.
  3. Confirm the PROD deployment is using the expected profile database configuration (`prod_account_profile`) through the approved platform view. `[TODO: confirm the read-only PROD platform procedure for checking database connectivity and deployment configuration]`.
- **Recovery check:** readiness returns HTTP 2xx and an approved PROD profile query succeeds. `[TODO: confirm an approved PROD account ID and the approved GraphQL access procedure]`. No production request was sent during runbook generation.
- **Escalate:** if readiness remains unhealthy, database access/configuration is incorrect, or customer reads remain impaired, follow the [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE).

</details>

<details>
<summary>Profile query returns null or an empty list</summary>

- **Symptoms:** `tmvAccountProfile` returns `null`, or `tmvAccountProfilesV2` omits an expected account. These are the API's normal results when no matching row is returned from the profile database.
- **Actions:**
  1. Confirm the account ID and requested query with the caller; the single and multiple-account resolvers query by account ID.
  2. From the approved PROD client, retry only for the confirmed account by sending `POST [TODO: confirm PROD URL scheme]://prod-accounts-profile.apps.bc62.cip-production.prod.internal.aws.kiwibank.co.nz/api/accounts-profile/graphql` with an approved bearer token and the `tmvAccountProfile` query for that account ID. Expect HTTP 200 with profile data when the row exists; a missing row returns `null` (or is omitted from the multi-account result). The private/internal hostname is not verified as laptop-reachable; `[TODO: confirm approved PROD access and account-lookup procedure]`. No request was sent during runbook generation.
  3. If the expected account is still absent, have the authorised support process verify the PROD profile data path. The API is read-only; do not insert or alter profile rows manually. `[TODO: confirm the approved read-only PROD profile-data verification procedure]`.
- **Recovery check:** the same approved PROD query returns the expected profile fields for the confirmed account. No production request was sent during runbook generation.
- **Escalate:** if a confirmed account remains absent after the data-path check, or the issue affects multiple accounts, follow the [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE).

</details>

<details>
<summary>GraphQL authentication or access denied</summary>

- **Symptoms:** an approved caller receives an authentication/authorization denial instead of profile data. PROD configuration requires a bearer token from the configured Microsoft Entra issuer and limits GraphQL access to an authorised service principal.
- **Actions:**
  1. From the approved PROD client, send `POST [TODO: confirm PROD URL scheme]://prod-accounts-profile.apps.bc62.cip-production.prod.internal.aws.kiwibank.co.nz/api/accounts-profile/graphql` with an approved, unexpired bearer token and query body. An authorised request should return HTTP 200 without GraphQL errors; unauthorised callers are denied by the configured issuer/service-mesh policy. The hostname is private/internal; laptop/VPN reachability and the exact query are unverified. `[TODO: confirm approved PROD access and account-lookup procedure]`. No production request was sent during runbook generation. Never paste tokens into logs or support messages.
  2. Check the PROD `Authorization` policy and issuer configuration in `src/profile/Deploy/Account.Profile.Api/values-deliver.yaml`; do not broaden policy as an incident workaround.
  3. `[TODO: confirm the supported PROD client, access path, and token-validation procedure]`. The configured PROD hostname is private/internal; laptop reachability is unverified.
- **Recovery check:** the approved caller receives HTTP 200 and a response without GraphQL errors for a confirmed PROD account. No production request was sent during runbook generation.
- **Escalate:** if valid approved credentials continue to be rejected, or access policy/issuer configuration differs from the authorised client, follow the [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE).

</details>

<details>
<summary>Read audit event missing or outbox/Kafka delivery failing</summary>

- **Symptoms:** read-audit events are not observed after profile queries, `audit.events.emitted` telemetry changes unexpectedly, or logs show audit publisher/outbox/Kafka delivery errors. The API builds `AccountAuditLogCreated` events with a success/failure outcome and persists/publishes them through the audit outbox and Kafka integration.
- **Actions:**
  1. Correlate the query time with `audit.events.emitted`, audit-publisher/outbox errors, and Kafka connectivity or authentication errors.
  2. Check the PROD deployment's Kafka bootstrap, schema registry, and secret *names* against `src/profile/Deploy/Account.Profile.Api/values-deliver.yaml`; do not display secret values or invent a topic/replay command.
  3. `[TODO: confirm the approved PROD outbox backlog and Kafka delivery inspection procedure]`. Do not manually edit outbox records, replay events, or restart the API as a default action.
- **Recovery check:** an approved PROD profile read produces its expected audit event and the outbox/delivery signal returns to its approved normal state. `[TODO: confirm the authoritative PROD outbox/Kafka recovery signal]`. No production read was performed during runbook generation.
- **Escalate:** if audit events remain missing, outbox delivery is blocked, or audit data may be incomplete, follow the [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE).

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>
