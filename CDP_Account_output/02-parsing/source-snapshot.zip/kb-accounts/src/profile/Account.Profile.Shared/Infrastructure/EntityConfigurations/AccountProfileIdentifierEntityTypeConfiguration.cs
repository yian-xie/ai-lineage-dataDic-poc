﻿using Account.Profile.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.Profile.Shared.Infrastructure.EntityConfigurations;

public class AccountProfileIdentifierEntityTypeConfiguration :
    AccountBaseConcurrentEntityTypeConfiguration<
        AccountProfileIdentifier, AccountProfileDbContext>
{
    protected override string TableName => "account_profile_identifier";

    protected override void ConfigureTable(EntityTypeBuilder<AccountProfileIdentifier> builder)
    {
        builder.HasKey(x => x.RowId);
    }
}