﻿using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Shared.Entities;

using Enterprise.Shared.Database;

namespace Account.PaymentInstruction.Shared.Repositories;

public interface IPaymentInstructionStatusRepository : IRepository
{
    /// <summary>
    ///     Insert <see cref="PaymentInstructionStatus" /> into the database
    /// </summary>
    /// <param name="paymentInstructionStatus">
    ///     <see cref="PaymentInstructionStatus" />
    /// </param>
    void Add(PaymentInstructionStatus paymentInstructionStatus);

    /// <summary>
    ///     Get <see cref="PaymentInstructionStatus" /> from the database
    /// </summary>
    /// <param name="clientBatchId">The batch id</param>
    /// <param name="clientId">The client id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    Task<PaymentInstructionStatus[]> GetAsync(
        string clientBatchId,
        string clientId,
        CancellationToken cancellationToken);
}