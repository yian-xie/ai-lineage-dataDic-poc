﻿using System;

using HotChocolate;

namespace Account.PaymentInstruction.Api.Queries.Types;

[GraphQLName("PaymentInstructionStatus")]
public class PaymentInstructionStatus
{
    [GraphQLName("batchId")] public string? BatchId { get; set; }

    [GraphQLName("status")] public Status Status { get; set; }

    [GraphQLName("statusDate")] public DateTimeOffset StatusDate { get; set; }
}