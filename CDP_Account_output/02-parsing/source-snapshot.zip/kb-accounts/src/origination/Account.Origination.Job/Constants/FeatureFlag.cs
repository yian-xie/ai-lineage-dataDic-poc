﻿namespace Account.Origination.Job.Constants
{
    public static class FeatureFlag
    {
        public const string UseTmvRestApiClient = "enable_use_tmv_rest_api_client";
        // TODO: AB#804747 - Remove this feature flag once fully rolled out
        public const string EnableDecoupleBankingRelationship = "enable_decouple_banking_relationship";
    }
}