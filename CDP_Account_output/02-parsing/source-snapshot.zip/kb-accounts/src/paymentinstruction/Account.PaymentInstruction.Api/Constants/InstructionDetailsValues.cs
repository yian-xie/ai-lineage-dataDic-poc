﻿namespace Account.PaymentInstruction.Api.Constants;

/// <summary>
/// Payment Instruction Details additional properties values.
/// </summary>
public static class InstructionDetailsValues
{
    /// <summary>
    /// Transaction code for credit.
    /// </summary>
    public const string TransactionCodeCodeCredit = "32";

    /// <summary>
    /// Transaction source code for credit.
    /// </summary>
    public const string TransactionCodeSourceCodeCredit = "CT";

    /// <summary>
    /// Transaction code for debit.
    /// </summary>
    public const string TransactionCodeCodeDebit = "52";

    /// <summary>
    /// Transaction source code for debit.
    /// </summary>
    public const string TransactionCodeSourceCodeDebit = "DT";

    /// <summary>
    /// Payment instruction category for intra core transfer.
    /// </summary>
    public const string PaymentInstructionCategoryIntraCoreTransfer = "IntraCoreTransfer";

    /// <summary>
    /// Payment instruction leg for credit.
    /// </summary>
    public const string PaymentInstructionLegCredit = "Credit";

    /// <summary>
    /// Payment instruction leg for debit.
    /// </summary>
    public const string PaymentInstructionLegDebit = "Debit";
}