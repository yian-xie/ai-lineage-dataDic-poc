﻿using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Api.Queries.Types;
using Account.PaymentInstruction.Api.Services;

using HotChocolate;
using HotChocolate.Authorization;
using HotChocolate.Types;

namespace Account.PaymentInstruction.Api.Queries;

/// <summary>
///     The Payment Instruction Api query to return <see cref="PaymentInstructionWithStatus" />.
/// </summary>
public class PaymentInstructionQuery
{
    /// <summary>
    ///     Get a list of <see cref="PaymentInstructionWithStatus" /> by transaction id.
    /// </summary>
    /// <param name="transactionId">The transaction id</param>
    /// <param name="paymentInstructionGetter">
    ///     <see cref="IPaymentInstructionGetter" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>A list of <see cref="PaymentInstructionWithStatus" /></returns>
    [Authorize(Policy = "PaymentInstructionView")]
    [UseResolverScope]
    public async Task<PaymentInstructionWithStatus[]?> PaymentInstructionsAsync(
        string transactionId,
        [Service] IPaymentInstructionGetter paymentInstructionGetter,
        CancellationToken cancellationToken)
    {
        return await paymentInstructionGetter.GetAsync(transactionId, cancellationToken);
    }

    /// <summary>
    ///     Get <see cref="PaymentInstructionWithStatus" /> by Client Batch id and Client id.
    /// </summary>
    /// <param name="clientBatchId">Client Batch id</param>
    /// <param name="clientId">Client id</param>
    /// <param name="paymentInstructionGetter">
    ///     <see cref="IPaymentInstructionGetter" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="PaymentInstructionWithStatus" />
    /// </returns>
    [Authorize(Policy = "PaymentInstructionView")]
    [UseResolverScope]
    public async Task<PaymentInstructionWithStatus?> PaymentInstructionAsync(
        string clientBatchId,
        string clientId,
        [Service] IPaymentInstructionGetter paymentInstructionGetter,
        CancellationToken cancellationToken)
    {
        return await paymentInstructionGetter.GetAsync(clientBatchId, clientId, cancellationToken);
    }
}