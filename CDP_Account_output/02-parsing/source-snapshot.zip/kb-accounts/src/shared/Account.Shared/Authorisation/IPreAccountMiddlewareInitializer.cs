﻿using HotChocolate.Resolvers;

namespace Account.Shared.Authorisation;

public interface IPreAccountMiddlewareInitializer
{
    /// <summary>
    /// Process the HTTP context before the account middleware <see cref="AccountMiddleware"/> is executed.
    /// </summary>
    /// <param name="context"><see cref="IMiddlewareContext"/></param>
    void PreProcess(IMiddlewareContext context);
}