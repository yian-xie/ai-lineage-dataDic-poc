﻿using System;

using HotChocolate;

namespace Account.PaymentInstruction.Api.Queries.Types;

[GraphQLName("PaymentInstruction")]
public class PaymentInstruction
{
    [GraphQLName("id")] public string Id { get; set; }

    [GraphQLName("transactionId")] public string TransactionId { get; set; }

    [GraphQLName("clientId")] public string ClientId { get; set; }

    [GraphQLName("clientBatchId")] public string ClientBatchId { get; set; }

    [GraphQLName("type")] public TransactionType Type { get; set; }

    [GraphQLName("requestDate")] public DateTimeOffset RequestDate { get; set; }

    [GraphQLName("valueDate")] public DateTimeOffset? ValueDate { get; set; }

    [GraphQLName("description")] public string? Description { get; set; }

    [GraphQLName("lifecycle")] public Lifecycle Lifecycle { get; set; }
}