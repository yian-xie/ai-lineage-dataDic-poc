﻿using System.Collections.Generic;

namespace Account.Shared.FeatureFlags;

public sealed class LaunchDarklyOptions
{
    public const string ConfigurationKey = "LaunchDarkly";

    public string UserKey { get; set; }
    public string SdkKey { get; set; }
    public Dictionary<string, string> FlagValues { get; set; } = new();
}