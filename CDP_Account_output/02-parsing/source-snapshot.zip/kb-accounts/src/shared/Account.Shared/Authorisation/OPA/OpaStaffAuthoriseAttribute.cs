﻿using System;
using System.Threading.Tasks;

using Kb.Api.Infrastructure.Authorization.OPA;

using Microsoft.AspNetCore.Http;

namespace Account.Shared.Authorisation.OPA;

[AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
public class OpaStaffAuthoriseAttribute : OpaAuthoriseAttributeBase
{
    protected override async Task AuthoriseAsync(
        IOpaAuthorizationService authorizationService,
        HttpContext httpContext)
    {
        await OpaAuthoriseAttributeHelper.Authorise(
            this,
            authorizationService,
            () => Task.FromResult<string>(null));
    }
}