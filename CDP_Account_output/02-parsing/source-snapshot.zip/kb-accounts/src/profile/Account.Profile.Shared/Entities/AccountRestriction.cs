﻿using System;

using Account.Shared.Entities;

#nullable enable

namespace Account.Profile.Shared.Entities;

public class AccountRestriction : AccountBaseEntity
{
    /// <summary>
    /// Event Id
    /// </summary>
    public required string EventId { get; set; }
    /// <summary>
    /// Restriction Set Id
    /// </summary>
    public required string RestrictionSetId { get; set; }
    /// <summary>
    /// Change Id
    /// </summary>
    public long? ChangeId { get; set; }
    /// <summary>
    /// Effective date time
    /// </summary>
    public DateTimeOffset? EffectiveAt { get; set; }
    /// <summary>
    /// Expiry date time
    /// </summary>
    public DateTimeOffset? ExpiryAt { get; set; }
    /// <summary>
    /// Processing date time
    /// </summary>
    public DateTimeOffset ProcessingAt { get; set; }
    /// <summary>
    /// Type
    /// </summary>
    public string? Type { get; set; }
    /// <summary>
    /// Description
    /// </summary>
    public string? Description { get; set; }
    /// <summary>
    /// Is active to indicate if the restriction is still effective or not
    /// </summary>
    public bool IsActive { get; set; }
    /// <summary>
    /// Restriction set event payload
    /// </summary>
    public byte[]? RestrictionSetEventPayload { get; set; }
    /// <summary>
    /// <see cref="AccountProfile"/>
    /// </summary>
    public AccountProfile Profile { get; set; }
}