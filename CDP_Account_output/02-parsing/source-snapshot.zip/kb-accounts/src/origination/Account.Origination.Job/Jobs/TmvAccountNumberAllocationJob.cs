﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Activities;
using Account.Origination.Job.Constants;
using Account.Origination.Job.Infrastructure.Resilience;
using Account.Origination.Job.Services;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Repositories;
using Account.Shared.FeatureFlags;
using Account.Shared.Metrics;

using Enterprise.Shared.Database;

using Kb.Api.Observability.Metrics;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Jobs;

public class TmvAccountNumberAllocationJob<TQuery>(
    ITmvCustomerAction tmvCustomerAction,
    ITmvAccountActionGetter tmvAccountActionGetter,
    IDbTransactionBuilder dbTransactionBuilder,
    IOptions<AccountOriginationJobOptions> accountOriginationJobOptions,
    TimeProvider timeProvider,
    ILogger<TmvAccountNumberAllocationJob<TQuery>> logger,
    IAccountOriginationActivity accountOriginationActivity,
    IProfilingMetrics metrics,
    IAccountNumberAllocationService accountNumberAllocationService,
    IPartyClient partyClient,
    IFeatureService featureService,
    IStandardResiliencePipeline<ICollection<PartyResultDto>, DefaultResilienceStrategy, IPartyClient> resiliencePipeline)
    : AccountOriginationJobBase<TQuery>(
        tmvCustomerAction,
        tmvAccountActionGetter,
        dbTransactionBuilder,
        accountOriginationJobOptions,
        timeProvider,
        logger,
        accountOriginationActivity,
        partyClient,
        featureService,
        resiliencePipeline,
        metrics,
        "Allocate TMV account number")
    where TQuery : IAccountOpeningGetReadyJobQuery
{
    private readonly IProfilingMetrics _metrics = metrics;

    protected override async Task<Domain.Account?> DoWorkInternalAsync(
        AccountOpening accountOpening,
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken)
    {
        try
        {
            var partyIds = new[] { accountOpening.PartyId.ToString()! };
            var result = await PartyResiliencePipeline.ExecuteAsync(
                async ct => await PartyClient.GetPartyProfilesAsync(partyIds, ct),
                cancellationToken,
                new
                {
                    PartyIds = partyIds
                });

            var partyResultDto = result.Single();

            var accessNumber = int.Parse(partyResultDto.AccessNumber!);
            var accountNumber =
                await accountNumberAllocationService.AllocateAccountNumberAsync(accessNumber, accountOpening.ProductCode!, cancellationToken);

            logger.LogInformation("Account number has been allocated for account {accountId}",
                accountOpening.AccountId);

            UpdateAccountOpeningNumberAllocated(accountOpening, accountNumber.ToString(), repositoryFactory);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception e)
        {
            logger.LogError(e, "Failed to allocate account number for account {accountId}",
                accountOpening.AccountId);

            UpdateAccountOpeningFailed(accountOpening, TimeProvider.GetUtcNow(),
                repositoryFactory);

            var exceptionTag =
                new KeyValuePair<string, object>(TelemetryTagKeys.ExceptionType, e.GetType().Name);

            // Include the EventType tag (from base class) for proper observability filtering/grouping
            // This makes exception metrics attributable to the specific job/activity
            _metrics.Counter(string.Concat(Metrics.OriginationJob, Metrics.Exception), 1,
                [.. GetStandardTagList(), exceptionTag]);
        }

        return null;
    }
}