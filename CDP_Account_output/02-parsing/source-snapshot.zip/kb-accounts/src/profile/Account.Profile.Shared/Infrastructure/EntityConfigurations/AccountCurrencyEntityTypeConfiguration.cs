﻿using Account.Profile.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.Profile.Shared.Infrastructure.EntityConfigurations;

public class AccountCurrencyEntityTypeConfiguration :
    AccountBaseConcurrentEntityTypeConfiguration<AccountCurrency, AccountProfileDbContext>
{
    protected override string TableName => "account_currency";

    protected override void ConfigureTable(EntityTypeBuilder<AccountCurrency> builder)
    {
        builder.HasKey(x => x.RowId);
    }
}