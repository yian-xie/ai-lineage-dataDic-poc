﻿namespace Account.Shared.Constants.Tmv;

/// <summary>
///     EDM TSide Names.
/// </summary>
public static class TSideNames
{
    public const string Asset = "Asset";
    public const string Liability = "Liability";
    public const string Unknown = "Unknown";
}