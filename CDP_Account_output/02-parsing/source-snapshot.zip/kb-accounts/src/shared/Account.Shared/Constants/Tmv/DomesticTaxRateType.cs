﻿namespace Account.Shared.Constants.Tmv;

/// <summary>
///     All TMV withholding_tax_type.
/// </summary>
public static class DomesticTaxRateType
{
    /// <summary>
    /// Resident withholding tax
    /// </summary>
    public const string RWT = "RWT";
    /// <summary>
    /// Non-Resident withholding tax
    /// </summary>
    public const string NRWT = "NRWT";
    /// <summary>
    /// Approved issuer levy
    /// </summary>
    public const string AIL = "AIL";
}