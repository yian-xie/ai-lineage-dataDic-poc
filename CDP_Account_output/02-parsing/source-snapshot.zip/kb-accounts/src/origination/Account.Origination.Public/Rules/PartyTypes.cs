﻿
namespace Account.Origination.Public.Rules
{
    internal static class PartyTypes
    {
        internal const string Personal = "PERSON";
        internal const string Organisation = "ORGANISATION";
    }
}