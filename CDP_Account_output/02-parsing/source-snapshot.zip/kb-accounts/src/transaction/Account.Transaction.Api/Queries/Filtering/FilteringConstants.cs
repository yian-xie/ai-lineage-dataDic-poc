﻿namespace Account.Transaction.Api.Queries.Filtering;

/// <summary>
/// Defines payment instruction category constants used for filtering transactions.
/// </summary>
public static class PaymentInstructionCategoryConstants
{
    /// <summary>
    /// PaymentInstructionCategory value used to mark special technical
    /// transactions created only for migration purposes.
    ///
    /// These entries are filtered out of transactions history responses.
    /// Transactions with other categories are returned normally.
    /// </summary>
    public const string Migration = "Migration";
}