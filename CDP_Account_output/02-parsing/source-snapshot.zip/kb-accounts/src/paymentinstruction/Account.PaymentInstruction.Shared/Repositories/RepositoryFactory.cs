﻿using Account.PaymentInstruction.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.PaymentInstruction.Shared.Repositories;

public class RepositoryFactory(
    PaymentInstructionDbContext dbContext,
    IPaymentInstructionRepository paymentInstructionRepository,
    IPaymentInstructionStatusRepository paymentInstructionStatusRepository) : IRepositoryFactory
{
    public PaymentInstructionDbContext DbContext { get; } = dbContext;
    public IUnitOfWork UnitOfWork { get; } = dbContext;

    public IPaymentInstructionRepository PaymentInstructionRepository { get; } =
        paymentInstructionRepository;

    public IPaymentInstructionStatusRepository PaymentInstructionStatusRepository { get; } =
        paymentInstructionStatusRepository;
}