﻿namespace Account.Shared.Authorisation.Constants.OPA;

public static class PolicyPaths
{
    public const string AccountAssert = "/v1/data/accounts/graphql_api/assert";
}