﻿namespace Account.Origination.Processor.Configurations;

/// <summary>
///     The AccountOriginationProcessorOptions settings defined in appsettings.json.
/// </summary>
public class AccountOriginationProcessorOptions
{
    /// <summary>
    ///     Validity period in days for account opening.
    /// </summary>
    public int ValidityPeriodDays { get; init; } = 14;
}