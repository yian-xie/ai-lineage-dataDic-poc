﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddOutboxItemIndex : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "idx_outbox_retry_last_retry",
                table: "outbox",
                columns: new[] { "retry_count", "last_retry", "id" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "idx_outbox_retry_last_retry",
                table: "outbox");
        }
    }
}