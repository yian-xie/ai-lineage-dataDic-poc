﻿using Account.Profile.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.Profile.Shared.Infrastructure.EntityConfigurations;

public class AccountProfileEntityTypeConfiguration : AccountBaseConcurrentEntityTypeConfiguration<
    AccountProfile, AccountProfileDbContext>
{
    protected override string TableName => "account_profile";

    protected override void ConfigureTable(EntityTypeBuilder<AccountProfile> builder)
    {
        builder.HasKey(profile => profile.AccountId);
        builder.ComplexProperty(profile => profile.DomesticTaxRate).IsRequired();
        builder.ComplexProperty(profile => profile.ProductFacility).IsRequired();
        builder.ComplexProperty(profile => profile.BankingRelationship).IsRequired();
        builder.ComplexProperty(profile => profile.AccountFreezeDetails).IsRequired();

        builder.Property(profile => profile.Name)
            .IsRequired()
            .HasMaxLength(130);

        builder.Property(profile => profile.AlternateName)
            .HasMaxLength(130);

        builder.Property(profile => profile.AccountClosureReason);

        builder.HasMany(profile => profile.Identifiers)
            .WithOne(identifier => identifier.Profile)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasMany(profile => profile.AccountCurrencies)
            .WithOne(identifier => identifier.Profile)
            .OnDelete(DeleteBehavior.Cascade);
    }
}