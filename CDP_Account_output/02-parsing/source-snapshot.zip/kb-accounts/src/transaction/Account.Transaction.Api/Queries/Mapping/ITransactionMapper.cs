﻿using System.Linq;

namespace Account.Transaction.Api.Queries.Mapping;

/// <summary>
///     Provide mapping functionality to map from source class TSource to target class TTarget.
/// </summary>
public interface ITransactionMapper<in TSource, out TTarget> where TSource : class where TTarget : class
{
    /// <summary>
    ///     Mapping the <see cref="IQueryable{TSource}" /> to <see cref="IQueryable{TTarget}" /> where TSource and TTarget are class.
    /// </summary>
    /// <param name="query"><see cref="IQueryable{TSource}" /> where TSource is a class</param>
    /// <param name="accountId">Account Id is from query parameter which used for mapping for Credit Card and Ultracs</param>
    /// <returns><see cref="IQueryable{TTarget}" /> where TTarget is a class</returns>
    IQueryable<TTarget> MapTo(IQueryable<TSource> query, string accountId);
}