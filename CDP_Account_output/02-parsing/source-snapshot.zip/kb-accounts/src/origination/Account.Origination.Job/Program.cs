﻿using Account.Origination.Job.Extension;

using Enterprise.Shared.Application.WebHostService;

namespace Account.Origination.Job;

public class Program : WebHostServiceBase<Program>
{
    public static void Main(string[] args)
    {
        var built = CreateHostBuilder(args).Build();
        _ = built.LoadSemanticVersionCache();
        built.Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args)
    {
        return createWebHostBuilder<Startup>(args);
    }
}