﻿using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Events;

using Confluent.Kafka;

using Enterprise.Shared.Kafka.Produce;
using Enterprise.Shared.Telemetry;

namespace Account.Shared.Kafka.Produce
{
    public interface ITmvEventPublisher<in TEvent> where TEvent : IEvent
    {
        Task PublishAsync(TEvent outgoingEvent, CancellationToken cancellationToken);
    }

    /// <summary>
    ///     Publishes messages directly to Kafka. This implementation is a spin
    ///     on <see cref="KafkaEventPublisher{TEvent}" /> whereby allowing TEvent
    ///     to be of type IEvent (i.e.: not IMetadataEvent)
    ///     This is useful if we want to publish Events to TMV where no Metadata
    ///     is actually required.
    /// </summary>
    /// <remarks>
    ///     Use where data is not at risk of being lost.
    ///     Where there is the risk of losing data, use <see cref="OutboxEventPublisher{TEvent}" />
    /// </remarks>
    /// <typeparam name="TEvent"></typeparam>
    public class TmvEventPublisher<TEvent> : KafkaPublisher<Null, TEvent>,
        ITmvEventPublisher<TEvent>
        where TEvent : class, IEvent
    {
        public TmvEventPublisher(
            IProducer<Null, TEvent> producer,
            IActivityAccessor activityAccessor,
            IActivityPropagator<Headers> activityPropagator,
            // ReSharper disable once SuggestBaseTypeForParameterInConstructor
            TmvKafkaSettings kafkaSettings) :
            base(producer, activityAccessor, activityPropagator,
                kafkaSettings)
        { }

        public Task PublishAsync(TEvent outgoingEvent, CancellationToken cancellationToken)
        {
            return PublishAsync(null, outgoingEvent, cancellationToken);
        }
    }
}