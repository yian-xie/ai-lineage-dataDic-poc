﻿using System.Threading;
using System.Threading.Tasks;

using Account.Posting.Shared.Entities;
using Account.Posting.Shared.Infrastructure;

using Enterprise.Shared.Database;

using Microsoft.EntityFrameworkCore;

namespace Account.Posting.Shared.Repositories;

public class TmvPostingBatchRepository(AccountPostingDbContext dbContext)
    : RepositoryBase<AccountPostingDbContext>(dbContext), ITmvPostingBatchRepository
{
    public void Add(TmvPostingBatch tmvPostingBatch)
    {
        DbContext.TmvPostingBatch.Add(tmvPostingBatch);
    }

    public async Task<TmvPostingBatch> GetByIdAsync(string id, CancellationToken cancellationToken)
    {
        return await DbContext.TmvPostingBatch
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }
}