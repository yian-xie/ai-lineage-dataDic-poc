﻿using Account.Posting.Shared.Entities;
using Account.Posting.Shared.Infrastructure.EntityConfigurations;
using Account.Shared.Constants;
using Account.Shared.Database;

using Enterprise.Shared.Database.Configurations;

using Microsoft.EntityFrameworkCore;

namespace Account.Posting.Shared.Infrastructure;

public class AccountPostingDbContext(
    DbContextOptions<AccountPostingDbContext> options,
    CustomDbContextOptions customDbContextOptions)
    : AccountBaseDbContext<AccountPostingDbContext>(options, customDbContextOptions),
        IDbContextSchemaName
{
    public DbSet<TmvPostingBatch> TmvPostingBatch { get; set; }

    public static string SchemaName()
    {
        return DatabaseSchemaName.Posting;
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfiguration(new TmvPostingBatchEntityTypeConfiguration());
    }
}