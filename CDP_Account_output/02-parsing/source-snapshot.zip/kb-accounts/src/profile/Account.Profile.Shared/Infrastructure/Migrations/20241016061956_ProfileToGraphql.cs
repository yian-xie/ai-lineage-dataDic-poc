﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ProfileToGraphql : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "trace_context",
                schema: "profile",
                table: "account_profile",
                newName: "withholding_tax_withholding_tax_type");

            migrationBuilder.AddColumn<string>(
                name: "product_facility_banking_product_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "product_facility_banking_product_version_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "withholding_tax_withholding_tax_rate",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "account_profile_identifier",
                schema: "profile",
                columns: table => new
                {
                    row_id = table.Column<Guid>(type: "uuid", nullable: false),
                    account_identification = table.Column<string>(type: "text", nullable: true),
                    account_identification_type = table.Column<string>(type: "text", nullable: true),
                    account_profile_account_id = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_account_profile_identifier", x => x.row_id);
                    table.ForeignKey(
                        name: "fk_account_profile_identifier_account_profile_account_profile_",
                        column: x => x.account_profile_account_id,
                        principalSchema: "profile",
                        principalTable: "account_profile",
                        principalColumn: "account_id");
                });

            migrationBuilder.CreateIndex(
                name: "ix_account_profile_identifier_account_profile_account_id",
                schema: "profile",
                table: "account_profile_identifier",
                column: "account_profile_account_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "account_profile_identifier",
                schema: "profile");

            migrationBuilder.DropColumn(
                name: "product_facility_banking_product_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "product_facility_banking_product_version_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "withholding_tax_withholding_tax_rate",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.RenameColumn(
                name: "withholding_tax_withholding_tax_type",
                schema: "profile",
                table: "account_profile",
                newName: "trace_context");
        }
    }
}