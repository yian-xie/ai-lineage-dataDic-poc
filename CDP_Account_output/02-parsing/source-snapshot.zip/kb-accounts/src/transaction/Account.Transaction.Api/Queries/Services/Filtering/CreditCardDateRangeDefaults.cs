﻿using System;

using Account.Transaction.Api.Queries.Services.Models;

namespace Account.Transaction.Api.Queries.Services.Filtering;

/// <summary>
/// Get default date ranges for Credit Card transactions.
/// </summary>
/// <param name="timeProvider"><see cref="TimeProvider"/></param>
public class CreditCardDateRangeDefaults(TimeProvider timeProvider) : ICreditCardDateRangeDefaults
{
    /// <summary>
    /// Get default date ranges for Credit Card transactions.
    /// if both fromDateTime and toDateTime are null, set fromDateTime to 6 months ago and toDateTime to current date.
    /// if fromDateTime is provided but toDateTime is null, set toDateTime to fromDateTime + 6 months or current date, whichever is earlier.
    /// if toDateTime is provided, use it as is.
    /// if only toDateTime is provided, set fromDateTime to toDateTime - 6 months.
    /// </summary>
    /// <param name="fromDateTime">From datetime <see cref="DateTimeOffset"/></param>
    /// <param name="toDateTime">To datetime <see cref="DateTimeOffset"/></param>
    /// <returns><see cref="DateRange"/></returns>
    public DateRange Get(DateTimeOffset? fromDateTime, DateTimeOffset? toDateTime)
    {
        var currentDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(timeProvider.GetUtcNow(), TimeZoneIds.NewZealandStandardTime).Date;
        var fromDate = fromDateTime.HasValue ? TimeZoneInfo.ConvertTimeBySystemTimeZoneId(fromDateTime.Value, TimeZoneIds.NewZealandStandardTime).Date : currentDate.AddMonths(-6);

        var toDate = toDateTime.HasValue
            ?
            TimeZoneInfo
                .ConvertTimeBySystemTimeZoneId(toDateTime.Value,
                    TimeZoneIds.NewZealandStandardTime)
                .Date
            : fromDateTime.HasValue
                ? fromDate.AddMonths(6) < currentDate ? fromDate.AddMonths(6) : currentDate
                : currentDate;

        return new DateRange(fromDate, toDate, currentDate);
    }
}