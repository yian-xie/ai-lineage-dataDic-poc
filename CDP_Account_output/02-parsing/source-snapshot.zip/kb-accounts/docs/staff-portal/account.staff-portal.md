# Staff Portal

Staff Portal and associated functionality used for administration, validation and misc testing purposes. 


Read [Staff Portal Functional Specs](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/4346284500/Account+Spud) for more information on purpose and intent.

![Staff Portal Container View](./container/account.staff-portal.svg)

![Staff Portal Use Case Diagram](./use-case/account.staff-portal.svg)

## Services


### Account.Spud.API
Provides 

View [Implementation Details ](../../src/spud/Account.Spud.API/README.md)

