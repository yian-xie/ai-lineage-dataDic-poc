﻿namespace Account.Transaction.Api.Observability;

/// <summary>
/// Observability metric names.
/// </summary>
public static class MetricNames
{
    /// <summary>
    /// Transaction API response error count metric name.
    /// </summary>
    public const string ResponseErrorCountMetric = "transaction-api-response-error-count";

    /// <summary>
    /// Ultracs transaction future date issue count metric name.
    /// </summary>
    public const string UltracsTransactionFutureDateIssueCountMetric = "ultracs-transaction-future-date-issue-count";

    /// <summary>
    /// Ultracs Proxy API response error count metric name.
    /// </summary>
    public const string UltracsProxyApiResponseErrorCountMetric = "ultracs-proxy-api-response-error-count";

    /// <summary>
    /// Ultracs transactions call duration metric name.
    /// </summary>
    public const string UltracsTransactionCallDurationMetric = "ultracs-transactions-call-duration";

    /// <summary>
    /// Ultracs authorisation transactions call duration metric name.
    /// </summary>
    public const string UltracsAuthorisationCallDurationMetric = "ultracs-authorisation-transactions-call-duration";

    /// <summary>
    /// Ultracs Proxy API.
    /// </summary>
    public const string UltracsProxyApi = "UltracsProxyApi";

    /// <summary>
    /// Cards API.
    /// </summary>
    public const string CardsApi = "CardsTransactionsApi";

    /// <summary>
    /// Error code tag key for metrics.
    /// </summary>
    public const string ErrorCodeTagKey = "error_code";

    /// <summary>
    /// Ultracs transaction type tag key for metrics.
    /// </summary>
    public const string UltracsTransactionTypeTagKey = "transaction_type";

    /// <summary>
    /// Ultracs future date issue retry tag for metrics.
    /// </summary>
    public const string UltracsFutureDateIssueRetryTag = "future_date_issue_retry";

    /// <summary>
    /// Ultracs Transactions tag value for metrics.
    /// </summary>
    public const string UltracsTransactions = "Transactions";

    /// <summary>
    /// Ultracs Authorisation Transactions tag value for metrics.
    /// </summary>
    public const string UltracsAuthorisationTransactions = "Authorisation Transactions";

    /// <summary>
    /// Account Domain Directory Service API.
    /// </summary>
    public const string AccountDomainDirectoryServiceApi = "AccountDomainDirectoryServiceApi";

    /// <summary>
    /// Account Domain Directory Service call duration metric name.
    /// </summary>
    public const string AccountDomainDirectoryServiceCallDurationMetric = "account-domain-directory-service-call-duration";

    /// <summary>
    /// Account Domain Directory Service error count metric name.
    /// </summary>
    public const string AccountDomainDirectoryServiceErrorCountMetric = "account-domain-directory-service-error-count";
}