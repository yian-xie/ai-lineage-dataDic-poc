﻿namespace Account.Origination.Public
{
    public class Party
    {
        public Party(string partyType, string firstName, string middleName, string lastName, string fullName)
        {
            PartyType = partyType;
            FirstName = firstName;
            LastName = lastName;
            MiddleName = middleName;
            FullName = fullName;
        }

        public string PartyType { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string MiddleName { get; private set; }
        public string FullName { get; private set; }

        public string? GetFirstNameInitials()
        {
            return (FirstName?.Trim().ToUpper().FirstOrDefault() is var ch && ch != '\0') ? ch.ToString() : string.Empty;
        }

        public string GetLastNameCapital()
        {
            return (LastName ?? string.Empty).ToUpper();
        }

        public string GetMiddleNameInitials()
        {
            return GetInitials(MiddleName);
        }

        private string GetInitials(string data)
        {
            if (string.IsNullOrWhiteSpace(data))
            { return string.Empty; }

            var middleNameComponents = data.ToUpper().Split(' ', StringSplitOptions.TrimEntries);
            return string.Join(' ', middleNameComponents.Select(mp => mp[0]));
        }
    }
}