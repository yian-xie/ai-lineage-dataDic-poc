﻿namespace Account.Profile.Shared.Entities;

public class AccountBankingRelationship
{
    public string BankingRelationshipId { get; set; }
    public string BankingRelationshipType { get; set; }
    public string[] PartyIds { get; set; }
    public string NominatedTaxPartyId { get; set; }
}