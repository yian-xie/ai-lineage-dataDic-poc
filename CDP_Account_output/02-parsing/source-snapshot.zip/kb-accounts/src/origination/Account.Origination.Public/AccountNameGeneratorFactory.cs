﻿using Account.Origination.Public.Interfaces;
using Account.Origination.Public.Rules;

namespace Account.Origination.Public
{
    public class AccountNameGeneratorFactory
    {
        public static IAccountNameGenerator CreateDefault()
        {
            IEnumerable<INameGenerator> dependencies = new List<INameGenerator>()
            {
                new MononymSinglePersonalPartyNameGenerator(),
                new PolynymSinglePersonalPartyNameGenerator()
            };

            return new AccountNameGenerator(dependencies);
        }
    }
}