﻿#nullable enable
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Shared.Authorisation.Constants;
using Account.Shared.Constants;
using Account.Shared.Kafka.Publishers;

using HotChocolate;
using HotChocolate.Resolvers;

using Kb.Api.Infrastructure.ErrorHandling.Exceptions;
using Kb.Api.Infrastructure.JwtTokenProvider;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;

namespace Account.Shared.Authorisation;

public class AccountMiddleware(
    FieldDelegate next,
    IHttpContextAccessor httpContextAccessor,
    IHostEnvironment hostEnvironment,
    IAccountAuditLogEventPublisher publisher,
    IPreAccountMiddlewareInitializer? preAccountAuthorisation)
{
    private readonly JwtSecurityTokenHandler _jwtSecurityTokenHandler = new();

    /// <summary>
    /// Processes the GraphQL middleware pipeline by handling GraphQL request and audit logging.
    /// For staff tokens, publishes audit log events. For customer tokens, extracts and sets the access number.
    /// </summary>
    /// <param name="context">The GraphQL middleware context.</param>
    /// <param name="jwtTokenProviders">Collection of JWT token providers used to extract customer access numbers.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    /// <exception cref="UnauthorizedException">Thrown when the access number cannot be retrieved from the customer token.</exception>
    public async Task InvokeAsync(
        IMiddlewareContext context,
        [Service] IEnumerable<IJwtTokenProvider> jwtTokenProviders)
    {
        // get transaction type and clean account id if there's any valid prefix attached to the account id.
        preAccountAuthorisation?.PreProcess(context);

        if (httpContextAccessor.HttpContext is not null && IsStaffToken(httpContextAccessor.HttpContext))
        {
            // audit log only required for staff token
            await publisher.PublishAccountAuditLogEventAsync(
                context,
                httpContextAccessor.HttpContext,
                hostEnvironment.ApplicationName,
                CancellationToken.None);
            context.SetLocalState(LocalStateConstants.IsStaffKey, true);

            await next(context);

            return;
        }

        // Get access number from customer token
        var accessNumber = GetAccessNumber(jwtTokenProviders);
        context.SetLocalState(LocalStateConstants.AccessNumberKey, accessNumber);

        await next(context);
    }

    private bool IsStaffToken(HttpContext httpContext)
    {
        var authorization = httpContext.Request.Headers.Authorization.ToString();

        if (string.IsNullOrWhiteSpace(authorization))
        {
            throw new UnauthorizedException(ErrorMessages.AuthorizationHeaderIsMissing);
        }

        var splitToken = authorization.Split(" ");

        return splitToken switch
        {
            [_, { } token] when _jwtSecurityTokenHandler.CanReadToken(token) => true,
            _ => false
        };
    }

    private static int GetAccessNumber(IEnumerable<IJwtTokenProvider> jwtTokenProviders)
    {
        var tokenProvider =
            jwtTokenProviders.FirstOrDefault(jwtTokenProvider =>
                jwtTokenProvider.CanProvideToken());

        try
        {
            var identity = tokenProvider?.GetClaimsPrincipal().Identities.FirstOrDefault();

            if (int.TryParse(identity?.Name, out var accessNumber))
            {
                return accessNumber;
            }
        }
        catch (SecurityTokenMalformedException) { }

        throw new UnauthorizedException(ErrorMessages.FailedToGetAccessNumber);
    }
}