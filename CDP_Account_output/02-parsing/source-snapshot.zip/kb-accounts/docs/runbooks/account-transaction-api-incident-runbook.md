## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | `Account.Transaction.Api` |
| Customer or business impact | Authorised customers and staff cannot retrieve TMV, credit-card, or Ultracs transaction history, or receive incomplete results. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Transaction API Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/AYDrPAE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33944146)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>GraphQL API unavailable or readiness failing</summary>

**Symptoms**

- Availability or non-HTTP-5xx SLO alerts fire for `accounts-transaction-api`.
- Pods in `prod-transaction-api` are not ready, or `/health/readiness` fails while `/health/liveness` may remain healthy.
- TMV transaction queries fail because the readiness check and TMV query path depend on PostgreSQL.

**Actions**

1. For a non-production check, request `GET https://accept-accounts-transaction.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz/health/readiness`. Authentication is not specified for the probe; expected result is HTTP 200. This internal host is not verified as laptop-reachable. [TODO: confirm the VPN/private-DNS or other access path and health-response body.]
2. Filter sumo [logs](https://kbprod.au.sumologic.com/library/33944146) by Kubernetes namespace (`accept-transaction-api`, `situat-transaction-api`, `perf0-transaction-api`, `preprod-transaction-api`, or `prod-transaction-api`) and correlate SQL errors with readiness failures and the deployment time.
3. If the failure began with a release, stop further promotion and use the approved pipeline rollback or fix-forward procedure. [TODO: confirm the approved pipeline rollback procedure.]

**Recovery check**

- Readiness returns HTTP 200 in ACCEPT, pods remain ready, and GraphQL success rate and latency return to their pre-incident range.

**Escalate when**

- PostgreSQL remains unavailable, production readiness continues to fail, or customer queries remain unavailable after the application deployment is healthy.

</details>

<details>
<summary>Account routing or authorisation failures</summary>

**Symptoms**

- GraphQL errors increase with `UNAUTHORIZED`, `FORBIDDEN`, or internal-server error codes.
- Logs contain `Account with ID` and `was not found in the Account Domain Directory Service`, `Token auth failure from downstream`, `Forbidden from downstream`, or `ApiException occurred`.
- TMV or Ultracs requests fail before their transaction source is queried.

**Actions**

1. Filter `Account.Transaction.Api` logs for the exact messages above and group by HTTP status and environment; do not include account IDs in incident communications.
2. Distinguish expected 401/403 responses for invalid or expired credentials from ADDS 5xx/timeouts affecting valid requests.
3. Confirm the configured ADDS target for the affected deployment; ACCEPT uses `account-domain-directory-service-web-api-svc-accept.accept-account-domain-directory-service-web-api.svc.cluster.local`.

**Recovery check**

- ADDS error count returns to baseline and valid authorised GraphQL requests route to TMV, Cards, or Ultracs without server errors.

**Escalate when**

- Valid users fail across multiple accounts, ADDS returns sustained 5xx/timeouts, or routing produces unsupported transaction-type errors for known account sources.

</details>

<details>
<summary>Cards transaction dependency failing</summary>

**Symptoms**

- Credit-card transaction queries return `RECEIVED_CREDIT_CARD_TRANSACTION_EXCEPTION_FROM_CARDS_API`, `SERVICE_UNAVAILABLE`, or internal-server errors.
- Logs contain `Fail in fetching credit card transactions for access number` or `Partial success in fetching credit card transactions`.
- The `call-duration` metric tagged for the Cards API rises toward the configured 25-second timeout.

**Actions**

1. Use the linked observability page to compare Credit Card synthetic checks, downstream call duration, GraphQL errors, and overall API health.
2. Filter logs for the two exact Cards messages and correlate by trace ID; do not expose access numbers outside approved logs.
3. Confirm that the deployment has the `transaction-api` secret and mTLS material configured; do not rotate or replace certificates during triage without an approved procedure.
4. Use the ACCEPT Cards synthetic check as the non-production verification path. Direct laptop calls require the repository-documented mTLS certificate setup; no direct endpoint request was verified during runbook generation.

**Recovery check**

- The ACCEPT Credit Card synthetic and downstream checks pass, Cards call duration returns to baseline, and credit-card GraphQL requests no longer return dependency errors.

**Escalate when**

- The Cards downstream synthetic remains failed, mTLS material is missing or invalid, or partial responses continue after downstream recovery.

</details>

<details>
<summary>Ultracs transaction dependency failing</summary>

**Symptoms**

- Ultracs transaction or authorisation queries return internal-server errors.
- Logs contain `Ultracs returned an error`, `Ultracs returned future date error`, or `Retry fetching`.
- `ultracs-proxy-api-response-error-count` rises, or Ultracs call-duration metrics increase.

**Actions**

1. Use the linked observability page to compare Ultracs synthetic checks, response-error count, call duration, and Azure AD token failures.
2. Filter logs for the exact messages above and determine whether the built-in one-time retry with yesterday's `toDate` succeeds.
3. Confirm the environment's `UltracsClientOptions__BaseUrl` and the presence of `AzureAdTokenOptions__ClientSecret`; never copy the secret value into the incident record.
4. Use the ACCEPT Ultracs synthetic check as the non-production verification path. Direct requests require an Azure AD bearer token and internal network access; [TODO: confirm the supported laptop access procedure.]

**Recovery check**

- ACCEPT Ultracs synthetic checks pass, error-count and latency metrics return to baseline, and both transaction and authorisation queries succeed without exhausting the date retry.

**Escalate when**

- Token acquisition fails across pods, Ultracs Proxy remains unavailable, or the future-date retry continues to fail.

</details>

<details>
<summary>GraphQL request and context errors spike</summary>

**Symptoms**

- Request-validation, required-field, or internal-server GraphQL error codes rise while dependencies remain healthy.
- Logs or GraphQL errors report a missing access number, missing `AccountId`, missing transaction type, invalid date range, or unsupported origination source.

**Actions**

1. Group GraphQL errors by code and operation `transactionsV2`; separate caller validation errors from missing middleware context and unsupported-source server errors.
2. Check whether the spike aligns with a client or schema release. The endpoint is `POST /api/accounts-transaction/graphql`, requires OAuth 2.0, and is not verified as directly laptop-reachable outside local development.
3. For date errors, confirm the request obeys the repository rules: no future dates, `from` before `to`, at most two years in the past, and a maximum six-month Cards or 24-month Ultracs range.
4. For missing context or unsupported-source errors, stop further promotion of the responsible release and use the approved fix-forward or rollback path. [TODO: confirm the approved pipeline rollback procedure.]

**Recovery check**

- Server-side context errors return to baseline and valid `transactionsV2` operations succeed; expected invalid requests continue to receive validation errors.

**Escalate when**

- Required context is missing for valid requests, known account types are reported as unsupported, or the issue follows a shared authorisation or schema change.

</details>

<details>
<summary>Audit log event missing or outcome incorrect</summary>

**Symptoms**

- Transaction API requests complete, but the expected v2 `AccountAuditLogEvent` is not visible for the request, or the event has an unexpected `SUCCESS` or `FAILURE` outcome.
- `audit.events.emitted` does not increase with GraphQL traffic, or logs do not contain `Building audit log v2 event` for the affected request.
- The event does not identify `Account.Transaction.Api`, `/api/accounts-transaction/graphql`, the account primary record, or the request trace ID.

**Actions**

1. Filter `Account.Transaction.Api` logs for `Building audit log v2 event`; correlate `RequestPath`, `HasErrors`, and `TraceId` with the affected GraphQL request. Do not include account IDs, access numbers, tokens, or request variables in incident communications.
2. Verify the emitted v2 event in the affected non-production or production environment through the approved audit-event observability or Kafka access path. The event must have `Metadata.Type=AccountAuditLogCreated`, `Client=Account.Transaction.Api`, `RequestPath=/api/accounts-transaction/graphql`, `InteractionType=View`, and the matching account primary record. A request without GraphQL errors is expected to produce `Outcome=SUCCESS`; a request with resolver errors is expected to produce `Outcome=FAILURE`.
3. Confirm the deployment's Kafka settings by inspecting configuration, without exposing values: `Kafka__BootstrapServers`, `Kafka__SchemaRegistry__Url`, and `Kafka__OutgoingTopicPrefix`. ACCEPT uses outgoing prefix `accept`; the repository integration-test environment uses prefix `test`. [TODO: confirm the concrete v2 audit-event topic name and the approved production/rehearse consumer or dashboard access procedure.]
4. If the builder log is present but the event or `audit.events.emitted` signal is missing, investigate the shared audit outbox publisher, Kafka connectivity, schema registry access, and the deployment's Kafka secret names. Do not replay events, delete outbox records, or restart pods without an approved recovery procedure.
5. Reproduce only in the repository's non-production integration-test environment using the existing `Publish_AuditLogEvent_For_Successful_Staff_Request` and `Publish_Failed_AuditLogEvent_For_Partial_Success_Staff_Request` coverage. The test expects v2 events to be consumed by `KafkaTestProcessor` with outgoing prefix `test`; no production command or request was run while generating this runbook.

**Recovery check**

- A successful non-production `transactionsV2` request produces one v2 event with `Outcome=SUCCESS`, and a request with GraphQL errors produces one event with `Outcome=FAILURE`; both contain the expected client, path, account primary record, and trace correlation. `audit.events.emitted` returns to the request volume baseline.

**Escalate when**

- Events remain absent or have incorrect outcomes after the approved Kafka, schema registry, and outbox checks; `audit.events.emitted` remains stalled; or audit events cannot be verified in the affected environment because the required access path is unavailable.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>