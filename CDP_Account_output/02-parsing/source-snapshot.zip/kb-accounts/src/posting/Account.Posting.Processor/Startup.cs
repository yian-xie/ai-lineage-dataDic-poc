﻿using System;

using Account.Posting.Processor.Publishers;
using Account.Posting.Processor.Subscribers;
using Account.Posting.Shared;
using Account.Posting.Shared.Infrastructure;
using Account.Shared;
using Account.Shared.Configurations;
using Account.Shared.Extensions;
using Account.Shared.Metrics.Decorator;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using Enterprise.Shared.Kafka;
using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Posting.Processor;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        var retrySettings = Configuration.GetSection(RetrySettings.Key).Get<RetrySettings>();
        ArgumentNullException.ThrowIfNull(retrySettings);
        services.AddSingleton(retrySettings);

        AddPooledDbContextWithOutbox<AccountPostingDbContext>(services);

        UseKafka(services);
        services.AddTmvKafkaClusterConfigurations(configuration);

        services
            // TMV Kafka failover consumer to support TMV OAuth.
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvPibCreatedEventSubscriber, string, PostingBatchEvent>(configuration, GetKafkaSettings())
            .AddRepositories()
            .AddSingleton<IAccountPostingEventBuilder, AccountPostingEventBuilder>()
            .AddSingleton<IAccountPostingEventOutboxPublisher,
                AccountPostingEventOutboxPublisher>();

        services.AddAlertingServices(Configuration);

        services
            .Decorate<IIncomingEventSubscriber<PostingBatchEvent>,
                AccountIncomingEventSubscriberMetricDecorator<PostingBatchEvent>>();
    }
}