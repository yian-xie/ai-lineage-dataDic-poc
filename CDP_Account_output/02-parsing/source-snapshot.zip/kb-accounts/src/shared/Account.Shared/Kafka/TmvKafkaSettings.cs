﻿using Enterprise.Shared.Kafka;

namespace Account.Shared.Kafka
{
    public class TmvKafkaSettings : KafkaSettings
    {
        public new const string Key = "TmvKafka";
    }
}