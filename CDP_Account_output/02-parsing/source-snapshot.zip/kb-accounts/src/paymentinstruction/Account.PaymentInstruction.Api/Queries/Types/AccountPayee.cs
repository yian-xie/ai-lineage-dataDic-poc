﻿using HotChocolate;

namespace Account.PaymentInstruction.Api.Queries.Types;

[GraphQLName("AccountPayee")]
public class AccountPayee
{
    [GraphQLName("accountId")] public string AccountId { get; set; }
}