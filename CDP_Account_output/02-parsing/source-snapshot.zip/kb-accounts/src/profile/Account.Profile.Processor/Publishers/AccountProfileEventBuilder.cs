﻿#nullable enable

using System;
using System.Linq;

using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Services;
using Account.Profile.Shared.Entities;
using Account.Shared.Constants.Tmv;

using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using AccountStatus = Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile.AccountStatus;
using AsyncAPI = Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Metadata = Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile.Metadata;
using MetadataType = Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile.MetadataType;

namespace Account.Profile.Processor.Publishers;

/// <summary>
///     Implements IAccountProfileEventBuilder interface for building AccountProfileEvent.
/// </summary>
public class AccountProfileEventBuilder(TimeProvider timeProvider) : IAccountProfileEventBuilder
{
    private const string Source = "Account.Profile.Processor";


    /// <summary>
    ///     Build AccountProfileEvent.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="AccountProfile" />
    /// </param>
    /// ///
    /// <param name="metadataType">
    ///     <see cref="MetadataType" />
    /// </param>
    /// <param name="accountStatusTimestamp">The account status timestamp</param>
    /// <param name="correlationId">The correlation ID</param>
    /// <returns>
    ///     <see cref="AsyncAPI.AccountProfileEvent" />
    /// </returns>
    public AsyncAPI.AccountProfileEvent BuildEvent(AccountProfile accountProfile, MetadataType metadataType, DateTimeOffset accountStatusTimestamp, Guid? correlationId = null)
    {
        return new AsyncAPI.AccountProfileEvent
        {
            Metadata = new Metadata
            {
                Id = Guid.NewGuid(),
                Type = metadataType,
                Time = timeProvider.GetUtcNow(),
                CorrelationId = correlationId ?? accountProfile.CorrelationId,
                Source = Source,
                Subject = string.Empty,
                Actor = string.Empty
            },
            Data = {
                AfterState = CreateAccountProfileEventData(accountProfile, accountStatusTimestamp)
            }
        };
    }

    /// <summary>
    ///     Create AccountProfile.Account.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="AccountProfile" />
    /// </param>
    /// <param name="accountStatusTimestamp">The account status timestamp</param>
    /// <returns>
    ///     <see cref="AsyncAPI.Account" />
    /// </returns>
    private static AsyncAPI.Account CreateAccountProfileEventData(
        AccountProfile accountProfile,
        DateTimeOffset accountStatusTimestamp)
    {
        return new AsyncAPI.Account
        {
            AccountId = accountProfile.AccountId,
            AccountCreatedUserId = accountProfile.AccountCreatedUserId,
            AccountOrganisationUnitId = accountProfile.AccountOrganisationUnitId ?? string.Empty,
            AccountLocation = AsyncAPI.AccountLocation.TMV,
            AccountName = accountProfile.Name,
            AlternateAccountName = accountProfile.AlternateName,
            AccountIdentifications = accountProfile.Identifiers
                .Where(identifier =>
                    identifier.AccountIdentificationType is not ProfileKeys.Details
                        .BaseAccountNumber)
                .Select(identifier =>
                    new AsyncAPI.AccountIdentifications
                    {
                        AccountIdentificationType =
                            GetAccountIdentificationType(identifier.AccountIdentificationType),
                        AccountIdentification = identifier.AccountIdentification
                    })
                .ToList(),
            AccountStatus = AccountStatusHelper.AccountStatusFromString(accountProfile.Status),
            AccountStatusDateTime = accountStatusTimestamp,
            AccountTSide = GetAccountTSide(accountProfile.TSide),
            MinimumNumberOfAuthoriser = accountProfile.MinimumNumberOfAuthoriser ?? string.Empty,
            AccountCreatedDateTime = accountProfile.Created ??
                throw new ArgumentNullException($"Source Created time is empty for account {accountProfile.AccountId}"),
            AccountOpenedDateTime = accountProfile.Opened,
            AccountClosedDateTime = accountProfile.Closed,
            AccountClosureReason = accountProfile.AccountClosureReason,
            BankingRelationship = new AsyncAPI.BankingRelationship
            {
                BankingRelationshipId = accountProfile.BankingRelationship.BankingRelationshipId ??
                    string.Empty,
                BankingRelationshipType =
                    AsyncAPI.BankingRelationshipType.PersonalCustomerRelationship,
                NominatedTaxPartyId = accountProfile.BankingRelationship.NominatedTaxPartyId,
                PartyIds = accountProfile.BankingRelationship.PartyIds
            },
            ProductFacility = new AsyncAPI.ProductFacility
            {
                ProductFacilityId = accountProfile.ProductFacility.ProductFacilityId,
                BankingProductId = accountProfile.ProductFacility.BankingProductId,
                BankingProductVersionId = accountProfile.ProductFacility.BankingProductVersionId,
                BankingProductCode = accountProfile.ProductFacility.BankingProductCode,
                LimitArrangements = [],
                InterestArrangement = new AsyncAPI.InterestArrangement
                {
                    Rate = accountProfile.ProductFacility.InterestRate,
                    ValidFrom = accountProfile.ProductFacility.InterestRateValidFrom,
                    RatePlanChangeId = accountProfile.ProductFacility.InterestRatePlanChangeId
                }
            },
            DomesticTaxRate = new AsyncAPI.DomesticTaxRate
            {
                DomesticTaxType = string.IsNullOrEmpty(accountProfile.DomesticTaxRate.DomesticTaxType) ? null : GetDomesticTaxType(accountProfile.DomesticTaxRate.DomesticTaxType),
                RateValue = accountProfile.DomesticTaxRate.RateValue,
                CountryAlpha3Code = accountProfile.DomesticTaxRate.CountryAlpha3Code
            },
            AccountCurrencies = accountProfile.AccountCurrencies.Select(accountCurrency =>
                    new AsyncAPI.AccountCurrencies
                    {
                        AccountCurrency = GetAccountCurrency(accountCurrency.Currency),
                        AccountCurrencyType = GetAccountCurrencyType(accountCurrency.CurrencyType)
                    })
                .ToList(),
            AccountFreezeDescription = accountProfile.AccountFreezeDetails.FreezeDescription,
            AccountFreezeType = accountProfile.AccountFreezeDetails.FreezeType,
            AccountFrozenDateTime = accountProfile.AccountFreezeDetails.Effective
        };
    }

    public static AsyncAPI.DomesticTaxRateDomesticTaxType GetDomesticTaxType(string value)
    {
        return value switch
        {
            DomesticTaxRateType.RWT => AsyncAPI.DomesticTaxRateDomesticTaxType.ResidentWithholdingTax,
            DomesticTaxRateType.NRWT => AsyncAPI.DomesticTaxRateDomesticTaxType.NonResidentWithholdingTax,
            DomesticTaxRateType.AIL => AsyncAPI.DomesticTaxRateDomesticTaxType.ApprovedIssuerLevy,
            _ => throw new NotSupportedException()
        };
    }

    public static AsyncAPI.AccountTSide GetAccountTSide(string value)
    {
        return value switch
        {
            TSideNames.Asset => AsyncAPI.AccountTSide.Asset,
            TSideNames.Liability => AsyncAPI.AccountTSide.Liability,
            TSideNames.Unknown => AsyncAPI.AccountTSide.Unknown,
            _ => throw new NotSupportedException()
        };
    }

    public static AsyncAPI.AccountIdentificationsAccountIdentificationType
        GetAccountIdentificationType(string value)
    {
        return value switch
        {
            ProfileKeys.Details.NzBankAccountNumber => AsyncAPI
                .AccountIdentificationsAccountIdentificationType.NewZealandBankAccountNumber,
            ProfileKeys.Details.LegacyCoreAccountId => AsyncAPI
                .AccountIdentificationsAccountIdentificationType.LegacyCoreAccountId,
            ProfileKeys.Details.Alias => AsyncAPI.AccountIdentificationsAccountIdentificationType
                .AccountAlias,
            _ => throw new NotSupportedException()
        };
    }

    public static AsyncAPI.AccountCurrenciesAccountCurrency GetAccountCurrency(string value)
    {
        return Enum.TryParse(value, out AsyncAPI.AccountCurrenciesAccountCurrency currency)
            ? currency
            : throw new NotSupportedException();
    }

    public static AsyncAPI.AccountCurrenciesAccountCurrencyType GetAccountCurrencyType(string value)
    {
        return Enum.TryParse(value, out AsyncAPI.AccountCurrenciesAccountCurrencyType currencyType)
            ? currencyType
            : throw new NotSupportedException();
    }


}