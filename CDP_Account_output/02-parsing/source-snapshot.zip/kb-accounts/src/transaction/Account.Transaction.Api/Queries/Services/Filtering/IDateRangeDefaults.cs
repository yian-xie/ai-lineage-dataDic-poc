﻿using System;

using Account.Transaction.Api.Queries.Services.Models;

namespace Account.Transaction.Api.Queries.Services.Filtering;

/// <summary>
/// Supplies default date ranges when none are provided.
/// </summary>
public interface IDateRangeDefaults
{
    /// <summary>
    /// Gets the date range, applying defaults as necessary.
    /// </summary>
    /// <param name="fromDateTime">From datetime <see cref="DateTimeOffset"/></param>
    /// <param name="toDateTime">To datetime <see cref="DateTimeOffset"/></param>
    /// <returns><see cref="DateRange"/></returns>
    DateRange Get(DateTimeOffset? fromDateTime, DateTimeOffset? toDateTime);
}

/// <summary>
/// Marker interface for credit card date range defaults.
/// </summary>
public interface ICreditCardDateRangeDefaults : IDateRangeDefaults
{
}

/// <summary>
/// Marker interface for Ultracs date range defaults.
/// </summary>
public interface IUltracsDateRangeDefaults : IDateRangeDefaults
{
}