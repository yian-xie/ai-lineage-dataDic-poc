﻿using System.Threading.Tasks;

using Account.Domain.Directory.Service.WebApiClient;

namespace Account.Transaction.Api.Queries.Services;

/// <summary>
/// Provides methods to interact with the Account Domain Directory Service for retrieving account information.
/// </summary>
public interface IAccountDomainDirectoryService
{
    /// <summary>
    /// Retrieves account information from the Account Domain Directory Service.
    /// </summary>
    /// <param name="accessNumber">The party identifier to filter accounts by.</param>
    /// <param name="accountId">The accountId to retrieve.</param>
    /// <returns>An account result DTO.</returns>
    Task<AccountsResultDto> GetAccount(
        string accessNumber, string accountId);
}