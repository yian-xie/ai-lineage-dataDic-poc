﻿using System;

using Enterprise.Shared.Database.Configurations;
using Enterprise.Shared.Infrastructure.Configuration.Extensions;

using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Account.PaymentInstruction.Shared.Infrastructure;

public class
    PaymentInstructionDbContextDesignFactory : IDesignTimeDbContextFactory<
    PaymentInstructionDbContext>
{
    public PaymentInstructionDbContext CreateDbContext(string[] args)
    {
        var configuration =
            new ConfigurationBuilder().BuildConfig(
                Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"), args);

        return new PaymentInstructionDbContext(
            configuration.CreateSqlServerDbContextOptionBuilder<PaymentInstructionDbContext>()
                .Options,
            new CustomDbContextOptions { IsPooled = false });
    }
}