﻿namespace Account.Shared.Database;

/// <summary>
///     Adds static schema name to the implementing class. Used on DbContext
/// </summary>
public interface IDbContextSchemaName
{
    /// <summary>
    ///     Schema name used with this DB Context
    /// </summary>
    /// <returns></returns>
    abstract static string SchemaName();
}