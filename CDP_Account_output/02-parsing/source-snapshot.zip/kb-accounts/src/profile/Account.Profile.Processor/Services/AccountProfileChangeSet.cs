﻿#nullable enable
using System;
using System.Collections.Generic;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Represents AccountProfile changes from AccountEvent.
/// </summary>
public class AccountProfileChangeSet
{
    public string AccountId { get; set; } = string.Empty;
    public long ChangeId { get; set; }
    public Guid CorrelationId { get; set; }
    public DateTimeOffset? Created { get; set; }
    public DateTimeOffset? Opened { get; set; }
    public DateTimeOffset? Closed { get; set; }
    public string? Status { get; set; }
    public string TSide { get; set; } = string.Empty;
    public string? AccountName { get; set; }
    public string? AlternateAccountName { get; set; }
    public string? WithholdingTaxRate { get; set; }
    public string? WithholdingTaxType { get; set; }
    public string? CountryAlpha3Code { get; set; }
    public string? ProductFacilityId { get; set; }
    public string? AccountClosureReason { get; set; }
    public string? BankingProductId { get; set; }

    public string? BankingProductCode { get; set; }
    public string? BankingProductVersionId { get; set; }
    public string? NzBankAccountNumber { get; set; }
    public string? LegacyCoreAccountId { get; set; }
    public string? AccountCreatedUserId { get; set; }

    public string? BankingRelationshipId { get; set; }

    public string? BankingRelationshipType { get; set; }

    public string[]? PartyIds { get; set; }
    public string? BaseAccountNumber { get; set; }
    public ICollection<AccountCurrency> AccountCurrencies { get; set; } = [];
    public string? AccountOrganisationUnitId { get; set; }
    public string? NominatedTaxPartyId { get; set; }
    public string? MinimumNumberOfAuthoriser { get; set; }
    public string? InterestRate { get; set; }
    public DateTimeOffset? InterestRateValidFrom { get; set; }
    public string? InterestRatePlanChangeId { get; set; }
}

public class AccountCurrency
{
    public string Currency { get; set; } = string.Empty;
    public string CurrencyType { get; set; } = string.Empty;
}

public static class ProfileKeys
{
    public static string? GetEntry(this IDictionary<string, object> details, string key)
    {
        return details.TryGetValue(key, out var result) ? result as string : null;
    }

    public static string? GetEntry(this IDictionary<string, string> details, string key)
    {
        return details.TryGetValue(key, out var result) ? result : null;
    }

    /// <summary>
    ///     Define the key that is available in account details.
    /// </summary>
    public static class Details
    {
        public const string Alias = "accountAlias";
        public const string Name = "accountName";
        public const string ProductFacilityId = "productFacilityId";
        public const string NzBankAccountNumber = "nzBankAccountNumber";
        public const string UltracsAccountId = "ultracsAccountId";  // Name of legacyCoreAccountId in TMV event
        public const string LegacyCoreAccountId = "legacyCoreAccountId";
        public const string AccountCreatedUserId = "accountCreatedUserId";
        public const string BaseAccountNumber = "baseAccountNumber";
        public const string BankingRelationshipId = "bankingRelationshipId";
        public const string BankingRelationshipType = "bankingRelationshipType";
        public const string AccountOrganisationUnitId = "accountOrganisationUnitId";
        public const string MinimumNumberOfAuthoriser = "minimumNumberOfAuthoriser";
        public const string AccountClosureReason = "accountClosureReason";
    }

    public static class AccountCurrencyType
    {
        public const string AccountBaseCurrency = "AccountBaseCurrency";
        public const string AccountReportingCurrency = "AccountReportingCurrency";
        public const string AccountSecondaryCurrency = "AccountSecondaryCurrency";
    }
}

/// <summary>
/// Define the strings to match in the edm.attribute property of parameters
/// in parameters array of contract notification / parameter_change events.
/// </summary>
public static class ParameterChangeEdmAttributeKeys
{
    public const string WithholdingTaxType = "account.withholding_tax_type";
    public const string WithholdingTaxPercentage = "account.withholding_tax_percentage";
    public const string CreditInterestRatePercentage = "account.credit_interest_rate_percentage";
    public const string WithholdingTaxNonResidentCountryCode = "account.withholding_tax_non_resident_country_code";
    public const string WithholdingNominatedTaxPartyId = "account.withholding_tax_nominated_tax_party_id";
    public const string StandardCreditInterestRatePlanChangeId = "account.standard_credit_interest_rate_plan_change_id";
    public const string BankingProductCode = "account.banking_product_code";
    public const string BankingProductId = "account.banking_product_id";
    public const string BankingProductVersionId = "account.banking_product_version_id";
}