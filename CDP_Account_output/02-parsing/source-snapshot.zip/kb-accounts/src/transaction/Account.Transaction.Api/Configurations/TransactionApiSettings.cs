﻿using Enterprise.Shared.Configuration;

namespace Account.Transaction.Api.Configurations;

/// <summary>
///     Configuration settings for the Transaction API.
/// </summary>
public class TransactionApiSettings : IKeyedConfigurationSection
{
    /// <summary>
    ///     Gets or sets the prefix for TMV account IDs used in the Transaction API.
    /// </summary>
    public string TmvAccountIdPrefix { get; set; } = "nc_";

    /// <summary>
    ///     Gets or sets the prefix for credit card account IDs used in the Transaction API.
    /// </summary>
    public string CreditCardAccountIdPrefix { get; set; } = "cc_";

    /// <summary>
    ///     Transaction API settings configuration key.
    /// </summary>
    public static string Key => "TransactionApi";
}