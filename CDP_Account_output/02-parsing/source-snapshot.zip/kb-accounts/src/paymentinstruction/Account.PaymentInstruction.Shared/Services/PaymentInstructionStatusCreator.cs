﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Shared.Repositories;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

using PaymentInstructionStatus =
    Account.PaymentInstruction.Shared.Entities.PaymentInstructionStatus;

namespace Account.PaymentInstruction.Shared.Services;

/// <summary>
///     Used in Payment Instruction Api mutation to process the <see cref="Shared.Entities.PaymentInstruction" /> with the
///     given <see cref="Status" />
///     and insert the <see cref="PaymentInstructionStatus" /> into payment_instruction_status table.
/// </summary>
public class PaymentInstructionStatusCreator(
    IRepositoryFactory repositoryFactory,
    TimeProvider timeProvider)
    : IPaymentInstructionStatusCreator
{
    public async Task<PaymentInstructionStatus> CreateAsync(
        Entities.PaymentInstruction paymentInstruction,
        PaymentInstructionStatusStatus status,
        CancellationToken cancellationToken,
        PostingInstructionBatch postingInstructionBatch = null)
    {
        var paymentInstructionStatus = new PaymentInstructionStatus
        {
            BatchId = postingInstructionBatch?.Id,
            ClientBatchId = paymentInstruction.ClientBatchId,
            ClientId = paymentInstruction.ClientId,
            Date = timeProvider.GetUtcNow(),
            State = status.ToString()
        };

        repositoryFactory.PaymentInstructionStatusRepository.Add(paymentInstructionStatus);
        await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);

        return paymentInstructionStatus;
    }
}