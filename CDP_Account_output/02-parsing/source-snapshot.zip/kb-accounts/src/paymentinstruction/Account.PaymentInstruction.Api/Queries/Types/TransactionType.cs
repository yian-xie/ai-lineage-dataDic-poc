﻿namespace Account.PaymentInstruction.Api.Queries.Types;

public enum TransactionType
{
    Transfer,
    CashDeposit,
    LoanRedraw,
    Adjustment
}