﻿using System;

using Account.Shared.Entities;

namespace Account.Profile.Shared.Entities;

public class AccountCurrency : AccountBaseConcurrentEntity
{
    public Guid RowId { get; set; }
    public string Currency { get; set; }
    public string CurrencyType { get; set; }
    public AccountProfile Profile { get; set; }
}