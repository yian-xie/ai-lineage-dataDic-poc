﻿namespace Account.TopicLogger.Processor.Services;

/// <summary>
///     Interface for Kubernetes helper service.
/// </summary>
public interface IKubernetesHelper
{
    /// <summary>
    ///     Gets the current namespace.
    /// </summary>
    /// <returns>The current namespace.</returns>
    string GetCurrentNamespace();
}