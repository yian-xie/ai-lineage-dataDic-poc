﻿using System.Threading;
using System.Threading.Tasks;

using Account.Posting.Shared.Entities;

using Enterprise.Shared.Database;

namespace Account.Posting.Shared.Repositories;

public interface ITmvPostingBatchRepository : IRepository
{
    /// <summary>
    ///     Insert <see cref="TmvPostingBatch" /> into the database.
    /// </summary>
    /// <param name="tmvPostingBatch">
    ///     <see cref="TmvPostingBatch" />
    /// </param>
    void Add(TmvPostingBatch tmvPostingBatch);

    /// <summary>
    ///     Get <see cref="TmvPostingBatch" /> from the database by posting instruction id.
    /// </summary>
    /// <param name="id">Posting Instruction Id</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    Task<TmvPostingBatch> GetByIdAsync(string id, CancellationToken cancellationToken);
}