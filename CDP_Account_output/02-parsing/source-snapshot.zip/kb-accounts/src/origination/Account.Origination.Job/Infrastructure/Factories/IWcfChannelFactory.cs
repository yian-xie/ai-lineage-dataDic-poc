﻿namespace Account.Origination.Job.Infrastructure.Factories;

/// <summary>
/// This file is copied from kb-kiwisaver-accounts-api repo
/// see https://github.com/Kiwibank/kb-kiwisaver-accounts-api/blob/main/src/KiwiSaver.Accounts.Core/Contracts/Factories/IWcfChannelFactory.cs
/// Unfortunately we don't have a nuget package for this WcfChannelFactory yet. Similar code can also be found in kb-cap and kb-phoenix-apis
/// </summary>
public interface IWcfChannelFactory<out T>
{
    /// <summary>
    /// Use the generic ChannelFactory class to create and return an object of type T that
    /// can be used to make WCF requests to Middleware endpoints and methods.
    /// </summary>
    /// <returns>Valid channel object of type T that uses the correct credentials and security type</returns>
    T CreateChannel();
}