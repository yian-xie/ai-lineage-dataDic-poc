﻿using Account.Origination.Processor.Configurations;
using Account.Origination.Processor.Services;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Services;

using Api.Shared.Clients.Events.Kiwibank.V1.LendingProductProposition;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.Extensions.Options;

namespace Account.Origination.Processor.Subscribers;

public class ProductPropositionEventSubscriber(
    ILogger<ProductPropositionEventSubscriber> logger,
    IJobCreator jobCreator,
    IOptions<AccountOriginationProcessorOptions> options)
    : IIncomingEventSubscriber<LendingProductPropositionEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        LendingProductPropositionEvent incomingEvent,
        CancellationToken cancellationToken)
    {
        logger.LogInformation("Received LendingProductPropositionEvent with ID {MetadataId}.",
            incomingEvent.Metadata.Id);

        if (incomingEvent.Metadata.Type == MetadataType.ProductPropositionUpdated)
        {
            logger.LogInformation(
                "LendingProductPropositionEvent {MetadataId} is an update event. No action will be taken.",
                incomingEvent.Metadata.Id);

            return EventSubscriberResults.Success;
        }

        if (incomingEvent.Data.AfterState.ProductFacilities == null ||
            !incomingEvent.Data.AfterState.ProductFacilities.Any())
        {
            logger.LogInformation(
                "LendingProductPropositionEvent {MetadataId} has no ProductFacilities.",
                incomingEvent.Metadata.Id);

            return EventSubscriberResults.Success;
        }

        // Assume only one product facility of SV1 banking product per product proposition
        //TODO:check BankingProductVersioning
        var onlineCallProductFacility =
            incomingEvent.Data.AfterState.ProductFacilities.SingleOrDefault(pf =>
                string.Equals(pf.BankingProductCode,
                    Product.Sv1,
                    StringComparison.InvariantCultureIgnoreCase));

        if (onlineCallProductFacility != null)
        {
            logger.LogInformation(
                "LendingProductPropositionEvent {MetadataId} has Investment type ProductFacilities.",
                incomingEvent.Metadata.Id);

            var accountOpening = CreateAccountOpening(incomingEvent, onlineCallProductFacility);
            await jobCreator.CreateAsync(accountOpening, cancellationToken);

            return EventSubscriberResults.Success;
        }

        logger.LogInformation(
            "LendingProductPropositionEvent {MetadataId} has ProductFacilities but unsupported facility type for origination.",
            incomingEvent.Metadata.Id);

        return EventSubscriberResults.Success;
    }

    private AccountOpening CreateAccountOpening(
        LendingProductPropositionEvent lendingProductPropositionEvent,
        ProductFacility onlineCallProductFacility)
    {
        // Assume only one party involvement per product facility for Drop 5
        var partyInvolvement = onlineCallProductFacility.PartyInvolvements?.FirstOrDefault();

        if (partyInvolvement == null)
        {
            throw new InvalidOperationException(
                "No PartyInvolvement found for the given ProductFacility.");
        }

        return new AccountOpening
        {
            AccountId = Guid.NewGuid().ToString(),
            EventId = lendingProductPropositionEvent.Metadata.Id,
            CorrelationId = lendingProductPropositionEvent.Metadata.CorrelationId,
            PartyId = Guid.Parse(partyInvolvement.PartyId),
            PartyRoleIds = [partyInvolvement.PartyRoleId],
            AlternateAccountName = onlineCallProductFacility.AlternateAccountName,
            BankingProductId = Guid.Parse(onlineCallProductFacility.BankingProductId),
            BankingProductVersionId = Guid.Parse(onlineCallProductFacility.BankingProductVersionId),
            ProductCode = onlineCallProductFacility.BankingProductCode,
            BankingRelationshipId = Guid.Parse(partyInvolvement.BankingRelationshipId),
            ProductPropositionId =
                Guid.Parse(lendingProductPropositionEvent.Data.AfterState.ProductPropositionId),
            ProductFacilityId = Guid.Parse(onlineCallProductFacility.ProductFacilityId),
            ValidUntil = lendingProductPropositionEvent.Metadata.Time +
                TimeSpan.FromDays(options.Value.ValidityPeriodDays),
            ScheduledOpen = DateTimeOffset.UtcNow,
            State = AccountOpeningState.Initial
        };
    }
}