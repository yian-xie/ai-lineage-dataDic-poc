## Service Summary

| Field | Details |
|---|---|
| Business purpose | GraphQL API for reading one or more TMV account profiles by account ID. |
| Runtime | .NET 10 ASP.NET Core / Hot Chocolate GraphQL |
| Source | `src/profile/Account.Profile.Api` |
| Pipeline | `src/profile/.pipelineconfig/pipeline.yaml` (`accounts-profile`; API image `accounts/account/account-profile-api`) |
| Last reviewed | 2026-10-09 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. The ASP.NET Core host serves GraphQL at `/api/accounts-profile/graphql`; Kubernetes probes `/health/readiness` and `/health/liveness` on container port 8080.
2. `AccountProfileQuery` calls `AccountProfileAction`, which reads account profiles, identifiers, currencies, and restrictions from PostgreSQL using `AccountProfileDbContext`.
3. GraphQL audit middleware builds read-audit events; the database outbox and Kafka publisher provide persistence and delivery.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Read | PostgreSQL profile database | Profile query data and SQL readiness health check | `ConnectionStrings__DefaultConnection`; PREPROD database `preprod_account_v2_profile`; `AccountProfileDbContext` |
| Outbound audit | Kafka and database outbox | Persist and publish profile-read audit events | `Kafka__BootstrapServers`, `Kafka__SchemaRegistry__Url`, `AccountAuditLogEventBuilder`, outbox registration in `Startup` |
| Inbound authentication | Microsoft Entra bearer tokens / service-mesh policy | Restrict GraphQL access to authorised callers | `Authorization` header and issuer/policy in environment-specific API values |

### Interfaces and Schedule

- GraphQL: `POST /api/accounts-profile/graphql`; queries include `tmvAccountProfile(accountId)` and `tmvAccountProfilesV2(accountIds)`.
- Health probes: `GET /health/readiness` and `GET /health/liveness` on container port 8080.
- No scheduled/background job or Kafka consumer is registered by the API startup; Kafka is used for outbound audit events.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| `ConnectionStrings__DefaultConnection` | PostgreSQL connection | Host/user values are supplied by the deployment environment; PREPROD database is `preprod_account_v2_profile`. Never copy connection-string values into logs. |
| `Graphql__Path`, `Graphql__IntrospectionEnabled` | GraphQL route and introspection | `src/profile/Account.Profile.Api/appsettings.json`; introspection varies by environment. |
| `Kafka__BootstrapServers`, `Kafka__OutgoingTopicPrefix`, `Kafka__SchemaRegistry__Url` | Audit event transport/schema | Non-production and production settings are in `src/profile/Deploy/Account.Profile.Api/values-*.yaml`. Do not infer topic names. |
| `Authorization` issuer and service-mesh rules | Authenticate and authorise callers | See the environment-specific `src/profile/Deploy/Account.Profile.Api/values-*.yaml` files. |
| Secret names | Database, Kafka/schema registry, and telemetry credentials | Pipeline references include `kafka_key`, `kafka_secret`, `kafka_schema_key`, `kafka_schema_secret`, and `dynatrace_api_key`. Secret values must remain in the secret store. |
| Deployment environments | ACCEPT, SITUAT, PREPROD/rehearse, and PROD | Stages and API Helm values are mapped in `src/profile/.pipelineconfig/pipeline.yaml`. PREPROD and PROD virtual-service hosts are internal; client reachability/access steps are not documented here. |

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| PREPROD readiness probe: `GET http://127.0.0.1:8080/health/readiness` from the API pod's network namespace; no application bearer token | HTTP 2xx; probe is configured on port 8080 and readiness includes the SQL health check | Probe fails or profile queries fail. Laptop access is not possible via this loopback address; `[TODO: confirm the approved PREPROD pod-access procedure and role]`. Not exercised during runbook generation. |
| PREPROD liveness probe: `GET http://127.0.0.1:8080/health/liveness` from the API pod's network namespace; no application bearer token | HTTP 2xx; probe is configured on port 8080 | Probe fails. Laptop access is not possible via this loopback address; `[TODO: confirm the approved PREPROD pod-access procedure and role]`. Not exercised during runbook generation. |
| PREPROD GraphQL route: `POST [TODO: confirm URL scheme for preprod-accounts-profile.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz]/api/accounts-profile/graphql` with an approved bearer token | HTTP 200 and expected profile data with no GraphQL errors for a known test account | Authentication denial, GraphQL errors, missing expected data, or latency/error signals. Private-host laptop/VPN reachability and token procedure: `[TODO: confirm approved access path and test credentials]`. No request was sent during runbook generation. |
| Read audit telemetry and delivery | Controlled profile reads produce the expected audit event; `audit.events.emitted` is available to observability | Missing event, publisher/outbox errors, or Kafka/schema-registry errors. `[TODO: confirm authoritative delivery/backlog thresholds and recovery signal]`. |

Observability: [Account Profile API observability and support](https://kiwibank.atlassian.net/wiki/x/AYBBKAE)

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the `accounts/account/account-profile-api` image is built from `src/profile/.pipelineconfig/account-profile-api/Dockerfile` with repository-root context; the Docker build runs the API unit tests.
2. Review profile database migration compatibility in `src/profile/Account.Profile.Shared` and confirm the target environment's API values and secret *names* are correct.

### After Deployment

1. In the deployment platform for the target environment, confirm API readiness and liveness probes pass; use the PREPROD endpoint details in **Health & Verification** only in PREPROD.
2. In PREPROD/rehearse, validate an approved test-account GraphQL read and its read-audit event. The pipeline's `post-rehearse` step runs profile system integration tests; no runtime validation was performed for this runbook.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

Use the mapped `accounts-profile` pipeline and its environment-specific Helm values to deploy a corrected API image. The pipeline also runs profile database migrations from `src/profile/Account.Profile.Shared`; database rollback and release rollback procedures are not specified in the repository: `[TODO: confirm the approved rollback procedure, including migration compatibility and authority]`.

### Recovery Validation

1. Confirm the deployed API's PREPROD readiness and liveness probes return HTTP 2xx.
2. Confirm a known PREPROD account can be queried and its audit event is delivered. `[TODO: confirm the authoritative audit delivery signal and approved test account]`.

Operational guardrail: do not manually edit profile/outbox database rows, replay Kafka events, broaden caller authorization, or restart the API as a default recovery action.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [kb-accounts](https://github.com/Kiwibank/kb-accounts/tree/main/src/profile/Account.Profile.Api) |
| Dashboards and logs | <ul><li>[Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/AYBBKAE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33954157)</li></ul> |
| Minimum Standard for Runbooks | [Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |
