﻿using FluentValidation;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Validations.PaymentInstructionRequestInputValidation;

/// <summary>
///     Validator that validates length of field in <see cref="PaymentInstructionRequestInput" />
/// </summary>
public class FieldLengthValidator : AbstractValidator<PaymentInstructionRequestInput>
{
    public const int FieldLengthLimit = 200;

    public FieldLengthValidator()
    {
        RuleFor(i => i.PaymentInstruction.Transfer.Credit.Code)
            .Must(s => s?.Length <= FieldLengthLimit)
            .WithMessage(ErrorMessage());

        RuleFor(i => i.PaymentInstruction.Transfer.Credit.Particulars)
            .Must(s => s?.Length <= FieldLengthLimit)
            .WithMessage(ErrorMessage());

        RuleFor(i => i.PaymentInstruction.Transfer.Credit.Reference)
            .Must(code => code?.Length <= FieldLengthLimit)
            .WithMessage(ErrorMessage());

        RuleFor(i => i.PaymentInstruction.Transfer.Debit.Code)
            .Must(s => s?.Length <= FieldLengthLimit)
            .WithMessage(ErrorMessage());

        RuleFor(i => i.PaymentInstruction.Transfer.Debit.Particulars)
            .Must(code => code?.Length <= FieldLengthLimit)
            .WithMessage(ErrorMessage());

        RuleFor(i => i.PaymentInstruction.Transfer.Debit.Reference)
            .Must(s => s?.Length <= FieldLengthLimit)
            .WithMessage(ErrorMessage());
    }

    private static string ErrorMessage()
    {
        return $"Must shorter or equal to {FieldLengthLimit}";
    }
}