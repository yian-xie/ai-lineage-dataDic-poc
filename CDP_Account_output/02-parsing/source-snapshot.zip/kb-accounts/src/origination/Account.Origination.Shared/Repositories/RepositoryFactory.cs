﻿using Account.Origination.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.Origination.Shared.Repositories;

public class RepositoryFactory(
    OriginationDbContext dbContext,
    IAccountOpeningRepository accountOpeningRepository) : IRepositoryFactory
{
    public OriginationDbContext DbContext { get; } = dbContext;
    public IUnitOfWork UnitOfWork { get; } = dbContext;
    public IAccountOpeningRepository AccountOpeningRepository { get; } = accountOpeningRepository;
}