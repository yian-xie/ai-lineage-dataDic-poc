﻿namespace Account.Shared.Constants;

public static class DatabaseSchemaName
{
    public const string Transaction = "transaction";
    public const string Profile = "profile";
    public const string Origination = "origination";
    public const string Paymentinstruction = "paymentinstruction";
    public const string Posting = "posting";
}