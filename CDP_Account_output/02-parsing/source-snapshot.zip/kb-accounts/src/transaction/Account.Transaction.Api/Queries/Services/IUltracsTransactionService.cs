﻿using System.Threading;
using System.Threading.Tasks;

using Account.Transaction.Api.Queries.Types;

using Ultracs.Integration.Client;

namespace Account.Transaction.Api.Queries.Services;

public interface IUltracsTransactionService
{
    Task<ResponseDataOfTransactions> GetUltracsTrasactionsAsync(string bankAccountNumber, AccountTransactionQueryParams queryParams, CancellationToken cancellationToken);

    Task<ResponseDataOfAuthorisationTransactions> GetUltracsAuthorisationTransactionsAsync(string bankAccountNumber, AccountTransactionQueryParams queryParams, CancellationToken cancellationToken);
}