﻿using System;

using Enterprise.Shared.Configuration;

namespace Account.Shared.Configurations;

public class RetrySettings : IKeyedConfigurationSection
{
    public TimeSpan RedeliveryInterval { get; set; } = TimeSpan.FromSeconds(5);
    public int RetryAttemptAlertThreshold { get; set; } = 3;
    public static string Key => "Retry";
}