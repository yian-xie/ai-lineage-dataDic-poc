﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddInterestRate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "product_facility_interest_rate",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "product_facility_interest_rate_plan_change_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "product_facility_interest_rate_valid_from",
                schema: "profile",
                table: "account_profile",
                type: "timestamp with time zone",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "product_facility_interest_rate",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "product_facility_interest_rate_plan_change_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "product_facility_interest_rate_valid_from",
                schema: "profile",
                table: "account_profile");
        }
    }
}