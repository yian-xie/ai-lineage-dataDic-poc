﻿using System;

using Account.Shared.Authorisation.Constants.OPA;

using HotChocolate.Execution.Configuration;

using Kb.Api.Infrastructure.Authorization.OPA;
using Kb.Api.Infrastructure.JwtTokenProvider;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Shared.Authorisation;

public static class AuthorisationExtensions
{
    public static IServiceCollection AddTokenProviders(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var authorizationOptions = configuration.GetSection(nameof(AuthorizationOptions))
            .Get<AuthorizationOptions>();
        ArgumentNullException.ThrowIfNull(authorizationOptions);

        services.Configure<AuthorizationOptions>(options =>
        {
            options.IntrospectionHeader = authorizationOptions.IntrospectionHeader;
            options.AuthorizationHeader = authorizationOptions.AuthorizationHeader;
            options.TimeoutInSeconds = authorizationOptions.TimeoutInSeconds;
            options.WaitRetryTimeInSeconds = authorizationOptions.WaitRetryTimeInSeconds;
        });

        services.AddScoped<IJwtTokenProvider, CiamTokenProvider>();
        services.AddScoped<IJwtTokenProvider, StaffTokenProvider>();
        services.AddScoped<TokenProviderLocator>();

        return services;
    }

    public static IServiceCollection AddAccountAuthorization(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var authorizationOptions = configuration.GetSection("AuthorizationOptions")
            .Get<AuthorizationOptions>();
        ArgumentNullException.ThrowIfNull(authorizationOptions);
        services.AddAuthorization(authorizationOptions);

        return services;
    }

    public static IRequestExecutorBuilder AddAccountAuthorization(
        this IRequestExecutorBuilder builder)
    {
        return builder.AddAuthorization(options =>
        {
            options.AddPolicy("AccountView", policy => policy.Requirements.Add(
                new OpaRequirement(
                    Actions.AccountView,
                    string.Empty,
                    PolicyPaths.AccountAssert)));

            options.AddPolicy("AccountMaintain", policy => policy.Requirements.Add(
                new OpaRequirement(
                    Actions.AccountEdit,
                    string.Empty,
                    PolicyPaths.AccountAssert)));

            options.AddPolicy("PaymentInstructionView", policy => policy.Requirements.Add(
                new OpaRequirement(
                    Actions.AccountView,
                    string.Empty,
                    PolicyPaths.AccountAssert)));

            options.AddPolicy("PaymentInstructionMaintain", policy => policy.Requirements.Add(
                new OpaRequirement(
                    Actions.AccountEdit,
                    string.Empty,
                    PolicyPaths.AccountAssert)));
        });
    }
}