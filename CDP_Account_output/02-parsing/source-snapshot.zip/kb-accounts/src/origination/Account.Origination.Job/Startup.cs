﻿using Account.Origination.Job.AccountNumberMiddleware;
using Account.Origination.Job.Activities;
using Account.Origination.Job.Configurations;
using Account.Origination.Job.Extension;
using Account.Origination.Job.Infrastructure.Factories;
using Account.Origination.Job.Infrastructure.Resilience;
using Account.Origination.Job.Jobs;
using Account.Origination.Job.Services;
using Account.Origination.Job.TMVClient.Factories;
using Account.Origination.Job.TMVClient.SemanticVersion;
using Account.Origination.Public;
using Account.Origination.Shared;
using Account.Origination.Shared.Infrastructure;
using Account.Origination.Shared.Repositories;
using Account.Shared;
using Account.Shared.FeatureFlags;

using Api.Shared.Clients.Rest.ThoughtMachine;
using Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Kb.TMV.Client.DependencyInjection;

using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace Account.Origination.Job;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        services.AddLaunchDarkly();

        services.Configure<AccountOriginationJobOptions>(
            Configuration.GetSection(nameof(AccountOriginationJobOptions)));
        services.Configure<MiddlewareOptions>(Configuration.GetSection(nameof(MiddlewareOptions)));

        services.Configure<ResilienceOptions>(
            Configuration.GetSection(nameof(ResilienceOptions)));

        services.Configure<TmvSemanticOptionCollection>(
            Configuration.GetSection(nameof(TmvSemanticOptionCollection)));

        services.AddSingleton(resolver =>
            resolver.GetRequiredService<IOptions<TmvSemanticOptionCollection>>().Value);

        services.AddHttpClient<ICoreAPIAccountsClient, CoreAPIAccountsClient>(TmvClientUtils
            .Configure);

        services.AddHttpClient<ICoreAPICustomersClient, CoreAPICustomersClient>(TmvClientUtils
            .Configure);

        services.AddHttpClient<ICoreAPIProductsClient, CoreAPIProductsClient>(TmvClientUtils
            .Configure);

        services.AddHttpClient<IOnlineCallClient, OnlineCallClient>(TmvClientUtils
            .Configure);

        services.AddTmvClient(Configuration)
            .AddSupportForGetAccount()
            .AddSupportForOpenAccount()
            .AddSupportForCreateSpudAccount()
            .AddSupportForCreateOnlineCallAccount()
            .AddSupportForGetCustomer()
            .AddSupportForCreateCustomer();

        // Add new OAuth registration alongside for dual header migration mode
        services.AddTmvOAuth(Configuration);

        var tmvProductsSettings = Configuration.GetSection(TmvProductsSettings.Key)
            .Get<TmvProductsSettings>();
        ArgumentNullException.ThrowIfNull(tmvProductsSettings);
        services.AddSingleton(tmvProductsSettings);

        UseKafka(services);

        services
            .AddRepositories()
            .AddScoped<ITmvAccountActionGetter, TmvAccountActionGetter>()
            .AddScoped<ITmvAccountAction, SV1AccountAction>()
            .AddScoped<ITmvAccountAction, SpudAccountAction>()
            .AddScoped<ITmvCustomerAction, TmvCustomerAction>()
            .AddScoped<IAccountOriginationActivity, AccountOriginationActivity>()
            .AddScoped(typeof(TmvAccountCreationJob<>))
            .AddScoped(typeof(TmvAccountOpeningJob<>))
            .AddScoped(typeof(TmvAccountNumberAllocationJob<>));

        services
            .AddSingleton<IHostedService, AccountOriginationJobRunner<
                TmvAccountCreationJob<AccountCreationJobQuery>>>();

        services
            .AddSingleton<IHostedService, AccountOriginationJobRunner<
                TmvAccountOpeningJob<AccountOpeningJobQuery>>>();

        services
            .AddSingleton<IHostedService, AccountOriginationJobRunner<
                TmvAccountNumberAllocationJob<AccountNumberAllocationJobQuery>>>();

        UsePooledDbContext<OriginationDbContext>(services);

        services
            .AddSingleton<IWcfChannelFactory<IInvokeAccountChannel>,
                WcfChannelFactory<IInvokeAccountChannel>>();

        services.AddScoped<IAccountNumberAllocationService, AccountNumberAllocationService>();
        services.AddSingleton(AccountNameGeneratorFactory.CreateDefault());

        services.AddSingleton<IMemoryCache, MemoryCache>();
        services.AddSingleton<IProductVersionIterator, ProductVersionIterator>();
        services.AddSingleton<ISemanticVersionResolver, SemanticVersionResolver>();
        services.AddSingleton<IOnlineCallAccountRequestFactory, OnlineCallAccountRequestFactory>();

        services.AddLaunchDarkly();

        services.AddSingleton(typeof(IStandardResiliencePipeline<,,>), typeof(StandardResiliencePipeline<,,>));
        services.AddSingleton<TmvApiExceptionResilienceStrategy>();
        services.AddSingleton<DefaultResilienceStrategy>();
        services.AddSingleton<MiddlewareResilienceStrategy>();

        services.ConfigureAccountDomainDirectoryServiceWebApiClient(Configuration);
    }
}