﻿using System.Collections.Generic;

namespace Account.Transaction.Api.Queries.Services.Models;

/// <summary>
/// Represents the state of a response from the Cards API.
/// </summary>
public record CardTransactionsResponseState(IReadOnlyCollection<CreditCardTransaction> creditCardTransactions, ResponseState responseState);