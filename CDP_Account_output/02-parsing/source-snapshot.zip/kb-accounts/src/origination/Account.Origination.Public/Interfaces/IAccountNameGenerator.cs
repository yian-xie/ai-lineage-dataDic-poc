﻿
namespace Account.Origination.Public.Interfaces
{
    public interface IAccountNameGenerator
    {
        string GenerateAccountName(Party[] parties);
    }
}