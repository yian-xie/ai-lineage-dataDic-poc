﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddNewColumnsToAccountProfile : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "product_facility_banking_product_code",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "banking_relationship_banking_relationship_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "banking_relationship_banking_relationship_type",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);
            migrationBuilder.AddColumn<string>(
                name: "banking_relationship_party_ids",
                schema: "profile",
                table: "account_profile",
                type: "text[]",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "product_facility_banking_product_code",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "banking_relationship_banking_relationship_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "banking_relationship_banking_relationship_type",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "banking_relationship_party_ids",
                schema: "profile",
                table: "account_profile");
        }
    }
}