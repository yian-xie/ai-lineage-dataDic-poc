﻿#nullable enable

using System.Runtime.Serialization;

using Enterprise.Shared.Telemetry;

namespace Account.Origination.Shared.Entities;

public enum AccountOpeningState
{
    [EnumMember(Value = "PendingNumberAllocation")]
    PendingNumberAllocation,

    [EnumMember(Value = "Initial")]
    Initial,

    [EnumMember(Value = "Created")]
    Created,

    [EnumMember(Value = "Opened")]
    Opened,

    [EnumMember(Value = "Failed")]
    Failed
}

public class AccountOpening : IPropagatorEntity
{
    /// <summary>
    ///     Account id.
    /// </summary>
    public required string AccountId { get; set; }

    /// <summary>
    ///     Account opening state.
    /// </summary>
    public required AccountOpeningState State { get; set; }

    /// <summary>
    ///     Event id.
    /// </summary>
    public required Guid EventId { get; set; }

    /// <summary>
    ///     Correlation id.
    /// </summary>
    public required Guid CorrelationId { get; set; }

    /// <summary>
    ///     Party id.
    /// </summary>
    public Guid? PartyId { get; set; }

    /// <summary>
    ///     Party role ids.
    /// </summary>
    public required string[] PartyRoleIds { get; set; }

    /// <summary>
    ///     Account creation date.
    /// </summary>
    public DateTimeOffset? Created { get; set; }

    /// <summary>
    ///     Account creation or opening failed date.
    /// </summary>
    public DateTimeOffset? Failed { get; set; }

    /// <summary>
    ///     Account scheduled open date.
    /// </summary>
    public DateTimeOffset ScheduledOpen { get; set; }

    /// <summary>
    ///     Account open date.
    /// </summary>
    public DateTimeOffset? Opened { get; set; }

    /// <summary>
    ///     When the account opening expires.
    /// </summary>
    public DateTimeOffset ValidUntil { get; set; }

    /// <summary>
    ///     Last retry date.
    /// </summary>
    public DateTimeOffset? LastRetry { get; set; }

    /// <summary>
    ///     Account retry opening count.
    /// </summary>
    public int RetryCount { get; set; }

    public string? TraceContext { get; set; }

    /// <summary>
    ///     Banking Product Id.
    /// </summary>
    public Guid? BankingProductId { get; set; }

    /// <summary>
    ///     Banking Product Version Id.
    /// </summary>
    public Guid? BankingProductVersionId { get; set; }

    /// <summary>
    ///     Product type. e.g. SV1
    /// </summary>
    public string? ProductCode { get; set; }

    /// <summary>
    ///     Account Number.
    /// </summary>
    public string? AccountNumber { get; set; }

    /// <summary>
    ///     Account Name.
    /// </summary>
    public string? AccountName { get; set; }

    /// <summary>
    ///     Alternate Account Name.
    /// </summary>
    public string? AlternateAccountName { get; set; }

    /// <summary>
    ///     Banking Relationship Id.
    /// </summary>
    public Guid? BankingRelationshipId { get; set; }

    /// <summary>
    ///     Product Proposition Id.
    /// </summary>
    public Guid? ProductPropositionId { get; set; }

    /// <summary>
    ///     Product Facility Id.
    /// </summary>
    public Guid? ProductFacilityId { get; set; }
}