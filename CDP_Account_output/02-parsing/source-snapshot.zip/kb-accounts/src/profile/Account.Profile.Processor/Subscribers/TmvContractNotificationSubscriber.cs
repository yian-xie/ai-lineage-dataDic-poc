﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Services;
using Account.Profile.Shared.Constants;
using Account.Shared.Configurations;
using Account.Shared.Services;

using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;
using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Subscribers;

public class TmvContractNotificationSubscriber(
    ILogger<TmvContractNotificationSubscriber> logger,
    IContractNotificationProcessor contractNotificationProcessor,
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings,
    RetrySettings retrySettings)
    : IIncomingEventSubscriber<ContractNotification>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        ContractNotification incomingEvent,
        CancellationToken cancellationToken)
    {
        if (!ShouldProcessEvent(context, incomingEvent))
        {
            return EventSubscriberResults.Skip;
        }

        try
        {
            await contractNotificationProcessor.ProcessEvent(
                context,
                incomingEvent,
                cancellationToken);

            return EventSubscriberResults.Success;
        }
        catch (Exception ex)
        {
            await HandleException(ex, context, incomingEvent,
                cancellationToken);

            return new RedeliverMessageEventSubscriberResult(retrySettings.RedeliveryInterval);
        }
    }

    private bool ShouldProcessEvent(IncomingEventContext context, ContractNotification incomingEvent)
    {
        logger.LogInformation(
            "Received ContractNotification with eventId: {eventId} notificationType: {notificationType} " +
            "for resource {resourceId}. TopicPartitionOffset: {@TopicPartitionOffset}",
            incomingEvent.Event_id,
            incomingEvent.Notification_type,
            incomingEvent.Resource_id,
            context.ConsumeResult.TopicPartitionOffset);

        if (incomingEvent.Notification_type != ThoughtMachineNotificationTypes.ParameterChange)
        {
            logger.LogInformation(
                "Skipped ContractNotification with eventId: {eventId} notificationType: {notificationType} " +
                "for resource {resourceId}. " +
                "It is not targetNotificationType: {TargetNotificationType}.",
                incomingEvent.Event_id,
                incomingEvent.Notification_type,
                incomingEvent.Resource_id,
                ThoughtMachineNotificationTypes.ParameterChange);

            return false;
        }

        if (incomingEvent.Resource_type != ContractNotificationResource_type.RESOURCE_ACCOUNT)
        {
            logger.LogInformation(
                "Skipped ContractNotification with eventId: {eventId} notificationType: {notificationType} " +
                "for resource {resourceId} with resourceType: {resourceType}. " +
                "It is not targetResourceType: {targetResourceType}.",
                incomingEvent.Event_id,
                incomingEvent.Notification_type,
                incomingEvent.Resource_id,
                incomingEvent.Resource_type,
                ContractNotificationResource_type.RESOURCE_ACCOUNT);

            return false;
        }

        return true;
    }

    private async Task HandleException(
        Exception exception,
        IncomingEventContext context,
        ContractNotification incomingEvent,
        CancellationToken cancellationToken)
    {
        var accountId = incomingEvent.Resource_id;

        logger.LogError(
            exception,
            "Exception processing event with eventId: {eventId} notificationType: {notificationType} " +
            "for resource {resourceId}.  TopicPartitionOffset: {@TopicPartitionOffset}",
            incomingEvent.Event_id,
            incomingEvent.Notification_type,
            incomingEvent.Resource_id,
            context.ConsumeResult.TopicPartitionOffset);

        // If the retry attempts has exceeded the threshold, raise sumologic alert
        if (context.DeliveryAttempt > retrySettings.RetryAttemptAlertThreshold)
        {
            try
            {
                await sumoLogicClientHelper.IngestLogAsync(
                    $"Failed to process Contract Notification Event for AccountId: {accountId} and EventId: {incomingEvent.Event_id}. Exception: {exception}",
                    sumoLogicSettings.SourceCategory,
                    sumoLogicSettings.SourceName +
                    Constants.SumoSourceNames.TmvContractNotificationSubscriber,
                    sumoLogicSettings.ApiToken,
                    cancellationToken);
            }
            catch (Exception nestedEx)
            {
                logger.LogError(
                    nestedEx,
                    "Failed to push log into SumoLogic for failed processing of Contract Notification Event for AccountId: {AccountId} and EventId: {EventId}",
                    accountId, incomingEvent.Event_id);
            }
        }
    }
}