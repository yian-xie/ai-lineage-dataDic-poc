﻿using System.Threading;
using System.Threading.Tasks;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;
using PaymentInstructionWithStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionWithStatus;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     An interface that declares the method signature to handle <see cref="PaymentInstructionRequestInput" />
/// </summary>
public interface IAddPaymentInstructionRequestHandler
{
    /// <summary>
    ///     Handles <see cref="PaymentInstructionRequestInput" />
    /// </summary>
    Task<PaymentInstructionWithStatus> HandleAsync(
        PaymentInstructionRequestInput input,
        CancellationToken cancellationToken);
}