﻿namespace Account.PaymentInstruction.Shared;

public static class Telemetry
{
    public const string ActivitySourceName = "account_paymentinstruction";
}