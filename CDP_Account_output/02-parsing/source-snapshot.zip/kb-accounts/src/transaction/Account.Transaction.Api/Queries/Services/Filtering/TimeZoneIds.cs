﻿namespace Account.Transaction.Api.Queries.Services.Filtering;

/// <summary>
///
/// </summary>
public class TimeZoneIds
{
    public const string NewZealandStandardTime = "Pacific/Auckland";
}