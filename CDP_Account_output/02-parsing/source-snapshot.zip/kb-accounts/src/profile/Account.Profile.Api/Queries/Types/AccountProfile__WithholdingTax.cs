﻿using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__WithholdingTax")]
public class AccountProfile__WithholdingTax
{
    [GraphQLDeprecated("WithholdingTax type will be deprecated. Use DomesticTaxRate domesticTaxType instead.")]
    [GraphQLName("withholdingTaxType")]
    public string WithholdingTaxType { get; set; }

    [GraphQLDeprecated("WithholdingTax rate will be deprecated. Use DomesticTaxRate rateValue instead.")]
    [GraphQLName("withholdingTaxRate")]
    public string WithholdingTaxRate { get; set; }
}