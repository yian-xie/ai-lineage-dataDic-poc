﻿namespace Account.Shared;

/// <summary>
///     Keys for use in the additional properties
/// </summary>
public static class AdditionalPropertyKeys
{
    public const string RequestedAccountId = "requestedAccountId";
}