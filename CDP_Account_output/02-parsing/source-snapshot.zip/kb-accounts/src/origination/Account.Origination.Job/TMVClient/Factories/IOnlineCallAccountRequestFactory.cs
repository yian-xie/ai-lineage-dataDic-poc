﻿using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Shared.Entities;

namespace Account.Origination.Job.TMVClient.Factories;

public interface IOnlineCallAccountRequestFactory
{
    Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount.CreateOnlineCallAccountRequest Create(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        string semanticVersionId,
        string accountName);

    Kb.TMV.Client.Actions.CreateOnlineCallAccount.Requests.CreateOnlineCallAccountRequest CreateV2AccountRequest(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        string semanticVersionId,
        string accountName);
}