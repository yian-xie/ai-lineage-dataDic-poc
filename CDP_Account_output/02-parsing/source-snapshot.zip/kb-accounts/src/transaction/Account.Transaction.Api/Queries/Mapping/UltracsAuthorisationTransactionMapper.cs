﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

using Account.Transaction.Api.Queries.Services.Filtering;
using Account.Transaction.Api.Queries.Types;

using Ultracs.Integration.Client;

namespace Account.Transaction.Api.Queries.Mapping;

/// <summary>
/// Map <see cref="AuthorisationTransactionItem"/> from Ultracs to <see cref="AccountTransaction"/> for the Account Transactions API.
/// </summary>
public partial class UltracsAuthorisationTransactionMapper : ITransactionMapper<AuthorisationTransactionItem, AccountTransaction>
{
    [GeneratedRegex(@"#(\d+)")]
    private static partial Regex PendingIdRegex();

    /// <summary>
    ///     Mapping the <see cref="AuthorisationTransactionItem"/> to <see cref="AccountTransaction" />.
    /// </summary>
    /// <param name="query"><see cref="IQueryable{TSource}" /> where TSource is <see cref="AuthorisationTransactionItem"/></param>
    /// <param name="accountId"></param>
    /// <returns><see cref="IQueryable{TTarget}" /> where TTarget is <see cref="AccountTransaction" /></returns>
    /// <remarks>Reference: <see href="https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/6037635467/ATS+Ultracs+Transaction+Fields+Mapping"/></remarks>
    public IQueryable<AccountTransaction> MapTo(
        IQueryable<AuthorisationTransactionItem> query,
        string accountId)
    {
        return query.AsEnumerable()
            .Select(x =>
            {
                var key = CreateDeterministicGuid(x, accountId);

                var valueDateTime = new DateTimeOffset(x.RequestDate, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneIds.NewZealandStandardTime).GetUtcOffset(x.RequestDate));

                return new AccountTransaction
                {
                    Id = key,
                    Index = GetPendingId(x.Description1),
                    TransactionId = key.ToString(),
                    MaskedCardNumber = x.CardNumber,
                    AccountId = accountId,
                    AccountNumber = x.AccountNumber,
                    AccountNumberDisplay = x.AccountNumber,
                    TransactionDescription = x.Description1,
                    TransactionDescription2 = x.Description2,
                    FinancialTransactionAmount = new Money
                    {
                        Value = x.SettledAmount.ToString(CultureInfo.InvariantCulture),
                        Currency = Currency.NZD
                    },
                    OutstandingAmount = new Money
                    {
                        Value = x.OutstandingAmount.ToString(CultureInfo.InvariantCulture),
                        Currency = Currency.NZD
                    },
                    CreditDebitIndicator = x.OutstandingAmount < 0 ? CreditDebitIndicator.Credit : CreditDebitIndicator.Debit,
                    Branch = x.Branch,
                    Operator = x.Operator,
                    SupInf = x.SupInf,
                    Cheque = x.Cheque,
                    BookingDateTime = x.EffectiveDate.HasValue ? new DateTimeOffset(x.EffectiveDate.Value, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneIds.NewZealandStandardTime).GetUtcOffset(x.EffectiveDate.Value)) : x.EffectiveDate,
                    ValueDateTime = valueDateTime,
                    TransactionCode = x.TransactionCode,
                    DeclineCode = x.DeclineCode,
                    Status = GetStatus(x),
                    // Set InsertedDateTime to ValueDateTime as the Ultracs API does not provide an inserted date, and ValueDateTime
                    // is the closest approximation to when the transaction occurred.
                    InsertionDateTime = valueDateTime
                };
            }).AsQueryable();
    }

    /// <summary>
    /// Use MD5 has of the <see cref="AuthorisationTransactionItem"/> to create a deterministic Guid.
    /// </summary>
    /// <param name="authorisationTransactionItem"><see cref="AuthorisationTransactionItem"/></param>
    /// <param name="accountId">The account ID for uniqueness</param>
    /// <returns><see cref="Guid"/></returns>
    public static Guid CreateDeterministicGuid(AuthorisationTransactionItem authorisationTransactionItem, string accountId)
    {
        var key =
            $"""
             {accountId}
             |{GetPendingId(authorisationTransactionItem.Description1)}
             |{authorisationTransactionItem.Branch}
             |{authorisationTransactionItem.Operator}
             |{authorisationTransactionItem.TransactionCode}
             |{authorisationTransactionItem.DeclineCode}
             |{authorisationTransactionItem.Status}
             """;
        var hash = MD5.HashData(Encoding.UTF8.GetBytes(key));

        return new Guid(hash);
    }

    /// <summary>
    /// Get the <see cref="Status"/>
    /// </summary>
    /// <param name="authorisationTransactionItem"><see cref="AuthorisationTransactionItem"/></param>
    /// <returns><see cref="Status"/></returns>
    /// <exception cref="ArgumentOutOfRangeException">Throw exception when fail to map to coressponding status.</exception>
    // TODO: Confirm the mapping of Ultracs Authorisation Transaction Status to Account Transaction Status
    private static Status GetStatus(AuthorisationTransactionItem authorisationTransactionItem)
    {
        // TODO: Confirm the mapping of Ultracs Authorisation Transaction Status to Account Transaction Status
        return authorisationTransactionItem.Status switch
        {
            "A" => // Pre-auth (pending)
                Status.Pending,
            "K" => // Completed (When transaction is posted, status is updated from "A" to "K")
                Status.Executed,
            "D" or "L" or "X" => // Manually deleted
                                 // Lapsed (Did not post before authorisation dropped - after 5 business days)
                                 // Declined
                Status.Cancelled,
            _ => throw new ArgumentOutOfRangeException(
                $"Unknown Ultracs Authorisation Transaction Status: {authorisationTransactionItem.Status}")
        };
    }

    /// <summary>
    /// Get the pending ID from description1 field.
    /// </summary>
    /// <param name="description1"></param>
    /// <returns>Pending ID</returns>
    private static int GetPendingId(string description1)
    {
        var match = PendingIdRegex().Match(description1);

        return match.Success ? Convert.ToInt32(match.Groups[1].Value) : 0;
    }
}