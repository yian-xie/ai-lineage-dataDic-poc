﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAlternateAccountNameAndBankingProductId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "alternate_account_name",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "banking_product_id",
                schema: "origination",
                table: "account_opening",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "banking_product_version_id",
                schema: "origination",
                table: "account_opening",
                type: "uuid",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "alternate_account_name",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "banking_product_id",
                schema: "origination",
                table: "account_opening");

            migrationBuilder.DropColumn(
                name: "banking_product_version_id",
                schema: "origination",
                table: "account_opening");
        }
    }
}