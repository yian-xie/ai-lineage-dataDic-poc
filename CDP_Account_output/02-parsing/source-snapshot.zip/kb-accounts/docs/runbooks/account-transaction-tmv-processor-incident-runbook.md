## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | `Account.Transaction.Tmv.Processor` |
| Customer or business impact | TMV posting events are not converted into current account balances and transaction events, causing stale balance and transaction views and delayed downstream ESP events. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Transaction Processor Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5211979790)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33414087)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Posting instruction batches repeatedly redeliver</summary>

**Symptoms**

- Logs repeatedly contain `Failed to process Posting Instruction Batch Event with batch Id` for the same batch.
- The event is redelivered every five seconds; delivery attempt 3 triggers one Sumo Logic ingestion attempt and records `LastAlertRaisedAt` when that write succeeds.
- `Rollback transaction for Posting Instruction Batch` appears, and no matching success/completion logs follow.

**Actions**

1. In the linked sumo logs, filter the affected environment and exact failure message by `batchId`; identify whether the exception originates in balance-spec loading, calculation, PostgreSQL, or an outbox enqueue.
2. Correlate `Received Posting Instruction Batch`, `balanceCalculation completed`, `database operations completed`, and `Completed processing` to locate the failed stage.
3. Check PostgreSQL and Kafka/outbox telemetry for the same trace and time window. Balance, transaction, PIB, account-posting outbox, and transaction-event outbox changes are committed together for accepted batches.
4. Do not reset offsets, delete the PIB record, or replay manually. [TODO: confirm the approved poison-event quarantine/replay procedure and consumer-offset procedure.]

**Recovery check**

- The batch logs `Successfully processed` and `Completed processing`, the event stops redelivering, and inserted balance/transaction counts match the payload.

**Escalate when**

- The same valid batch continues beyond the alert threshold, transaction rollback fails, or multiple partitions show sustained redelivery.

</details>

<details>
<summary>Balance specification contract notifications repeatedly fail</summary>

**Symptoms**

- Logs contain `Failed to process Contract Notification Event with account Id` for balance-specification notifications.
- The event redelivers every five seconds and Sumo ingestion is attempted when delivery attempt equals 3.
- Later PIB processing fails while loading balance specifications, or uses stale account/specification associations.

**Actions**

1. Filter logs for the exact failure message and correlate `accountId` and `balance specification Id` only within approved logging tools.
2. Distinguish malformed specification JSON or missing `version` from PostgreSQL read/write failure.
3. Confirm whether non-`BALANCE_SPECIFICATION` notifications are being skipped as designed rather than failing.
4. Do not edit specification or lookup rows manually. [TODO: confirm the approved contract-notification replay and data-reconciliation procedure.]

**Recovery check**

- The event logs `Successfully processed Contract Notification Event`, stops redelivering, and a subsequent non-production PIB can load the affected specification.

**Escalate when**

- Valid notifications remain unprocessable after dependency recovery, many accounts are affected, or PIB processing is blocked by missing specifications.

</details>

<details>
<summary>TMV Kafka consumer connectivity or OAuth failure</summary>

**Symptoms**

- No new `Received Posting Instruction Batch` or contract-notification logs appear despite confirmed upstream events.
- Kafka authentication, broker timeout, or partition-assignment errors appear for `vault.api.v1.postings.posting_instruction_batch.created` or `vault.core_api.v1.contracts.contract_notification.events`.
- Consumer lag rises for group `cg_accept_accounts_transaction_tmv_processor` in ACCEPT or its environment-specific equivalent.

**Actions**

1. Confirm pod health/restarts and TMV Kafka errors for the affected namespace.
2. Confirm the configured primary `TMVKafkaOAuth` brokers, OAuth endpoint/client ID/scope, and presence of secret key `KafkaClusters__TMVKafkaOAuth__OAuth__ClientSecret`.
3. Determine from startup logs whether the library selected the OAuth cluster or its configured plain-TLS failover.
4. Do not reset offsets or change consumer groups during triage. [TODO: confirm the approved TMV broker failover and offset-management procedures.]

**Recovery check**

- Partition assignment is restored, new events produce receive/success logs, and lag for the environment consumer group trends to baseline without duplicate processing.

**Escalate when**

- Both TMV clusters are unavailable, OAuth cannot obtain tokens across pods, or lag continues to grow after assignments recover.

</details>

<details>
<summary>Outbox events stop reaching ESP</summary>

**Symptoms**

- PIB processing completes and database balances/transactions exist, but downstream account transaction, account posting, or consumption events are delayed.
- Kafka/outbox telemetry degrades while PIB receive and completion metrics remain healthy.
- Outbox rows accumulate or retry without successful publication.

**Actions**

1. Compare successful logs for PIB completion with Kafka producer/outbox throughput and errors.
2. Confirm Confluent bootstrap and schema-registry connectivity and the presence of `Kafka__SaslUsername`, `Kafka__SaslPassword`, `Kafka__SchemaRegistry__ApiKey`, and `Kafka__SchemaRegistry__SecretKey`.
3. Determine whether new transactions are committed with outbox items and whether the asynchronous outbox service is running.
4. Do not delete, update, or manually republish outbox rows. [TODO: confirm the supported outbox inspection and replay procedure.]

**Recovery check**

- Outbox backlog drains, producer errors cease, and a non-production PIB produces the expected downstream event exactly once.

**Escalate when**

- Database processing is healthy but outbox backlog grows, schema registration/compatibility blocks publication, or downstream consumers remain missing events.

</details>

<details>
<summary>Failure alerts are not ingested into Sumo Logic</summary>

**Symptoms**

- Local logs contain `Failed to push log into SumoLogic` after a PIB or contract-notification failure.
- Redelivery continues, but the expected threshold alert is absent from the monitoring-log source.
- Sumo ingestion failures are isolated from event processing and have no automatic retry in the subscriber.

**Actions**

1. Filter application logs for both the original processing failure and `Failed to push log into SumoLogic`; retain the original batch/specification correlation.
2. Confirm `SumoLogicIngestion__SourceCategory`, `SumoLogicIngestion__SourceName`, and presence of `SumoLogicIngestion__ApiToken` for the affected deployment.
3. Use Dynatrace and application logs as the temporary source of truth while ingestion is impaired.
4. Do not rotate the token without the approved secret-rotation procedure. [TODO: confirm the Sumo Logic token validation and rotation procedure.]

**Recovery check**

- A controlled non-production processing failure reaches the configured Sumo source and application logs no longer show ingestion failures. No failure was injected during runbook generation.

**Escalate when**

- Alert ingestion remains unavailable during active redeliveries or failures affect multiple services using the collector.

</details>

<details>
<summary>Migration history consumer does not scale with lag</summary>

**Symptoms**

- Lag on `accept.migrate.transactions.history.v1.event` or the environment-prefixed equivalent exceeds 5000 without scaling toward 10 replicas.
- Pipeline logs say `Skipping KEDA resources` or `ERROR: Failed to apply` while the script exits without failing deployment.
- KEDA falls back to 3 replicas after 3 scaler failures.

**Actions**

1. Confirm the issue is the KB migration-history topic; the KEDA object does not scale the two TMV topics.
2. Inspect deployment logs from `apply-keda-resources.sh` for missing namespace, CRDs, KEDA operator, values, TriggerAuthentication, or ScaledObject application.
3. Compare migration-topic lag with replicas in the exact environment namespace; ACCEPT is `accept-transaction-tmv-processor`.
4. Confirm the `transaction-tmv-processor-kafka-auth` reference resolves secret keys `Kafka__SaslUsername` and `Kafka__SaslPassword`. [TODO: confirm the approved cluster-access procedure for direct KEDA inspection.]

**Recovery check**

- The ScaledObject reports healthy, lag above 10 activates scaling, lag above 5000 drives additional replicas up to the configured maximum, and backlog trends down.

**Escalate when**

- KEDA resources cannot be applied, scaler authentication fails, or lag grows at 10 replicas.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>