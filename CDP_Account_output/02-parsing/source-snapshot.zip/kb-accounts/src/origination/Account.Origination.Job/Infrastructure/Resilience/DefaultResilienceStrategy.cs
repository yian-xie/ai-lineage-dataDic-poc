﻿using System.Net;

namespace Account.Origination.Job.Infrastructure.Resilience;

/// <summary>
///     Provides a default implementation of the resilience strategy for handling HttpRequestExceptions
///     during operations.
///     In order to handle specific exceptions or to implement custom retry logic, this class can be extended and the ShouldRetry method can be overridden.
/// </summary>
public class DefaultResilienceStrategy : IResilienceExceptionStrategy
{
    private static readonly HashSet<HttpStatusCode> RetryableStatusCodes =
    [
        HttpStatusCode.RequestTimeout,
        HttpStatusCode.TooManyRequests,
        HttpStatusCode.GatewayTimeout,
        HttpStatusCode.BadGateway,
        HttpStatusCode.InternalServerError,
        HttpStatusCode.ServiceUnavailable
    ];

    public virtual bool ShouldRetry(Exception ex)
    {
        if (ex is HttpRequestException httpRequestException)
        {
            return RetryableStatusCodes.Contains(httpRequestException.StatusCode ?? HttpStatusCode.OK);
        }

        return false;
    }
}