﻿using System;

using Account.Profile.Api.Queries;
using Account.Profile.Api.Services;
using Account.Profile.Shared;
using Account.Profile.Shared.Constants;
using Account.Profile.Shared.Infrastructure;
using Account.Shared;
using Account.Shared.Authorisation;
using Account.Shared.Graphql;
using Account.Shared.Kafka;
using Account.Shared.Kafka.Publishers;
using Account.Shared.Middleware;

using Enterprise.Shared.Database;

using Kb.Api.Observability;
using Kb.Api.Observability.Metrics;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using AccountAuditLogEventBuilder = Account.Profile.Api.Services.AccountAuditLogEventBuilder;

namespace Account.Profile.Api;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Constants.Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        var metricsOptions = Configuration.GetSection(nameof(MetricsOptions)).Get<MetricsOptions>();
        ArgumentNullException.ThrowIfNull(metricsOptions);
        services.AddSingleton(metricsOptions);
        services.AddSingleton<IProfilingMetrics, ProfilingMetrics>();

        services
            .AddRepositories()
            .AddRelatedAccountAuditLogServices()
            .AddAccountAuditLogServices()
            .AddScoped<IAccountProfileAction, AccountProfileAction>();

        AddPooledDbContextWithOutbox<AccountProfileDbContext>(services);

        services.AddScoped<IUnitOfWork, AccountProfileDbContext>();
        services.AddScoped<IProfileAuditLogDataProvider, ProfileAuditLogDataProvider>();
        services.AddScoped<IAccountAuditLogV2EventBuilder, AccountAuditLogEventBuilder>();

        services.AddHeaderPropagation(options =>
        {
            options.Headers.Add(ObservabilityConstants.HeaderNames.Authorization);
            options.Headers.Add(ObservabilityConstants.HeaderNames.XKbBearerIntrospection);
        });
        services.AddTokenProviders(Configuration);

        UseKafka(services);

        UsePooledDbContext<AccountProfileDbContext>(services);

        services.UseGraphql<AccountProfileQuery>(Configuration, useAuthorization: false)
            .UseField<AuditLogMiddleware>()
            .ModifyOptions(x => x.UseXmlDocumentation = true);
    }
}