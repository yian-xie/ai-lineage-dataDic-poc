﻿namespace Account.Origination.Processor.Services;

public interface IAccountIdCreator
{
    /// <summary>
    ///     Create account id.
    /// </summary>
    /// <param name="incomingId">Given event id</param>
    /// <returns>Return account id</returns>
    string Create(Guid incomingId);
}