﻿using FluentValidation;

using Lifecycle = Account.PaymentInstruction.Api.Queries.Types.Lifecycle;
using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;
using TransactionType = Account.PaymentInstruction.Api.Queries.Types.TransactionType;

namespace Account.PaymentInstruction.Api.Validations.PaymentInstructionRequestInputValidation;

/// <summary>
///     Validator that validates property values in <see cref="PaymentInstructionRequestInput" /> are supported.
/// </summary>
public class SupportabilityValidator : AbstractValidator<PaymentInstructionRequestInput>
{
    public SupportabilityValidator()
    {
        RuleFor(i => i.PaymentInstruction.Type)
            .Must(t => t == TransactionType.Transfer)
            .WithMessage("Only Transfer supported.");

        RuleFor(i => i.PaymentInstruction.Lifecycle)
            .Must(l => l == Lifecycle.HardSettlement)
            .WithMessage("Only HardSettlement supported.");
    }
}