﻿using System.Net;

namespace Account.Transaction.Api.Queries.Exceptions;

/// <summary>
/// Request validation exception for invalid transaction requests.
/// </summary>
public class UnsupportedTransactionTypeException : TransactionExceptionBase
{
    /// <summary>
    /// Unsupported transaction type exception constructor
    /// </summary>
    /// <param name="message">The error message</param>
    public UnsupportedTransactionTypeException(string message) : base(message) { }

    /// <summary>
    /// Unsupported transaction type exception constructor with status code
    /// </summary>
    /// <param name="message">The error message</param>
    /// <param name="statusCode"><see cref="HttpStatusCode"/></param>
    public UnsupportedTransactionTypeException(string message, HttpStatusCode statusCode) : base(message, statusCode) { }
}