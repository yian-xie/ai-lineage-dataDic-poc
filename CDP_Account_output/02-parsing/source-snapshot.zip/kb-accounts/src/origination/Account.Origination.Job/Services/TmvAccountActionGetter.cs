﻿using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Services;

namespace Account.Origination.Job.Services;

public class TmvAccountActionGetter(IEnumerable<ITmvAccountAction> tmvAccountActions)
    : ITmvAccountActionGetter
{
    /// <summary>
    ///     Get the implemented <see cref="ITmvAccountAction" />.
    /// </summary>
    /// <remarks>
    ///     This is a workaround in order to get the <see cref="SpudAccountAction" /> for SPUD product by checking the account
    ///     id prefix. Returning first non SpudAccountAction for other product.
    ///     To consider a better approach to support multiple product, please check:
    ///     https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/4415488181/How+to+support+multiple+product+type+in+account+creation+opening.
    /// </remarks>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <returns>
    ///     <see cref="ITmvAccountAction" />
    /// </returns>
    public ITmvAccountAction GetTmvAccountAction(AccountOpening accountOpening)
    {
        return accountOpening.AccountId.StartsWith(Product.Spud)
            ? tmvAccountActions.Single(x => x.Product == Product.Spud)
            : GetActionByProductCode(accountOpening);
    }

    private ITmvAccountAction GetActionByProductCode(AccountOpening accountOpening)
    {
        return accountOpening.ProductCode switch
        {
            Product.Sv1 => tmvAccountActions.Single(x => x.Product == Product.Sv1),
            _ => throw new InvalidOperationException(
                $"No TMV account action found for product code {accountOpening.ProductCode}.")
        };
    }
}