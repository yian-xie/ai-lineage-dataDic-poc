﻿using Account.Domain.Directory.Service.WebApiClient;

using Kb.Api.Infrastructure.Http;
using Kb.Api.Infrastructure.JwtTokenProvider;

namespace Account.Origination.Job.Extension;

public static class ServiceExtensions
{
    public static IServiceCollection ConfigureAccountDomainDirectoryServiceWebApiClient(this IServiceCollection serviceCollection, IConfiguration configuration)
    {
        serviceCollection.Configure<WebApiClientOptions>(
            configuration.GetSection("AccountDomainDirectoryServiceWebApiClientOptions"));

        serviceCollection.Configure<AzureAdTokenOptions>(configuration.GetSection(nameof(AzureAdTokenOptions)));

        serviceCollection.AddScoped<IAzureAdTokenService, AzureAdTokenService>();
        serviceCollection.AddTransient<AzureTokenHandler>();

        serviceCollection.AddAccountsClients().AddHttpMessageHandler<AzureTokenHandler>();
        serviceCollection.AddPartyClients().AddHttpMessageHandler<AzureTokenHandler>();
        return serviceCollection;
    }
}