﻿using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

using Account.Transaction.Api.CardsClient.Exceptions;

using Microsoft.Extensions.Logging;

namespace Account.Transaction.Api.CardsClient.Extensions;

/// <summary>
/// Provides extension methods for <see cref="HttpResponseMessage"/> to handle common tasks such as deserializing the response content.
/// </summary>
public static class HttpResponseMessageExtensions
{
    /// <summary>
    /// Asynchronously deserializes the JSON content of an HTTP response to a specified type.
    /// </summary>
    /// <typeparam name="T">The type to which the response content will be deserialized. Must be a class.</typeparam>
    /// <param name="response">The HTTP response message containing the JSON content.</param>
    /// <param name="logger">The logger used to log critical issues during the deserialization process.</param>
    /// <returns>A task representing the asynchronous operation, which upon completion returns the deserialized object of type <typeparamref name="T"/>.</returns>
    /// <exception cref="Exception">Throws an exception if the response content is empty or if deserialization fails.</exception>
    public static async Task<T> DeserializeResponseContent<T>(this HttpResponseMessage response, ILogger logger) where T : class
    {
        try
        {
            var responseString = await response.Content.ReadAsStringAsync();

            if (string.IsNullOrEmpty(responseString))
            {
                logger.LogCritical("Response content is empty");
                throw new Exception("Response content is empty");
            }
            var deserializedResponse = JsonSerializer.Deserialize<T>(responseString, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (deserializedResponse == null)
            {
                logger.LogCritical($"{nameof(deserializedResponse)} cannot be null");
                throw new Exception($"{nameof(deserializedResponse)} cannot be null");
            }

            return deserializedResponse;
        }
        catch (Exception ex)
        {
            logger.LogError(ex.Message, ex);
            throw new CreditCardTransactionsException(ex.Message);
        }
    }
}