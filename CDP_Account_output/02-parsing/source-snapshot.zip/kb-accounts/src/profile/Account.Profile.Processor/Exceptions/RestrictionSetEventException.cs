﻿using System;

namespace Account.Profile.Processor.Exceptions;

public class RestrictionSetEventException : Exception
{
    public RestrictionSetEventException(string message)
        : base(message) { }
}