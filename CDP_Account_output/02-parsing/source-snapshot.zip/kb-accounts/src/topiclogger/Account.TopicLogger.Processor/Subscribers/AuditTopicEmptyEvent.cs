﻿using Api.Shared.Clients.Events;

namespace Account.TopicLogger.Processor.Subscribers;

/// <summary>
///     Typically, the IIncomingEventSubscriber for Kafka event consumers expects events
///     to follow predefined schemas. However, events from different Kafka topics may each
///     have unique schemas. For log ingestion purposes, there is no need to be aware of
///     the event schema; the event will be directly extracted from the consumeResult and
///     ingested into Sumo Logic. However, we still need an empty schema for the consumer
///     to work.
/// </summary>
public class AuditTopicEmptyEvent : IEvent;