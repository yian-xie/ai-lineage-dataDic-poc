﻿using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Models;
using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.ThoughtMachine.V1.RestrictionSet;

namespace Account.Profile.Processor.Services;

/// <summary>
/// Handling TMV Restriction Set events which is related to account profile freeze and unfreeze.
/// </summary>
public interface IRestrictionSetEventHandler
{
    /// <summary>
    /// This property is used to indicate the type of TMV Restriction Set event handler, either Created or Updated.
    /// </summary>
    RestrictionType Type { get; }

    /// <summary>
    /// Handling TMV Restriction Set event for account freeze and unfreeze.
    /// </summary>
    /// <param name="accountProfile"><see cref="AccountProfile"/></param>
    /// <param name="restriction"><see cref="Restriction"/></param>
    /// <returns>True if the Restriction is successfully handled, otherwise false.</returns>
    bool Handle(AccountProfile accountProfile, Restriction restriction);
}

public enum RestrictionType
{
    Created,
    Updated
}