﻿#nullable enable

using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Processor.Helper;
using Account.Profile.Processor.Publishers;
using Account.Profile.Shared.Constants;
using Account.Profile.Shared.Entities;
using Account.Profile.Shared.Repositories;
using Account.Shared.Services;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;
using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;
using Api.Shared.Clients.Rest.SumoLogic;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Implements IAccountProfileUpdater interface for updating AccountProfile in the database.
/// </summary>
public class AccountProfileUpdater(
    IRepositoryFactory repositoryFactory,
    IAccountProfileEventPublisher accountProfileEventPublisher,
    IAccountProfileCreator accountProfileCreator,
    IAccountProfileChangeSetCreator accountProfileChangeSetCreator,
    ILogger<AccountProfileUpdater> logger,
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings)
    : IAccountProfileUpdater
{
    public async Task<AccountProfile?> UpdateAndPublishAsync(
        AccountEvent accountEvent,
        DateTimeOffset accountStatusTimestamp,
        CancellationToken cancellationToken)
    {
        var accountId = accountEvent.Account_updated.Account.Id;
        try
        {
            var existingAccountProfile =
                await repositoryFactory.AccountProfileRepository.GetAccountAsync(
                    accountId,
                    cancellationToken);

            if (existingAccountProfile is null)
            {
                var logMessage =
                    $"Received Account update event (eventId: {accountEvent.Event_id}) for non-existing account profile {accountId}. The account profile will be created from the update event.";
                logger.LogWarning(logMessage);

                try
                {
                    await sumoLogicClientHelper.IngestLogAsync(
                        logMessage,
                        sumoLogicSettings.SourceCategory,
                        sumoLogicSettings.SourceName + Constants.SumoSourceNames.TmvAccountEventSubscriber,
                        sumoLogicSettings.ApiToken,
                        cancellationToken);
                }
                catch (Exception nestedEx)
                {
                    logger.LogError(
                        nestedEx,
                        $"Failed to push log into SumoLogic for receiving Account update event (eventId: {accountEvent.Event_id}) for non-existing account profile {accountId}.");
                }
            }

            var accountProfile = existingAccountProfile == null
                ? await accountProfileCreator.CreateAndPublishAsync(
                    accountEvent,
                    accountStatusTimestamp,
                    true,
                    cancellationToken)
                : await UpdateAndPublishAsync(
                    accountEvent,
                    existingAccountProfile,
                    accountStatusTimestamp,
                    cancellationToken);

            return accountProfile;
        }
        catch (DbUpdateConcurrencyException ex)
        {
            logger.LogWarning(
                ex,
                $"Concurrency conflict of updating account profile {accountId}.");

            throw;
        }
    }

    /// <summary>
    ///     Update and publish the account profile. If the received change id is less than current change id + 1, return null
    ///     account profile and no account profile update and publish.
    /// </summary>
    /// <param name="accountEvent"></param>
    /// <param name="accountProfile">
    ///     <see cref="AccountProfile" />
    /// </param>
    /// <param name="accountStatusTimestamp">The account status timestamp</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfile" />
    /// </returns>
    private async Task<AccountProfile?> UpdateAndPublishAsync(
        AccountEvent accountEvent,
        AccountProfile accountProfile,
        DateTimeOffset accountStatusTimestamp,
        CancellationToken cancellationToken)
    {

        var updateAccountProfile = accountProfileChangeSetCreator.CreateAccountProfileChangeSetForUpdate(accountEvent);

        if (updateAccountProfile.ChangeId < accountProfile.ChangeId + 1)
        {
            logger.LogWarning(
                $"Received changeId {updateAccountProfile.ChangeId} of accountId {updateAccountProfile.AccountId} which is less than existing changeId {accountProfile.ChangeId} plus one. Ignore the message.");

            return null;
        }

        if (updateAccountProfile.ChangeId > accountProfile.ChangeId + 1)
        {
            var logMessage = $"Encounter a skipping update event for account profile {accountProfile.AccountId}. Expecting changeId {accountProfile.ChangeId + 1} but received changeId {updateAccountProfile.ChangeId}. The profile will be updated with info available from the Account update event.";
            logger.LogWarning(logMessage);

            try
            {
                await sumoLogicClientHelper.IngestLogAsync(
                    logMessage,
                    sumoLogicSettings.SourceCategory,
                    sumoLogicSettings.SourceName + Constants.SumoSourceNames.TmvAccountEventSubscriber,
                    sumoLogicSettings.ApiToken,
                    cancellationToken);
            }
            catch (Exception nestedEx)
            {
                logger.LogError(
                    nestedEx,
                    $"Failed to push log into SumoLogic for encountering skipping update events of account profile {accountProfile.AccountId}.");
            }

            // create the account profile updates base on the entire account update event, instead of just relying on update masks
            updateAccountProfile =
                accountProfileChangeSetCreator.CreateAccountProfileChangeSet(accountEvent);
        }

        var afterStateAccountProfile = UpdateAccountProfile(
            accountProfile,
            updateAccountProfile,
            logger);

        repositoryFactory.AccountProfileRepository.Update(afterStateAccountProfile);
        await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);

        logger.LogInformation(
            "The account profile {accountId} with changeId {changeId} is updated.",
            afterStateAccountProfile.AccountId,
            afterStateAccountProfile.ChangeId);


        await accountProfileEventPublisher.PublishAccountProfileEventAsync(
            afterStateAccountProfile,
            MetadataType.AccountUpdated,
            accountStatusTimestamp,
            accountEvent.GetCorrelationId(logger),
            repositoryFactory.UnitOfWork,
            cancellationToken);


        return afterStateAccountProfile;
    }

    /// <summary>
    ///     Update account profile by AccountProfileChangeSet.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="AccountProfile" />
    /// </param>
    /// <param name="accountProfileChangeSet">
    ///     <see cref="AccountProfileChangeSet" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfile" />
    /// </returns>
    public static AccountProfile UpdateAccountProfile(
        AccountProfile accountProfile,
        AccountProfileChangeSet accountProfileChangeSet,
        ILogger<AccountProfileUpdater> logger = null)
    {
        accountProfile.ChangeId = accountProfileChangeSet.ChangeId;
        // Don't override the correlationId if it is already set.
        accountProfile.CorrelationId = accountProfile.CorrelationId == Guid.Empty ? accountProfileChangeSet.CorrelationId : accountProfile.CorrelationId;

        if (accountProfileChangeSet.Status is not null)
        {
            if (accountProfile.Status == nameof(AccountStatus.Frozen))
            {
                if (AccountStatusHelper.IsTmvAccountStatusPreOpen(accountProfileChangeSet.Status) && logger != null)
                {
                    // Something has gone wrong if TMV status is still Pre-Open while account profile is already frozen,
                    // log the issue and keep the freeze until TMV status is Post-Open.
                    logger.LogWarning($"Received Pre-Open status for accountId {accountProfile.AccountId} which is frozen.");
                }
                if (AccountStatusHelper.IsTmvAccountStatusPostOpen(accountProfileChangeSet.Status))
                {
                    // TMV status is no longer Open, remove the freeze.
                    accountProfile.Status = AccountStatusHelper.AccountStatusStringFromTmvStatusString(accountProfileChangeSet.Status);
                    accountProfile.AccountFreezeDetails = new AccountFreezeDetails();
                }
                // TMV status is still Open, leave it frozen.
            }
            else
            {
                accountProfile.Status = AccountStatusHelper.AccountStatusStringFromTmvStatusString(accountProfileChangeSet.Status);
            }
            accountProfile.TmvStatus = accountProfileChangeSet.Status;
        }

        if (accountProfileChangeSet.Created is not null)
        {
            accountProfile.Created = accountProfileChangeSet.Created;
        }

        if (accountProfileChangeSet.Opened is not null)
        {
            accountProfile.Opened = accountProfileChangeSet.Opened;
        }

        if (accountProfileChangeSet.Closed is not null)
        {
            accountProfile.Closed = accountProfileChangeSet.Closed;
        }

        if (accountProfileChangeSet.AccountClosureReason is not null)
        {
            accountProfile.AccountClosureReason = accountProfileChangeSet.AccountClosureReason;
        }

        if (accountProfileChangeSet.AccountName is not null)
        {
            accountProfile.Name = accountProfileChangeSet.AccountName;
        }

        if (accountProfileChangeSet.AlternateAccountName is not null)
        {
            accountProfile.AlternateName = accountProfileChangeSet.AlternateAccountName;
        }

        if (accountProfileChangeSet.AccountOrganisationUnitId is not null)
        {
            accountProfile.AccountOrganisationUnitId =
                accountProfileChangeSet.AccountOrganisationUnitId;
        }

        if (accountProfileChangeSet.AccountCreatedUserId is not null)
        {
            accountProfile.AccountCreatedUserId =
                accountProfileChangeSet.AccountCreatedUserId;
        }

        if (accountProfileChangeSet.NzBankAccountNumber is not null)
        {
            var identifier = accountProfile.Identifiers.FirstOrDefault(x =>
                x.AccountIdentificationType == ProfileKeys.Details.NzBankAccountNumber);

            if (identifier == null)
            {
                identifier = new AccountProfileIdentifier
                {
                    AccountIdentificationType = ProfileKeys.Details.NzBankAccountNumber
                };
                accountProfile.Identifiers.Add(identifier);
            }

            identifier.AccountIdentification = accountProfileChangeSet.NzBankAccountNumber;
        }

        if (accountProfileChangeSet.LegacyCoreAccountId is not null)
        {
            var identifier = accountProfile.Identifiers.FirstOrDefault(x =>
                x.AccountIdentificationType == ProfileKeys.Details.LegacyCoreAccountId);

            if (identifier == null)
            {
                identifier = new AccountProfileIdentifier
                {
                    AccountIdentificationType = ProfileKeys.Details.LegacyCoreAccountId
                };
                accountProfile.Identifiers.Add(identifier);
            }

            identifier.AccountIdentification = accountProfileChangeSet.LegacyCoreAccountId;
        }

        if (accountProfileChangeSet.ProductFacilityId is not null)
        {
            accountProfile.ProductFacility.ProductFacilityId =
                accountProfileChangeSet.ProductFacilityId;
        }

        if (accountProfileChangeSet.BankingProductId is not null)
        {
            accountProfile.ProductFacility.BankingProductId =
                accountProfileChangeSet.BankingProductId;
        }

        if (accountProfileChangeSet.BankingProductCode is not null)
        {
            accountProfile.ProductFacility.BankingProductCode =
                accountProfileChangeSet.BankingProductCode;
        }

        if (accountProfileChangeSet.BankingProductVersionId is not null)
        {
            accountProfile.ProductFacility.BankingProductVersionId =
                accountProfileChangeSet.BankingProductVersionId;
        }

        if (accountProfileChangeSet.BankingRelationshipId is not null)
        {
            accountProfile.BankingRelationship.BankingRelationshipId =
                accountProfileChangeSet.BankingRelationshipId;
        }

        if (accountProfileChangeSet.BankingRelationshipType is not null)
        {
            accountProfile.BankingRelationship.BankingRelationshipType =
                accountProfileChangeSet.BankingRelationshipType;
        }

        if (accountProfileChangeSet.PartyIds is not null)
        {
            accountProfile.BankingRelationship.PartyIds = accountProfileChangeSet.PartyIds;
        }

        if (accountProfileChangeSet.MinimumNumberOfAuthoriser is not null)
        {
            accountProfile.MinimumNumberOfAuthoriser =
                accountProfileChangeSet.MinimumNumberOfAuthoriser;
        }

        var accountCurrenciesToRemove = accountProfile.AccountCurrencies
            .Where(existingAccountCurrency =>
                !accountProfileChangeSet.AccountCurrencies.Any(accountCurrency =>
                    accountCurrency.Currency == existingAccountCurrency.Currency &&
                    accountCurrency.CurrencyType == existingAccountCurrency.CurrencyType))
            .ToList();

        var accountCurrenciesToAdd = accountProfileChangeSet.AccountCurrencies
            .Where(accountCurrency =>
                !accountProfile.AccountCurrencies.Any(existingAccountCurrency =>
                    existingAccountCurrency.Currency == accountCurrency.Currency &&
                    existingAccountCurrency.CurrencyType == accountCurrency.CurrencyType))
            .Select(accountCurrency =>
                new Shared.Entities.AccountCurrency
                {
                    Currency = accountCurrency.Currency,
                    CurrencyType = accountCurrency.CurrencyType
                })
            .ToList();

        accountProfile.AccountCurrencies = accountProfile.AccountCurrencies
            .Except(accountCurrenciesToRemove)
            .Concat(accountCurrenciesToAdd)
            .ToList();

        return accountProfile;
    }
}