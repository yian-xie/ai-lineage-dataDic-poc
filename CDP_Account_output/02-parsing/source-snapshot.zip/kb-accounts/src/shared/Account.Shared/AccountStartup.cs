﻿using System;

using Account.Shared.Constants;
using Account.Shared.Database;
using Account.Shared.Infrastructure.Filters;
using Account.Shared.Kafka;

using Api.Shared.Clients.Rest.ThoughtMachine;

using Enterprise.Shared.Application.WebHostService;
using Enterprise.Shared.Database;
using Enterprise.Shared.Infrastructure.Filters;
using Enterprise.Shared.Kafka;
using Enterprise.Shared.Kafka.Outbox;
using Enterprise.Shared.Kafka.Outbox.Telemetry;

using FluentValidation;

using Kb.Api.Infrastructure.ErrorHandling;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Account.Shared;

public abstract class AccountStartup(
    IConfiguration configuration,
    IWebHostEnvironment webHostEnvironment,
    string activitySourceName)
    : StartupCustom(configuration, webHostEnvironment, activitySourceName)
{
    protected abstract void AddApplicationServices(IServiceCollection services);

    protected void UseKafka(IServiceCollection services)
    {
        services
            .AddKafka()
            .AddKafkaTelemetry();
    }

    protected void UseDbContext<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext
    {
        services
            .UseDb(Configuration)
            .WithDbContext<TDbContext>(Migration.SetAssembly)
            .AddSqlHealthCheck();
    }

    protected void UsePooledDbContext<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IDbContextSchemaName
    {
        services
            .UseDb(Configuration, true)
            .WithPooledDbContext<TDbContext>(Migration.SetAssembly,
                option => option.UseSnakeCaseNamingConvention(),
                option => option.MigrationsHistoryTable(
                    DatabaseConstants.MigrationTableName,
                    TDbContext.SchemaName()))
            .AddSqlHealthCheck();
    }

    protected void UseDbContextFactory<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext
    {
        services
            .UseDb(Configuration)
            .WithDbContextFactory<TDbContext>(Migration.SetAssembly)
            .AddSqlHealthCheck();
    }

    protected void AddDbContextWithOutbox<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IOutboxStore
    {
        SetupDb<TDbContext>(services)
            .AddSqlHealthCheck();

        services
            .AddKafkaOutboxTelemetry()
            .AddOutboxService<TDbContext>();
    }

    protected void AddPooledDbContextWithOutbox<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IOutboxStore, IDbContextSchemaName
    {
        SetupPooledDb<TDbContext>(services);

        services
            .AddKafkaOutboxTelemetry()
            .AddOutboxService<TDbContext>();
    }

    protected void AddDbContextFactoryWithOutbox<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IOutboxStore
    {
        SetupDbFactory<TDbContext>(services)
            .AddSqlHealthCheck();

        services
            .AddKafkaOutboxTelemetry()
            .AddOutboxService<TDbContext>();
    }

    private DbSetupContext<TDbContext> SetupDb<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IOutboxStore
    {
        return services
            .UseDb(Configuration)
            .WithDbContext<TDbContext>(Migration.SetAssembly);
    }

    private DbSetupContext<TDbContext> SetupPooledDb<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IOutboxStore, IDbContextSchemaName
    {
        return services
            .UseDb(Configuration, true)
            .WithPooledDbContext<TDbContext>(Migration.SetAssembly,
                option => option.UseSnakeCaseNamingConvention(),
                option => option.MigrationsHistoryTable(
                    DatabaseConstants.MigrationTableName,
                    TDbContext.SchemaName()));
    }

    private DbSetupContext<TDbContext> SetupDbFactory<TDbContext>(IServiceCollection services)
        where TDbContext : DbContext, IOutboxStore
    {
        return services
            .UseDb(Configuration)
            .WithDbContextFactory<TDbContext>(Migration.SetAssembly);
    }

    public override void Configure(IApplicationBuilder app)
    {
        app.UseMiddleware<ExceptionHandlingMiddleware>();

        base.Configure(app);
    }

    protected sealed override void ConfigureCustomServices(IServiceCollection services)
    {
        // Graphql validators
        services.AddValidatorsFromAssembly(GetType().Assembly);

        services.AddSingleton<IGlobalHttpExceptionHandler, GlobalHttpExceptionHandler>();

        GetApplicationSettingsFromConfig(services);

        AddApplicationServices(services);
    }

    protected KafkaSettings GetKafkaSettings()
    {
        return Configuration.GetSection(KafkaSettings.Key).Get<KafkaSettings>();
    }

    /// <summary>
    ///     Get the Kafka settings with specific retry topic count.
    /// </summary>
    /// <param name="retryTopicCount">Retry topic count</param>
    /// <returns>
    ///     <see cref="KafkaSettings" />
    /// </returns>
    protected KafkaSettings GetKafkaSettings(int retryTopicCount)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(retryTopicCount);
        var kafkaSettings = GetKafkaSettings();
        kafkaSettings.RetryTopicCount = retryTopicCount;

        return kafkaSettings;
    }

    protected TmvKafkaSettings GetTmvKafkaSettings()
    {
        return Configuration.GetSection(TmvKafkaSettings.Key).Get<TmvKafkaSettings>();
    }

    private void GetApplicationSettingsFromConfig(IServiceCollection services)
    {
        var tmvConfig = Configuration
            .GetSection(ThoughtMachineVaultConfig.Position)
            .Get<ThoughtMachineVaultConfig>();

        if (tmvConfig is not null)
        {
            services.AddSingleton(tmvConfig!);
        }

        services.Configure<ThoughtMachineVaultConfig>(
            Configuration.GetSection(ThoughtMachineVaultConfig.Position));

        var kafkaSettings = GetKafkaSettings();

        if (kafkaSettings is not null)
        {
            services.AddSingleton(kafkaSettings);
        }

        var tmvKafkaSettings = GetTmvKafkaSettings();

        if (tmvKafkaSettings is not null)
        {
            services.AddSingleton(tmvKafkaSettings);
        }
    }
}