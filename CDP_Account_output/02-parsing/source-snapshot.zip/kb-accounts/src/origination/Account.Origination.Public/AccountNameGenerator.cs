﻿using Account.Origination.Public.Interfaces;

namespace Account.Origination.Public
{
    public sealed class AccountNameGenerator : IAccountNameGenerator
    {
        private readonly IEnumerable<INameGenerator> _nameGenerators;

        public AccountNameGenerator(IEnumerable<INameGenerator> nameGenerators)
        {
            _nameGenerators = nameGenerators ?? throw new ArgumentNullException(nameof(nameGenerators));
            if (!_nameGenerators.Any())
            {
                throw new ArgumentNullException(nameof(nameGenerators), "Provided name generation rule list is empty.");
            }
        }

        public string GenerateAccountName(Party[] parties)
        {
            if (parties == null || parties.Length == 0)
            {
                throw new ArgumentException("Parties cannot be null or empty.", nameof(parties));
            }

            // Find single matching generator.Rules are mutual exclusive
            var matchingGenerator = _nameGenerators.SingleOrDefault(generator => generator.IsMatch(parties));

            if (matchingGenerator == null)
            {
                throw new InvalidOperationException("No name generation rule found for the provided parties.");
            }

            return matchingGenerator.GenerateName(parties);
        }
    }
}