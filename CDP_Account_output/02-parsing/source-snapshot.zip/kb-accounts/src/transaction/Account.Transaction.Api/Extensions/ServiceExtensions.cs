﻿using System;
using System.Net.Http.Headers;

using Account.Transaction.Api.CardsClient;
using Account.Transaction.Api.CardsClient.Configuration;

using Kb.Api.Observability.Metrics;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Account.Transaction.Api.Extensions;

/// <summary>
/// Provides extension methods for configuring HTTP clients and services in the Transaction API.
/// </summary>
public static class ServiceExtensions
{
    /// <summary>
    /// Configures and registers an HTTP client for the Cards service with timeout settings,
    /// base URL configuration, and authorization header propagation.
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <returns></returns>
    /// <exception cref="InvalidOperationException"></exception>
    public static IHttpClientBuilder AddCardsClient(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<CardsClientConfiguration>(
            configuration.GetSection(CardsClientConfiguration.Key));

        var metricsOptions = configuration.GetSection(nameof(MetricsOptions)).Get<MetricsOptions>();
        ArgumentNullException.ThrowIfNull(metricsOptions);
        services.AddSingleton(metricsOptions);

        services.AddSingleton<IProfilingMetrics, ProfilingMetrics>();

        return services.AddHttpClient<ICardsClient, CardsClient.CardsClient>((sp, client) =>
            {
                var config = sp.GetService<IOptions<CardsClientConfiguration>>() ??
                    throw new InvalidOperationException(
                        "CardsClientConfiguration section is missing from appsettings");

                client.BaseAddress = new Uri(config.Value.BaseUrl);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));

                client.Timeout = TimeSpan.FromSeconds(config.Value.TimeoutInSeconds);
            })
            .AddHeaderPropagation();
    }
}