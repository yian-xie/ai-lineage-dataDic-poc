﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAccountFreezeDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "account_freeze_details_change_id",
                schema: "profile",
                table: "account_profile",
                type: "bigint",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "account_freeze_details_freeze_description",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "account_freeze_details_freeze_type",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "account_freeze_details_change_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "account_freeze_details_freeze_description",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "account_freeze_details_freeze_type",
                schema: "profile",
                table: "account_profile");
        }
    }
}