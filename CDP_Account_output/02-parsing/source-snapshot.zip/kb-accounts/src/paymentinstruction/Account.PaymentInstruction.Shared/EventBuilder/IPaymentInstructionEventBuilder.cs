﻿using Api.Shared.Clients.Events.Kiwibank.V1.AccountPaymentInstructionResult;
using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch;

namespace Account.PaymentInstruction.Shared.EventBuilder;

/// <summary>
///     The interface to build the Payment Instruction event.
/// </summary>
public interface IPaymentInstructionEventBuilder
{
    /// <summary>
    ///     Build the Payment Instruction event from a PIB
    /// </summary>
    /// <param name="incomingEvent">
    ///     <see cref="PostingBatchEvent" />
    /// </param>
    /// <param name="instruction">Matched Payment Instruction</param>
    /// <returns>Payment Instruction Event</returns>
    PaymentInstructionEvent BuildFromPostingInstructionBatchEvent(
        PostingBatchEvent incomingEvent,
        Shared.Entities.PaymentInstruction instruction);

    /// <summary>
    ///     Build the error Payment Instruction event.
    /// </summary>
    /// <param name="instruction">Matched Payment Instruction</param>
    /// <returns>Payment Instruction Event</returns>
    PaymentInstructionEvent BuildErrorFromPostingInstructionBatch(
        Shared.Entities.PaymentInstruction instruction);

    PaymentInstructionEvent BuildWithStatus(
        Entities.PaymentInstruction paymentInstruction,
        PaymentInstructionStatusStatus status);
}