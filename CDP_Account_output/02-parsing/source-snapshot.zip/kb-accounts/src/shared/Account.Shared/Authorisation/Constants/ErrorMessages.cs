﻿namespace Account.Shared.Authorisation.Constants;

public static class ErrorMessages
{
    public const string AuthorizationHeaderIsMissing = "Authorization header is missing.";
    public const string FailedToGetAccessNumber = "Failed to get AccessNumber from the token.";

    public const string UnauthorisedMessage =
        "The current user is not authorized to access this resource.";
}