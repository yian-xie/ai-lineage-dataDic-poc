﻿namespace Account.PaymentInstruction.Api.Queries.Types;

public enum Lifecycle
{
    Authorisation,
    Settlement,
    Adjustment,
    Release,
    HardSettlement
}