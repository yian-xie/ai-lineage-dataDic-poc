﻿namespace Account.Posting.Shared;

public static class Telemetry
{
    public const string ActivitySourceName = "account_posting";
}