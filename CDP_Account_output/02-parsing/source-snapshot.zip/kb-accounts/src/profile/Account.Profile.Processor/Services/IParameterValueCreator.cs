﻿#nullable enable

using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Represents an interface for creating parameter values in the database and publish event to Enterprise topic.
/// </summary>
public interface IParameterValueCreator
{
    /// <summary>
    ///     Insert parameter values into database and publish event to Enterprise topic.
    /// </summary>
    /// <param name="accountProfileChangeSet">
    ///     <see cref="AccountProfileChangeSet" />
    /// </param>
    /// <param name="parameterValueTimestamp">The account status timestamp</param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfile" />
    /// </returns>
    Task<AccountProfile> CreateAsync(
        AccountProfileChangeSet accountProfileChangeSet,
        DateTimeOffset parameterValueTimestamp,
        CancellationToken cancellationToken);
}