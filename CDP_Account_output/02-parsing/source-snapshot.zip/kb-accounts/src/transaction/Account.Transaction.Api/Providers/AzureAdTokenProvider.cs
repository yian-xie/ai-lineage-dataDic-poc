﻿
using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Transaction.Api.Configurations;

using Microsoft.Identity.Client;
using Microsoft.Identity.Client.Extensibility;

using Serilog;

namespace Account.Transaction.Api.Providers;

/// <summary>
///   Provides functionality to acquire Azure AD tokens based on specified options.
/// </summary>
/// <remarks>
///    Initializes a new instance of the <see cref="AzureAdTokenProvider"/> class with the specified options.
/// </remarks>
/// <param name="options"></param>
/// <exception cref="ArgumentNullException"></exception>
public class AzureAdTokenProvider(AzureAdTokenOptions options) : IAzureAdTokenProvider
{
    private readonly AzureAdTokenOptions _options = options ?? throw new ArgumentNullException(nameof(options));

    /// <summary>
    ///   Acquires an Azure AD token based on the provided options.
    /// </summary>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    public async Task<string> GetTokenAsync(CancellationToken cancellationToken)
    {
        try
        {
            var app = ConfidentialClientApplicationBuilder.Create(_options.ClientId)
                .WithTenantId(_options.TenantId)
                .WithClientSecret(_options.ClientSecret)
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{_options.TenantId}"))
                .Build();

            var result = await app.AcquireTokenForClient(_options.Scopes).OnBeforeTokenRequest(data =>
            {
                // Redirect MSAL’s token POST so it can also be configured in Pact Test
                data.RequestUri = new Uri($"{_options.BaseUrl}/{_options.TenantId}/oauth2/v2.0/token");
                return Task.CompletedTask;

            }).ExecuteAsync(cancellationToken);
            return result.AccessToken;
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Failed to acquire Azure AD token for clientId {ClientId}", _options.ClientId);
            throw;
        }
    }
}