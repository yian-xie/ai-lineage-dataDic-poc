﻿namespace Account.TopicLogger.Processor.Services;

/// <summary>
///     Interface for interacting with the Dynatrace Metrics API.
///     This interface defines a method for ingesting metrics into Dynatrace.
/// </summary>
public interface IDynatraceMetricsClientHelper
{
    /// <summary>
    ///     Ingests a metric into Dynatrace.
    /// </summary>
    /// <param name="topicName">The name of the topic associated with the metric.</param>
    /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task IngestMetricAsync(string topicName, CancellationToken cancellationToken);
}