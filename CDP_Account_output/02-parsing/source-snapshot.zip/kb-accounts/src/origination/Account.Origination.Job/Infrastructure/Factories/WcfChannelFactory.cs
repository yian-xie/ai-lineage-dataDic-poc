﻿using System.Security.Principal;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Security;

using Account.Origination.Job.Configurations;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Infrastructure.Factories;

/// <summary>
/// This file is copied from kb-kiwisaver-accounts-api repo
/// see https://github.com/Kiwibank/kb-kiwisaver-accounts-api/blob/main/src/KiwiSaver.Accounts.Core/Factories/WcfChannelFactory.cs
/// Unfortunately we don't have a nuget package for this WcfChannelFactory yet. Similar code can also be found in kb-cap and kb-phoenix-apis
/// </summary>
public class WcfChannelFactory<TInterface>(IOptions<MiddlewareOptions> middlewareOptions)
    : IWcfChannelFactory<TInterface>, IDisposable
{
    private ChannelFactory<TInterface>? _factory;

    /// <summary>
    /// Use the generic ChannelFactory class to create and return an object of type T that
    /// can be used to make WCF requests to Middleware endpoints and methods.
    /// </summary>
    /// <returns>Valid channel object of type T that uses the correct credentials and security type</returns>
    public TInterface CreateChannel()
    {
        var address = CreateChannelAddress();
        _factory ??= CreateFactory(address);
        return _factory.CreateChannel();
    }

    /// <summary>
    /// Creates a valid ChannelFactory for the channel of type TInterface. Security configuration
    /// depends on the environment that the service is running in. 
    /// </summary>
    /// <param name="address">Endpoint address for Middleware</param>
    /// <returns>ChannelFactory object that is setup with the correct security for the environment the service is running in</returns>
    private ChannelFactory<TInterface> CreateFactory(EndpointAddress address)
    {
        var isHttps = middlewareOptions.Value.MiddlewareUrl.StartsWith("https", StringComparison.InvariantCultureIgnoreCase);
        var isWinAuth = middlewareOptions.Value.MiddlewareUrl.EndsWith("windows", StringComparison.InvariantCultureIgnoreCase);
        var isHttp = middlewareOptions.Value.MiddlewareUrl.StartsWith("http://", StringComparison.InvariantCultureIgnoreCase);

        var binding = CreateBinding(isHttps, isWinAuth, isHttp);
        var factory = new ChannelFactory<TInterface>(binding, address);

        if (isWinAuth)
        {
            factory.Endpoint.EndpointBehaviors.Remove(typeof(ClientCredentials));
            var credentials = new ClientCredentials
            {
                Windows =
                {
                    AllowedImpersonationLevel = TokenImpersonationLevel.Impersonation,
                    ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials
                }
            };
            factory.Endpoint.EndpointBehaviors.Add(credentials);
        }

        if (isHttps)
        {
            factory.Credentials.ServiceCertificate.SslCertificateAuthentication = new X509ServiceCertificateAuthentication
            {
                CertificateValidationMode = X509CertificateValidationMode.PeerOrChainTrust,
                RevocationMode = System.Security.Cryptography.X509Certificates.X509RevocationMode.NoCheck
            };
        }

        // support local host mock services for application integration tests
        if (isHttp)
        {
            factory.Endpoint.EndpointBehaviors.Remove(typeof(ClientCredentials));
            ClientCredentials credentials = new() { UserName = { UserName = "TestUserName", Password = "TestPassword" } };
            factory.Endpoint.EndpointBehaviors.Add(credentials);
        }

        factory.Endpoint.EndpointBehaviors.Add(new ChannelIdentifierEndpointBehaviour(middlewareOptions));

        return factory;
    }

    /// <summary>
    /// Return binding that has the valid security settings for the current Middleware url.
    /// </summary>
    /// <param name="isHttps">Boolean for if the Middleware url uses https</param>
    /// <param name="isWinAuth">Boolean for if the Middleware url uses Windows authentication</param>
    /// <param name="isHttp">Boolean for if the Middleware url is from the mock service</param>
    /// <returns>BasicHttpBinding with correct security settings for the Middleware url</returns>
    private static BasicHttpBinding CreateBinding(bool isHttps, bool isWinAuth, bool isHttp)
    {
        var binding = new BasicHttpBinding
        {
            Security = new BasicHttpSecurity
            {
                Mode = BasicHttpSecurityMode.Transport,
                Transport = new HttpTransportSecurity
                {
                    ClientCredentialType = HttpClientCredentialType.Certificate
                }
            }
        };
        //support Certificate over HTTPS (i.e. Issuer services talking to ACI)
        if (isHttps && !isWinAuth)
        {
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            binding.Security.Transport = new HttpTransportSecurity
            {
                ClientCredentialType = HttpClientCredentialType.Certificate,
            };
        }
        //support HTTPS with Kerberos 
        //Do NOT support HTTP with Kerberos
        else if (isHttps && isWinAuth)
        {
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            binding.Security.Transport = new HttpTransportSecurity
            {
                ClientCredentialType = HttpClientCredentialType.Windows,
            };
        }
        //support http for local mock services
        else if (isHttp)
        {
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport = new HttpTransportSecurity { ClientCredentialType = HttpClientCredentialType.Basic };
        }
        return binding;
    }

    /// <summary>
    /// Create EndpointAddress for the Middleware url.
    /// </summary>
    /// <returns>EndpointAddress to Middleware.</returns>
    private EndpointAddress CreateChannelAddress()
    {
        return new EndpointAddress(new Uri(middlewareOptions.Value.MiddlewareUrl));
    }

    public void Dispose()
    {
        _factory?.Close();
        _factory = null;
    }
}