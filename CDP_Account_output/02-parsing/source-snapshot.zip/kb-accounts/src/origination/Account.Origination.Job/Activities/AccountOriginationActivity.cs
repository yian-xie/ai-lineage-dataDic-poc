﻿using System.Diagnostics;

using Account.Origination.Shared;
using Account.Origination.Shared.Entities;

using Enterprise.Shared.Telemetry;

namespace Account.Origination.Job.Activities;

public class AccountOriginationActivity(
    IActivityAccessor activityAccessor,
    IActivityPropagator<IPropagatorEntity> activityPropagator)
    : IAccountOriginationActivity
{
    public Activity? StartActivityFromPropagationContext(
        string activityName,
        AccountOpening accountOpening)
    {
        var activitySource = activityAccessor.GetActivitySource(Telemetry.ActivitySourceName);

        return activityPropagator.StartActivityFromPropagationContext(accountOpening,
            activitySource, activityName, ActivityKind.Internal,
            new KeyValuePair<string, object?>[] {
                new(nameof(accountOpening.EventId), accountOpening.EventId),
                new(nameof(accountOpening.AccountId), accountOpening.AccountId)
            });
    }
}