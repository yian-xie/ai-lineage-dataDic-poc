﻿using Account.Origination.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.Origination.Shared.Repositories;

public interface IRepositoryFactory
{
    OriginationDbContext DbContext { get; }
    IUnitOfWork UnitOfWork { get; }
    IAccountOpeningRepository AccountOpeningRepository { get; }
}