﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class RenameAccountCreateUserIdToAccountCreatedUserId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "account_create_user_id",
                schema: "profile",
                table: "account_profile",
                newName: "account_created_user_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "account_created_user_id",
                schema: "profile",
                table: "account_profile",
                newName: "account_create_user_id");
        }
    }
}