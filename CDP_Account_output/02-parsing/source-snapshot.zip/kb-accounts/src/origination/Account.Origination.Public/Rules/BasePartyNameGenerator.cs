﻿using Account.Origination.Public.Interfaces;

namespace Account.Origination.Public.Rules
{
    internal abstract class BasePartyNameGenerator : INameGenerator
    {
        protected string[] NameFields = [];

        private readonly Func<Party, string[]> _funcGetPropertyArray = (party) => [party.FirstName, party.MiddleName, party.LastName];

        protected bool ParametersAreValid(Party[] parties)
        {
            if (parties == null || !parties.Any())
            {
                throw new ArgumentNullException(nameof(parties),
                    "Input parameter can not be null or empty.");
            }

            foreach (var _ in parties)
            {
                var nameFieldCollection = _funcGetPropertyArray.Invoke(_);
                var allEmpty = nameFieldCollection.All(element => string.IsNullOrWhiteSpace(element));

                if (allEmpty)
                {
                    return false;
                }
            }

            return true;
        }

        protected bool IsMultipleNameFieldProvided(Party party)
        {
            NameFields = _funcGetPropertyArray.Invoke(party);
            var singleNameProvided = NameFields.Count(n => !string.IsNullOrWhiteSpace(n)) == 1;

            return !singleNameProvided;
        }
        public abstract bool IsMatch(Party[] parties);
        public abstract string GenerateName(Party[] parties);
    }
}