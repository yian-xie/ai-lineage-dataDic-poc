# Account Opening States: Current Implementation & Migration Guide

This document describes all possible states that an `AccountOpening` can have in the `Account.Origination.Job` system. These states are inferred from the combination of various columns in the `AccountOpening` entity rather than being explicitly defined as an enum.

This document also provides comprehensive instructions for migrating to an explicit state machine design with feature flags, database migrations, and code updates.

> **See Also:** [AccountOpeningStateMachine-TargetDesign.md](./AccountOpeningStateMachine-TargetDesign.md) - Target state machine design with explicit state enum (the desired end-state after refactoring)

**Note:** Retry behavior (`RetryCount > 0`) is not a separate state but can apply to any non-terminal state.

## Overview

The Account Origination system uses three background jobs to process account openings:

1. **TmvAccountNumberAllocationJob** - Allocates account numbers for SV1 products (when required)
2. **TmvAccountCreationJob** - Creates accounts in TMV with status `ACCOUNT_STATUS_PENDING`
3. **TmvAccountOpeningJob** - Opens accounts by changing status to `ACCOUNT_STATUS_OPEN`

**Note on Retries:** Retry behavior (`RetryCount` and `LastRetry`) is not a separate state but a property that can apply to any non-terminal state (Pending Number Allocation, Initial, or Created). Records in any of these states may have `RetryCount > 0` indicating previous failed attempts.

## State-Defining Columns

The following columns in the `AccountOpening` entity define the current state:

- `Created` (DateTimeOffset?) - When the account was created in TMV
- `Failed` (DateTimeOffset?) - When creation or opening failed
- `ScheduledOpen` (DateTimeOffset) - When the account should be opened
- `Opened` (DateTimeOffset?) - When the account was opened in TMV
- `ValidUntil` (DateTimeOffset) - Expiration time for the account opening
- `LastRetry` (DateTimeOffset?) - Last retry timestamp
- `RetryCount` (int) - Number of retry attempts
- `AccountNumber` (string?) - Account number (required for SV1 products)
- `ProductCode` (string?) - Product type (e.g., "SV1")

## State Definitions

### 1. Initial

**Condition:**
- `Created == null`
- `Failed == null`
**Description:**
The single entry point for all account opening requests. The record is picked up by `TmvAccountCreationJob`, which determines whether the account can be created immediately or must first have a number allocated (SV1 only).

**Processed By:** `TmvAccountCreationJob` (via `AccountCreationJobQuery`)

**Retry Behavior:** Like other non-terminal states, this state may have `RetryCount > 0` if previous attempts failed.

---

### 2. Pending Number Allocation (SV1 Only)

**Condition:**
- `Created == null`
- `Failed == null`
- `AccountNumber == null`
- `ProductCode == "SV1"`

**Description:**
An intermediate state for SV1 products. When `TmvAccountCreationJob` picks up an `Initial` SV1 record without an account number, it transitions it to this state. The record then waits for `TmvAccountNumberAllocationJob` to allocate a number before creation can proceed.

**Processed By:** `TmvAccountNumberAllocationJob` (via `AccountNumberAllocationJobQuery`)

**Transition:** Once an account number is allocated, transitions back to **Initial** state so `TmvAccountCreationJob` can proceed with creation.

**Retry Behavior:** Like other non-terminal states, this state may have `RetryCount > 0` if previous allocation attempts failed.

---

### 3. Created (Pending Opening)

**Condition:**
- `Created != null`
- `Opened == null`
- `Failed == null`

**Description:**
The account has been successfully created in TMV with status `ACCOUNT_STATUS_PENDING`. It is now waiting for the scheduled opening time or for the opening job to process it.

**Processed By:** `TmvAccountOpeningJob` (via `AccountOpeningJobQuery`)

**Note:** The job will only open the account when `ScheduledOpen <= now`.

**Retry Behavior:** Like other non-terminal states, this state may have `RetryCount > 0` if previous opening attempts failed.

---

### 4. Opened (Final Success State)

**Condition:**
- `Opened != null`

**Description:**
The account has been successfully opened in TMV with status `ACCOUNT_STATUS_OPEN`. This is a terminal success state. The account is now active and operational.

**Note:** Once an account reaches this state, it will not be processed by any job again.

---

### 5. Failed (Final Failure State)

**Condition:**
- `Failed != null`

**Description:**
The account creation or opening has failed permanently. This occurs when:
- The `ValidUntil` time has passed before the account could be successfully opened
- Number allocation fails (for SV1 products)

**Note:** Once an account reaches this state, it will not be retried. A failure event is published to the event bus.

---

## Retry Behavior

Retry behavior is not a separate state but a cross-cutting concern that applies to all non-terminal states (Pending Number Allocation, Initial, and Created).

**Retry Indicators:**
- `RetryCount` (int) - Number of retry attempts (0 means no retries yet)
- `LastRetry` (DateTimeOffset?) - Timestamp of the last retry attempt

**Retry Logic:**
- Jobs will retry after `RetryIntervalSeconds` (configured in `AccountOriginationJobOptions`)
- Retry queries check: `RetryCount == 0 OR (LastRetry.HasValue && LastRetry <= retryTimeThreshold)`
- Records are ordered by `RetryCount` (ascending), then `ScheduledOpen`, then `AccountId`
- Retries continue until success or `ValidUntil` expires

**Common Retry Causes:**
- Customer not found in TMV (customer creation is attempted)
- TMV service exceptions
- Network issues (handled by Polly resilience policies)
- Account number allocation failures (SV1 only)

When a retry is needed:
1. `RetryCount` is incremented
2. `LastRetry` is updated to current timestamp
3. The record remains in its current state (Pending Number Allocation, Initial, or Created)
4. The job will pick it up again after the retry interval has elapsed

---

## State Transitions

```mermaid
stateDiagram-v2
    [*] --> Initial: Account Opening Created

    Initial --> PendingNumberAllocation: SV1 without AccountNumber
    Initial --> Created: Account Created in TMV
    Initial --> Initial: Creation Failed (Retry)
    Initial --> Failed: ValidUntil Expired

    PendingNumberAllocation --> Initial: Account Number Allocated
    PendingNumberAllocation --> PendingNumberAllocation: Allocation Failed (Retry)
    PendingNumberAllocation --> Failed: ValidUntil Expired
    
    Created --> Opened: Account Opened (ScheduledOpen reached)
    Created --> Created: Opening Failed (Retry)
    Created --> Failed: ValidUntil Expired
    
    Opened --> [*]: Success
    Failed --> [*]: Permanent Failure
```

**Note:** Self-transitions (e.g., `Initial --> Initial`) represent retry behavior where `RetryCount` is incremented and the record stays in the same state.

## State Transition Details

### From Initial

| Trigger | Next State | Conditions | Job |
|---------|-----------|------------|-----|
| SV1 account without AccountNumber detected | PendingNumberAllocation | `ProductCode == SV1 && AccountNumber == null` | TmvAccountCreationJob |
| Account created successfully in TMV | Created | `Created` timestamp set | TmvAccountCreationJob |
| Creation fails (retryable error) | Initial | Exception or customer not found, RetryCount incremented | TmvAccountCreationJob |
| ValidUntil expired | Failed | `now > ValidUntil` | TmvAccountCreationJob |
| Already created in TMV | Created | TMV account status is PENDING | TmvAccountCreationJob |
| Already opened in TMV | Opened | TMV account status is OPEN | TmvAccountCreationJob |

### From Pending Number Allocation

| Trigger | Next State | Conditions | Job |
|---------|-----------|------------|-----|
| Account number allocated successfully | Initial | Account number assigned to record | TmvAccountNumberAllocationJob |
| Allocation fails (retryable error) | Pending Number Allocation | Exception caught, RetryCount incremented | TmvAccountNumberAllocationJob |
| ValidUntil expired | Failed | `now > ValidUntil` | TmvAccountNumberAllocationJob |

### From Created

| Trigger | Next State | Conditions | Job |
|---------|-----------|------------|-----|
| Account opened successfully in TMV | Opened | `Opened` timestamp set, status OPEN | TmvAccountOpeningJob |
| Opening fails (retryable error) | Created | Exception caught, RetryCount incremented | TmvAccountOpeningJob |
| ValidUntil expired | Failed | `now > ValidUntil` | TmvAccountOpeningJob |
| Already opened in TMV | Opened | TMV account status is OPEN | TmvAccountOpeningJob |

## Job Processing Logic

### TmvAccountNumberAllocationJob Query

```csharp
Where(x => !x.Created.HasValue)
Where(x => !x.Opened.HasValue)
Where(x => !x.Failed.HasValue)
Where(x => x.AccountNumber == null)
Where(x => x.ProductCode == Product.Sv1)
Where(x => x.RetryCount == 0 || 
           (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
OrderBy(x => x.RetryCount)
ThenBy(x => x.ScheduledOpen)
ThenBy(x => x.AccountId)
```

### TmvAccountCreationJob Query

```csharp
Where(x => !x.Created.HasValue)
Where(x => !x.Opened.HasValue)
Where(x => !x.Failed.HasValue)
Where(x => x.RetryCount == 0 || 
           (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
OrderBy(x => x.RetryCount)
ThenBy(x => x.ScheduledOpen)
ThenBy(x => x.AccountId)
```

### TmvAccountOpeningJob Query

```csharp
Where(x => x.Created.HasValue)
Where(x => !x.Opened.HasValue)
Where(x => !x.Failed.HasValue)
Where(x => x.RetryCount == 0 || 
           (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
Where(x => x.ScheduledOpen <= now)
OrderBy(x => x.RetryCount)
ThenBy(x => x.ScheduledOpen)
ThenBy(x => x.AccountId)
```

## State Identification Logic

To determine the current state of an `AccountOpening` record, use the following logic:

```csharp
public static string GetState(AccountOpening accountOpening)
{
    if (accountOpening.Opened.HasValue)
        return "Opened";
    
    if (accountOpening.Failed.HasValue)
        return "Failed";
    
    if (accountOpening.Created.HasValue)
        return "Created";
    
    if (accountOpening.ProductCode == "SV1" && string.IsNullOrEmpty(accountOpening.AccountNumber))
    return "Pending Number Allocation";

    return "Initial";
}

public static bool IsRetrying(AccountOpening accountOpening)
{
    return accountOpening.RetryCount > 0 && 
           !accountOpening.Opened.HasValue && 
           !accountOpening.Failed.HasValue;
}
```

## Observability

Each job execution is tracked using OpenTelemetry with the following activity tags:
- `TmvAccountCreationJob`: "create TMV account"
- `TmvAccountNumberAllocationJob`: "Allocate TMV account number"
- `TmvAccountOpeningJob`: "open TMV account"

Telemetry context is propagated via the `TraceContext` field in the `AccountOpening` entity.

## Error Handling & Resilience

### Retry Logic
- Jobs retry on transient failures
- Retry interval configured via `AccountOriginationJobOptions.RetryIntervalSeconds`
- Records with lower `RetryCount` are processed first
- Maximum retries are implicitly limited by `ValidUntil` timestamp

### Polly Resilience Policies
- TMV service calls are protected by Polly resilience pipelines
- Circuit breakers and progressive backoff for TMV service issues
- These retries are separate from job-level retries and don't affect `RetryCount`

### Permanent Failures
- When `now > ValidUntil`, the record transitions to Failed state
- A failure event is published to `account.profile.v1.event` topic
- Failed records are no longer processed by any job

## Migration to Explicit State Machine

This section provides guidance for refactoring the current implicit state machine to use an explicit `State` enum, with feature flags for gradual rollout and easy rollback. See [AccountOpeningStateMachine-TargetDesign.md](./AccountOpeningStateMachine-TargetDesign.md) for the target design.

### Migration Overview

The migration involves adding an explicit `State` column to the `AccountOpening` entity and updating all job query logic to use it instead of inferring state from column combinations. The implementation uses feature flags to enable gradual rollout, allowing both old (timestamp-based) and new (state-based) query logic to coexist during the transition period.

### Database Migration Steps

#### Step 1: Add State Column

Add a nullable `State` enum column to the `account_opening` table:

```sql
ALTER TABLE account_opening
ADD COLUMN state VARCHAR(50) NULL;
```

#### Step 2: Backfill Existing Data

Backfill the `state` column using the current state inference logic:

```sql
UPDATE account_opening
SET state = CASE
    WHEN opened IS NOT NULL THEN 'Opened'
    WHEN failed IS NOT NULL THEN 'Failed'
    WHEN created IS NOT NULL THEN 'Created'
    ELSE 'Initial'
END
WHERE state IS NULL;
```

Verify backfill results:

```sql
-- Check state distribution
SELECT state, COUNT(*) as count
FROM account_opening
GROUP BY state
ORDER BY count DESC;

-- Verify no NULL states remain
SELECT COUNT(*) as null_states
FROM account_opening
WHERE state IS NULL;
```

#### Step 3: Make State Column Non-Nullable

After verifying backfill is complete:

```sql
ALTER TABLE account_opening
ALTER COLUMN state SET NOT NULL;
```

#### Step 4: Add Database Index

Add index on `state` column for efficient job queries:

```sql
CREATE INDEX ix_account_opening_state ON account_opening(state, retry_count, last_retry);
```

### Code Migration Steps

#### Step 1: Define State Enum

Add `AccountOpeningState` enum to the `AccountOpening` entity:

```csharp
public enum AccountOpeningState
{
    PendingNumberAllocation,
    Initial,
    Created,
    Opened,
    Failed
}

public class AccountOpening : IPropagatorEntity
{
    public required AccountOpeningState State { get; set; }
    
    // Existing properties remain for audit purposes
    public DateTimeOffset? Created { get; set; }
    public DateTimeOffset? Opened { get; set; }
    public DateTimeOffset? Failed { get; set; }
    // ...
}
```

#### Step 2: Update Entity Configuration

Update EF Core configuration:

```csharp
public class AccountOpeningEntityTypeConfiguration : IEntityTypeConfiguration<AccountOpening>
{
    public void Configure(EntityTypeBuilder<AccountOpening> builder)
    {
        builder.Property(x => x.State)
            .HasConversion<string>()
            .IsRequired();
        
        // ... other configurations
    }
}
```

#### Step 3: Update Processor to Set Initial State

The **Account.Origination.Processor** project is responsible for creating `AccountOpening` records when events are received. Update the event subscribers to set the initial `State` when creating new records.

**Update ProductPropositionEventSubscriber.cs:**

```csharp
private AccountOpening CreateAccountOpening(
    LendingProductPropositionEvent lendingProductPropositionEvent,
    ProductFacility onlineCallProductFacility)
{
    // Assume only one party involvement per product facility for Drop 5
    var partyInvolvement = onlineCallProductFacility.PartyInvolvements?.FirstOrDefault();

    if (partyInvolvement == null)
    {
        throw new InvalidOperationException(
            "No PartyInvolvement found for the given ProductFacility.");
    }

    var accountOpening = new AccountOpening
    {
        AccountId = Guid.NewGuid().ToString(),
        EventId = lendingProductPropositionEvent.Metadata.Id,
        CorrelationId = lendingProductPropositionEvent.Metadata.CorrelationId,
        PartyId = Guid.Parse(partyInvolvement.PartyId),
        PartyRoleIds = [partyInvolvement.PartyRoleId],
        AlternateAccountName = onlineCallProductFacility.AlternateAccountName,
        BankingProductId = Guid.Parse(onlineCallProductFacility.BankingProductId),
        BankingProductVersionId = Guid.Parse(onlineCallProductFacility.BankingProductVersionId),
        ProductCode = onlineCallProductFacility.BankingProductCode,
        BankingRelationshipId = Guid.Parse(partyInvolvement.BankingRelationshipId),
        ProductPropositionId =
            Guid.Parse(lendingProductPropositionEvent.Data.AfterState.ProductPropositionId),
        ProductFacilityId = Guid.Parse(onlineCallProductFacility.ProductFacilityId),
        ValidUntil = lendingProductPropositionEvent.Metadata.Time +
            TimeSpan.FromDays(options.Value.ValidityPeriodDays),
        ScheduledOpen = DateTimeOffset.UtcNow,
        
        // NEW: All accounts start in Initial state
        // TmvAccountCreationJob will detect SV1 without AccountNumber and transition to PendingNumberAllocation
        State = AccountOpeningState.Initial
    };
}
```

**Update SpudProductApplicationEventSubscriber.cs:**

```csharp
private AccountOpening CreateAccountOpening(
    SpudProductApplicationEvent spudProductApplicationEvent)
{
    return new AccountOpening
    {
        EventId = spudProductApplicationEvent.Metadata.Id,
        AccountId = GetAccountId(spudProductApplicationEvent),
        CorrelationId = spudProductApplicationEvent.Metadata.CorrelationId,
        PartyRoleIds = [spudProductApplicationEvent.Data.AfterState.PartyRoleId],
        ScheduledOpen = timeProvider.GetUtcNow(),
        ValidUntil = spudProductApplicationEvent.Data.AfterState.ValidUntil,
        
        // NEW: Set initial state
        // SPUD applications don't have ProductCode, so they go to Initial state
        State = AccountOpeningState.Initial
    };
}
```

**Key Points:**
- **SV1 products** start in `PendingNumberAllocation` state (need account number before creation)
- **Non-SV1 products** start in `Initial` state (can go straight to creation)
- **SPUD applications** start in `Initial` state
- The initial state must be set during object creation to satisfy the `required` property constraint

#### Step 4: Create EF Core Migration

After updating the entity and configuration, create an EF Core migration:

**Using .NET CLI:**

```bash
# Navigate to the project containing the DbContext
cd src/origination/Account.Origination.Shared

# Create migration
dotnet ef migrations add AddStateColumnToAccountOpening --context OriginationDbContext

# Review the generated migration file
# It should contain:
# - AddColumn operation for State
# - SQL for backfilling data
# - AlterColumn operation to make State non-nullable
# - CreateIndex operations
```

**Generated Migration File Structure:**

```csharp
public partial class AddStateColumnToAccountOpening : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        // Step 1: Add nullable State column
        migrationBuilder.AddColumn<string>(
            name: "state",
            table: "account_opening",
            type: "varchar(50)",
            nullable: true);

        // Step 2: Backfill existing data
        migrationBuilder.Sql(@"
            UPDATE account_opening
            SET state = CASE
                WHEN opened IS NOT NULL THEN 'Opened'
                WHEN failed IS NOT NULL THEN 'Failed'
                WHEN created IS NOT NULL THEN 'Created'
                ELSE 'Initial'
            END
            WHERE state IS NULL;
        ");

        // Step 3: Make State column non-nullable
        migrationBuilder.AlterColumn<string>(
            name: "state",
            table: "account_opening",
            type: "varchar(50)",
            nullable: false,
            oldClrType: typeof(string),
            oldType: "varchar(50)",
            oldNullable: true);

        // Step 4: Create index
        migrationBuilder.CreateIndex(
            name: "ix_account_opening_state",
            table: "account_opening",
            columns: new[] { "state", "retry_count", "last_retry" });
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "ix_account_opening_state",
            table: "account_opening");

        migrationBuilder.DropColumn(
            name: "state",
            table: "account_opening");
    }
}
```

**Manual Adjustments:**

If the auto-generated migration doesn't include all steps, manually edit the migration file to:
1. Ensure the column is added as nullable first
2. Add the backfill SQL before making the column non-nullable
3. Add the necessary indexes if not auto-generated

**Apply Migration:**

```bash
# Review migration before applying
dotnet ef migrations script --context OriginationDbContext

# Apply to local database
dotnet ef database update --context OriginationDbContext

# Generate SQL script for production deployment
dotnet ef migrations script --context OriginationDbContext --idempotent --output migration.sql
```

**Verify Migration:**

```bash
# Check migration history
dotnet ef migrations list --context OriginationDbContext

# Verify in database
SELECT state, COUNT(*) as count
FROM account_opening
GROUP BY state;
```

#### Step 5: Update Job Queries

Replace column-based queries with state-based queries.

**AccountNumberAllocationJobQuery.cs:**

```csharp
public class AccountNumberAllocationJobQuery : IAccountOpeningGetReadyJobQuery
{
    public static Func<OriginationDbContext, DateTimeOffset, DateTimeOffset, Task<AccountOpening?>>
        GetQuery() => EF.CompileAsyncQuery<OriginationDbContext, DateTimeOffset, DateTimeOffset,
        AccountOpening?>((
        dbContext,
        retryTimeThreshold,
        now) => dbContext.AccountOpenings
        .TagWith(EntityFrameworkInterceptorTags.ForUpdateSkipLocked)
        .Where(x => x.State == AccountOpeningState.PendingNumberAllocation)
        .Where(x =>
            x.RetryCount == 0 ||
            (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
        .OrderBy(x => x.RetryCount)
        .ThenBy(x => x.ScheduledOpen)
        .ThenBy(x => x.AccountId)
        .FirstOrDefault());
}
```

**AccountCreationJobQuery.cs:**

```csharp
public class AccountCreationJobQuery : IAccountOpeningGetReadyJobQuery
{
    public static Func<OriginationDbContext, DateTimeOffset, DateTimeOffset, Task<AccountOpening?>>
        GetQuery() => EF.CompileAsyncQuery<OriginationDbContext, DateTimeOffset, DateTimeOffset,
        AccountOpening?>((
        dbContext,
        retryTimeThreshold,
        now) => dbContext.AccountOpenings
        .TagWith(EntityFrameworkInterceptorTags.ForUpdateSkipLocked)
        .Where(x => x.State == AccountOpeningState.Initial)
        .Where(x =>
            x.RetryCount == 0 ||
            (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
        .OrderBy(x => x.RetryCount)
        .ThenBy(x => x.ScheduledOpen)
        .ThenBy(x => x.AccountId)
        .FirstOrDefault());
}
```

**AccountOpeningJobQuery.cs:**

```csharp
public class AccountOpeningJobQuery : IAccountOpeningGetReadyJobQuery
{
    public static Func<OriginationDbContext, DateTimeOffset, DateTimeOffset, Task<AccountOpening?>>
        GetQuery() => EF.CompileAsyncQuery<OriginationDbContext, DateTimeOffset, DateTimeOffset,
        AccountOpening?>((
        dbContext,
        retryTimeThreshold,
        now) => dbContext.AccountOpenings
        .TagWith(EntityFrameworkInterceptorTags.ForUpdateSkipLocked)
        .Where(x => x.State == AccountOpeningState.Created)
        .Where(x =>
            x.RetryCount == 0 ||
            (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
        .Where(x => x.ScheduledOpen <= now)
        .OrderBy(x => x.RetryCount)
        .ThenBy(x => x.ScheduledOpen)
        .ThenBy(x => x.AccountId)
        .FirstOrDefault());
}
```

#### Step 6: Update State Transition Logic

Update jobs to explicitly set the `State` property.

**In TmvAccountCreationJob:**

```csharp
// SV1 without AccountNumber: transition to PendingNumberAllocation
var prerequisiteState = tmvAccountAction.GetPrerequisiteState(accountOpening);
if (prerequisiteState.HasValue)
{
    accountOpening.State = prerequisiteState.Value; // PendingNumberAllocation
    return null;
}

// Success: transition to Created
accountOpening.Created = timeProvider.GetUtcNow();
accountOpening.State = AccountOpeningState.Created;

// Retry: stay in Initial
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains Initial
```

**In TmvAccountNumberAllocationJob:**

```csharp
// Success: transition back to Initial for creation
accountOpening.AccountNumber = allocatedNumber;
accountOpening.State = AccountOpeningState.Initial;

// Retry: stay in PendingNumberAllocation
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains PendingNumberAllocation

// Failure: transition to Failed
if (timeProvider.GetUtcNow() > accountOpening.ValidUntil)
{
    accountOpening.State = AccountOpeningState.Failed;
    accountOpening.Failed = timeProvider.GetUtcNow();
}
```

**In TmvAccountCreationJob:**

```csharp
// Success: transition to Created
accountOpening.Created = timeProvider.GetUtcNow();
accountOpening.State = AccountOpeningState.Created;

// Already opened: transition to Opened
if (tmvAccount.Status == ACCOUNT_STATUS_OPEN)
{
    accountOpening.State = AccountOpeningState.Opened;
    accountOpening.Opened = tmvAccount.Opening_timestamp;
}

// Retry: stay in Initial
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains Initial

// Failure: transition to Failed
if (timeProvider.GetUtcNow() > accountOpening.ValidUntil)
{
    accountOpening.State = AccountOpeningState.Failed;
    accountOpening.Failed = timeProvider.GetUtcNow();
}
```

**In TmvAccountOpeningJob:**

```csharp
// Success: transition to Opened
accountOpening.Opened = tmvAccount.Opening_timestamp;
accountOpening.State = AccountOpeningState.Opened;

// Retry: stay in Created
accountOpening.RetryCount++;
accountOpening.LastRetry = timeProvider.GetUtcNow();
// State remains Created

// Failure: transition to Failed
if (timeProvider.GetUtcNow() > accountOpening.ValidUntil)
{
    accountOpening.State = AccountOpeningState.Failed;
    accountOpening.Failed = timeProvider.GetUtcNow();
}
```

#### Step 7: Add State Transition Validation

Implement validation to prevent invalid state transitions:

```csharp
public class AccountOpeningStateTransitionValidator
{
    private static readonly Dictionary<AccountOpeningState, HashSet<AccountOpeningState>> ValidTransitions = new()
    {
        [AccountOpeningState.Initial] = new() 
        { 
            AccountOpeningState.Initial,                    // Retry
            AccountOpeningState.PendingNumberAllocation,    // SV1 needs number allocation
            AccountOpeningState.Created,                    // Account created
            AccountOpeningState.Opened,                     // Already opened (edge case)
            AccountOpeningState.Failed                      // Expired
        },
        [AccountOpeningState.PendingNumberAllocation] = new() 
        { 
            AccountOpeningState.PendingNumberAllocation,  // Retry
            AccountOpeningState.Initial,                  // Number allocated, back to creation
            AccountOpeningState.Failed                    // Expired
        },
        [AccountOpeningState.Created] = new() 
        { 
            AccountOpeningState.Created,  // Retry
            AccountOpeningState.Opened,   // Account opened
            AccountOpeningState.Failed    // Expired
        },
        [AccountOpeningState.Opened] = new() { },   // Terminal state
        [AccountOpeningState.Failed] = new() { }    // Terminal state
    };

    public static bool IsValidTransition(
        AccountOpeningState fromState, 
        AccountOpeningState toState)
    {
        return ValidTransitions[fromState].Contains(toState);
    }

    public static void ValidateTransition(
        AccountOpening accountOpening, 
        AccountOpeningState newState)
    {
        if (!IsValidTransition(accountOpening.State, newState))
        {
            throw new InvalidStateTransitionException(
                $"Invalid state transition from {accountOpening.State} to {newState} " +
                $"for account {accountOpening.AccountId}");
        }
    }
}
```

Use the validator before setting state:

```csharp
AccountOpeningStateTransitionValidator.ValidateTransition(accountOpening, AccountOpeningState.Initial);
accountOpening.State = AccountOpeningState.Initial;
```

### Testing Strategy

#### Unit Tests

Create or update unit tests for:

1. **State Transition Validation**
   ```csharp
   [Fact]
   public void ValidateTransition_InvalidTransition_ThrowsException()
   {
       var accountOpening = new AccountOpening { State = AccountOpeningState.Opened };
       
    Assert.Throws<InvalidStateTransitionException>(() =>
           AccountOpeningStateTransitionValidator.ValidateTransition(
               accountOpening, 
               AccountOpeningState.Initial));
   }
   ```

2. **Job Query Logic**
   - Verify each job query selects only records in the correct state
   - Test ordering by RetryCount, ScheduledOpen, AccountId

3. **State Transition Logic**
   - Test success transitions
   - Test retry behavior (state stays same, RetryCount increments)
   - Test failure transitions (ValidUntil expiration)

#### Integration Tests

1. **Complete Workflow Tests**
   - Test SV1 product flow: PendingNumberAllocation → Initial → Created → Opened
   - Test non-SV1 flow: Initial → Created → Opened
   - Test failure scenarios with ValidUntil expiration

2. **Retry Behavior Tests**
   - Test retries in each non-terminal state
   - Verify RetryCount increments correctly
   - Verify LastRetry timestamp updates

3. **Edge Case Tests**
   - Test account already opened in TMV
   - Test multiple retries before success
   - Test transition to Failed from each state

#### Migration Tests

1. **Data Backfill Verification**
   ```csharp
   [Fact]
   public async Task BackfillState_InfersCorrectStates()
   {
       // Arrange: Create test data with various column combinations
       // Act: Run backfill SQL
       // Assert: Verify State column matches expected values
   }
   ```

2. **Backward Compatibility**
   - Test that queries work during migration period
   - Verify both State enum and timestamp columns are updated

### Feature Flag Implementation

The migration should be controlled by a feature flag to enable gradual rollout and easy rollback. This codebase uses **LaunchDarkly** for feature flag management.

#### Step 1: Add Feature Flag Service Dependency

Ensure the `IFeatureService` is available in your job classes:

```csharp
public class TmvAccountCreationJob<TQuery>(
    IFeatureService featureService,
    // ... other dependencies
    ) where TQuery : IAccountOpeningGetReadyJobQuery
{
    private const string UseExplicitStateFeatureFlag = "account-opening-use-explicit-state";
    
    // ... existing code
}
```

#### Step 2: Implement Feature Flag Check

Wrap the new state-based logic with a feature flag check:

```csharp
private AccountOpening? GetNextAccountOpening()
{
    var useExplicitState = featureService.IsFeatureEnabled(
        UseExplicitStateFeatureFlag, 
        defaultValue: false);

    if (useExplicitState)
    {
        // New: Use explicit State-based query
        return dbContext.AccountOpenings
            .Where(x => x.State == AccountOpeningState.Initial)
            .Where(x => x.RetryCount == 0 || 
                   (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
            .OrderBy(x => x.RetryCount)
            .ThenBy(x => x.ScheduledOpen)
            .ThenBy(x => x.AccountId)
            .FirstOrDefault();
    }
    else
    {
        // Old: Use implicit state inference
        return dbContext.AccountOpenings
            .Where(x => !x.Created.HasValue)
            .Where(x => !x.Opened.HasValue)
            .Where(x => !x.Failed.HasValue)
            .Where(x => x.RetryCount == 0 || 
                   (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
            .OrderBy(x => x.RetryCount)
            .ThenBy(x => x.ScheduledOpen)
            .ThenBy(x => x.AccountId)
            .FirstOrDefault();
    }
}
```

#### Step 3: Configure Feature Flag

**Local Development (appsettings.Development.json):**

```json
{
  "LaunchDarkly": {
    "SdkKey": "",
    "FlagValues": {
      "account-opening-use-explicit-state": "false"
    }
  }
}
```

**Production (LaunchDarkly Dashboard):**

1. Create a new boolean feature flag: `account-opening-use-explicit-state`
2. Set default value to `false` (off)
3. Configure targeting rules for gradual rollout:
   - Start with 0% rollout
   - Increase to 10% after initial monitoring
   - Increase to 50% after validation
   - Increase to 100% when confident

**Using Environment Variables:**

```bash
# For container deployments
LaunchDarkly__SdkKey=sdk-key-from-secret-manager
LaunchDarkly__FlagValues__account-opening-use-explicit-state=false
```

#### Step 4: Feature Flag Transition Logic

Ensure both code paths update the State column during the transition period:

```csharp
// Whether using old or new logic, always set State when transitioning
accountOpening.State = AccountOpeningState.Created;
accountOpening.Created = timeProvider.GetUtcNow(); // Keep for audit
```

This ensures:
- The State column is always up-to-date
- Switching the feature flag on/off is safe
- No data inconsistency during gradual rollout

#### Step 5: Monitoring Feature Flag Impact

Add logging and metrics around feature flag usage:

```csharp
var useExplicitState = featureService.IsFeatureEnabled(
    UseExplicitStateFeatureFlag, 
    defaultValue: false);

logger.LogInformation(
    "Processing account opening with explicit state: {UseExplicitState}",
    useExplicitState);

metrics.RecordFeatureFlagUsage(UseExplicitStateFeatureFlag, useExplicitState);
```

#### Feature Flag Removal

After the migration is complete and stable:

1. Set feature flag to 100% (always on) in LaunchDarkly
2. Monitor for 1-2 weeks
3. Remove feature flag checks from code
4. Delete old inference-based query logic
5. Archive the feature flag in LaunchDarkly

**Code after cleanup:**

```csharp
// Simply use the new State-based query
private AccountOpening? GetNextAccountOpening()
{
    return dbContext.AccountOpenings
        .Where(x => x.State == AccountOpeningState.Initial)
            .Where(x => x.RetryCount == 0 || 
               (x.LastRetry.HasValue && x.LastRetry <= retryTimeThreshold))
            .OrderBy(x => x.RetryCount)
            .ThenBy(x => x.ScheduledOpen)
            .ThenBy(x => x.AccountId)
            .FirstOrDefault();
}
```

### Rollout Strategy

This strategy leverages the feature flag implementation (see [Feature Flag Implementation](#feature-flag-implementation) section above) for safe, gradual rollout.

#### Phase 1: Preparation (Non-Production)
1. Implement feature flag checks in all three jobs (see Feature Flag Implementation)
2. Deploy code with State enum and feature flag (set to OFF)
3. Run database migration in development environment
4. Verify state distribution matches expectations
5. Run full test suite with feature flag both ON and OFF
6. Test feature flag toggling works correctly

#### Phase 2: Production Migration
1. Deploy code to production with feature flag `account-opening-use-explicit-state` set to OFF
2. Verify deployment successful and jobs running normally
3. Run database migration during maintenance window:
   - Add State column (nullable)
   - Backfill existing data using state inference logic
   - Make State column non-nullable
   - Add indexes
4. Verify migration success:
   - Check state distribution matches expectations
   - Confirm no NULL state values remain
   - Verify indexes created successfully

#### Phase 3: Enable New Logic (Gradual Rollout)
1. **Initial Enable (0% → 10%)**
   - Set feature flag to 10% rollout in LaunchDarkly
   - Monitor for 24-48 hours:
     - Job processing rates (should remain stable)
     - State transition metrics
     - Error rates
     - Database query performance
   
2. **Increase Rollout (10% → 50%)**
   - If metrics look good, increase to 50%
   - Monitor for 24-48 hours
   - Compare performance between old and new logic
   
3. **Full Rollout (50% → 100%)**
   - Increase to 100% rollout
   - Monitor for 1 week
   - Verify all jobs using new State-based queries

#### Phase 4: Cleanup
1. Monitor with feature flag at 100% for 1-2 weeks
2. Remove feature flag code from all three jobs
3. Remove old inference-based query logic
4. Update documentation
5. Archive the `account-opening-use-explicit-state` feature flag in LaunchDarkly
6. Consider removing redundant timestamp columns (optional, keep for audit purposes)

### Monitoring and Observability

Add metrics for state transitions:

```csharp
// In each job, record state transitions
metrics.RecordStateTransition(
    fromState: accountOpening.State,
    toState: newState,
    jobName: "TmvAccountCreationJob");
```

Create dashboards to track:
- Current state distribution
- State transition rates
- Time spent in each state
- Retry rates by state
- Failure rates and reasons

### Rollback Plan

If issues arise:

1. **Immediate Rollback** (if critical issues)
   - Disable feature flag to revert to inference-based queries
   - Investigate issues
   - Fix and redeploy

2. **Data Rollback** (if State column data is corrupted)
   - Re-run backfill SQL to correct State values
   - Verify data integrity

3. **Full Rollback** (if migration needs to be reverted)
   - Deploy code without State enum support
   - Drop State column and indexes (in maintenance window)
   - Resume using inference-based state logic

## Related Documentation

- [Target State Machine Design](./AccountOpeningStateMachine-TargetDesign.md) - Final design with explicit state enum
- [Account Origination Job README](../../../src/origination/Account.Origination.Job/README.md)
- [Account Create Specification](https://kiwibank.atlassian.net/wiki/spaces/MVP/pages/4094034211/Account+Create)
- [AccountProfile Event Schema](../../shared/api-definitions/asyncapi/Kiwibank/AccountProfile_V1.yaml)
- [State Diagram (PlantUML)](./account.origination.state.plantuml)
