﻿namespace Account.Transaction.Api.Queries.Services.Filtering;

/// <summary>
/// The constants use in Ultracs Proxy API.
/// </summary>
public class UltracsQueryParamConstants
{
    /// <summary>
    /// Credit Transaction.
    /// </summary>
    public const string CreditTransaction = "CR";

    /// <summary>
    /// Debit Transaction.
    /// </summary>
    public const string DebitTransaction = "DR";
}