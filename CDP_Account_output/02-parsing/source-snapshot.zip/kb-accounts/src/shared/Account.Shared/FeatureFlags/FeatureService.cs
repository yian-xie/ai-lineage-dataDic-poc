﻿using LaunchDarkly.Sdk;
using LaunchDarkly.Sdk.Server.Interfaces;

namespace Account.Shared.FeatureFlags;

public class FeatureService(ILdClient ldClient) : IFeatureService
{
    public bool IsFeatureEnabled(string featureName, bool defaultValue = false)
        => IsFeatureEnabled(featureName, null, defaultValue);

    public bool IsFeatureEnabled(
        string featureName,
        string userKey,
        bool defaultValue = false)
    {
        var context = string.IsNullOrWhiteSpace(userKey)
            ? Context.Builder("default-anonymous-context").Anonymous(true).Build()
            : Context.Builder(userKey).Build();

        return ldClient.BoolVariation(featureName, context, defaultValue);
    }

    public bool IsFeatureEnabled(
        string featureName,
        Context context,
        bool defaultValue = false) => ldClient.BoolVariation(featureName, context, defaultValue);
}