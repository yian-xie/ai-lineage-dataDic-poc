﻿using System;

namespace Account.PaymentInstruction.Shared.Entities;

public class PaymentInstructionStatus
{
    /// <summary>
    ///     Id
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    ///     Client Id
    /// </summary>
    public string ClientId { get; set; }

    /// <summary>
    ///     The <see cref="Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatch.PostingInstructionBatch" /> Id
    /// </summary>
    public string BatchId { get; set; }

    /// <summary>
    ///     Client Batch Id
    /// </summary>
    public string ClientBatchId { get; set; }

    /// <summary>
    ///     Enum[Created, Posted, Error, Accepted, Rejected]
    /// </summary>
    public string State { get; set; }

    /// <summary>
    ///     Date
    /// </summary>
    public DateTimeOffset Date { get; set; }

    /// <summary>
    ///     Trace Context
    /// </summary>
    public string? TraceContext { get; set; }
}