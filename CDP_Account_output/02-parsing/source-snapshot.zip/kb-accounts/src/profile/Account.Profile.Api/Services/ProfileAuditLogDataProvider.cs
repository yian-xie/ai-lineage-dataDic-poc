﻿using System.Collections.Generic;

namespace Account.Profile.Api.Services;

/// <summary>
///     The implementation of ProfileAuditLogDataProvider
/// </summary>
public class ProfileAuditLogDataProvider : IProfileAuditLogDataProvider
{
    /// <inheritdoc />
    public List<string> AccountIds { get; set; } = [];

    /// <inheritdoc />
    public List<string> AccountNumbers { get; set; } = [];
}