﻿using HotChocolate;

namespace Account.PaymentInstruction.Api.Queries.Types;

[GraphQLName("PaymentInstructionWithStatus")]
public class PaymentInstructionWithStatus
{
    [GraphQLName("paymentInstruction")] public PaymentInstruction PaymentInstruction { get; set; }

    [GraphQLName("statuses")] public PaymentInstructionStatus[] Statuses { get; set; }
}