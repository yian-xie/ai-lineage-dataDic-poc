## Incident Quick Reference

| Field | Details / Link or path |
|---|---|
| Service | Account.TopicLogger.Processor (`accounts-topiclogger-processor`) |
| Customer or business impact | TMV action, audit, alert, and failure events may not reach Sumo Logic, and DLQ metrics may not reach Dynatrace. This reduces operational and audit visibility and may delay detection of upstream processing failures; this processor does not execute customer transactions. |
| Support channel | [Support (Teams)](https://teams.microsoft.com/l/channel/19%3A866817a3453b4455aa58d8575d50a187%40thread.tacv2/Support?groupId=0260d888-b62c-4b33-9fad-875bc097746e&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc) |
| Escalation path | [Incident Management Processes - Account Domain](https://kiwibank.atlassian.net/wiki/x/1wC2PgE) |
| Logs and dashboards | <ul><li>[Account Topiclogger Processor Observability Dashboard](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/6310101161/Account+Topiclogger+Processor+Observability+Dashboard)</li><li>[Topiclogger Sumo logs](https://kbprod.au.sumologic.com/library/41314788)</li></ul> |

## Common Scenarios and Recovery

<details>
<summary>Processor pods do not become ready or repeatedly restart</summary>

**Symptoms**

- Dynatrace shows fewer pods than the desired three replicas or increasing `builtin:kubernetes.container.restarts` for `<environment>-accounts-topiclogger-processor`.
- `GET /health/readiness` or `GET /health/liveness` on container port `8080` fails.
- Startup fails when required Kafka, Sumo Logic, or Dynatrace settings are missing or invalid.

**Actions**

1. Inspect the affected pod's startup log for configuration validation failures. Confirm the key names `Kafka`, `KafkaClusters`, `SumoLogicIngestion`, `SumoLogicMonitoringApiToken`, and `DynatraceMetricPost`;
2. Check `GET http://localhost:8080/health/readiness` and `GET http://localhost:8080/health/liveness` from inside the affected pod. No endpoint authentication is configured in this repository; the expected result is HTTP 2xx. These pod-local URLs are not directly reachable from a developer laptop. [TODO: confirm the approved VPN, Kubernetes context, and pod-exec or port-forward procedure.]
3. Correct the deployment configuration or referenced `accounts-topiclogger-processor` Kubernetes secret through the normal pipeline, then deploy the corrected artifact. Do not edit a live secret value during diagnosis.

**Recovery check**

All three replicas remain available without new restarts, both health requests return HTTP 2xx, and Kafka event ingestion resumes.

**Escalate when**

Use the Incident Management Processes link when all replicas are unavailable, health remains failed after a corrected deployment, or the required configuration owner cannot be identified.

</details>

<details>
<summary>All topic ingestion stops or consumer lag grows</summary>

**Symptoms**

- Action, audit, alert, and DLQ source names all stop receiving events.
- Logs report OAuth/SASL authentication, broker connectivity, or consumer-group assignment failures.
- The environment consumer group stops advancing: `cg_tmv_accounts_topic_logger_tmv_accept`, `..._situat`, `..._perf0`, `..._preprod`, or `..._prod`.

**Actions**

1. Determine whether all source names stopped together. A simultaneous stop points to the shared Kafka connection rather than one topic or downstream destination.
2. Check logs for failure of the OAuth primary cluster and whether the plain TMV Kafka failover cluster was selected. Both cluster URLs are supplied by the environment Helm values.
3. Confirm that the deployed configuration contains the expected environment-specific `KafkaClusters__TMVKafkaOAuth__*`, `KafkaClusters__TMVKafka__Url`, and group ID values. Confirm only the presence and currency of `KafkaClusters__TMVKafkaOAuth__OAuth__ClientSecret`;
4. [TODO: confirm the approved consumer-group lag command, access path, and alert threshold for each environment.]
5. Restore broker connectivity or OAuth configuration through the normal pipeline. The code supports automatic fallback to the plain TMV Kafka cluster when configured.

**Recovery check**

The environment consumer group advances, all four Sumo Logic source-name families receive new events, and lag returns to [TODO: confirm the normal lag threshold and expected event cadence].

**Escalate when**

Use the Incident Management Processes link when both OAuth and plain clusters are unavailable, lag continues to grow after connectivity is restored, or multiple TMV consumers are affected.

</details>

<details>
<summary>A subscribed topic reports authorization failure</summary>

**Symptoms**

- Kafka reports `Topic authorization failed` for one or more configured topics while other topics continue to flow.
- One Sumo Logic source family or one `topicname` dimension becomes stale without a service-wide outage.
- The source explicitly disables two topics because TMV denied topic authorization, showing that permissions are topic-specific.

**Actions**

1. Capture the exact topic from the error and compare it with `TmvTopics.cs`. Do not add a topic to the deployment until TMV access is confirmed.
2. Verify whether the affected topic is one of the two intentionally disabled topics: `vault.core.contracts.journeys.account_schedule.responses.dlq` or `vault.core.balances.account_balance.events.contract_post_balance_update_processor.dlq`.
3. For an active topic, confirm the environment OAuth client and plain-cluster identity are authorized for that exact topic. [TODO: confirm the TMV permission-check procedure and responsible access team.]
4. After permission is granted, deploy a source change only if the topic was intentionally disabled; otherwise allow the existing consumer to reconnect.
5. Reach out to [ESP Support](https://teams.microsoft.com/l/channel/19%3AOUczqvpL2j_7CnB-CYsE86SPmDefz7zJUfWX5YODYmM1%40thread.tacv2/ESP%20support?groupId=e7a307ca-92e9-4457-a2cf-f866cbd89c73&tenantId=4b41160f-15b3-4c74-9723-96d1838309dc&ngc=true&allowXTenantAccess=true) for further help if during normal work hours.

**Recovery check**

The authorization error stops and new events for the exact topic appear under the expected Sumo Logic source or Dynatrace `topiclogger.tmv_dlq.log` `topicname` dimension.

**Escalate when**

Use the Incident Management Processes link when authorization is removed from an active topic, permissions differ between OAuth and failover clusters, or the event gap affects required audit evidence.

</details>

<details>
<summary>TMV events are not arriving in Sumo Logic</summary>

**Symptoms**

- One or more `topiclogger-processor-action-topics`, `-audit-topics`, `-alert-topics`, or `-dlq-topics` sources stop receiving data.
- Subscriber requests to `https://collectors.au.sumologic.com` fail or time out.
- Kafka consumption is active, but the expected environment source category has no recent events.

**Actions**

1. Run this repository-documented query in the Sumo Logic UI for situat; it requires the `SEC - AAD - Sumologic - TMV - Restricted` role. Expected result: recent TMV records when the upstream topic is active.

```text
_sourcecategory=situat/saas/tmv/tmv_audit/* tier=infrequent retention=long _index=saas_tmv_infreq_365
```

2. For another environment, select its documented `situat/saas/tmv/`, `perf0/saas/tmv/`, `preprod/saas/tmv/`, or `prod/saas/tmv/` category and the affected source name in the linked observability guidance.
3. Check [processor logs](https://kbprod.au.sumologic.com/library/41314788) for the HTTP failure from Sumo ingestion and identify whether operational-log and monitoring-log ingestion are both affected. They use separate token keys.
4. Confirm the endpoint and presence of `SumoLogicIngestion__ApiToken` and `SumoLogicMonitoringApiToken` in the deployment secret; Restore configuration through the normal pipeline.
5. [TODO: confirm whether failed events are retried or committed by `AddKafkaReliableEventConsumersWithTmvOAuth`, and document the approved replay procedure before attempting an offset change.]

**Recovery check**

New events appear under the affected source name and source category, with no continuing Sumo ingestion errors. No Sumo query or endpoint was executed while generating this runbook.

**Escalate when**

Use the Incident Management Processes link when ingestion remains unavailable, an unrecoverable event gap exists, or replay/offset handling is required.

</details>

<details>
<summary>DLQ logs arrive but the Dynatrace DLQ metric is missing</summary>

**Symptoms**

- Sumo Logic receives DLQ records, but `topiclogger.tmv_dlq.log` is stale or absent in Dynatrace.
- DLQ subscriber handling reports failure from the Dynatrace metrics request.
- Other action, audit, and alert ingestion remains healthy.

**Actions**

1. In the linked dashboard, select `topiclogger.tmv_dlq.log` and split by `k8s.namespace.name` and `topicname`. Expected result: one metric value for each handled DLQ event.
2. Confirm the configured `DynatraceMetricPost__ApiUrl`, metric name, and presence of `DynatraceMetricPost__ApiToken` in the `accounts-topiclogger-processor` secret;
3. Compare the metric gap with DLQ source events in Sumo Logic. The subscriber sends both operations concurrently, so one destination can succeed while the other fails.
4. Restore Dynatrace API connectivity or configuration through the normal pipeline.
5. [TODO: confirm whether the reliable consumer retries a handler when one `Task.WhenAll` destination fails and document any approved replay procedure.]

**Recovery check**

New DLQ events produce both a Sumo Logic record and a `topiclogger.tmv_dlq.log` value with the correct namespace and topic dimensions.

**Escalate when**

Use the Incident Management Processes link when the metric remains missing after API recovery, alerting is blind to DLQ events, or duplicate/replay handling must be decided.

</details>

<details>
<summary>The DLQ metric shows a sustained event surge</summary>

**Symptoms**

- `topiclogger.tmv_dlq.log` rises for one or more `topicname` dimensions.
- Matching failure-event or DLQ records appear under `topiclogger-processor-dlq-topics` in the environment operational-log category.
- TopicLogger remains healthy; the events indicate failures in an upstream TMV flow.

**Actions**

1. In the linked dashboard, split `topiclogger.tmv_dlq.log` by `k8s.namespace.name` and `topicname` to identify the affected environment and upstream flow.
2. In Sumo Logic, query `topiclogger-processor-dlq-topics` in the matching environment operational-log category and capture timestamps and non-sensitive correlation identifiers.
3. Confirm TopicLogger health and continued metric/log ingestion. Do not restart this processor when it is successfully recording upstream failures.
4. Route investigation to the owner of the failing topic through the Incident Management Process. [TODO: map each configured DLQ/failure topic to its owning service and confirm the alert threshold.]

**Recovery check**

The upstream owner confirms recovery, the affected `topicname` rate returns to [TODO: confirm the normal per-topic threshold], and no new matching failure records arrive in Sumo Logic.

**Escalate when**

Use the Incident Management Processes link when the surge is sustained, affects multiple topics, or corresponds to customer-impacting upstream failures.

</details>

## Custom Section

<details>
<summary>Click to expand</summary>

Add any custom additional content here.

</details>