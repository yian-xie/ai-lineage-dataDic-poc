﻿using Account.Posting.Shared.Repositories;

using Microsoft.Extensions.DependencyInjection;

namespace Account.Posting.Shared;

public static class Extensions
{
    public static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        return services
            .AddScoped<IRepositoryFactory, RepositoryFactory>()
            .AddScoped<ITmvPostingBatchRepository, TmvPostingBatchRepository>();
    }
}