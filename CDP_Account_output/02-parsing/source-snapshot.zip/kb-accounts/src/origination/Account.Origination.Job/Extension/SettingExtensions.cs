﻿using Account.Origination.Job.Configurations;
using Account.Origination.Job.TMVClient.SemanticVersion;

using Microsoft.Extensions.Options;

namespace Account.Origination.Job.Extension;

public static class SettingExtensions
{
    public static async Task LoadSemanticVersionCache(this IHost host)
    {
        using var scope = host.Services.CreateScope();

        var tmvSemanticSettings = scope.ServiceProvider
            .GetRequiredService<IOptions<TmvSemanticOptionCollection>>();

        if (tmvSemanticSettings == null)
        {
            throw new ArgumentNullException(nameof(TmvSemanticOptionCollection),
                "Setting TmvSemanticOptionCollection is not initialized.");
        }

        var semanticVersionResolver =
            scope.ServiceProvider.GetRequiredService<ISemanticVersionResolver>();

        using var cts = new CancellationTokenSource();

        foreach (var semanticOption in tmvSemanticSettings.Value.Options)
        {
            await semanticVersionResolver.ResolveAsync(semanticOption.Key, cts.Token);
        }
    }
}