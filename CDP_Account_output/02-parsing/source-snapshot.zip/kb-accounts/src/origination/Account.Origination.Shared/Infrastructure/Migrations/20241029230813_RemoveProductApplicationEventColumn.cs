﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Origination.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class RemoveProductApplicationEventColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "product_application_event",
                schema: "origination",
                table: "account_opening");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "product_application_event",
                schema: "origination",
                table: "account_opening",
                type: "text",
                nullable: false,
                defaultValue: "");
        }
    }
}