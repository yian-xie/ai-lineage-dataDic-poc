﻿using System.Threading.Tasks;

using Enterprise.Shared.Application.WebHostService;

using Microsoft.Extensions.Hosting;

namespace Account.PaymentInstruction.Tmv.Processor;

public class Program : WebHostServiceBase<Program>
{
    public static async Task Main(string[] args)
    {
        await CreateHostBuilder(args)
            .Build()
            .RunAsync();
    }

    /// <summary>
    ///     Note: Remember not to change the signature of the below method or removing it.
    ///     The ProcessorApplicationFactory in our integration test uses reflection and look for this
    ///     method with this exact signature.
    /// </summary>
    /// <param name="args"></param>
    /// <returns></returns>
    public static IHostBuilder CreateHostBuilder(string[] args)
    {
        return createWebHostBuilder<Startup>(args);
    }
}