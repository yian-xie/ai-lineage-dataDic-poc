﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;

using Account.Shared.Constants;
using Account.Shared.Kafka.Publishers;

using Api.Shared.Clients.Events.Kiwibank.V2.AccountAuditLog;

using HotChocolate.Language;
using HotChocolate.Resolvers;

using Kb.Api.Infrastructure.JwtTokenProvider;

using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;

namespace Account.Profile.Api.Services;

/// <summary>
///     Audit log Event Builder implementation for Account Profile Api
/// </summary>
public class AccountAuditLogEventBuilder(IProfileAuditLogDataProvider dataProvider) : IAccountAuditLogV2EventBuilder
{
    private const string Source = "urn:nz:co:kiwibank:account:audit";

    /// <summary>
    ///
    /// </summary>
    /// <param name="middlewareContext"></param>
    /// <param name="httpContext"></param>
    /// <param name="appName"></param>
    /// <returns></returns>
    public AccountAuditLogEvent BuildEvent(
        IMiddlewareContext middlewareContext,
        HttpContext httpContext,
        string appName)
    {
        var tokenString = httpContext.Request.Headers[HeaderNames.Authorization].ToString();
        var jwtToken = TokenStringExtensions.ReadJwtToken(tokenString);
        var interactionUtcTime = DateTimeOffset.UtcNow;

        var nzTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Pacific/Auckland");
        var nzTime = TimeZoneInfo.ConvertTime(interactionUtcTime, nzTimeZone);

        var requestIdentifier = jwtToken.Claims
            .FirstOrDefault(claim => Enumerable.Contains(General.IdentityClaimNames, claim.Type));

        var variables = JsonSerializer.Serialize(middlewareContext.Variables.ToDictionary(
            x => x.Name,
            x => x.Value switch
            {
                StringValueNode stringValue => stringValue.Value,
                ListValueNode listValue => listValue.Items.Select(item =>
                        item is StringValueNode strNode ? strNode.Value : item.ToString())
                    .ToList(),
                _ => x.Value.Value
            }
        ));

        var requestBody = middlewareContext.Selection.SelectionSet?.ToString();

        var primaryRecordIds = dataProvider.AccountNumbers.Select(accountNumber =>
                new PrimaryRecordId { Id = accountNumber, EntityType = "account" })
            .ToList();

        var auditEvent = new AccountAuditLogEvent
        {
            Metadata = new Metadata
            {
                Id = Guid.NewGuid(),
                Type = MetadataType.AccountAuditLogCreated,
                Time = interactionUtcTime,
                CorrelationId = Guid.Empty,
                Source = Source,
                Subject = string.Empty,
                Actor = string.Empty
            },
            Data = new Data
            {
                AfterState = new AccountAuditLogData
                {
                    ClientLogRequestId = Guid.NewGuid().ToString(),
                    Client = appName,
                    Action = "Read",
                    TenantIdentifier =
                        TokenStringExtensions.ExtractFieldValue(jwtToken, JwtClaimTypes.TenantId),
                    TenantClientId =
                        TokenStringExtensions.ExtractFieldValue(jwtToken,
                            JwtClaimTypes.AuthorizedParty),
                    RequestIdentifier = requestIdentifier?.Value,
                    RequestIdentifierType = requestIdentifier?.Type,
                    RequestCustomerIdentifier = string.Empty,
                    RequestAction = httpContext.Request.Method,
                    RequestPath = httpContext.Request.Path,
                    RequestBody = requestBody,
                    RequestParameters = variables,
                    TraceId = Activity.Current?.TraceId.ToString(),
                    PrimaryRecordEntityType = "account",
                    PrimaryRecordId = primaryRecordIds,
                    InteractionType = AccountAuditLogDataInteractionType.View,
                    Outcome = middlewareContext.HasErrors ? AccountAuditLogDataOutcome.FAILURE : AccountAuditLogDataOutcome.SUCCESS,
                    InteractionTimestamp = nzTime,
                    BusinessReason = "", //TODO: needs to get exception message from httpContext
                    AuthenticatedCustomer = "",
                    Application = "",
                    MutationType = "",
                    MutationDetail = [],
                    Summary = $"The following was queried for profile data: {string.Join(",", dataProvider.AccountIds)}"
                }
            }
        };

        return auditEvent;
    }
}