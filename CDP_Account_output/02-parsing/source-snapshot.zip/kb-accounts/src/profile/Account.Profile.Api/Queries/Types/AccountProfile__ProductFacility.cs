﻿using System;

using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__ProductFacility")]
public class AccountProfile__ProductFacility
{
    [GraphQLName("bankingProductId")] public string BankingProductId { get; set; }

    [GraphQLName("bankingProductVersionId")]
    public string BankingProductVersionId { get; set; }

    [GraphQLName("bankingProductCode")] public string BankingProductCode { get; set; }

    [GraphQLName("productFacilityId")] public string ProductFacilityId { get; set; }

    [GraphQLName("interestArrangement")] public AccountProfile__ProductFacility__InterestArrangement InterestArrangement { get; set; }
}