﻿#nullable enable
using Api.Shared.Clients.Events.ThoughtMachine.V1.ContractNotification;
using Api.Shared.Clients.Events.ThoughtMachine.V2.Account;

namespace Account.Profile.Processor.Services;

/// <summary>
///     Represents an interface for creating AccountProfileChangeSet.
/// </summary>
public interface IAccountProfileChangeSetCreator
{
    /// <summary>
    ///     Create account_profile entry.
    /// </summary>
    /// <param name="accountEvent">
    ///     <see cref="AccountEvent" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfileChangeSet" />
    /// </returns>
    public AccountProfileChangeSet CreateAccountProfileChangeSet(
        AccountEvent accountEvent);

    /// <summary>
    ///     Update account_profile entry.
    /// </summary>
    /// <param name="accountEvent">
    ///     <see cref="AccountEvent" />
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfileChangeSet" />
    /// </returns>
    public AccountProfileChangeSet CreateAccountProfileChangeSetForUpdate(
        AccountEvent accountEvent);

    /// <summary>
    ///     Create AccountProfileChangeSet from ContractNotification event for parameter(s) change.
    /// </summary>
    /// <param name="contractNotification">
    ///     ContractNotification event containing parameter_change
    /// </param>
    /// <returns>
    ///     <see cref="AccountProfileChangeSet" /> if at least one parameter is supported, null if parameter should be ignored
    /// </returns>
    public AccountProfileChangeSet? CreateAccountProfileChangeSetFromContractNotification(
        ContractNotification contractNotification);
}