﻿using Newtonsoft.Json;

namespace Account.Shared.Testing.Integration;

/// <summary>
///     Class for storing the results of a query to OPA.
/// </summary>
/// <typeparam name="T">Return data type of the results from opa query</typeparam>
public class QueryResult<T>
{
    [JsonProperty("result")] public List<T> ResultItems { get; set; } = [];
}