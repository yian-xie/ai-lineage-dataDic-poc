﻿#nullable enable

using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;

using Enterprise.Shared.Database;
using Enterprise.Shared.Kafka.Produce;

using MetadataType = Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile.MetadataType;

namespace Account.Profile.Processor.Publishers;

public class AccountProfileEventPublisher(
    IAccountProfileEventBuilder accountProfileEventBuilder,
    IOutboxEventPublisher<AccountProfileEvent> publisher)
    : IAccountProfileEventPublisher
{
    public async Task PublishAccountProfileEventAsync(
        AccountProfile accountProfile,
        MetadataType metadataType,
        DateTimeOffset accountStatusTimestamp,
        Guid? correlationId,
        IUnitOfWork unitOfWork,
        CancellationToken cancellationToken)
    {
        var accountProfileEvent = accountProfileEventBuilder.BuildEvent(
            accountProfile,
            metadataType,
            accountStatusTimestamp,
            correlationId);

        await publisher.PublishAsync(
            accountProfile.AccountId,
            accountProfileEvent,
            unitOfWork,
            cancellationToken);
    }
}