﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Account.Transaction.Api.CardsClient.Exceptions;

/// <summary>
/// Represents a collection of validation errors returned from the API
/// </summary>
public class ValidationErrors
{
    /// <summary>
    /// List of individual validation error details
    /// </summary>
    [JsonPropertyName("errors")]
    public List<Error>? Errors { get; set; }
}

/// <summary>
/// Represents a single validation error with type, property, and message information
/// </summary>
public class Error
{
    /// <summary>
    /// The type of validation error
    /// </summary>
    [JsonPropertyName("$type")]
    public string? Type { get; set; }

    /// <summary>
    /// The property name that failed validation
    /// </summary>
    [JsonPropertyName("property")]
    public string? Property { get; set; }

    /// <summary>
    /// The validation error message describing the issue
    /// </summary>
    [JsonPropertyName("message")]
    public string? Message { get; set; } = string.Empty;
}