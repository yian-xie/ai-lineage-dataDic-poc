﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Account.Shared.Database;

/// <summary>
///     Entity type configuration base for the account domain.
/// </summary>
/// <typeparam name="TEntity">The entity type to be configured.</typeparam>
/// <typeparam name="TDbContext">DbContext that inherits IDbContextSchemaName</typeparam>
public abstract class
    AccountBaseEntityTypeConfiguration<TEntity, TDbContext> : IEntityTypeConfiguration<TEntity>
    where TEntity : class where TDbContext : IDbContextSchemaName
{
    protected abstract string TableName { get; }

    public void Configure(EntityTypeBuilder<TEntity> builder)
    {
        builder.ToTable(TableName, TDbContext.SchemaName());
        Init(builder);
    }

    private void Init(EntityTypeBuilder<TEntity> builder)
    {
        PreConfigureTable(builder);
        ConfigureTable(builder);
        PostConfigureTable(builder);
    }

    /// <summary>
    ///     Invoke code that you want to guarantee is always executed prior the overridden ConfigureTable() method.
    /// </summary>
    /// <param name="builder">
    ///     <see cref="EntityTypeBuilder" />
    /// </param>
    protected virtual void PreConfigureTable(EntityTypeBuilder<TEntity> builder) { }

    /// <summary>
    ///     Invoke code that you want to guarantee is always executed after the overridden ConfigureTable() method.
    /// </summary>
    /// <param name="builder">
    ///     <see cref="EntityTypeBuilder" />
    /// </param>
    protected virtual void PostConfigureTable(EntityTypeBuilder<TEntity> builder) { }

    /// <summary>
    ///     Configure the table keys and properties
    /// </summary>
    /// <remarks>`ToTable` has already been executed</remarks>
    /// <param name="builder">Entity Builder</param>
    protected abstract void ConfigureTable(EntityTypeBuilder<TEntity> builder);
}