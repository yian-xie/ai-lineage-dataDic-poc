﻿using FluentValidation;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Validations.PaymentInstructionRequestInputValidation;

/// <summary>
///     Validator that validates Amount property of <see cref="PaymentInstructionRequestInput" />
/// </summary>
public class AmountValidator : AbstractValidator<PaymentInstructionRequestInput>
{
    public AmountValidator()
    {
        RuleFor(i => Amount(i))
            .GreaterThan(0)
            .WithMessage(i => "Expected Amount that is greater than 0.");
    }

    private static decimal Amount(PaymentInstructionRequestInput input)
    {
        return input.PaymentInstruction.Transfer.Amount;
    }
}