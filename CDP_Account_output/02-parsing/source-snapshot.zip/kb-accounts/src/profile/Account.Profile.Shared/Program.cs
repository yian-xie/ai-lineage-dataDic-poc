﻿// See https://aka.ms/new-console-template for more information

using System.Threading.Tasks;

using Account.Profile.Shared.Infrastructure;

using Enterprise.Shared.Database;

using Microsoft.Extensions.Hosting;

namespace Account.Profile.Shared;

public class Program
{
    public static async Task Main(string[] args)
    {
        await MigrationHelper.RunMigrationAsync<AccountProfileDbContext>(() =>
            CreateHostBuilder(args));
    }

    public static IHostBuilder CreateHostBuilder(string[] args)
    {
        return Host.CreateDefaultBuilder(args)
            .ConfigureServices((host, services) =>
            {
                services
                    .UseDb(host.Configuration)
                    .WithDbContext<AccountProfileDbContext>(Migration.SetAssembly)
                    .AddSqlHealthCheck();
            });
    }
}