﻿namespace Account.TopicLogger.Processor.Configurations;

public static class SumoLogicSourceNames
{
    public const string ActionTopic = "action-topics";
    public const string AuditTopic = "audit-topics";
    public const string DlqTopic = "dlq-topics";
    public const string AlertTopic = "alert-topics";
}


public static class SumoLogicSourceCategories
{
    public const string OperationalLogs = "operational_logs";
    public const string MonitoringLogs = "monitoring_logs";
}

public static class ExtraSettings
{
    public const string SumoLogicMonitoringApiToken = "SumoLogicMonitoringApiToken";
}