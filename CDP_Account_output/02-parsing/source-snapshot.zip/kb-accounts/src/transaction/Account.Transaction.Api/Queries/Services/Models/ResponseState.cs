﻿using System.Collections.Generic;

using Account.Transaction.Api.CardsClient.Models;

namespace Account.Transaction.Api.Queries.Services.Models;

/// <summary>
/// The credit card transactions response state.
/// </summary>
/// <param name="warnings">List of <see cref="Warning"/></param>
/// <param name="status"><see cref="ResponseStatusType"/></param>
public record ResponseState(IReadOnlyCollection<Warning> warnings, ResponseStatusType status);