## Service Summary

| Field | Details |
|---|---|
| Business purpose | Returns the latest account balances and accepts ADPS PIB responses to create temporary cached balances and interim-booked transactions. |
| Runtime | .NET ASP.NET Core with Hot Chocolate GraphQL and an MVC REST controller; image `accounts/account/transaction-balance-api`. |
| Source | `src/transaction/Account.Transaction.Balance.Api` |
| Pipeline | `src/transaction/.pipelineconfig/pipeline.yaml`; deployment values in `src/transaction/Deploy/Account.Transaction.Balance.Api` |
| Last reviewed | 2026-10-05 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. GraphQL queries read PostgreSQL balances and return the newest record per currency and balance type, preferring actual over cached records for the same PIB.
2. ADPS posts a PIB response to `/api/posting-instruction-batch`; validators check the request and the shared calculator derives cached balances.
3. Cached balances and interim-booked transactions are persisted independently; actual balances later written by Account.Transaction.Tmv.Processor supersede matching cached balances.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Data store | PostgreSQL `account_transaction`, schema `transaction` | Read balances; store cached balances, transactions, balance specifications, and audit outbox records | `ConnectionStrings__DefaultConnection`; `AccountTransactionDbContext` |
| Inbound system | ADPS | Forwards PIB responses before the corresponding TMV event | `POST /api/posting-instruction-batch` |
| Downstream data path | Account.Transaction.Tmv.Processor | Persists actual balances that supersede cached values | shared transaction schema and PIB identity |
| Platform | Kafka outbox, Dynatrace, and Sumo Logic | Audit-event delivery and observability | Kafka deployment settings and repository observability links |

### Interfaces and Schedule

- GraphQL: `POST /api/accounts-transaction-balance/graphql`; operations `tmvAccountBalances` and `tmvAccountsBalances`.
- REST: `POST /api/posting-instruction-batch`; no application-level authentication. Expected success is HTTP 201 with an `ids` array; invalid input returns HTTP 400.
- Health: `GET /health/liveness` and `GET /health/readiness` on port 8080; readiness includes SQL health.
- No schedule. Requests are synchronous. Platform/network access controls for internal hosts are not documented. [TODO: confirm the supported laptop access path for non-production endpoints.]

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| `Graphql:Path`, `Graphql__IntrospectionEnabled` | GraphQL endpoint and schema access | Path is `/api/accounts-transaction-balance/graphql`; introspection is enabled in ACCEPT. |
| `ConnectionStrings__DefaultConnection` | Shared transaction PostgreSQL database | Injected by the deployment platform; never record its value. |
| `Kafka__*` | Audit outbox publishing and schema registry | Secret keys include SASL username/password and schema-registry API key/secret. |
| `MetricsOptions`, `TracingOptions` | Dynatrace metrics and tracing | Environment prefix changes per stage. |
| `transaction-balance-api` secret | Deployment environment values | Secret values are not stored in this runbook. |

Environments map to namespaces `accept-transaction-balance-api`, `situat-transaction-balance-api`, `perf0-transaction-balance-api`, `preprod-transaction-balance-api`, and `prod-transaction-balance-api`, all with release `transaction-balance-api`.

</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `/health/liveness` | HTTP 200; process is responsive | Probe fails or pods restart. |
| `/health/readiness` | HTTP 200; PostgreSQL is reachable | Probe fails for three consecutive five-second periods. |
| API availability and success | Availability at or above 99.85%; success at or above 99.9% per repository alerts | SLO alert fires or 5xx errors increase. |
| API response time | 99th percentile at or below one second | Repository response-time alert fires. |
| PIB persistence logs | Completion count matches stored cached balances and expected transactions | Persistence error is followed by completion/201, or transaction count unexpectedly equals zero. |

Observability: <ul><li>[Account Transaction Balance API Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/B4BAKAE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33974169)</li></ul> 

Non-production interfaces use the ACCEPT host `accept-accounts-transaction-balance.apps.bc62.cip-non-production.nonprod.internal.aws.kiwibank.co.nz`. GraphQL requests require a bearer token and expected valid query data; the PIB endpoint has no application auth and returns HTTP 201 for valid input. Laptop reachability is unverified, and no request was executed during generation. [TODO: confirm VPN/private-DNS or other access requirements.]

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the pipeline built `accounts/account/transaction-balance-api` and passed its unit and integration stages.
2. Review GraphQL/REST contract changes, validators, database migrations, balance-selection ordering, and independent cached-balance/transaction persistence behavior.

### After Deployment

1. Confirm the `transaction-balance-api` release reaches its configured replica count and both probes remain healthy in the target namespace.
2. In ACCEPT or the promoted non-production environment, verify GraphQL telemetry, PIB 201/400 behavior through repository integration checks, and absence of persistence-error logs.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

Use the repository deployment pipeline and environment-specific Helm values. Stop promotion for probe, API, selection-order, or persistence regressions. Prefer a fix forward where data has already been written; [TODO: confirm the approved pipeline rollback command or UI procedure and data-reconciliation owner.]

### Recovery Validation

1. Verify liveness and SQL-backed readiness in ACCEPT or the affected non-production environment and confirm stable API telemetry.
2. Verify a valid non-production PIB produces stored cached balances and interim-booked transactions, then confirm an actual balance for the same PIB supersedes the cache entry.

Operational guardrail: Never replay a PIB or manually edit balance/transaction rows until idempotency, duplicate handling, and the reconciliation procedure have been confirmed.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Account.Transaction.Balance.Api source](https://github.com/Kiwibank/kb-accounts/tree/main/src/transaction/Account.Transaction.Balance.Api) |
| Dashboards and logs | <ul><li>[Account Transaction Balance API Observability Dashboard](https://kiwibank.atlassian.net/wiki/x/B4BAKAE)</li><li>[Sumo logs](https://kbprod.au.sumologic.com/library/33974169)</li></ul> |
| Minimum Standard for Runbooks | [Account Domain Minimum Standard for Runbooks](https://kiwibank.atlassian.net/wiki/x/g4M7hgE) |