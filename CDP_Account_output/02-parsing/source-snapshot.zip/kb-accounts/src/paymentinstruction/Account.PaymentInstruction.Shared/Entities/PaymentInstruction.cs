﻿using System;

namespace Account.PaymentInstruction.Shared.Entities;

public class PaymentInstruction
{
    /// <summary>
    ///     Request Id
    /// </summary>
    public string RequestId { get; set; }

    /// <summary>
    ///     Transaction Id
    /// </summary>
    public string TransactionId { get; set; }

    /// <summary>
    ///     Client Id
    /// </summary>
    public string ClientId { get; set; }

    /// <summary>
    ///     Client Batch Id
    /// </summary>
    public string ClientBatchId { get; set; }

    /// <summary>
    ///     The type of transaction. (For FIP, this is just ‘Transfer’)
    /// </summary>
    public string? Type { get; set; }

    /// <summary>
    ///     Request Date
    /// </summary>
    public DateTimeOffset RequestDate { get; set; }

    /// <summary>
    ///     Value Date
    /// </summary>
    public DateTimeOffset? ValueDate { get; set; }

    /// <summary>
    ///     Description
    /// </summary>
    public string Description { get; set; }

    /// <summary>
    ///     Lifecycle
    /// </summary>
    public string? Lifecycle { get; set; }

    /// <summary>
    ///     Additional information required for that transaction type.
    /// </summary>
    public string AdditionalInformation { get; set; }
}