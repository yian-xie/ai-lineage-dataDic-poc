# Account Profile & Maintenance

![Account Profile Container View](./container/account.profile.svg)
# Account Profile Sequences
![Sequence for Account Created Event](./sequence/account.profile.tmv-account-created-event.svg)
![Sequence for Account Updated Event](./sequence/account.profile.tmv-account-updated-event.svg)


# Event examples

#### vault.core_api.v2.accounts.account.events with account_created

```json
{
    "event_id": "7f375cda-c404-4e29-905b-75189c8de162",
    "timestamp": "2025-09-22T21:52:54.735523Z",
    "change_id": 0,
    "account_created": {
        "account": {
            "id": "spud-P4Hng_cmSEOARUHI4XFhNQ",
            "type": "ACCOUNT_TYPE_CUSTOMER",
            "smart_contract_version_id": "633",
            "pending_smart_contract_version_id": "",
            "stakeholder_ids": [
                "7850db7e-19dc-40f2-938f-19de91772935"
            ],
            "alias": "",
            "status": "ACCOUNT_STATUS_PENDING",
            "vault_create_timestamp": "2025-09-22T21:52:54.735523Z",
            "source_create_timestamp": "2025-09-22T21:52:54.735523Z",
            "source_open_timestamp": null,
            "source_close_timestamp": null,
            "update_timestamp": null,
            "activation_timestamp": null,
            "permitted_denominations": [
                "NZD"
            ],
            "details": {
                "accountName": "spud-P4Hng_cmSEOARUHI4XFhNQ"
            },
            "t_side": "T_SIDE_LIABILITY",
            "contract_update_timestamp": null,
            "processing_group_id": "DEFAULT",
            "tranche_id": "",
            "parameter_value_hierarchy_node_id": "",
            "processing_label": ""
        }
    },
    "streamed_to_v1_topic": true
}

```
#### vault.core_api.v2.accounts.account.events with account_updated
```json
{
    "event_id": "47860340-b021-45af-94e6-1356d1f4f99a",
    "timestamp": "2025-09-29T22:26:50.887644Z",
    "change_id": 2,
    "account_updated": {
        "account": {
            "id": "spud-27C_gVM1DUOq37Ji2L8Exg",
            "type": "ACCOUNT_TYPE_CUSTOMER",
            "smart_contract_version_id": "633",
            "pending_smart_contract_version_id": "",
            "stakeholder_ids": [
                "7850db7e-19dc-40f2-938f-19de91772935"
            ],
            "alias": "",
            "status": "ACCOUNT_STATUS_OPEN",
            "vault_create_timestamp": "2025-09-29T22:26:49.388730Z",
            "source_create_timestamp": "2025-09-29T22:26:49.388730Z",
            "source_open_timestamp": "2025-09-29T22:26:49.893181Z",
            "source_close_timestamp": null,
            "update_timestamp": "2025-09-29T22:26:50.887644Z",
            "activation_timestamp": null,
            "permitted_denominations": [
                "NZD"
            ],
            "details": {
                "accountName": "spud-27C_gVM1DUOq37Ji2L8Exg"
            },
            "t_side": "T_SIDE_LIABILITY",
            "contract_update_timestamp": null,
            "processing_group_id": "DEFAULT",
            "tranche_id": "",
            "parameter_value_hierarchy_node_id": "",
            "processing_label": ""
        },
        "update_mask": {
            "paths": [
                "status",
                "update_timestamp"
            ]
        },
        "error": null
    },
    "streamed_to_v1_topic": true
}
```

