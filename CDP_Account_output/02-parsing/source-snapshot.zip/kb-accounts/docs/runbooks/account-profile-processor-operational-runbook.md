## Service Summary

| Field | Details |
|---|---|
| Business purpose | Maintains the Account Profile datastore from TMV account, parameter-change, and restriction-set events, then publishes Account Profile change events to ESP. |
| Runtime | .NET 10 ASP.NET Core executable in a Linux container; `dotnet Account.Profile.Processor.dll`; HTTP port 8080. |
| Source | [Account.Profile.Processor source](https://github.com/Kiwibank/kb-accounts/tree/main/src/profile/Account.Profile.Processor) |
| Pipeline | [Profile pipeline](https://github.com/Kiwibank/kb-accounts/blob/main/src/profile/.pipelineconfig/pipeline.yaml), building [the processor Dockerfile](https://github.com/Kiwibank/kb-accounts/blob/main/src/profile/.pipelineconfig/account-profile-processor/Dockerfile) and deploying [processor Helm values](https://github.com/Kiwibank/kb-accounts/tree/main/src/profile/Deploy/Account.Profile.Processor) |
| Last reviewed | 2026-09-30 |

## System Architecture / Dependencies

<details>
<summary>Click to expand</summary>

### Runtime Flow

1. Reliable Kafka subscribers consume TMV account V2, contract-notification parameter-change, and restriction-set events, preferring the TMV OAuth cluster with plain-cluster failover.
2. The processor creates or updates PostgreSQL Account Profile state and records outgoing messages through the shared outbox-backed persistence path.
3. Account changes are published as `account.profile.v1.event` events to ESP; subscriber metrics, traces, application logs, and failure alerts are exported.

### Dependencies

| Direction / Type | Dependency | Purpose | Configuration or source |
|---|---|---|---|
| Inbound Kafka | TMV Kafka OAuth with plain-cluster failover | Supplies `vault.core_api.v2.accounts.account.events`, `vault.core_api.v1.contracts.contract_notification.events`, and `vault.core_api.v1.restrictions.restriction_set.events`. | `KafkaClusters` and `Consumers:DefaultConsumers`; environment overrides in processor Helm values. |
| Persistence | PostgreSQL Account Profile datastore | Stores account profile, currency, identifier, restriction, and outbox state. | `ConnectionStrings__DefaultConnection`; schema and mappings in `src/profile/Account.Profile.Shared`. |
| Outbound Kafka | ESP / Confluent Kafka and Schema Registry | Publishes environment-prefixed `account.profile.v1.event` using registered schemas. | `Kafka__*` and `Kafka__SchemaRegistry__*` in environment Helm values. |
| Observability | Dynatrace and SumoLogic | Receives metrics/traces and processing-failure logs. | `MetricsOptions__*`, `TracingOptions__*`, and `SumoLogicIngestion__*`. |

### Interfaces and Schedule

- Event-driven service with no repository-defined schedule.
- All three TMV consumers use the environment-specific `cg_tmv_accounts_account_profile_<environment>` group in deployed environments.
- Account subscriber: internal accounts are skipped; not-null persistence violations move directly to DLQ; other failures redeliver every five seconds.
- Contract subscriber: only `PARAMETER_CHANGE` notifications for `RESOURCE_ACCOUNT` are processed; failures redeliver every five seconds.
- Restriction subscriber: malformed events move to DLQ; missing profiles and unexpected failures redeliver every five seconds.
- Retry alerts are raised after delivery attempt 3.

</details>

## Configuration & Environments

<details>
<summary>Click to expand</summary>

| Item | Purpose | Source or environment notes |
|---|---|---|
| Pipeline stages | Build, migrate, and deploy the profile components. | `accept`, `integrate` (`situat`), `rehearse` (`preprod`), and `deliver` (`prod`) are defined in `src/profile/.pipelineconfig/pipeline.yaml`; PERF0 is deployed by `post-integrate.sh`. |
| Image and workload | Selects the immutable processor image and Kubernetes app. | Repository `accounts/account/account-profile-processor`; tag `$UNIQUE_TAG`; app `accounts-profile-processor`; base replica count 3 and `maxUnavailable` 1. |
| Kafka and Schema Registry | Configures inbound TMV consumers and outbound ESP publishing. | Environment values define brokers, prefixes, consumer groups, authentication mode, and Schema Registry URL. README and runtime configuration conflict on whether parameter changes arrive from a direct parameter topic or contract-notification topic; runtime configuration is authoritative. |
| PostgreSQL | Configures the Profile datastore connection and pool. | Environment connection strings use `PGHOST`, `PGDATABASE*`, `PGUSER`, SSL, maximum pool size 5, and minimum pool size 2. |
| Retry | Controls subscriber redelivery and alert threshold. | `Retry__RedeliveryInterval` defaults to five seconds; `Retry__RetryAttemptAlertThreshold` defaults to 3. |
| Secrets | Supplies Kafka, Schema Registry, TMV OAuth, telemetry, and database credentials. | Kubernetes secret reference: `accounts-profile-processor`; pipeline secret variable names are listed in the profile pipeline. |


</details>

## Health & Verification

<details>
<summary>Click to expand</summary>

| Signal | Expected state | Investigate when |
|---|---|---|
| `GET` `http://accounts-profile-processor/health/readiness` on service port 80 (target port 8080) | HTTP 200; Kubernetes starts after 10 seconds, polls every 5 seconds, and marks unready after 3 failures. Cluster-internal endpoint; not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and authentication requirements]. | Non-200 response, timeout over 3 seconds, or a replica remains unready. |
| `GET` `http://accounts-profile-processor/health/liveness` on service port 80 (target port 8080) | HTTP 200; Kubernetes starts after 10 seconds, polls every 5 seconds, and restarts after 3 failures. Cluster-internal endpoint; not directly laptop-reachable. [TODO: confirm the approved VPN, cluster-shell, or port-forward procedure and authentication requirements]. | Non-200 response, timeout over 2 seconds, or repeated restarts. |
| Subscriber processing | Successful-processing logs continue and lag remains within the agreed environment baseline. | Redelivery/DLQ logs occur, throughput stops, or lag rises. [TODO: confirm dashboards, lag thresholds, and consumer-group access procedure]. |
| Profile output | Profile datastore state and `account.profile.v1.event` reflect the latest valid source event. | Source and stored change IDs differ, expected profile events are absent, or outbox publication is delayed. |

Observability: 
- [Account Profile Processor Observability Dashboard (confluence)](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5223645397/Account+Profile+Processor+Observability+Dashboard)
- [Account Profile Processor Observability Dashboard (dynatrace)](https://xye92727.live.dynatrace.com/#dashboard;gtf=-24h%20to%20now;gf=all;id=834f618d-443f-47a4-a54b-a278dfabe6a1)
- [Sumo Logic Library](https://kbprod.au.sumologic.com/library/33964165)

</details>

## Deployment Checks

<details>
<summary>Click to expand</summary>

### Before Deployment

1. Confirm the pipeline builds `accounts/account/account-profile-processor` from `src/profile/.pipelineconfig/account-profile-processor/Dockerfile`, and unit/integration evidence passes for the candidate commit.
2. Review processor and shared migration changes together; confirm the target stage values define the expected image tag, database, TMV brokers, ESP brokers/prefixes, consumer groups, Schema Registry, telemetry, and secret references.
3. Promote through `integrate`/SITUAT and `rehearse`/PREPROD before `deliver`; production verification must not be substituted by local or pre-production evidence.

### After Deployment

1. In the deployed environment, confirm the expected replica count is ready and both health probes return HTTP 200 using the approved access path.
2. Confirm the deployed image tag equals `$UNIQUE_TAG`, successful subscriber logs resume, consumer lag is stable, and no new retry-threshold, DLQ, Schema Registry, Kafka, or PostgreSQL errors appear.
3. In non-production, process a representative account event and verify the Profile datastore update and matching `account.profile.v1.event`; record the environment and result in the change evidence.

</details>

## Recovery & Change

<details>
<summary>Click to expand</summary>

### Rollback or Fix Forward

- Prefer fix-forward when a deployment includes an Account Profile database migration or has already emitted externally visible events.
- For an application-only regression, redeploy the last approved immutable image through the profile pipeline. [TODO: confirm the pipeline rollback action, release identifier, required approval, and whether database migrations can be reversed].
- Do not reset Kafka offsets, replay DLQ events, edit Profile data, or reverse migrations without the approved environment-specific procedure and change authority.

### Recovery Validation

1. Confirm all replicas are ready and live, dependency errors stop, subscriber processing resumes, and lag returns toward the pre-incident baseline.
2. Verify an affected account's latest valid source event is represented in the Profile datastore and corresponding outbound event; check for duplicate effects before closing recovery.

Operational guardrail: Treat every consumed event as repeatable but not automatically safe to replay; preserve ordering, idempotency, database, and outbox behavior by using an approved replay procedure only.

</details>

## Reference Links

| Resource | Link or path |
|---|---|
| Repository | [Kiwibank kb-accounts](https://github.com/Kiwibank/kb-accounts) |
| Dashboards and logs | <ul><li>[Account Profile Processor Observability Dashboard (confluence)](https://kiwibank.atlassian.net/wiki/spaces/AccountDomain/pages/5223645397/Account+Profile+Processor+Observability+Dashboard)</li><li>[Account Profile Processor Observability Dashboard (dynatrace)](https://xye92727.live.dynatrace.com/#dashboard;gtf=-24h%20to%20now;gf=all;id=834f618d-443f-47a4-a54b-a278dfabe6a1)</li><li>[Sumo Logic Library](https://kbprod.au.sumologic.com/library/33964165)</li></ul> |