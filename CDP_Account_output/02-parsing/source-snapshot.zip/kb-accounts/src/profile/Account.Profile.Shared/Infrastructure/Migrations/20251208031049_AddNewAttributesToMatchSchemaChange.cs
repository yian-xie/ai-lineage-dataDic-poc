﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddNewAttributesToMatchSchemaChange : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "withholding_tax_withholding_tax_type",
                schema: "profile",
                table: "account_profile",
                newName: "domestic_tax_rate_domestic_tax_type");

            migrationBuilder.RenameColumn(
                name: "withholding_tax_withholding_tax_rate",
                schema: "profile",
                table: "account_profile",
                newName: "domestic_tax_rate_rate_value");

            migrationBuilder.AddColumn<string>(
                name: "account_create_user_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "account_organisation_unit_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "banking_relationship_nominated_tax_party_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "domestic_tax_rate_country_alpha3code",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "minimum_number_of_authoriser",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "account_create_user_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "account_organisation_unit_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "banking_relationship_nominated_tax_party_id",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "domestic_tax_rate_country_alpha3code",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "minimum_number_of_authoriser",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.RenameColumn(
                name: "domestic_tax_rate_domestic_tax_type",
                schema: "profile",
                table: "account_profile",
                newName: "withholding_tax_withholding_tax_type");

            migrationBuilder.RenameColumn(
                name: "domestic_tax_rate_rate_value",
                schema: "profile",
                table: "account_profile",
                newName: "withholding_tax_withholding_tax_rate");
        }
    }
}