﻿using System;
using System.Collections.Generic;
using System.Linq;

using GraphqlPaymentInstruction =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstruction;
using GraphqlPaymentInstructionStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionStatus;
using Lifecycle = Account.PaymentInstruction.Api.Queries.Types.Lifecycle;
using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;
using PaymentInstructionStatus =
    Account.PaymentInstruction.Shared.Entities.PaymentInstructionStatus;
using PaymentInstructionWithStatus =
    Account.PaymentInstruction.Api.Queries.Types.PaymentInstructionWithStatus;
using Status = Account.PaymentInstruction.Api.Queries.Types.Status;
using TransactionType = Account.PaymentInstruction.Api.Queries.Types.TransactionType;

namespace Account.PaymentInstruction.Api.Infrastructure;

/// <summary>
///     Implement the Payment Instruction Api data mapper.
/// </summary>
public static class PaymentInstructionMapper
{
    /// <summary>
    ///     Map <see cref="PaymentInstructionRequestInput" /> to <see cref="Shared.Entities.PaymentInstruction" />.
    /// </summary>
    /// <param name="paymentInstructionRequestInput">
    ///     <see cref="PaymentInstructionRequestInput" />
    /// </param>
    /// <param name="clientBatchId">Client batch id</param>
    /// <param name="clientId">Client id</param>
    /// <param name="utcNow">The current UTC time</param>
    /// <returns>
    ///     <see cref="Shared.Entities.PaymentInstruction" />
    /// </returns>
    public static Shared.Entities.PaymentInstruction Map(
        PaymentInstructionRequestInput paymentInstructionRequestInput,
        string clientBatchId,
        string clientId,
        DateTimeOffset utcNow)
    {
        return new Shared.Entities.PaymentInstruction
        {
            RequestId = paymentInstructionRequestInput.RequestId,
            ClientBatchId = clientBatchId,
            ClientId = clientId,
            TransactionId = paymentInstructionRequestInput.PaymentInstruction.TransactionId,
            Lifecycle = paymentInstructionRequestInput.PaymentInstruction.Lifecycle.ToString(),
            Type = paymentInstructionRequestInput.PaymentInstruction.Type.ToString(),
            RequestDate = utcNow
        };
    }

    /// <summary>
    ///     Map DB <see cref="Shared.Entities.PaymentInstruction" /> to GraphQL <see cref="PaymentInstructionWithStatus" />
    /// </summary>
    /// <param name="paymentInstruction">
    ///     <see cref="Shared.Entities.PaymentInstruction" />
    /// </param>
    /// <param name="paymentInstructionStatuses">A list of <see cref="PaymentInstructionStatus" /></param>
    /// <returns>
    ///     <see cref="PaymentInstructionWithStatus" />
    /// </returns>
    public static PaymentInstructionWithStatus ToPaymentInstructionWithStatus(
        this
            Shared.Entities.PaymentInstruction paymentInstruction,
        IEnumerable<PaymentInstructionStatus> paymentInstructionStatuses)
    {
        var graphqlPaymentInstruction =
            new GraphqlPaymentInstruction
            {
                Id = paymentInstruction.RequestId,
                ClientBatchId = paymentInstruction.ClientBatchId,
                ClientId = paymentInstruction.ClientId,
                TransactionId = paymentInstruction.TransactionId,
                Lifecycle = Enum.Parse<Lifecycle>(paymentInstruction.Lifecycle!),
                Type = Enum.Parse<TransactionType>(paymentInstruction.Type!),
                Description = paymentInstruction.Description,
                RequestDate = paymentInstruction.RequestDate,
                ValueDate = paymentInstruction.ValueDate
            };

        var graphqlPaymentInstructionStatuses = paymentInstructionStatuses.Select(x =>
                new GraphqlPaymentInstructionStatus
                {
                    BatchId = x.BatchId,
                    Status = Enum.Parse<Status>(x.State),
                    StatusDate = x.Date
                })
            .ToArray();

        return new PaymentInstructionWithStatus
        {
            PaymentInstruction = graphqlPaymentInstruction,
            Statuses = graphqlPaymentInstructionStatuses
        };
    }
}