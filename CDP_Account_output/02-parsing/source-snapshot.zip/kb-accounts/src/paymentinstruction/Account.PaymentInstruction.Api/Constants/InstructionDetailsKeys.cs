﻿namespace Account.PaymentInstruction.Api.Constants;

/// <summary>
/// Payment Instruction Details additional properties key constants.
/// </summary>
public static class InstructionDetailsKeys
{
    /// <summary>
    /// Transaction code.
    /// </summary>
    public const string TransactionCodeCode = "transaction_code.code";

    /// <summary>
    /// Transaction source code.
    /// </summary>
    public const string TransactionCodeSourceCode =
        "transaction_code.source_code";


    /// <summary>
    /// Payment instruction category.
    /// </summary>
    public const string PaymentInstructionCategory =
        "payment.instruction_category";

    /// <summary>
    /// Payment instruction leg.
    /// </summary>
    public const string PaymentInstructionLeg = "payment.instruction_leg";

    /// <summary>
    /// Type.
    /// </summary>
    public const string Type = "type";

    /// <summary>
    /// Particulars.
    /// </summary>
    public const string Particulars = "particulars";

    /// <summary>
    /// Code.
    /// </summary>
    public const string Code = "code";

    /// <summary>
    /// Reference.
    /// </summary>
    public const string Reference = "reference";
}