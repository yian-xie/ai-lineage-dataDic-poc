﻿namespace Account.Shared.Metrics;

/// <summary>
///     List of common keys used when creating telemetry tags
/// </summary>
/// <example>
///     <code> TagList? tagList = [new KeyValuePair<string, object>
///         (TelemetryTagKeys.EventType,
///         nameof(PostingBatchEvent))];</code>
/// </example>
public static class TelemetryTagKeys
{
    public const string EventType = "EventType";
    public const string ExceptionType = "ExceptionType";
    public const string DownStreamServiceName = "DownStreamServiceName";

    public const string Outcome = "outcome";

    public static class Outcomes
    {
        public const string Success = "success";
    }
}