﻿using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__DomesticTaxRate")]
public class AccountProfile__DomesticTaxRate
{
    [GraphQLName("domesticTaxType")] public string DomesticTaxType { get; set; }

    [GraphQLName("rateValue")] public string RateValue { get; set; }

    [GraphQLName("countryAlpha3Code")] public string CountryAlpha3Code { get; set; }
}