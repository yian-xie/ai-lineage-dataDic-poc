﻿using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Api.Shared.Clients.Rest.SumoLogic.V1.SumoLogicIngestionManual;

namespace Account.Shared.Services;

/// <summary>
///     Helper class for interacting with the Sumo Logic API.
///     This class is responsible for ingesting logs into Sumo Logic using the provided
///     Sumo Logic client and settings.
/// </summary>
public class SumoLogicClientHelper(
    ISumoLogicClient sumoLogicClient)
    : ISumoLogicClientHelper
{
    /// <summary>
    ///     Ingests a log into Sumo Logic.
    /// </summary>
    /// <param name="message">The log message to ingest.</param>
    /// <param name="sourceCategory">The source category for the log.</param>
    /// <param name="sourceName">The source name for the log</param>
    /// <param name="apiToken">The api token for the Sumo Logic endpoint.</param>
    /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task IngestLogAsync(
        byte[] message,
        string sourceCategory,
        string sourceName,
        string apiToken,
        CancellationToken cancellationToken)
    {
        await sumoLogicClient.IngestLogAsync(
            apiToken,
            sourceCategory,
            sourceName,
            Encoding.UTF8.GetString(message),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    ///     Ingests a log into Sumo Logic.
    /// </summary>
    /// <param name="message">The log message to ingest.</param>
    /// <param name="sourceCategory">The source category for the log.</param>
    /// <param name="sourceName">The source name for the log</param>
    /// <param name="apiToken">The api token for the Sumo Logic endpoint.</param>
    /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task IngestLogAsync(
        string message,
        string sourceCategory,
        string sourceName,
        string apiToken,
        CancellationToken cancellationToken)
    {
        await sumoLogicClient.IngestLogAsync(
            apiToken,
            sourceCategory,
            sourceName,
            message,
            cancellationToken: cancellationToken);
    }
}