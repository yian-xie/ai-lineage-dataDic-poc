﻿using Account.Origination.Shared.Repositories;

namespace Account.Origination.Job.Jobs;

/// <summary>
///     Define the interface to handle the data in the Account Opening repository and interact with TMV to create and open
///     the account.
/// </summary>
public interface IAccountOriginationJob
{
    /// <summary>
    ///     Account Origination task.
    /// </summary>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <param name="cancellationToken">
    ///     <see cref="CancellationToken" />
    /// </param>
    /// <returns>
    ///     <see cref="Account" />
    /// </returns>
    Task<Domain.Account?> DoWorkAsync(
        IRepositoryFactory repositoryFactory,
        CancellationToken cancellationToken);
}