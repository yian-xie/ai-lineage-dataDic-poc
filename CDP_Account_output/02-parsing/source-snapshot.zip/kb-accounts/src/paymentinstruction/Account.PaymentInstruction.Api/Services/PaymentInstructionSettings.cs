﻿namespace Account.PaymentInstruction.Api.Services;

public class PaymentInstructionSettings
{
    /// <summary>
    ///     Client Id
    /// </summary>
    public string ClientId { get; set; }
}