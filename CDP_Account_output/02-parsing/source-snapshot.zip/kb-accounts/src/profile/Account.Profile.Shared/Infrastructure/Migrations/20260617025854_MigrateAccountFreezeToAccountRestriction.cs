﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MigrateAccountFreezeToAccountRestriction : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Migrating existing account freeze data in account_profile to account_restriction table.
            migrationBuilder.Sql(
                $@"INSERT INTO profile.account_restriction (id,
                event_id,
                restriction_set_id,
                change_id,
                effective_at,
                expiry_at,
                processing_at,
                type,
                description,
                is_active,
                restriction_set_event_payload,
                profile_account_id,
                created_at,
                modified_at)
                SELECT gen_random_uuid(),
                gen_random_uuid()::text,
                account_freeze_details_restriction_set_id,
                account_freeze_details_change_id,
                account_freeze_details_effective,
                account_freeze_details_expiration,
                NOW(),
                account_freeze_details_freeze_type,
                account_freeze_details_freeze_description,
                true,
                NULL,
                account_id,
                NOW(),
                NULL
                FROM profile.account_profile
                WHERE account_freeze_details_restriction_set_id IS NOT NULL;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // No data rollback.
        }
    }
}