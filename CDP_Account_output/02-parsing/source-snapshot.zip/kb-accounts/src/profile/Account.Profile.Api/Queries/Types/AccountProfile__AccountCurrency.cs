﻿using HotChocolate;

namespace Account.Profile.Api.Queries.Types;

[GraphQLName("AccountProfile__AccountCurrency")]
public class AccountProfile__AccountCurrency
{
    [GraphQLName("accountCurrency")] public string AccountCurrency { get; set; }

    [GraphQLName("accountCurrencyType")] public string AccountCurrencyType { get; set; }
}