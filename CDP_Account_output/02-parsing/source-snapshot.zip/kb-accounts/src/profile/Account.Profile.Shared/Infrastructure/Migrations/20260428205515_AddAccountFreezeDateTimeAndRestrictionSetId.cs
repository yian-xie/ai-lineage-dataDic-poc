﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAccountFreezeDateTimeAndRestrictionSetId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "account_freeze_details_effective",
                schema: "profile",
                table: "account_profile",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "account_freeze_details_expiration",
                schema: "profile",
                table: "account_profile",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "account_freeze_details_restriction_set_id",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "account_freeze_details_effective",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "account_freeze_details_expiration",
                schema: "profile",
                table: "account_profile");

            migrationBuilder.DropColumn(
                name: "account_freeze_details_restriction_set_id",
                schema: "profile",
                table: "account_profile");
        }
    }
}