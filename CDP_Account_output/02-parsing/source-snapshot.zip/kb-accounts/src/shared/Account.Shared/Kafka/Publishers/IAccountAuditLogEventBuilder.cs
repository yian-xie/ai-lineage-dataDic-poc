﻿using Api.Shared.Clients.Events.Internal.V1.AccountAuditLog;

using HotChocolate.Resolvers;

using Microsoft.AspNetCore.Http;

namespace Account.Shared.Kafka.Publishers;

public interface IAccountAuditLogEventBuilder
{
    AccountAuditLogEvent BuildEvent(
        IMiddlewareContext middlewareContext,
        HttpContext httpContext,
        string appName);
}