﻿using System;

namespace Account.Shared.Infrastructure.Exceptions;

/// <summary>
///     Exception for invalid TMV Account TSide.
/// </summary>
public class UnexpectedTSideException(string tSide) : Exception($"UNKNOWN TSide : {tSide}");