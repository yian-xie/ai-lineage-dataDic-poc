﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Account.PaymentInstruction.Api.Infrastructure;
using Account.PaymentInstruction.Shared.Repositories;

using Microsoft.Extensions.Options;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Services;

/// <summary>
///     Used in Payment Instruction Api mutation to process the <see cref="PaymentInstructionRequestInput" /> and insert
///     the
///     <see cref="Shared.Entities.PaymentInstruction" /> into payment_instruction table.
/// </summary>
public class PaymentInstructionCreator(
    IRepositoryFactory repositoryFactory,
    IOptions<PaymentInstructionSettings> paymentInstructionSettings,
    TimeProvider timeProvider)
    : IPaymentInstructionCreator
{
    public async Task<Shared.Entities.PaymentInstruction> CreateAsync(
        PaymentInstructionRequestInput paymentInstructionRequestInput,
        string clientBatchId,
        CancellationToken cancellationToken)
    {
        var paymentInstruction = PaymentInstructionMapper.Map(
            paymentInstructionRequestInput,
            clientBatchId,
            paymentInstructionSettings.Value.ClientId,
            timeProvider.GetUtcNow());

        repositoryFactory.PaymentInstructionRepository.Add(paymentInstruction);
        await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);

        return paymentInstruction;
    }
}