﻿using Account.Shared;
using Account.Shared.Services;
using Account.TopicLogger.Processor.Configurations;
using Account.TopicLogger.Processor.Services;
using Account.TopicLogger.Processor.Subscribers;

using Api.Shared.Clients.Rest.Dynatrace;
using Api.Shared.Clients.Rest.Dynatrace.V2.DynatraceMetrics;
using Api.Shared.Clients.Rest.SumoLogic;
using Api.Shared.Clients.Rest.SumoLogic.V1.SumoLogicIngestionManual;

using Enterprise.Shared.Kafka;

namespace Account.TopicLogger.Processor;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        var monitoringSumoLogicApiToken = Configuration.GetValue<string>(ExtraSettings.SumoLogicMonitoringApiToken);
        ArgumentException.ThrowIfNullOrWhiteSpace(monitoringSumoLogicApiToken);

        var sumoLogSettings =
            Configuration.GetSection(SumoLogicSettings.Key).Get<SumoLogicSettings>();
        ArgumentNullException.ThrowIfNull(sumoLogSettings);
        sumoLogSettings.Validate();
        services.AddSingleton(sumoLogSettings);
        services.AddHttpClient<ISumoLogicClient, SumoLogicClient>(SumoLogicClientUtils.Configure);

        var dynatraceSettings =
            Configuration.GetSection(DynatraceSettings.Key).Get<DynatraceSettings>();
        ArgumentNullException.ThrowIfNull(dynatraceSettings);
        dynatraceSettings.Validate();
        services.AddSingleton(dynatraceSettings);

        services
            .AddHttpClient<IDynatraceMetricsClient, DynatraceMetricsClient>(
                DynatraceClientUtils.Configure);

        services
            .AddSingleton<IFileHelper, FileHelper>()
            .AddSingleton<IKubernetesHelper, KubernetesHelper>()
            .AddSingleton<ISumoLogicClientHelper, SumoLogicClientHelper>()
            .AddSingleton<IDynatraceMetricsClientHelper, DynatraceMetricsClientHelper>();


        UseKafka(services);
        services.AddTmvKafkaClusterConfigurations(configuration);

        var kafkaSettings = configuration
            .GetSection(KafkaSettings.Key)
            .Get<KafkaSettings>();
        ArgumentNullException.ThrowIfNull(kafkaSettings);
        services.AddSingleton(kafkaSettings);

        services
            // TMV Kafka failover consumers to support TMV OAuth.
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvActionEventSubscriber, string, ActionTopicEmptyEvent>(
                kafkaSettings, TmvTopics.ActionTopics)
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvAuditEventSubscriber, string, AuditTopicEmptyEvent>(
                kafkaSettings, TmvTopics.AuditTopics)
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvDlqEventSubscriber, string, DlqTopicEmptyEvent>(
                kafkaSettings, TmvTopics.DqlTopics)
            .AddKafkaReliableEventConsumersWithTmvOAuth<TmvAlertEventSubscriber, string, AlertTopicEmptyEvent>(
                kafkaSettings, TmvTopics.AlertTopics);
    }
}