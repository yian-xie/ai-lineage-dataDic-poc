﻿using System;
using System.Linq;
using System.Threading.Tasks;

using Account.Domain.Directory.Service.WebApiClient;
using Account.Shared.Authorisation;
using Account.Shared.Constants;
using Account.Transaction.Api.Extensions;
using Account.Transaction.Api.Queries.Exceptions;
using Account.Transaction.Api.Queries.Filtering;
using Account.Transaction.Api.Queries.Mapping;
using Account.Transaction.Api.Queries.Services;
using Account.Transaction.Api.Queries.Services.Models;
using Account.Transaction.Api.Queries.Sorting;
using Account.Transaction.Api.Queries.Types;
using Account.Transaction.Api.Services;
using Account.Transaction.Shared.Repositories;

using HotChocolate;
using HotChocolate.Data;
using HotChocolate.Data.Sorting;
using HotChocolate.Resolvers;
using HotChocolate.Types;

using Kb.Api.Infrastructure.ErrorHandling.Exceptions;

using Microsoft.Extensions.Logging;

using Ultracs.Integration.Client;

using AccountTransactionEntity = Account.Transaction.Shared.Entities.AccountTransaction;

namespace Account.Transaction.Api.Queries;

/// <summary>
///     The query for retrieving TMV account transactions.
/// </summary>
/// <param name="filteringService"><see cref="IFilteringService"/></param>
/// <param name="transactionMapper"><see cref="ITransactionMapper{TSource,TTarget}"/></param>
/// <param name="creditCardTransactionTransactionMapper"><see cref="ITransactionMapper{TSource,TTarget}"/></param>
/// <param name="creditCardTransactionsService"><see cref="ICreditCardTransactionsService"/></param>
/// <param name="ultracsTransactionMapper"><see cref="ITransactionMapper{TSource,TTarget}"/></param>
/// <param name="ultracsAuthorisationTransactionMapper"><see cref="ITransactionMapper{TSource,TTarget}"/></param>
/// <param name="ultracsTransactionService"><see cref="IUltracsTransactionService"/></param>
/// <param name="accountDomainDirectoryService"><see cref="IAccountDomainDirectoryService"/></param>
/// <param name="auditLogDataProvider"><see cref="ITransactionAuditLogDataProvider"/></param>
/// <param name="logger"><see cref="ILogger"/></param>
public class AccountTransactionQuery(
    IFilteringService filteringService,
    ITransactionMapper<AccountTransactionEntity, AccountTransaction> transactionMapper,
    ITransactionMapper<CreditCardTransaction, AccountTransaction> creditCardTransactionTransactionMapper,
    ITransactionMapper<TransactionItem, AccountTransaction> ultracsTransactionMapper,
    ITransactionMapper<AuthorisationTransactionItem, AccountTransaction> ultracsAuthorisationTransactionMapper,
    ICreditCardTransactionsService creditCardTransactionsService,
    IUltracsTransactionService ultracsTransactionService,
    IAccountDomainDirectoryService accountDomainDirectoryService,
    ITransactionAuditLogDataProvider auditLogDataProvider,
    ILogger<AccountTransactionQuery> logger)
{
    /// <summary>
    ///     The query for retrieving TMV account transactions based on the provided query parameters.
    /// </summary>
    /// <param name="queryParams">
    ///     <see cref="AccountTransactionQueryParams" />
    /// </param>
    /// <param name="sortingContext">
    ///     <see cref="ISortingContext" />
    /// </param>
    /// <param name="resolverContext"><see cref="IResolverContext"/></param>
    /// <param name="repositoryFactory">
    ///     <see cref="IRepositoryFactory" />
    /// </param>
    /// <returns>The TMV account transaction.</returns>
    /// <exception cref="UnauthorizedException">Throw unauthorized exception</exception>
    [Account]
    [UsePaging]
    [UseProjection]
    [UseSorting(typeof(AccountTransactionSortType))]
    [UseResolverScope]
    public async Task<IExecutable<AccountTransaction>> TransactionsV2(
        [GraphQLName("queryParams")] AccountTransactionQueryParams queryParams,
        ISortingContext sortingContext,
        IResolverContext resolverContext,
        [Service] IRepositoryFactory repositoryFactory)
    {
        IQueryable<AccountTransaction> result;

        queryParams.AccountId = GetAccountId(resolverContext);
        auditLogDataProvider.AccountIds = new[] { queryParams.AccountId };
        var transactionType = GetTransactionType(resolverContext);

        // Get access number from customer token if provided in the local state by the authorisation middleware
        var accessNumber = resolverContext.GetLocalStateOrDefault<int>(LocalStateConstants.AccessNumberKey);
        queryParams.AccessNumber = accessNumber == 0 ? queryParams.AccessNumber : accessNumber;

        if (queryParams.AccessNumber is null)
        {
            throw new RequestValidationException("Access number is required for transaction query but was not provided in the query parameters or token.");
        }

        switch (transactionType)
        {
            case HttpContextDataConstants.TransactionType.CreditCard:
                result = await GetCreditCardTransactionsAsync(queryParams, sortingContext, resolverContext);
                break;

            case HttpContextDataConstants.TransactionType.ForeignCurrency:
                throw new RequiredContextLocalStateInvalidException($"Transaction type {transactionType} is not supported.");

            // For TMV and Ultracs transactions, we need to check the account origination source first, then call the corresponding service to get transactions.
            default:
                {
                    var account = await accountDomainDirectoryService.GetAccount(queryParams.AccessNumber.ToString()!, queryParams.AccountId);

                    switch (account.OriginationSource)
                    {
                        case AccountOriginationSource.TmvCore:
                            result = GetTmvTransactions(queryParams, sortingContext, repositoryFactory);
                            break;

                        case AccountOriginationSource.UltracsCore:
                            var bankAccountNumber = account.AccountIdentifications
                            .FirstOrDefault(x => x.AccountIdentificationType == AccountIdentificationTypeDto.BankAccountNumber)?.AccountIdentification;

                            if (string.IsNullOrWhiteSpace(bankAccountNumber))
                            {
                                throw new RequestValidationException($"Bank account number for Ultracs account {queryParams.AccountId} cannot be found.");
                            }

                            result = await GetUltracsTransactionsAsync(bankAccountNumber, queryParams, sortingContext, resolverContext);
                            break;

                        default:
                            throw new UnsupportedTransactionTypeException($"Transaction type {account.OriginationSource} is not supported for accountId ({queryParams.AccountId}) with access number ({queryParams.AccessNumber}).");
                    }

                    break;
                }
        }

        return result.AsExecutable();
    }

    /// <summary>
    /// Get account id from the local state in the <see cref="IResolverContext"/>.
    /// </summary>
    /// <param name="resolverContext"><see cref="IResolverContext"/></param>
    /// <returns>The account id</returns>
    /// <exception cref="RequiredContextLocalStateMissingException">Throw when the <see cref="HttpContextDataConstants.AccountIdKey"/> is null or whitespace in the resolver context local state.</exception>
    private static string GetAccountId(IResolverContext resolverContext)
    {
        var accountId = resolverContext.GetLocalStateOrDefault<string?>(HttpContextDataConstants.AccountIdKey, null);

        return string.IsNullOrWhiteSpace(accountId) ? throw new RequiredContextLocalStateMissingException($"Failed to retrieve {HttpContextDataConstants.AccountIdKey} from the context data for transactionV2 query.") : accountId;
    }

    /// <summary>
    /// Get transaction type from the local state in the <see cref="IResolverContext"/>.
    /// </summary>
    /// <param name="resolverContext"><see cref="IResolverContext"/></param>
    /// <returns>The transaction type</returns>
    /// <exception cref="RequiredContextLocalStateMissingException">Throw when the <see cref="HttpContextDataConstants.TransactionType"/> is null or whitespace in the resolver context local state.</exception>
    private static HttpContextDataConstants.TransactionType GetTransactionType(IResolverContext resolverContext)
    {
        var transactionType =
            resolverContext.GetLocalStateOrDefault<HttpContextDataConstants.TransactionType?>(
                HttpContextDataConstants.TransactionTypeKey, null);

        return transactionType ?? throw new RequiredContextLocalStateMissingException($"Failed to retrieve {HttpContextDataConstants.TransactionTypeKey} from the context data for transactionV2 query.");
    }

    /// <summary>
    /// Query the Ultracs transactions via Ultracs Proxy API.
    /// </summary>
    /// <param name="bankAccountNumber">ultracs bank account number</param>
    /// <param name="queryParams"><see cref="AccountTransactionQueryParams"/></param>
    /// <param name="sortingContext"></param>
    /// <param name="resolverContext"><see cref="IResolverContext"/></param>
    /// <returns><see cref="IQueryable{T}"/> where T is <see cref="AccountTransaction"/></returns>
    private async Task<IQueryable<AccountTransaction>> GetUltracsTransactionsAsync(
        string bankAccountNumber,
        AccountTransactionQueryParams queryParams,
        ISortingContext sortingContext,
        IResolverContext resolverContext)
    {
        sortingContext.AppendStableOrder();

        switch (queryParams.UltracsTransactionFilterType)
        {
            case null or UltracsTransactionFilterType.ALL:
                {
                    var transactionTask =
                        ultracsTransactionService.GetUltracsTrasactionsAsync(bankAccountNumber, queryParams,
                            resolverContext.RequestAborted);

                    var authorisationTask =
                        ultracsTransactionService.GetUltracsAuthorisationTransactionsAsync(bankAccountNumber, queryParams,
                            resolverContext.RequestAborted);

                    await Task.WhenAll(transactionTask, authorisationTask);

                    var settled = transactionTask.Result;
                    var authorisations = authorisationTask.Result;

                    var transactions = ultracsTransactionMapper
                        .MapTo(settled.Data.TransactionItems.AsQueryable(), queryParams.AccountId)
                        .Concat(
                            ultracsAuthorisationTransactionMapper.MapTo(authorisations.Data
                                .AuthorisationItems
                                .AsQueryable(), queryParams.AccountId));

                    return transactions;
                }
            case UltracsTransactionFilterType.AuthorisationOnly:
                {
                    var authorisations =
                        await ultracsTransactionService.GetUltracsAuthorisationTransactionsAsync(bankAccountNumber, queryParams,
                            resolverContext.RequestAborted);

                    return ultracsAuthorisationTransactionMapper.MapTo(authorisations.Data.AuthorisationItems.AsQueryable(), queryParams.AccountId);
                }
            case UltracsTransactionFilterType.TransactionOnly:
                {
                    var settled =
                        await ultracsTransactionService.GetUltracsTrasactionsAsync(bankAccountNumber, queryParams,
                            resolverContext.RequestAborted);

                    return ultracsTransactionMapper.MapTo(settled.Data.TransactionItems.AsQueryable(), queryParams.AccountId);
                }
            default:
                throw new ArgumentOutOfRangeException(nameof(UltracsTransactionFilterType), queryParams.UltracsTransactionFilterType, "Unknown UltracsTransactionFilterType.");
        }
    }

    /// <summary>
    /// Query the credit card transactions via Cards API.
    /// </summary>
    /// <param name="queryParams"><see cref="AccountTransactionQueryParams"/></param>
    /// <param name="sortingContext"><see cref="ISortingContext"/></param>
    /// <param name="resolverContext"></param>
    /// <returns><see cref="IQueryable{T}"/> where T is <see cref="AccountTransaction"/></returns>
    private async Task<IQueryable<AccountTransaction>> GetCreditCardTransactionsAsync(
        AccountTransactionQueryParams queryParams, ISortingContext sortingContext, IResolverContext resolverContext)
    {
        sortingContext.AppendStableOrder();

        var cardTransactionsResponseState =
            await creditCardTransactionsService.GetCreditCardTransactionsAsync(queryParams, resolverContext.RequestAborted);

        if (cardTransactionsResponseState.responseState.status == ResponseStatusType.PartialSuccess)
        {
            logger.LogWarning("Partial success in fetching credit card transactions for access number {accessNumber}.", queryParams.AccessNumber);
            resolverContext.ReportResolverErrors(cardTransactionsResponseState.responseState.warnings);
        }

        return creditCardTransactionTransactionMapper.MapTo(cardTransactionsResponseState.creditCardTransactions.AsQueryable(), queryParams.AccountId);
    }

    /// <summary>
    /// Query the TMV account transactions from the repository.
    /// </summary>
    /// <param name="queryParams"><see cref="AccountTransactionQueryParams"/></param>
    /// <param name="sortingContext"><see cref="ISortingContext"/></param>
    /// <param name="repositoryFactory"><see cref="IRepositoryFactory"/></param>
    /// <returns><see cref="IQueryable{T}"/> where T is <see cref="AccountTransaction"/></returns>
    private IQueryable<AccountTransaction> GetTmvTransactions(
        AccountTransactionQueryParams queryParams, ISortingContext sortingContext, IRepositoryFactory repositoryFactory)
    {
        sortingContext.AppendStableOrder();

        var query = repositoryFactory.DbContext.AccountTransactions.AsQueryable();
        var filteredQuery = filteringService.ApplyFilter(query, queryParams);

        return transactionMapper.MapTo(filteredQuery, queryParams.AccountId);
    }
}