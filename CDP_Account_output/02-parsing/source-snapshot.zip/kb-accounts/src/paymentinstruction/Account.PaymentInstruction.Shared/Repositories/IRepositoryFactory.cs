﻿using Account.PaymentInstruction.Shared.Infrastructure;

using Enterprise.Shared.Database;

namespace Account.PaymentInstruction.Shared.Repositories;

public interface IRepositoryFactory
{
    PaymentInstructionDbContext DbContext { get; }
    IUnitOfWork UnitOfWork { get; }
    IPaymentInstructionRepository PaymentInstructionRepository { get; }
    IPaymentInstructionStatusRepository PaymentInstructionStatusRepository { get; }
}