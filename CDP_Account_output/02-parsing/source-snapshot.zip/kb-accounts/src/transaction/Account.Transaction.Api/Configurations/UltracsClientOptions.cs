﻿using Enterprise.Shared.Configuration;

namespace Account.Transaction.Api.Configurations;

/// <summary>
/// Ultracs client extended options.
/// </summary>
public class UltracsClientOptions : IKeyedConfigurationSection
{
    public static string Key => "UltracsClientOptions";

    /// <summary>
    /// Ultracs client proxy base URL.
    /// </summary>
    public required string BaseUrl { get; set; }

    /// <summary>
    /// Correlation ID header name.
    /// </summary>
    public required string CorrelationIdHeader { get; set; }

    /// <summary>
    /// Consumer ID header name.
    /// </summary>
    public required string ConsumerIdHeader { get; set; }

    /// <summary>
    /// Consumer ID value.
    /// </summary>
    public required string ConsumerId { get; set; }
}