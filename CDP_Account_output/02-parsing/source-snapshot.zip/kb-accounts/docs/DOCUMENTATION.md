# How to 

There are various levels of documentation. 

High level solution design will live in Account.

Open this repo using the [`./kb-accounts.code-workspace`] vscode workspace file. Vscode will recommend extensions that will assist in documentation.






## How to create diagrams

Diagrams in this repo should ideally be [plantuml](https://plantuml.com/) drawings. 

We are using a mix [C4](https://c4model.com/) and UML diagrams to represent high level views. 

Recommended diagrams are (but not limited do)

- [C4 System Context diagram](https://c4model.com/#SystemContextDiagram)
- [C4 Container diagram](https://c4model.com/#ContainerDiagram)
- [UML Sequence diagram](https://plantuml.com/sequence-diagram)
- [UML State diagram](https://plantuml.com/state-diagram)

Feel free to add other diagram types to meet your needs.

We leverage the [C4 Plantuml extension](https://github.com/plantuml-stdlib/C4-PlantUML) to provide C4 support in plantuml.


Plantuml diagrams should be exported as `.svg` format directly next to `.plantuml` file. 
A `.vscode/settings.json` file will set your export folder path automatically.


Set the `@startuml <name>` to match the diagram's filename.
```
// file is ./docs/origination/container/account.origination.plantuml
@startuml account.origination
  ...stuff
@enduml
// exports to ./docs/origination/container/account.origination.svg
```


See ['./example-c4-container-diagram.plantuml'](./example-c4-container-diagram.plantuml) for an overview of how to create a container diagram. 


## General Documentation Structure

`./docs` contains all the higher level design docs in [github markdown format](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/quickstart-for-writing-on-github).


Higher level documentation such as higher level context diagrams can live in a direct subfolder eg: `./docs/container`

Each subdomain is represented as a subfolder eg: `./docs/origination`
Subdomain views such as container, sequence, etc are stored in subfolders off the subdomain folder eg: `./docs/origination/container`



### Component documentation
Each component should have a root `README.md` file that describes. See [How to write a README.md](#how-to-write-a-readmemd) for details on the kind of details we need. 

Component related documentation should live within the component folder eg: `./src/spud/Account.Spud.Api/README.md`

Detailed component diagrams such as sequence diagrams that show a components internal flow should live within the component folder. eg: `./src/spud/Account.Spud.Api/docs`


## How to write a Component's README.md

Keep wording concise. 

We should be able to use this readme as a detailed design document. 

Check out the [Art of README](https://github.com/hackergrrl/art-of-readme#readme)

Use correct heading structures to ensure the [github table of contents feature](https://github.blog/changelog/2021-04-13-table-of-contents-support-in-markdown-files/) works.


Example: TODO link to origination job readme

What to include:

### 1. Project Title

### 2. Project Description. 

Describe what this component does in a paragraph.

Explain and link to where this component lives in the wider context. Link back to the subdomain container view and confluence-based higher solution designs and/or functional specs. 

Bullet point the features this component provides.

### 3. Diagrams
Add in the top level detail diagram(s) that provide an overview of the component

This could be the sequence diagram, state diagram

### 4. Details
List out key details the features of this component provides in sections with sufficient information so someone can understand what the overall intent is. 

Provide example expected input/outputs, if applicable.

Add information on sad-path/failure scenarios and handling. How will this component maintain resiliance?

### 5. API contracts
Link to any api contracts that this service uses. 











