﻿using Enterprise.Shared.Configuration;

namespace Account.Transaction.Api.Configurations;

/// <summary>
///     Configuration options for pagination in the Transaction API.
/// </summary>
public class PagingOptions : IKeyedConfigurationSection
{
    /// <summary>
    ///     Default page size in pagination.
    /// </summary>
    public required int DefaultPageSize { get; set; }

    /// <summary>
    ///     Maximum page size in pagination.
    /// </summary>
    public required int MaxPageSize { get; set; }

    /// <summary>
    ///     Paging options configuration key.
    /// </summary>
    public static string Key => "PagingOptions";
}