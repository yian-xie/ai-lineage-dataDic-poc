﻿using Account.Shared.Constants.Tmv;
using Account.Shared.Infrastructure.Exceptions;

using Api.Shared.Clients.Rest.ThoughtMachine.V4.Core;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

namespace Account.Shared.Mappers;

public static class TSideMapper
{
    public static string GetTSideName(this AccountingTside accountTSide)
    {
        return accountTSide switch
        {
            AccountingTside.TSIDE_ASSET => TSideNames.Asset,
            AccountingTside.TSIDE_LIABILITY => TSideNames.Liability,
            AccountingTside.TSIDE_UNKNOWN => TSideNames.Unknown,
            _ => throw new UnexpectedTSideException(accountTSide.ToString())
        };
    }

    public static string GetTSideName(this V2accountsTSide accountTSide)
    {
        return accountTSide switch
        {
            V2accountsTSide.T_SIDE_ASSET => TSideNames.Asset,
            V2accountsTSide.T_SIDE_LIABILITY => TSideNames.Liability,
            V2accountsTSide.T_SIDE_UNKNOWN => TSideNames.Unknown,
            _ => throw new UnexpectedTSideException(accountTSide.ToString())
        };
    }
}