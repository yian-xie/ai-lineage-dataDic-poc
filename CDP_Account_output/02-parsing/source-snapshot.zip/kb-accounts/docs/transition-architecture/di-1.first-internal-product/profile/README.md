# Profile - DI-1 First Internal Product

# Account.Profile.API

## GetAccounts
Gets a list of accounts associated to a partyRoleId



