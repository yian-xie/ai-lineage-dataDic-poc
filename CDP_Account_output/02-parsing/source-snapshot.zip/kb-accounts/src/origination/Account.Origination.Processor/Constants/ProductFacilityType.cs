﻿namespace Account.Origination.Processor.Constants;

public static class ProductFacilityType
{
    public const string Lending = "LENDING";
    public const string Investment = "INVESTMENT";
}