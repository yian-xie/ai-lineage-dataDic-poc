﻿namespace Account.Transaction.Api.CardsClient.Models;

/// <summary>
/// Request object for the Card Transactions API
/// </summary>
public class CardTransactionsRequest
{
    /// <summary>
    /// The access number associated with the card account
    /// </summary>
    public string AccessNumber { get; set; } = string.Empty;

    /// <summary>
    /// The unique identifier for the account card
    /// </summary>
    public string AccountCardId { get; set; } = string.Empty;

    /// <summary>
    /// The start date for the transaction query range in yyyy-MM-dd format. Optional.
    /// </summary>
    public string? FromDate { get; set; }

    /// <summary>
    /// The end date for the transaction query range in yyyy-MM-dd format. Optional.
    /// </summary>
    public string? ToDate { get; set; }
}