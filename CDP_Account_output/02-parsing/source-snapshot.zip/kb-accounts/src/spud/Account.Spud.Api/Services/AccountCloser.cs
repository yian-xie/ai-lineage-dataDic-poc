﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Account.Spud.Api.Exceptions;

using Kb.TMV.Client;
using Kb.TMV.Client.Actions.CloseAccount.Requests;

namespace Account.Spud.Api.Services
{
    public class AccountCloser : IAccountCloser
    {
        private readonly TimeProvider _timeProvider;
        private readonly ITmvClient _tmvClient;

        public AccountCloser(ITmvClient tmvClient, TimeProvider timeProvider)
        {
            _tmvClient = tmvClient;
            _timeProvider = timeProvider;
        }

        public async Task CloseAccountAsync(string accountId, string? correlationId, CancellationToken cancellationToken)
        {
            var closeAccountRequest = CreateCloseAccountRequest(accountId, correlationId);
            var result = await _tmvClient.CloseAccountAsync(closeAccountRequest, cancellationToken);

            if (!result.IsSuccess)
            {
                var error = result.Failure.Errors[0];
                throw new CloseAccountException(error.Code, error.Message);
            }
        }

        private CloseAccountRequest CreateCloseAccountRequest(string accountId, string? correlationId = null, string closureReason = "Closing Spud Account")
        {
            return new CloseAccountRequest(accountId, correlationId ?? Guid.NewGuid().ToString(), closureReason);
        }
    }
}