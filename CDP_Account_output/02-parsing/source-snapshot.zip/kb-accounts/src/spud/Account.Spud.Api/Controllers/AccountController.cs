﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Shared.Authorisation.Constants.OPA;
using Account.Shared.Authorisation.OPA;
using Account.Spud.Api.Exceptions;
using Account.Spud.Api.Services;

using Kb.TMV.Client.Actions.CloseAccount.Constants;

using Microsoft.AspNetCore.Mvc;

using SpudService = Api.Shared.Services.Rest.Kiwibank.V1.Spud;

namespace Account.Spud.Api.Controllers;

[ApiController]
public class AccountController(IAccountOpening accountOpening, IAccountCloser accountCloser)
    : SpudService.SpudControllerBase
{
    [OpaStaffAuthorise(PolicyPath = PolicyPaths.AccountAssert,
        Action = Actions.AccountEdit)]
    public override async Task<ActionResult<SpudService.OpenAccountResponse>> OpenAccount(
        string authorization,
        SpudService.OpenAccountRequest request,
        CancellationToken cancellationToken = new())
    {
        var accountId = "spud-" + Guid.NewGuid().ToString().Substring(9);

        var response = await accountOpening.OpenAccountAsync(accountId, cancellationToken);

        return response;
    }

    [OpaStaffAuthorise(PolicyPath = PolicyPaths.AccountAssert,
        Action = Actions.AccountEdit)]
    public override async Task<IActionResult> CloseAccount(
        string authorization,
        string accountId,
        CancellationToken cancellationToken = new())
    {
        try
        {
            var correlationId = HttpContext.Request.Headers["x-correlation-id"].FirstOrDefault();
            await accountCloser.CloseAccountAsync(accountId, correlationId, cancellationToken);
            return Ok();
        }
        catch (CloseAccountException ex)
        {
            // TMV Client can return lots of different error codes.
            // Not worth mapping them all ... just map account not exist to 404
            // and let anything else be reported as a 500 ... it will contain the
            // error details.
            //
            return ex.Code == CloseAccountConstants.ErrorCode.AccountNotExist
                ? NotFound(ex.Message)
                : Problem(ex.Message);
        }
    }
}