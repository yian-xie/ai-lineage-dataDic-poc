﻿using System;

using Account.Shared.Authorisation;
using Account.Shared.Constants;
using Account.Transaction.Api.Configurations;
using Account.Transaction.Api.Queries.Types;

using HotChocolate;
using HotChocolate.Language;
using HotChocolate.Resolvers;

namespace Account.Transaction.Api.Queries.Context;

/// <summary>
/// Process the HTTP context in transactionV2 query before the account authorisation middleware is executed.
/// </summary>
/// <param name="transactionApiSettings"><see cref="IMiddlewareContext"/></param>
public class PreAccountMiddlewareInitializer(TransactionApiSettings transactionApiSettings) : IPreAccountMiddlewareInitializer
{
    /// <summary>
    /// If it is a transactionV2 query, extract the accountId from the query parameters, determine the transaction type based on the accountId prefix.
    /// Store the transaction type and the original accountId (i.e. no prefix) in the context data dictionary.
    /// </summary>
    /// <param name="context"></param>
    public void PreProcess(IMiddlewareContext context)
    {
        var accountId = ExtractAccountId(context);
        HttpContextDataConstants.TransactionType transactionType;
        string prefix;

        if (accountId.StartsWith(transactionApiSettings.CreditCardAccountIdPrefix))
        {
            transactionType = HttpContextDataConstants.TransactionType.CreditCard;
            prefix = transactionApiSettings.CreditCardAccountIdPrefix;
        }
        else if (accountId.StartsWith(transactionApiSettings.TmvAccountIdPrefix))
        {
            transactionType = HttpContextDataConstants.TransactionType.Tmv;
            prefix = transactionApiSettings.TmvAccountIdPrefix;
        }
        else
        {
            transactionType = HttpContextDataConstants.TransactionType.Unknown;
            prefix = string.Empty;
        }

        context.SetLocalState<HttpContextDataConstants.TransactionType?>(HttpContextDataConstants.TransactionTypeKey, transactionType);
        context.SetLocalState<string?>(HttpContextDataConstants.AccountIdKey, accountId[prefix.Length..]);
    }

    /// <summary>
    /// Extract account Id from the given <see cref="IMiddlewareContext"/>.
    /// Only interested in the `transactionsV2` query.
    /// </summary>
    /// <param name="middlewareContext"><see cref="IMiddlewareContext"/></param>
    /// <returns>Account Id</returns>
    /// <exception cref="GraphQLException">
    /// Throw GraphQLException if the given context has no GraphQL query.
    /// Throw GraphQLException if the query name is not transactionV2.
    /// Throw GraphQLException if it is failed to retrieve accountId from the query parameters for the authorisation check.
    /// </exception>
    private static string ExtractAccountId(IMiddlewareContext middlewareContext)
    {
        var isQuery = middlewareContext.Operation.Type == OperationType.Query;
        var queryName = middlewareContext.Selection.Field.Name;

        if (!isQuery)
        {
            throw new GraphQLException(
                "The given context has no GraphQL query.");
        }

        if (!nameof(AccountTransactionQuery.TransactionsV2)
                .Equals(queryName, StringComparison.InvariantCultureIgnoreCase))
        {
            throw new GraphQLException(
                $"Expecting the query name is `{nameof(AccountTransactionQuery.TransactionsV2)}`, but `{queryName}`.");
        }

        foreach (var argument in middlewareContext.Selection.Field.Arguments)
        {
            var argumentValue = middlewareContext.ArgumentValue<object>(argument.Name);

            if (argumentValue.GetType() == typeof(AccountTransactionQueryParams))
            {
                return ((AccountTransactionQueryParams)argumentValue).AccountId;
            }
        }

        throw new GraphQLException(
            $"Fail to retrieve accountId from the {middlewareContext.Selection.Field.Name} query parameters for the authorisation check.");
    }
}