﻿using System.Threading.Tasks;

using Enterprise.Shared.Application.WebHostService;

using Microsoft.Extensions.Hosting;

namespace Account.Profile.Api
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class Program : WebHostServiceBase<Program>
    {
        public static async Task Main(string[] args)
        {
            await CreateHostBuilder(args).Build().RunWithGraphQLCommandsAsync(args);
        }

        /// <summary>
        ///     Note: Remember not to change the signature of the below method or removing it.
        ///     The WebApplicationFactory in our integration test uses reflection and look for this
        ///     method with this exact signature.
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return createWebHostBuilder<Startup>(args);
        }
    }
}