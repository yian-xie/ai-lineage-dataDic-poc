﻿#nullable enable

using System;

using Account.Profile.Shared.Entities;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountProfile;

namespace Account.Profile.Processor.Publishers;

/// <summary>
///     Represents an interface for building AccountProfileEvent.
/// </summary>
public interface IAccountProfileEventBuilder
{
    /// <summary>
    ///     Build AccountProfileEvent.
    /// </summary>
    /// <param name="accountProfile">
    ///     <see cref="AccountProfile" />
    /// </param>
    /// <param name="metadataType">
    ///     <see cref="MetadataType" />
    /// </param>
    /// <param name="accountStatusTimestamp">The account status timestamp</param>
    /// <param name="correlationId">The correlation ID</param>
    /// <returns>
    ///     <see cref="AccountProfileEvent" />
    /// </returns>
    AccountProfileEvent BuildEvent(
        AccountProfile accountProfile,
        MetadataType metadataType,
        DateTimeOffset accountStatusTimestamp,
        Guid? correlationId = null);
}