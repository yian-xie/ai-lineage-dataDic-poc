﻿using Account.Profile.Shared.Entities;
using Account.Shared.Database;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.ValueGeneration;

namespace Account.Profile.Shared.Infrastructure.EntityConfigurations;

public class AccountRestrictionEntityTypeConfiguration :
    AccountBaseEntityTypeConfiguration<AccountRestriction, AccountProfileDbContext>
{
    protected override string TableName => "account_restriction";

    protected override void ConfigureTable(EntityTypeBuilder<AccountRestriction> builder)
    {
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id)
            .ValueGeneratedOnAdd()
            .IsRequired();
        builder.Property(x => x.CreatedAt)
            .ValueGeneratedOnAdd()
            .HasDefaultValueSql("CURRENT_TIMESTAMP");
        builder.Property(x => x.ModifiedAt)
            .ValueGeneratedNever();
        builder.Property(x => x.EventId).IsRequired();
        builder.Property(x => x.RestrictionSetId).IsRequired();
        builder.Property(x => x.ProcessingAt).IsRequired();
        builder.Property(x => x.RestrictionSetEventPayload);

        builder.HasIndex(x => x.EventId).IsUnique();
        builder.HasIndex(x => new { x.EffectiveAt, x.ChangeId, x.ProcessingAt }).IsDescending();
    }
}