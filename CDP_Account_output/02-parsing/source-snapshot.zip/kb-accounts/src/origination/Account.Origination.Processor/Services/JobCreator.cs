﻿using System.Diagnostics;

using Account.Origination.Shared;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Repositories;

using Enterprise.Shared.Database;
using Enterprise.Shared.Telemetry;

namespace Account.Origination.Processor.Services;

public class JobCreator(
    IRepositoryFactory repositoryFactory,
    IDbTransactionBuilder dbTransactionBuilder,
    ILogger<JobCreator> logger,
    IActivityAccessor activityAccessor,
    IActivityPropagator<IPropagatorEntity> activityPropagator)
    : IJobCreator
{
    public async Task<AccountOpening?> CreateAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken)
    {
        var activity = StartActivity("start account_opening", accountOpening);

        using (activity)
        {
            return await CreateInternalAsync(accountOpening, cancellationToken);
        }
    }

    private async Task<AccountOpening?> CreateInternalAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken)
    {
        try
        {
            await using var transaction =
                dbTransactionBuilder.BeginTransaction(repositoryFactory.UnitOfWork);

            var existingAccountOpening =
                await repositoryFactory.AccountOpeningRepository.GetJobAsync(
                    accountOpening.EventId,
                    cancellationToken);

            if (existingAccountOpening != null)
            {
                logger.LogWarning(
                    "Received ProductApplicationEvent {eventId} is already exists.",
                    accountOpening.EventId);

                return existingAccountOpening;
            }

            activityPropagator.PropagateActivity(accountOpening);

            repositoryFactory.AccountOpeningRepository.Add(accountOpening);

            await repositoryFactory.UnitOfWork.SaveChangesAsync(cancellationToken);

            await transaction.CommitAsync(cancellationToken);

            logger.LogInformation(
                "The AccountOpening job {eventId} with account id {accountId} is created.",
                accountOpening.EventId,
                accountOpening.AccountId);

            return accountOpening;
        }
        catch (Exception ex)
        {
            logger.LogError(ex,
                "Failed to create AccountOpening for ProductApplicationEvent {eventId}.",
                accountOpening.EventId);

            throw;
        }
    }

    /// <summary>
    ///     Start activity.
    /// </summary>
    /// <param name="activityName">Activity name</param>
    /// <param name="accountOpening">
    ///     <see cref="AccountOpening" />
    /// </param>
    /// <returns>
    ///     <see cref="Activity" />
    /// </returns>
    private Activity? StartActivity(string activityName, AccountOpening accountOpening)
    {
        var activitySource = activityAccessor.GetActivitySource(Telemetry.ActivitySourceName);

        return activitySource.StartActivity(
            activityName,
            tags: new KeyValuePair<string, object?>[] {
                new(nameof(AccountOpening), accountOpening.EventId)
            });
    }
}