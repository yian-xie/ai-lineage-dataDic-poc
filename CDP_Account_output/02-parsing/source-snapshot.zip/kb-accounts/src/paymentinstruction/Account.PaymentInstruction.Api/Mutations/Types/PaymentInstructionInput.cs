﻿using Account.PaymentInstruction.Api.Queries.Types;

using HotChocolate;

namespace Account.PaymentInstruction.Api.Mutations.Types;

[GraphQLName("PaymentInstructionInput")]
public class PaymentInstructionInput
{
    [GraphQLName("lifecycle")] public Lifecycle Lifecycle { get; set; }

    [GraphQLName("transactionId")] public string TransactionId { get; set; }

    [GraphQLName("type")] public TransactionType Type { get; set; }

    [GraphQLName("transfer")] public Transfer Transfer { get; set; }
}