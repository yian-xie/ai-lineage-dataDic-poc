﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Account.Shared;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountSpudProductApplication;
using Api.Shared.Services.Rest.Kiwibank.V1.Spud;

using Enterprise.Shared.Kafka.Produce;

using Microsoft.Extensions.Options;

using Data = Api.Shared.Clients.Events.Kiwibank.V1.AccountSpudProductApplication.Data;
using Metadata = Api.Shared.Clients.Events.Kiwibank.V1.AccountSpudProductApplication.Metadata;
using MetadataType =
    Api.Shared.Clients.Events.Kiwibank.V1.AccountSpudProductApplication.MetadataType;

namespace Account.Spud.Api.Services;

public class SpudAccountOpening(
    IKafkaEventPublisher<SpudProductApplicationEvent> publisher,
    TimeProvider timeProvider,
    IOptions<SpudAccountSettings> spudAccountSettings)
    : IAccountOpening
{
    private readonly string _partyRoleId = spudAccountSettings.Value.PartyRoleId;
    private readonly int _validUntilTimeInSecond = spudAccountSettings.Value.ValidUntilTimeInSecond;

    /// <summary>
    ///     Create an origination event account and return the expected account ID in the additional properties
    /// </summary>
    /// <param name="accountId"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    public async Task<OpenAccountResponse> OpenAccountAsync(
        string accountId,
        CancellationToken cancellationToken)
    {
        var spudProductApplicationEvent = CreateProductApplicationEvent(accountId);
        await publisher.PublishAsync(spudProductApplicationEvent, cancellationToken, accountId);

        var openAccountResponse = new OpenAccountResponse
        {
            AdditionalProperties = {
                [AdditionalPropertyKeys.RequestedAccountId] =
                    spudProductApplicationEvent.Data.AfterState.AdditionalProperties[
                        AdditionalPropertyKeys.RequestedAccountId]
            }
        };

        return openAccountResponse;
    }

    private SpudProductApplicationEvent CreateProductApplicationEvent(string accountId)
    {
        var currentTime = timeProvider.GetUtcNow();

        return new SpudProductApplicationEvent
        {
            Metadata = new Metadata
            {
                Id = Guid.NewGuid(),
                Source = "ACCOUNT.SPUD.API",
                Type = MetadataType.ProductOfferAccepted,
                Subject = string.Empty,
                Time = currentTime,
                CorrelationId = Guid.Empty,
                Actor = string.Empty
            },
            Data = new Data
            {
                AfterState = new SpudProductApplication
                {
                    PartyRoleId = _partyRoleId,
                    // As a valid time to create and open SPUD account so it does not go into infinite loop.
                    ValidUntil = currentTime.AddSeconds(_validUntilTimeInSecond),
                    AdditionalProperties = new Dictionary<string, object>
                    {
                        [AdditionalPropertyKeys.RequestedAccountId] = accountId
                    }
                }
            }
        };
    }
}