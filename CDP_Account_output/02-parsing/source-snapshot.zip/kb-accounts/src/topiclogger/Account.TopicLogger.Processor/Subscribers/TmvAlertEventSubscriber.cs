﻿using Account.Shared.Services;
using Account.TopicLogger.Processor.Configurations;

using Api.Shared.Clients.Rest.SumoLogic;

using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.TopicLogger.Processor.Subscribers;

public class TmvAlertEventSubscriber(
    ISumoLogicClientHelper sumoLogicClientHelper,
    SumoLogicSettings sumoLogicSettings,
    IConfiguration configuration)
    : IIncomingEventSubscriber<AlertTopicEmptyEvent>
{
    public async Task<EventSubscriberResult> HandleAsync(
        IncomingEventContext context,
        AlertTopicEmptyEvent @event,
        CancellationToken cancellationToken)
    {
        var result = context.ConsumeResult;
        var monitoringApiToken = configuration[ExtraSettings.SumoLogicMonitoringApiToken];

        await sumoLogicClientHelper.IngestLogAsync(
            result.Message.Value,
            sumoLogicSettings.SourceCategory + SumoLogicSourceCategories.MonitoringLogs,
            sumoLogicSettings.SourceName + SumoLogicSourceNames.AlertTopic,
            monitoringApiToken,
            cancellationToken);

        return EventSubscriberResults.Success;
    }
}