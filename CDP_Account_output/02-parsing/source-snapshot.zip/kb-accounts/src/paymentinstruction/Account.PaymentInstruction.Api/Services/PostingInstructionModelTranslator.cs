﻿using Account.PaymentInstruction.Api.Extensions;

using Api.Shared.Clients.Events.ThoughtMachine.V1.PostingInstructionBatchRequest;

using PaymentInstructionRequestInput =
    Account.PaymentInstruction.Api.Mutations.Types.PaymentInstructionRequestInput;

namespace Account.PaymentInstruction.Api.Services;

using Input = PaymentInstructionRequestInput;
using Request = PostingInstructionBatchRequest;

/// <summary>
///     Translator that translates model from <see cref="Mutations.Types.PaymentInstructionInput" /> to
///     <see cref="PostingInstructionBatchRequest" />
/// </summary>
public class PostingInstructionModelTranslator : IPostingInstructionModelTranslator
{
    /// <summary>
    ///     Translates model from <see cref="Mutations.Types.PaymentInstructionInput" /> to
    ///     <see cref="PostingInstructionBatchRequest" />
    /// </summary>
    public Request Translate(
        Input input,
        string clientId,
        string clientBatchId)
    {
        var request = new Request
        {
            Request_id = input.RequestId,
            Posting_instruction_batch = {
                Client_id = clientId,
                Client_batch_id = clientBatchId,
                Posting_instructions = input.ToPostingInstructions()
            }
        };

        return request;
    }
}