﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddTmvStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "tmv_status",
                schema: "profile",
                table: "account_profile",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "tmv_status",
                schema: "profile",
                table: "account_profile");
        }
    }
}