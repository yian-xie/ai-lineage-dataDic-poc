﻿
namespace Account.Origination.Public.Interfaces
{
    public interface INameGenerator
    {
        bool IsMatch(Party[] parties);
        string GenerateName(Party[] parties);
    }
}