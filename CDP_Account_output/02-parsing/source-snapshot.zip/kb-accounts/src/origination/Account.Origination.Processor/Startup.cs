﻿using Account.Origination.Processor.Configurations;
using Account.Origination.Processor.Services;
using Account.Origination.Processor.Subscribers;
using Account.Origination.Shared;
using Account.Origination.Shared.Infrastructure;
using Account.Shared;
using Account.Shared.Metrics.Decorator;

using Api.Shared.Clients.Events.Kiwibank.V1.AccountSpudProductApplication;
using Api.Shared.Clients.Events.Kiwibank.V1.LendingProductProposition;

using Enterprise.Shared.Kafka;
using Enterprise.Shared.Kafka.Consume.EventSubscriber;

namespace Account.Origination.Processor;

public class Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    : AccountStartup(configuration, webHostEnvironment, Telemetry.ActivitySourceName)
{
    protected override void AddApplicationServices(IServiceCollection services)
    {
        services.Configure<AccountOriginationProcessorOptions>(
            Configuration.GetSection(nameof(AccountOriginationProcessorOptions)));

        UsePooledDbContext<OriginationDbContext>(services);

        UseKafka(services);

        services
            // Disabling ProductApplicationEventSubscriber while sorting out Confluent Cloud API Keys
            // Ticket AB#374996
            // .AddKafkaReliableEventConsumers<
            //     ProductApplicationEventSubscriber<BitsFlippedIdCreator>, string,
            //     ProductApplicationEvent>(
            //     kafkaSettings)
            .AddKafkaReliableEventConsumers<SpudProductApplicationEventSubscriber, string,
                SpudProductApplicationEvent>(GetKafkaSettings())
            .AddRepositories()
            .AddSingleton<BitsFlippedIdCreator>()
            .AddScoped<IJobCreator, JobCreator>();

        services
            .AddKafkaReliableEventConsumers<ProductPropositionEventSubscriber, string,
                LendingProductPropositionEvent>(GetKafkaSettings());

        services
            .Decorate<IIncomingEventSubscriber<SpudProductApplicationEvent>,
                AccountIncomingEventSubscriberMetricDecorator<SpudProductApplicationEvent>>();

        services
            .Decorate<IIncomingEventSubscriber<LendingProductPropositionEvent>,
                AccountIncomingEventSubscriberMetricDecorator<LendingProductPropositionEvent>>();
    }
}