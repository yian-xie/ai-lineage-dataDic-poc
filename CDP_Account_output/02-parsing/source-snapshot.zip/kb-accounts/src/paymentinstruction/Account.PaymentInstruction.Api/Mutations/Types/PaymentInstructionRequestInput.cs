﻿using HotChocolate;

namespace Account.PaymentInstruction.Api.Mutations.Types;

[GraphQLName("PaymentInstructionRequestInput")]
public class PaymentInstructionRequestInput
{
    [GraphQLName("requestId")] public string RequestId { get; set; }

    [GraphQLName("paymentInstruction")]
    public PaymentInstructionInput PaymentInstruction { get; set; }
}