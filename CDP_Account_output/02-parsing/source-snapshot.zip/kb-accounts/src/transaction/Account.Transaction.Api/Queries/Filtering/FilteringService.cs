﻿using System;
using System.Linq;

using Account.Transaction.Api.Configurations;
using Account.Transaction.Api.Queries.Types;

using AccountTransaction = Account.Transaction.Shared.Entities.AccountTransaction;

namespace Account.Transaction.Api.Queries.Filtering;

/// <summary>
///     Provide filtering functionality for <see cref="AccountTransaction" /> queries.
/// </summary>
/// <param name="timeProvider"></param>
public class FilteringService(
    TimeProvider timeProvider) : IFilteringService
{
    /// <summary>
    ///     Filtering the query based on the <see cref="Types.AccountTransactionQueryParams" />.
    ///     Migration in PaymentInstructionCategory are excluded by default.
    ///     Mandatory fields:
    ///     <see cref="AccountTransactionQueryParams.AccountId" />
    ///     <see cref="AccountTransactionQueryParams.TransactionDateTo" /> is null, use system current time
    ///     Optional fields:
    ///     <see cref="AccountTransactionQueryParams.TransactionDateFrom" />
    ///     <see cref="AccountTransactionQueryParams.CreditDebitIndicator" />
    /// </summary>
    /// <param name="query"><see cref="IQueryable{T}" /> of <see cref="Shared.Entities.AccountTransaction" /></param>
    /// <param name="queryParams">
    ///     <see cref="Types.AccountTransactionQueryParams" />
    /// </param>
    /// <returns><see cref="IQueryable" /> where T is <see cref="AccountTransaction" /></returns>
    public IQueryable<AccountTransaction> ApplyFilter(
        IQueryable<AccountTransaction> query,
        AccountTransactionQueryParams queryParams)
    {
        var filteredQuery = query.Where(x =>
                x.AccountId == queryParams.AccountId)
            .Where(x =>
                x.ValueDateTime <= (queryParams.TransactionDateTo ?? timeProvider.GetUtcNow()))
            .Where(x =>
                x.PaymentInstructionCategory == null ||
                x.PaymentInstructionCategory.ToUpper() != PaymentInstructionCategoryConstants.Migration.ToUpper());

        if (queryParams.TransactionDateFrom.HasValue)
        {
            filteredQuery = filteredQuery.Where(x =>
                x.ValueDateTime >= queryParams.TransactionDateFrom.Value);
        }

        if (queryParams.CreditDebitIndicator.HasValue)
        {
            filteredQuery = filteredQuery.Where(x =>
                x.CreditDebitIndicator == queryParams.CreditDebitIndicator.Value.ToString());
        }

        return filteredQuery;
    }
}