﻿using System;

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAccountRestriction : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "account_restriction",
                schema: "profile",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    event_id = table.Column<string>(type: "text", nullable: false),
                    restriction_set_id = table.Column<string>(type: "text", nullable: false),
                    change_id = table.Column<long>(type: "bigint", nullable: true),
                    effective_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    expiry_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    processing_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    type = table.Column<string>(type: "text", nullable: true),
                    description = table.Column<string>(type: "text", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    restriction_set_event_payload = table.Column<byte[]>(type: "bytea", nullable: true),
                    profile_account_id = table.Column<string>(type: "text", nullable: false),
                    created_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false, defaultValueSql: "CURRENT_TIMESTAMP"),
                    modified_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_account_restriction", x => x.id);
                    table.ForeignKey(
                        name: "fk_account_restriction_account_profile_profile_account_id",
                        column: x => x.profile_account_id,
                        principalSchema: "profile",
                        principalTable: "account_profile",
                        principalColumn: "account_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_account_restriction_effective_at_change_id_processing_at",
                schema: "profile",
                table: "account_restriction",
                columns: new[] { "effective_at", "change_id", "processing_at" },
                descending: new bool[0]);

            migrationBuilder.CreateIndex(
                name: "ix_account_restriction_event_id",
                schema: "profile",
                table: "account_restriction",
                column: "event_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_account_restriction_profile_account_id",
                schema: "profile",
                table: "account_restriction",
                column: "profile_account_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "account_restriction",
                schema: "profile");
        }
    }
}