﻿using System.Text.Json;
using System.Text.Json.Serialization;

using Account.Domain.Directory.Service.WebApiClient;
using Account.Origination.Job.Configurations;
using Account.Origination.Job.Constants;
using Account.Origination.Job.Extension;
using Account.Origination.Job.Infrastructure;
using Account.Origination.Job.TMVClient.SemanticVersion;
using Account.Origination.Public;
using Account.Origination.Public.Interfaces;
using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure.Exceptions;
using Account.Shared.FeatureFlags;

using Api.Shared.Clients.Rest.ThoughtMachine.V2.OnlineCallAccount;
using Api.Shared.Clients.Rest.ThoughtMachine.V5.Core;

using Kb.TMV.Client;
using Kb.TMV.Client.Actions.CreateCustomer.Requests;
using Kb.TMV.Client.Actions.CreateCustomer.Results;
using Kb.TMV.Client.Actions.CreateSpudAccount.Requests;
using Kb.TMV.Client.Actions.CreateSpudAccount.Results;

namespace Account.Origination.Job.Services;

public class SpudAccountAction(
    ICoreAPIAccountsClient coreApiAccountsClient,
    ITmvClient tmvClient,
    IOnlineCallClient onlineCallClient,
    ISemanticVersionResolver semanticVersionResolver,
    ILogger<TmvAccountAction> logger,
    TmvProductsSettings tmvProductsSettings,
    IFeatureService featureService)
    : TmvAccountAction(Shared.Services.Product.Spud, coreApiAccountsClient, onlineCallClient, semanticVersionResolver, logger, featureService, tmvClient)
{
    public override async Task<V1accountsAccount> CreateAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken)
    {
        try
        {
            var useTMVLibrary = featureService.IsFeatureEnabled(FeatureFlag.UseTmvRestApiClient, defaultValue: false);

            if (useTMVLibrary)
            {
                CreateSpudAccountRequest req = new CreateSpudAccountRequest(accountOpening.AccountId, accountOpening.CorrelationId.ToString(), accountOpening.EventId.ToString(), accountOpening.PartyRoleIds, tmvProductsSettings.SpudProductVersion, accountOpening.AccountId);
                CreateSpudAccountActionResult result = await _tmvClient.CreateSpudAccountAsync(req, CancellationToken.None);

                if (result.IsSuccess)
                {
                    var resultStatus = EnumConverter.ToEnum<V1accounts_commonAccountStatus>(result.Success.AccountStatus, V1accounts_commonAccountStatus.ACCOUNT_STATUS_UNKNOWN);

                    if ((resultStatus is not (V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING or V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN)))
                    {
                        throw new AccountOriginationException(
                            $"Expecting the returned TMV account {result.Success.AccountId} status is {V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING} or {V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN} after creating account but the status is {resultStatus}.");
                    }

                    Logger.LogInformation("Created TMV account {accountId}.", accountOpening.AccountId);

                    return new V1accountsAccount
                    {
                        Id = result.Success.AccountId,
                        Status = resultStatus,
                        Stakeholder_ids = accountOpening.PartyRoleIds,
                        Product_version_id = tmvProductsSettings.SpudProductVersion,
                    };
                }
                else
                {
                    logger.LogError("Failed to create TMV Spud account. CorrelationId: {CorrelationId}, EventId: {EventId}, Errors: {Errors}", accountOpening.CorrelationId, accountOpening.EventId, result.Failure.Errors);
                    throw new AccountOriginationException($"Failed to create TMV Spud account. Errors: {JsonSerializer.Serialize(result.Failure.Errors)}");
                }
            }
            else
            {
                var tmvAccount = await CreateTmvAccountAsync(accountOpening, cancellationToken);

                if (tmvAccount.Status is not (V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING
                    or V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN))
                {
                    throw new AccountOriginationException(
                        $"Expecting the returned TMV account {tmvAccount.Id} status is {V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING} or {V1accounts_commonAccountStatus.ACCOUNT_STATUS_OPEN} after creating account but the status is {tmvAccount.Status}.");
                }

                Logger.LogInformation("Created TMV account {accountId}.", accountOpening.AccountId);

                return tmvAccount;
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(
                ex,
                "Failed to create TMV account {accountId} for ProductApplicationEvent {eventId}.",
                accountOpening.AccountId, accountOpening.EventId);

            throw;
        }
    }

    public override Task<CreateOnlineCallAccountResponse> CreateV2Async(
        AccountOpening accountOpening,
        ICollection<PartyResultDto> partyResults,
        CancellationToken cancellationToken)
    {
        throw new NotSupportedException(
            $"{GetType().Name} does not support CreateV2Async. Use CreateAsync instead.");
    }

    private async Task<V1accountsAccount> CreateTmvAccountAsync(
        AccountOpening accountOpening,
        CancellationToken cancellationToken)
    {
        var request = CreateAccountsCreateAccountRequest(accountOpening);

        var tmvAccount =
            await CoreApiAccountsClient.CreateAccountAsync(request, cancellationToken);

        return tmvAccount;
    }

    private V1accountsCreateAccountRequest CreateAccountsCreateAccountRequest(
        AccountOpening accountOpening)
    {
        return new V1accountsCreateAccountRequest
        {
            Request_id = accountOpening.EventId.ToString("D"),
            Account = new V1accountsAccount
            {
                Id = accountOpening.AccountId,
                Status = V1accounts_commonAccountStatus.ACCOUNT_STATUS_PENDING,
                Stakeholder_ids = accountOpening.PartyRoleIds,
                Product_version_id = tmvProductsSettings.SpudProductVersion,
                Details = new Dictionary<string, string>
                    { { "accountName", accountOpening.AccountId } }
            }
        };
    }
}