﻿using Account.Origination.Shared.Entities;
using Account.Origination.Shared.Infrastructure.EntityConfigurations;
using Account.Shared.Constants;
using Account.Shared.Database;

using Enterprise.Shared.Database.Configurations;

using Microsoft.EntityFrameworkCore;

namespace Account.Origination.Shared.Infrastructure;

public class OriginationDbContext(
    DbContextOptions<OriginationDbContext> options,
    CustomDbContextOptions customDbContextOptions)
    : AccountBaseDbContext<OriginationDbContext>(options, customDbContextOptions),
        IDbContextSchemaName
{
    public DbSet<AccountOpening> AccountOpenings { get; set; }

    public static string SchemaName()
    {
        return DatabaseSchemaName.Origination;
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfiguration(new AccountOpeningEntityTypeConfiguration());
    }
}