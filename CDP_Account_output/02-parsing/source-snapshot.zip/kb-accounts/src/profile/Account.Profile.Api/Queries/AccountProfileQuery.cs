﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Account.Profile.Api.Queries.Types;
using Account.Profile.Api.Services;
using Account.Shared.Authorisation;
using Account.Shared.Constants;

using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;

namespace Account.Profile.Api.Queries;

public class AccountProfileQuery
{
    /// <summary>
    ///     Query multiple TMV account profiles based on <see cref="accountIds"/>
    /// </summary>
    /// <param name="accountIds"></param>
    /// <param name="accountProfileAction"></param>
    /// <param name="resolverContext"></param>
    /// <param name="auditLogDataProvider"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    [Account]
    [UseResolverScope]
    public async Task<IReadOnlyCollection<AccountProfile__AccountProfile>>
        TmvAccountProfilesV2Async(
            [GraphQLName("accountIds")] IReadOnlyCollection<string> accountIds,
            [Service] IAccountProfileAction accountProfileAction,
            IResolverContext resolverContext,
            IProfileAuditLogDataProvider auditLogDataProvider,
            CancellationToken cancellationToken)
    {
        return accountIds.Any()
            ? await accountProfileAction.GetAccountProfilesByAccountIdsAsync(
                accountIds,
                auditLogDataProvider,
                IsStaffUser(resolverContext),
                cancellationToken)
            : [];
    }

    /// <summary>
    ///     Query single TMV account profile based on <see cref="accountId"/>
    /// </summary>
    /// <param name="accountId"></param>
    /// <param name="accountProfileAction"></param>
    /// <param name="resolverContext"></param>
    /// <param name="auditLogDataProvider"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    [Account]
    [UseResolverScope]
    public async Task<AccountProfile__AccountProfile?> TmvAccountProfileAsync(
        [GraphQLName("accountId")] string accountId,
        [Service] IAccountProfileAction accountProfileAction,
        IResolverContext resolverContext,
        IProfileAuditLogDataProvider auditLogDataProvider,
        CancellationToken cancellationToken)
    {
        var accountProfile =
            await accountProfileAction.GetAccountProfileAsync(
                accountId,
                auditLogDataProvider,
                IsStaffUser(resolverContext),
                cancellationToken);

        return accountProfile;
    }

    private bool IsStaffUser(IResolverContext resolverContext)
    {
        return resolverContext.LocalContextData.TryGetValue(LocalStateConstants.IsStaffKey,
                out var value) &&
            value is true;
    }
}