﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Account.Profile.Shared.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddTmvStatusConversion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                UPDATE profile.account_profile
                SET
                    tmv_status = status,
                    status = CASE
                        WHEN status = 'ACCOUNT_STATUS_CANCELLED' THEN 'Cancelled'
                        WHEN status = 'ACCOUNT_STATUS_CLOSED' THEN 'Closed'
                        WHEN status = 'ACCOUNT_STATUS_CLOSING' THEN 'Closing'
                        WHEN status = 'ACCOUNT_STATUS_PENDING' THEN 'Pending'
                        WHEN status = 'ACCOUNT_STATUS_OPEN' THEN CASE
                            WHEN account_freeze_details_restriction_set_id is not null THEN 'Frozen'
                            ELSE 'Opened'
                        END
                        WHEN status = 'ACCOUNT_STATUS_OPENING' THEN 'Opening'
                        WHEN status = 'ACCOUNT_STATUS_PENDING_OPENING' THEN 'PendingOpening'
                        WHEN status = 'ACCOUNT_STATUS_PENDING_CLOSURE' THEN 'PendingClosure'
                        ELSE 'Unknown'
                    END
                WHERE status is not null
                  AND tmv_status is null;
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                UPDATE profile.account_profile
                SET
                    status = tmv_status
                WHERE tmv_status is not null");
        }
    }
}