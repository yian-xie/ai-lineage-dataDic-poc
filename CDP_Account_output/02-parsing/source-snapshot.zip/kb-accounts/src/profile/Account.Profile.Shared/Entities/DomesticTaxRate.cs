﻿namespace Account.Profile.Shared.Entities;

public class DomesticTaxRate
{
    /// <summary>
    ///     Domestic tax type
    /// </summary>
    public string DomesticTaxType { get; set; }

    /// <summary>
    ///     Domestic tax rate value
    /// </summary>
    public string RateValue { get; set; }

    /// <summary>
    ///     Domestic tax rate country alpha 3 code
    /// </summary>
    public string CountryAlpha3Code { get; set; }
}